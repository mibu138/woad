#!/usr/bin/python
import argparse
from pathlib import Path
import paths
import subprocess as sp
import sys
import os
from enum import Enum


class Kind(Enum):
    DEMO = 0
    BINARY = 1


arg_to_kind = {
        'demo': Kind.DEMO,
        'bin': Kind.BINARY,
        }

kind_to_name = {
        Kind.DEMO: 'demo',
        Kind.BINARY: 'binary',
        }

kind_to_root_dir = {
        Kind.DEMO: paths.demos,
        Kind.BINARY: paths.bins,
        }


def main_text(word):
    s = f"""\
#include <pome/pome.h>

int main(int argc, char **argv) {{
    return 0;
}}\n\
"""
    return s


def cmake_text(name, kind):
    tname = kind_to_name[kind]
    s = f"""\
pome_add_{tname}(
    {name}
    SOURCES main.cpp
)\n\
"""
    return s


def add(name, kind, greetee='bitches'):
    root_dir = kind_to_root_dir[kind]
    dr = kind_to_root_dir[kind] / name
    dr.mkdir()
    main = dr / 'main.cpp'
    cmake = dr / 'CMakeLists.txt'
    main.write_text(main_text(greetee))
    cmake.write_text(cmake_text(name, kind))

    line_to_add = f'add_subdirectory({name})'
    with (root_dir / 'CMakeLists.txt').open('a+') as f:
        lines = f.readlines()
        found = False
        for line in lines:
            if line_to_add in line:
                print(f"Line '{line_to_add}' already exists in {f.name}")
                found = True
                break
        if not found:
            f.write(f'add_subdirectory({name})\n')
        else:
            print(f"Line {line_to_add} already exists in CMakeLists.txt")


def main(args):
    parser = argparse.ArgumentParser()
    parser.add_argument('type', choices=['demo', 'bin'])
    parser.add_argument('name')

    args = parser.parse_args(args)

    kind = arg_to_kind[args.type]
    add(args.name, kind)


if __name__ == '__main__':
    main(sys.argv)




