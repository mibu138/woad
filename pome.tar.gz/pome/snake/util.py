import paths
import subprocess as sp


def ninja_build_command(argstr):
    args = argstr.split()
    cmd = ["ninja", "-C", str(paths.build)] + args
    r = sp.run(cmd, text=True, capture_output=True)
    r.check_returncode()
    return r.stdout


def list_ninja_targets():
    return ninja_build_command("-t targets")


def list_ninja_commands(tgt):
    l = ninja_build_command("-t commands " + tgt).split("\n")
    l = list(filter(lambda elem: len(elem) > 0, l))
    return l


def show_reflection_command(tgt):
    l = list_ninja_commands(tgt)
    for e in l:
        if "build/tools/reflect " in e:
            return e
    return None
