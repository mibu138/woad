#!/usr/bin/python
import argparse
import os
import subprocess as sp
import build, add, compile

subprograms = {
        'build': build,
        'add': add,
        'compile': compile,
        }


def main():
    parser = argparse.ArgumentParser(
            prog="snake",
            description="Jack-knife for project management",
            add_help=False,
            )
    parser.add_argument("subprogram", choices=subprograms.keys())

    args = parser.parse_known_args()
    extra_args = args[1]
    args = args[0]

    subprograms[args.subprogram].main(extra_args)


if __name__ == "__main__":
    main()
