#!/usr/bin/python
import argparse
import os, sys
import shutil
from pathlib import Path
import paths
import util
import subprocess as sp

DEPS = 0
MAIN = 1

CLEAN = 0
CONFIGURE = 1
BUILD = 2
BLAST = 3

MAIN_SRC = paths.root
MAIN_BUILD = paths.build
DEPS_BUILD = paths.deps_build
DEPS_SRCS = paths.deps_src


def run(cmd):
    print(cmd)
    r = sp.run(cmd)
    if r.returncode != 0:
        print("command failed.")
        sys.exit(r.returncode)


def configure(src_dir, build_dir, build_type, args):
    cmd = ["cmake", "-S", src_dir, "-B", build_dir, "-GNinja"]
    cmd.append("-DCMAKE_BUILD_TYPE=" + build_type)
    run(cmd)


def build(build_dir, target, args):
    cmd = ["cmake", "--build", build_dir, "--target", target] + args
    run(cmd)


def clean(build_dir):
    cmd = ["cmake", "--build", build_dir, "--target", "clean"]
    run(cmd)


def blast(build_dir):
    assert build_dir.parent == MAIN_SRC
    if not build_dir.exists():
        return
    print(f"Blasting {build_dir}")
    shutil.rmtree(build_dir)


def main(args):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--buildtype", default="Debug", choices=["Debug", "Release"]
    )
    parser.add_argument(
        "target",
        help="Target to act one",
        nargs="?",
        default="all",
    )
    parser.add_argument(
        "--baseline",
        help="Baseline to act on",
        nargs="?",
        default="main",
        choices=["deps", "main", "all"],
    )
    parser.add_argument(
        "--clean", help="Clean build directory", action="store_true"
    )
    parser.add_argument(
        "--test", help="Run tests", action="store_true"
    )
    parser.add_argument("--blast", help="Blows away build", action="store_true")
    parser.add_argument("--build", help="Build", action="store_true")
    parser.add_argument(
        "--lstargets", help="List ninja targets", action="store_true"
    )
    parser.add_argument(
        "--lscommands",
        nargs=1,
        dest="ninjatarget",
        help="List ninja commands for target. Target must come"
        " from output of --lstargets",
        action="store",
    )
    parser.add_argument(
        "--reflectcmd",
        nargs=1,
        dest="refltarget",
        help="Show the reflection command for the target if it exists",
        action="store",
    )
    parser.add_argument("-c", "--configure", action="store_true")

    args = parser.parse_known_args(args)
    extra_args = args[1]
    args = args[0]

    tasks = set()
    baselines = set()

    if args.lstargets:
        r = util.list_ninja_targets()
        print(r)
        return

    if args.ninjatarget:
        r = util.list_ninja_commands(args.ninjatarget[0])
        print(r)
        return

    if args.refltarget:
        r = util.show_reflection_command(args.refltarget[0])
        print(r)
        return

    if args.baseline == "main":
        baselines.add(MAIN)
    elif args.baseline == "deps":
        baselines.add(DEPS)
    else:
        baselines.add(MAIN)
        baselines.add(DEPS)

    if args.configure:
        tasks.add(CONFIGURE)

    if args.clean:
        tasks.add(CLEAN)

    if args.build:
        tasks.add(BUILD)

    if args.blast:
        tasks.add(BLAST)

    if not args.clean and not args.configure and not args.blast:
        tasks.add(BUILD)

    tasks = sorted(tasks)
    baselines = sorted(baselines)

    dirs = {
        MAIN: (MAIN_SRC, MAIN_BUILD),
        DEPS: (DEPS_SRCS, DEPS_BUILD),
    }

    for baseline in baselines:
        src_dir, build_dir = dirs[baseline]
        build_type = args.buildtype
        if baseline == DEPS:
            build_type = "Debug"
        if BLAST in tasks:
            blast(build_dir)
        elif CLEAN in tasks:
            clean(build_dir)
        if CONFIGURE in tasks:
            configure(src_dir, build_dir, build_type, extra_args)
        if BUILD in tasks:
            if not build_dir.exists():
                configure(src_dir, build_dir, build_type, [])
            build(build_dir, args.target, extra_args)


if __name__ == "__main__":
    main(sys.argv)


