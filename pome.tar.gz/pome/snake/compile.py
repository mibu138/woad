#!/usr/bin/python
import argparse
import paths
from pathlib import Path
from itertools import chain
import os, sys
import subprocess as sp


project_root = Path(os.getenv("S"))
build_root = Path(os.getenv("B"))
ext_build_root = Path(os.getenv("XB"))


VERBOSE = False


def build_target(
    name,
    path,
    output,
    crate_type,
    debug=False,
    static_link_libs=[],
    extern_crates=[],
    link_dirs=[],
    native_link_dirs=[],
    extra_flags=[],
):
    return {
        "rootfile": path,
        "name": name,
        "output": output,
        "extern_crates": extern_crates,
        "link_dirs": link_dirs,
        "native_link_dirs": native_link_dirs,
        "static_link_libs": static_link_libs,
        "extra_flags": extra_flags,
        "crate_type": crate_type,
        "edition": "2021",
        "debug": debug,
    }


def build_num():
    root = project_root / "external" / "crates" / "num" / "src" / "lib.rs"
    return build_target(
        "num", root, ext_build_root / "rust" / "release" / "libnum.rlib", "rlib"
    )


def build_intrusive():
    root = project_root / "external" / "crates" / "intrusive-rs" / "src" / "lib.rs"
    return build_target(
        "intrusive", root, ext_build_root / "rust" / "release" / "libintrusive_collections.rlib", "rlib"
    )


def build_pome():
    num = build_num()
    intrusive = build_intrusive()
    pome_root = Path(os.getenv("RPOME")) / "lib.rs"
    output = Path(os.getenv("B")) / "rust" / "Debug" / "libpome.rlib"
    return build_target(
        "pome",
        pome_root,
        output,
        "rlib",
        static_link_libs=[
            "pome",
            "crux",
            "onyx",
            "hell",
            "coal",
            "glslang",
            "glslang_wrapper",
            "MachineIndependent",
            "spirv-cross-core",
            "OGLCompiler",
            "GenericCodeGen",
            "MachineIndependent",
            "OGLCompiler",
            "OSDependent",
            "SPIRV",
            "glslang",
            "glslang_wrapper",
            "spirv-cross-core",
            "spirv-cross-reflect",
            "spirv-cross-util",
        ],
        extern_crates=[num, intrusive],
        link_dirs=[ext_build_root / "rust" / "release" / "deps"],
        native_link_dirs=[build_root / "lib"],
        extra_flags=[
            "-lvulkan",
            "-lxcb",
            "-ldl",
            "-lxcb-keysyms",
            "-lxcb-xinput",
            "-lstdc++",
        ],
        debug=True,
    )


def compile_cmd(tgt, dry_run=True, verbose=True, emitjson=True):
    cmd = ["rustc"]
    for v in tgt["extern_crates"]:
        name = v["name"]
        output = str(v["output"])
        cmd += ["--extern", name + "=" + output]
    for v in tgt["link_dirs"]:
        cmd += ["-L", str(v)]
    for v in tgt["native_link_dirs"]:
        cmd += ["-L", "native=" + str(v)]
    for v in tgt["static_link_libs"]:
        cmd += ["-l", "static=" + str(v)]
    for v in tgt["extra_flags"]:
        cmd.append(v)
    if tgt["debug"]:
        cmd.append("-g")
    cmd += ["--edition", tgt["edition"]]
    cmd += ["--crate-type", tgt["crate_type"]]
    if dry_run:
        cmd += ["-o", "/dev/null"]
    else:
        cmd += ["-o", str(tgt["output"])]
    if verbose:
        cmd.append("-v")
    if emitjson:
        cmd.append("--error-format=json")
    cmd.append(str(tgt["rootfile"]))
    return cmd


def run_targets(targets):
    for t in targets:
        cmd = compile_cmd(t)
        if VERBOSE:
            print(" ".join(cmd))
        sp.run(cmd)


def main(args):
    root = paths.root
    examples = paths.examples
    bins = paths.bins

    targets = {}
    pome = build_pome()
    targets[pome["name"]] = pome

    ex = examples.rglob("*/main.rs")
    bi = bins.rglob("*/main.rs")
    ex = chain(ex, bi)
    for e in ex:
        name = e.parent.name
        output = build_root / "rust" / "Debug" / "examples" / name
        reflect_dir = build_root / "lib" / (str(name) + "_rust_reflection")
        reflect_lib = "reflection"
        tgt = build_target(
            name,
            e,
            output,
            "bin",
            debug=True,
            extern_crates=[pome],
            link_dirs=[
                ext_build_root / "rust" / "release",
                ext_build_root / "rust" / "release" / "deps",
            ],
            static_link_libs=[reflect_lib],
            native_link_dirs=[reflect_dir],
        )
        targets[tgt["name"]] = tgt

    parser = argparse.ArgumentParser(prog="compile")
    parser.add_argument(
        "target",
        help="Target to compile",
        choices=(list(targets.keys()) + ["all"]),
    )
    parser.add_argument("-v", help="Verbose output", action="store_true")
    parser.add_argument("-l", help="List targets", action="store_true")

    args = parser.parse_args(args)

    if args.v:
        global VERBOSE
        VERBOSE = True

    if args.l:
        for t in targets:
            print(t)

    ts = []
    target = args.target
    if target == "all":
        for key in targets.keys():
            ts.append(targets[key])
    else:
        ts.append(targets[target])

    run_targets(ts)


if __name__ == "__main__":
    main(sys.argv[1:])
