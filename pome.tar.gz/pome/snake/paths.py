import os
from pathlib import Path

root = Path(os.getenv('S'))
demos = root / 'demo'
bins = root / 'src'
build = Path(os.getenv('B'))
deps_build = Path(os.getenv('XB'))
deps_src = root / 'external'

