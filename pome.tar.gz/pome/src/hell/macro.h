#define HELL_INIT(framefn) \
    eventQueue = hell_alloc_event_queue();\
    grimoire   = hell_alloc_grimoire();\
    console    = hell_alloc_console();\
    window     = hell_alloc_window();\
    hellmouth  = hell_alloc_hellmouth();\
    hell_create_console(console);\
    hell_create_event_queue(eventQueue);\
    hell_create_grimoire(eventQueue, grimoire);\
    hell_create_window(eventQueue, 666, 666, NULL, window);\
    hell_create_hellmouth(grimoire, eventQueue, console, 1, &window, framefn, NULL, hellmouth)
