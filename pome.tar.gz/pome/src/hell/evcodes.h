#ifndef HELL_EVCODES_H
#define HELL_EVCODES_H

// IMPORTANT. Key values MUST be below 128

// key values are ascii lower case
#define HELL_KEY_SPACE 32
#define HELL_KEY_CTRL 24
#define HELL_KEY_ESC 27

#define HELL_KEY_BACKSPACE 8
#define HELL_KEY_PERIOD 46

#define HELL_KEY_A 97
#define HELL_KEY_B 98
#define HELL_KEY_C 99
#define HELL_KEY_D 100
#define HELL_KEY_E 101
#define HELL_KEY_F 102
#define HELL_KEY_G 103
#define HELL_KEY_H 104
#define HELL_KEY_I 105
#define HELL_KEY_J 106
#define HELL_KEY_K 107
#define HELL_KEY_L 108
#define HELL_KEY_M 109
#define HELL_KEY_N 110
#define HELL_KEY_O 111
#define HELL_KEY_P 112
#define HELL_KEY_Q 113
#define HELL_KEY_R 114
#define HELL_KEY_S 115
#define HELL_KEY_T 116
#define HELL_KEY_U 117
#define HELL_KEY_V 118
#define HELL_KEY_W 119
#define HELL_KEY_X 120
#define HELL_KEY_Y 121
#define HELL_KEY_Z 122
#define HELL_KEY_0 48
#define HELL_KEY_1 49
#define HELL_KEY_1 49
#define HELL_KEY_2 50
#define HELL_KEY_3 51
#define HELL_KEY_4 52
#define HELL_KEY_5 53
#define HELL_KEY_6 54
#define HELL_KEY_7 55
#define HELL_KEY_8 56
#define HELL_KEY_9 57
#define HELL_KEY_DELETE 127
#define HELL_KEY_ENTER 13
#define HELL_KEY_MINUS 45

#define HELL_MOUSE_LEFT 1
#define HELL_MOUSE_RIGHT 2
#define HELL_MOUSE_MID 3

// for bindgen
static const unsigned char HELL_KEY_SPACE_VAR     = HELL_KEY_SPACE;
static const unsigned char HELL_KEY_CTRL_VAR      = HELL_KEY_CTRL;
static const unsigned char HELL_KEY_ESC_VAR       = HELL_KEY_ESC;
static const unsigned char HELL_KEY_BACKSPACE_VAR = HELL_KEY_BACKSPACE;
static const unsigned char HELL_KEY_PERIOD_VAR    = HELL_KEY_PERIOD;

static const unsigned char HELL_KEY_A_VAR      = HELL_KEY_A;
static const unsigned char HELL_KEY_B_VAR      = HELL_KEY_B;
static const unsigned char HELL_KEY_C_VAR      = HELL_KEY_C;
static const unsigned char HELL_KEY_D_VAR      = HELL_KEY_D;
static const unsigned char HELL_KEY_E_VAR      = HELL_KEY_E;
static const unsigned char HELL_KEY_F_VAR      = HELL_KEY_F;
static const unsigned char HELL_KEY_G_VAR      = HELL_KEY_G;
static const unsigned char HELL_KEY_H_VAR      = HELL_KEY_H;
static const unsigned char HELL_KEY_I_VAR      = HELL_KEY_I;
static const unsigned char HELL_KEY_J_VAR      = HELL_KEY_J;
static const unsigned char HELL_KEY_K_VAR      = HELL_KEY_K;
static const unsigned char HELL_KEY_L_VAR      = HELL_KEY_L;
static const unsigned char HELL_KEY_M_VAR      = HELL_KEY_M;
static const unsigned char HELL_KEY_N_VAR      = HELL_KEY_N;
static const unsigned char HELL_KEY_O_VAR      = HELL_KEY_O;
static const unsigned char HELL_KEY_P_VAR      = HELL_KEY_P;
static const unsigned char HELL_KEY_Q_VAR      = HELL_KEY_Q;
static const unsigned char HELL_KEY_R_VAR      = HELL_KEY_R;
static const unsigned char HELL_KEY_S_VAR      = HELL_KEY_S;
static const unsigned char HELL_KEY_T_VAR      = HELL_KEY_T;
static const unsigned char HELL_KEY_U_VAR      = HELL_KEY_U;
static const unsigned char HELL_KEY_V_VAR      = HELL_KEY_V;
static const unsigned char HELL_KEY_W_VAR      = HELL_KEY_W;
static const unsigned char HELL_KEY_X_VAR      = HELL_KEY_X;
static const unsigned char HELL_KEY_Y_VAR      = HELL_KEY_Y;
static const unsigned char HELL_KEY_Z_VAR      = HELL_KEY_Z;
static const unsigned char HELL_KEY_0_VAR      = HELL_KEY_0;
static const unsigned char HELL_KEY_1_VAR      = HELL_KEY_1;
static const unsigned char HELL_KEY_2_VAR      = HELL_KEY_2;
static const unsigned char HELL_KEY_3_VAR      = HELL_KEY_3;
static const unsigned char HELL_KEY_4_VAR      = HELL_KEY_4;
static const unsigned char HELL_KEY_5_VAR      = HELL_KEY_5;
static const unsigned char HELL_KEY_6_VAR      = HELL_KEY_6;
static const unsigned char HELL_KEY_7_VAR      = HELL_KEY_7;
static const unsigned char HELL_KEY_8_VAR      = HELL_KEY_8;
static const unsigned char HELL_KEY_9_VAR      = HELL_KEY_9;
static const unsigned char HELL_KEY_DELETE_VAR = HELL_KEY_DELETE;
static const unsigned char HELL_KEY_ENTER_VAR  = HELL_KEY_ENTER;
static const unsigned char HELL_KEY_MINUS_VAR  = HELL_KEY_MINUS;

static const unsigned char HELL_MOUSE_LEFT_VAR  = HELL_MOUSE_LEFT;
static const unsigned char HELL_MOUSE_RIGHT_VAR = HELL_MOUSE_RIGHT;
static const unsigned char HELL_MOUSE_MID_VAR   = HELL_MOUSE_MID;

#endif /* end of include guard: HELL_EVCODES_H */
