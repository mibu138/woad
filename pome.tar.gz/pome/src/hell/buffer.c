#include "buffer.h"
#include <memory.h>
#include <string.h>

void hell_buffer_init(HellBuffer* buf, Byte* data, Size length)
{
    memset(buf, 0, sizeof(*buf));
    buf->data = data;
    buf->max_size = length;
}
