#ifndef HELL_DEBUG_H
#define HELL_DEBUG_H

#include <assert.h>

#if defined( NDEBUG ) || defined( HELL_NO_DEBUG_PRINT )
#define HELL_DEBUG_PRINTING 0
#else
#define HELL_DEBUG_PRINTING 1
#endif

#define HELL_DEBUG_TAG_NO_TAG   "NO_TAG"

#ifdef __cplusplus
extern "C" {
#endif

// do not call directly. use hell_d_print.
// reason is so we can enable logging in the debug m
void     hell_debug_print_impl(const char* fmt, ...);

#define hell_debug_print(tag, fmt, ...) \
    do {if (HELL_DEBUG_PRINTING) \
        { \
            hell_debug_print_impl("%s:%s:%d:%s(): " fmt, tag, __FILE__, __LINE__, __func__, ##__VA_ARGS__); \
        } \
    } while (0)

#define hell_d_print(fmt, ...) \
    do {if (HELL_DEBUG_PRINTING) \
        { \
            hell_debug_print_impl(HELL_DEBUG_TAG_NO_TAG); \
            hell_debug_print_impl(":%s:%d:%s(): ", __FILE__, __LINE__, __func__); \
            hell_debug_print_impl(fmt, ##__VA_ARGS__); \
        } \
    } while (0)

#define debug_print(fmt, ...) \
    do {if (HELL_DEBUG_PRINTING) \
        { \
            hell_debug_print_impl("%s:%s():%d: " fmt "\n", __FILE__, __func__, __LINE__, ##__VA_ARGS__); \
        } \
    } while (0)

// these only accept string literals.... 
void hell_add_filter_tag(const char* tag);
void hell_add_filter_tags(const unsigned int count, const char* tags[]);

#ifdef __cplusplus
};
#endif

#endif /* end of include guard: HELL_DEBUG_H */

