#ifndef HELL_FRAME_H
#define HELL_FRAME_H

#include "common.h"

void     hell_create_hellmouth(HellGrimoire *grimoire, HellEventQueue *queue,
                               HellConsole *console, uint32_t windowCount,
                               HellWindow *windows[], HellFrameFn userFrame,
                               HellShutDownFn userShutDown, HellMouth *hellmouth);
// abreviated hellmouth creation that allocs and creates everythin
// returns 0 as success
int32_t  hell_open_mouth(uint32_t option_flags, HellMouth *hm);
void     hell_close_hellmouth(HellMouth *hellmouth);
void     hell_close_and_exit(HellMouth *);

HellWindow *hell_hellmouth_add_window(HellMouth *hm, u16 w, u16 h,
                                      const char *name);

HellWindow *hell_get_window(HellMouth *hm, uint32_t window);

void hell_frame(HellMouth *); // run single frame
                              //
void hell_begin_frame(Hell *h);
void hell_end_frame(Hell *h);

void hell_loop(Hell* h, HellFrameFn user_frame);

const HellEvent *hell_get_events(HellMouth *h, int32_t *event_count);

// calls shutdown and exits the program
void hell_quit(HellGrimoire *grim, void *hellmouthvoid);

HellMouth      *hell_alloc_hellmouth(void);

#endif
