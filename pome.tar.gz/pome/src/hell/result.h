#ifndef HELL_RESULT_H
#define HELL_RESULT_H

#include "numerictypes.h"

typedef enum hell_result_code {
    HELL_RESULT_CODE_SUCCESS,
} HellResultCode;

typedef enum hell_result_code_type {
    HELL_RESULT_CODE_TYPE_HELL,
    HELL_RESULT_CODE_TYPE_VULKAN,
    HELL_RESULT_CODE_TYPE_ERRNO,
} HellResultCodeType;

#define HELL_RESULT_MSG_MAX_LEN 256
#define HELL_RESULT_MAX_CODES 4

/// This can be used for returning errors
typedef struct hell_result {
    u32 code_count;
    // result can contain multiple kinds of error codes, either from us or one of the
    // backends / libraries we use, as long as the code can be expressed as a
    // u64
    struct {
        enum hell_result_code_type type;
        u64 code;
    } codes[HELL_RESULT_MAX_CODES];
} HellResult;

HellResult hell_result_single_code(u64 code, HellResultCodeType type);

#endif
