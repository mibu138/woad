#ifndef HELL_INPUT_H
#define HELL_INPUT_H

#include <stdint.h>
#include <stdbool.h>
#include "ds.h"
#include "types.h"
#include "evcodes.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct HellMouseEventData {
    int16_t       x;
    int16_t       y;
    uint8_t       button_code;
} HellMouseEventData;

typedef struct HellStylusEventData {
    float         pressure;
} HellStylusEventData;

typedef struct HellResizeEventData {
    uint16_t      width;
    uint16_t      height;
} HellResizeEventData;

typedef struct HellConsoleEventData {
    void*            ptr;
    uint32_t         ptr_len;
} HellConsoleEventData;

typedef struct HellKeyEventData {
    uint32_t      key_code;
} HellKeyEventData;

typedef union HellInputData {
    HellMouseEventData   mouse_data;
    HellStylusEventData  stylus_data;
    HellResizeEventData  resize_data;
    HellKeyEventData     key_data;
} HellInputData;

// data that is captured via a window
typedef struct HellWindowEventData {
    HellInputData data;
    HellWindowID  window_id;
} HellWindowEventData;

// data that is captured via a device directly
typedef struct HellDeviceEventData {
    HellInputData data;
} HellDeviceEventData;

typedef struct HellFrameEventData {
    int64_t frame_number;
} HellFrameEventData;

typedef union HellEventData {
    HellWindowEventData  win_data;
    HellDeviceEventData  dev_data;
    HellConsoleEventData con_data;
    HellFrameEventData frame_data;
} HellEventData;

typedef enum HellEventType {
    HELL_EVENT_TYPE_NONE,
    HELL_EVENT_TYPE_KEYDOWN,
    HELL_EVENT_TYPE_KEYUP,
    HELL_EVENT_TYPE_MOUSEDOWN,
    HELL_EVENT_TYPE_MOUSEUP,
    HELL_EVENT_TYPE_MOUSEWHEELDOWN,
    HELL_EVENT_TYPE_MOUSEWHEELUP,
    HELL_EVENT_TYPE_MOTION,
    HELL_EVENT_TYPE_RESIZE,
    HELL_EVENT_TYPE_CONSOLE,
    HELL_EVENT_TYPE_STYLUS,
    HELL_EVENT_TYPE_FRAME
} HellEventType;

typedef enum HellEventMaskBits {
    HELL_EVENT_MASK_NONE_BIT    = 1 << 0,
    HELL_EVENT_MASK_KEY_BIT     = 1 << 1,
    HELL_EVENT_MASK_POINTER_BIT = 1 << 2,
    HELL_EVENT_MASK_WINDOW_BIT  = 1 << 3,
    HELL_EVENT_MASK_CONSOLE_BIT = 1 << 4,
    HELL_EVENT_MASK_DEVICE_BIT  = 1 << 5,
    HELL_EVENT_MASK_ALL_BIT     = ~(uint32_t)1
} HellEventMaskBits;

typedef uint32_t HellEventMask;

typedef struct HellEvent {
    HellEventData data;
    HellEventType type;
    HellEventMask mask;
    int64_t       time;
} HellEvent;

// returning true consumes event
typedef bool (*HellSubscriberFn)(const HellEvent*, void* data);

#define	MAX_EDIT_LINE	256
#define MAX_QUEUE_EVENTS 64

typedef struct {
    int  cursor;
    int  scroll;
    int  width_in_chars;
    char buffer[MAX_EDIT_LINE];
} HellField;

// returning true consumes the event
#define MAX_SUBSCRIBERS 32

typedef struct HellSubscription {
    void*             data;
    HellSubscriberFn func;
    HellEventMask    event_mask;
    HellWindowID     window_id;
} HellSubscription;

//
// bk000306: upped this from 64
#define MASK_QUEUE_EVENTS (MAX_QUED_EVENTS - 1)

typedef struct HellConsole {
    int   erase_code;
    int   eof_code;
    HellField console;
} HellConsole;

typedef struct HellEventQueue {
    HellSubscription subscriptions[MAX_SUBSCRIBERS];
    int               subscriber_count;
    HellEvent        queue[MAX_QUEUE_EVENTS];
    // bk000306: initialize
    int               head;
    int               tail;
} HellEventQueue;

typedef struct hell_window     HellWindow;

// starts the clock for all hell instances.
// safe to call even if clock is already started.
void hell_start_clock(void);
bool hell_clock_started(void);

// generates events from input sources and moves them into the event queue.
// neither window nor console are required. if they are null it just does not
// try to generate events from them.
void hell_coagulate_input(HellEventQueue* queue, HellConsole* console, uint32_t windowCount, HellWindow* windows[]);

// drains the event queue and calls subscriber functions
// The frame_event_stack is an array that events will be copied into if no
// subscriber function claims them. frame_event_count will be incremented.
// the purpose is to have application loops where the input handling is donw
// insde the applications main frame function, instead of in a subscriber
// funciton
void hell_solve_input(HellEventQueue* queue, HellEvent* frame_event_stack, int* frame_event_count);

void hell_subscribe(HellEventQueue* queue, HellEventMask mask, HellWindowID winid, HellSubscriberFn func,
                           void* data);
void hell_unsubscribe(HellEventQueue*, const HellSubscriberFn);

void hell_create_console(HellConsole*);
void hell_create_event_queue(HellEventQueue*);
void hell_destroy_console(HellConsole*);
void hell_destroy_event_queue(HellEventQueue*);

void hell_push_window_resize_event(HellEventQueue*, uint32_t width,
                                uint32_t height, HellWindowID winid);
void hell_push_mouse_down_event(HellEventQueue*, int16_t x, int16_t y,
                             uint8_t buttonCode, HellWindowID winid);
void hell_push_mouse_wheel_down_event(HellEventQueue* queue, int16_t x, int16_t y, HellWindowID winid);
void hell_push_mouse_wheel_up_event(HellEventQueue* queue, int16_t x, int16_t y, HellWindowID winid);
void hell_push_mouse_up_event(HellEventQueue*, int16_t x, int16_t y,
                           uint8_t buttonCode, HellWindowID winid);
void hell_push_stylus_event2(HellEventQueue* queue, int16_t x, int16_t y, uint8_t buttonCode, float pressure,
                     HellWindowID winid);
void hell_push_mouse_motion_event(HellEventQueue*, int16_t x, int16_t y,
                               uint8_t buttonCode, HellWindowID winid);
void hell_push_key_down_event(HellEventQueue*, uint32_t keyCode, HellWindowID winid);
void hell_push_key_up_event(HellEventQueue*, uint32_t keyCode, HellWindowID winid);
void hell_push_empty_event(HellEventQueue*);
void hell_push_stylus_event(HellEventQueue* queue, float pressure, HellWindowID winid);
void hell_push_frame_event(HellEventQueue*, uint64_t frame_number);

void hell_event_print(const HellEvent*);

uint16_t hell_get_window_resize_width(const HellEvent* event);
uint16_t hell_get_window_resize_height(const HellEvent* event);
int16_t  hell_get_mouse_x(const HellEvent*);
int16_t  hell_get_mouse_y(const HellEvent*);
void hell_record_input(HellEventQueue* queue, HellArray* buffer);

uint8_t hell_get_event_button_code(const HellEvent* event);
uint8_t hell_get_event_key_code(const HellEvent* event);

HellWindow     *hell_alloc_window(void);
HellConsole    *hell_alloc_console(void);
HellEventQueue *hell_alloc_event_queue(void);

#ifdef __cplusplus
}
#endif

#endif /* end of include guard: HELL_INPUT_H */
