#include "io.h"
#include <stdio.h>
#include <string.h>
#include "common.h"
#include "cmd.h"
#include <errno.h>
#include "platform.h"
#include <sys/stat.h>
#include <assert.h>
#if defined(WIN32)
#include "fileapi.h"
#elif defined(UNIX)
#include <sys/types.h>
#include <unistd.h>
#define UNIX_LOG_DIR  "/tmp/hell"
#define UNIX_LOG_PATH UNIX_LOG_DIR"/"LOG_NAME
#define LOG_PATH UNIX_LOG_PATH
#else 
#error "Need to find an os specific place to put the log file"
#endif

static int globalFileCounter;
static FILE* hell_log;
// 
// https://docs.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-gettemppatha?redirectedfrom=MSDN
// should be large enough for windows and linux. windows docs list max length of temp dir path is 261
#define PATH_MAX 300
static char logpathbuf[PATH_MAX]; 

#define LOG_NAME "log.txt"
#define MAX_MSG_LEN 4096

static void
createDir(void)
{
#if defined(UNIX)
    strcpy(logpathbuf, UNIX_LOG_DIR);
#elif defined(WIN32)
    DWORD pathlen = GetTempPathA(PATH_MAX, logpathbuf);
    assert(pathlen);
    strcpy(logpathbuf + pathlen, "/hell"); // tack on our dir
#else 
#error "Not supported on this os yet"
#endif
    struct stat st = {0};
    if (stat(logpathbuf, &st) == -1)
    {
        int er = mkdir(logpathbuf, 0700);
        // Note we need to use fprintf here to avoid a recursive call to this function
        if (er)
            fprintf(stderr, "Error creating log directory\n");
    }
    strcat(logpathbuf, "/"LOG_NAME);
}

void hell_init_logger(void)
{
#ifdef WIN32
    return;
#endif
    // only open the log file on first call
    if (globalFileCounter) return;
    createDir();
    if (globalFileCounter == 0)
    {
        hell_log = fopen(logpathbuf, "w");
        if (!hell_log)
            printf(" Failed to open %s.\n", LOG_NAME);
    }
    globalFileCounter++;
}

void hell_shutdown_logger(void)
{
#ifdef WIN32
    return;
#endif
    globalFileCounter--;
    if (globalFileCounter == 0)
    {
        int r = fclose(hell_log);
        if (r)
            hell_error(HELL_ERR_MILD, "Error on closing %s.\n", LOG_NAME);
    }
}

void hell_write_to_log(const char* msg)
{
    // too much trouble to get this right
#ifdef WIN32
    return;
#endif
    // probably want a lock here so multiple threads could write to log
    hell_init_logger(); // so we can call this without explicitly starting up hell
    int l = strnlen(msg, MAX_MSG_LEN);
    if (l == MAX_MSG_LEN)
        hell_error(HELL_ERR_FATAL, "Message too long\n");
    int r = fwrite(msg, l, 1, hell_log);
    if (r == 0)
        hell_error(HELL_ERR_MILD, "Write to log failed.\n");
}


int hell_read_file(const char *filepath, ByteArray *array)
{
    int err = 0;
    long size;
    FILE *fp = fopen(filepath, "r");

    if (!fp) {
        err = errno;
        goto no_close;
    }

    err = fseek(fp, 0, SEEK_END);
    if (err) goto end;

    size = ftell(fp);
    rewind(fp);

    *array = byte_arr_create(NULL);
    byte_arr_set_count(array, size);

    size_t r = fread(array->elems, size, 1, fp);
    if (r == 0) {
        byte_arr_free(array);
        err = -1;
        goto end;
    }

    array->count = size;

end:
    if (fclose(fp))
        assert("File failed to close");
no_close:
    return err;
}

int hell_write_file(const char *filepath, const void *bytes, size_t byte_count)
{
    int err = 0;
    FILE *fp = fopen(filepath, "w");

    if (!fp) {
        fprintf(stderr, "ERROR %s : Failed to open file %s\n", __func__, filepath);
        return errno;
    }

    size_t bytes_written = fwrite(bytes, 1, byte_count, fp);
    if (bytes_written != byte_count)
    {
        fprintf(stderr, "ERROR %s : Failed to write all bytes to file %s\n", __func__, filepath);
        return 1;
    }

    if (fclose(fp))
        assert("File failed to close");
    return err;
}
