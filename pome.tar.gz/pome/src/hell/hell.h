#ifndef HELL_HELL_H
#define HELL_HELL_H

#ifdef __cplusplus
extern "C" {
#endif

#include "common.h"
#include "frame.h"

#ifdef __cplusplus
}
#endif

#endif /* end of include guard: HELL_HELL_H */
