#include "ds.h"
#define HELL_SIMPLE_FUNCTION_NAMES
#include "input.h"
#include "cmd.h"
#include "common.h"
#include "debug.h"
#include "platform.h"
#include "private.h"
#include "window.h"
#include <assert.h>
#include <fcntl.h>
#include <memory.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
//
#ifdef UNIX
#include <termios.h>
#include <unistd.h>
// stash the tc at program start here so we can reset it on shut down
struct termios origTc;
#elif WIN32
#include <windows.h>
#endif

static_assert(sizeof(HellEventType) == 4,
              "sizeof(HellI_EventType) should be 4");
static_assert(sizeof(HellEventMask) == 4,
              "sizeof(HellI_EventMask) should be 4");
static_assert(
    sizeof(HellEvent) == 32,
    "sizeof(HellI_Event) should be 32, to allow 2 events to be read with each "
    "cacheline read (assuming the event queue is aligned well)");

#ifdef UNIX
static_assert(STDIN_FILENO == 0, "We assume the the fd for stdin is 0");
#endif

static int  globalConsoleCounter;
static bool globalClockStarted;

#ifdef UNIX
static struct timespec unixEpoch;
#define UNIX_CLOCK_ID CLOCK_MONOTONIC

static void
initUnixTime(void)
{
    clock_gettime(UNIX_CLOCK_ID, &unixEpoch);
}

static int64_t
getUnixNanoSeconds(void)
{
    struct timespec curTime;
    clock_gettime(UNIX_CLOCK_ID, &curTime);
    time_t  s  = curTime.tv_sec - unixEpoch.tv_sec;
    long    ns = curTime.tv_nsec - unixEpoch.tv_nsec;
    int64_t v = s * 1000000000 + ns;
    return v;
}

#elif defined(WIN32)

static LARGE_INTEGER winEpoch;
static LARGE_INTEGER winFreq;

static void
initWinTime(void)
{
    QueryPerformanceFrequency(&winFreq);
    QueryPerformanceCounter(&winEpoch);
}

static int64_t
getWinMicroSeconds(void)
{
    LARGE_INTEGER curTicks, elapsedTime;
    QueryPerformanceCounter(&curTicks);
    elapsedTime.QuadPart = curTicks.QuadPart - winEpoch.QuadPart;
    elapsedTime.QuadPart *= 1000000;
    assert(winFreq.QuadPart > 0);
    elapsedTime.QuadPart /= winFreq.QuadPart;
    return elapsedTime.QuadPart;
}

#else
#error
#endif

static void
initTime(void)
{
    if (globalClockStarted)
        return;
#ifdef UNIX
    initUnixTime();
#elif defined(WIN32)
    initWinTime();
#else
#error
#endif
    globalClockStarted = true;
}

static void
fieldClear(HellField* field)
{
    memset(field, 0, sizeof(HellField));
}
// do a backspace
// TTimo NOTE: it seems on some terminals just sending '\b' is not enough
//   so for now, in any case we send "\b \b" .. yeah well ..
//   (there may be a way to find out if '\b' alone would work though)
static void
ttyBack(void)
{
    char key;
    key = '\b';
    write(1, &key, 1);
    key = ' ';
    write(1, &key, 1);
    key = '\b';
    write(1, &key, 1);
}

static char*
getConsoleInput(HellConsole* console)
{
    static char text[MAX_EDIT_LINE];
    static bool newline = true;
    if (newline)
    {
        write(1, ">> ", 3);
        newline = false;
    }
    char c;
    int  avail = read(0, &c, 1);
    if (avail != -1)
    {
        if (c == console->erase_code || c == 127 || c == 8)
        {
            if (console->console.cursor > 0)
            {
                console->console.buffer[--console->console.cursor] = '\0';
                ttyBack();
            }
            return NULL;
        }
        if (c == '\n')
        {
            strncpy(text, console->console.buffer, MAX_EDIT_LINE);
            // text[ttyConsole.cursor + 1] = '\0';
            fieldClear(&console->console);
            newline = true;
            write(1, &c, 1);
            return text;
        }
        console->console.buffer[console->console.cursor++] = c;
        write(1, &c, 1);
    }
    return NULL;
}

static void
pushEvent(HellEventQueue* queue, HellEvent event)
{
    queue->queue[queue->head] = event;
    queue->head               = (queue->head + 1) % MAX_QUEUE_EVENTS;
}

void
hell_create_event_queue(HellEventQueue* queue)
{
    memset(queue, 0, sizeof(HellEventQueue));
}

void
hell_create_console(HellConsole* console)
{
#ifdef UNIX
    memset(console, 0, sizeof(*console));
    struct termios tc;
    if (isatty(STDIN_FILENO) != 1)
        hell_error(0, "stdin is not a tty, tty console mode failed");
    if (tcgetattr(0, &tc) != 0)
        hell_error(0, "tcgetattr failed");
    if (globalConsoleCounter == 0)
    {
        fcntl(0, F_SETFL, fcntl(0, F_GETFL, 0) | FNDELAY);
        origTc = tc;
        tc.c_lflag &= ~(ECHO | ICANON);
        tc.c_iflag &= ~(ISTRIP | INPCK);
        tc.c_cc[VMIN]  = 1;
        tc.c_cc[VTIME] = 0;
        tcsetattr(0, TCSADRAIN, &tc);
        globalConsoleCounter++;
    }
    console->erase_code = origTc.c_cc[VERASE];
    console->eof_code   = origTc.c_cc[VEOF];
#elif defined(WIN32)
#endif
}

void
hell_start_clock(void)
{
    initTime();
}

bool
hell_clock_started(void)
{
    return globalClockStarted;
}

void
hell_coagulate_input(HellEventQueue* queue, HellConsole* console,
                    uint32_t windowCount, HellWindow* windows[])
{
    assert(queue);
    if (console)
    {
        char* ci = getConsoleInput(console);
        if (ci)
        {
            HellEvent ev          = {.type = HELL_EVENT_TYPE_CONSOLE,
                                      .mask = HELL_EVENT_MASK_CONSOLE_BIT};
            // this should put a trailing null at the end of the data, but not
            // sure if we need this... ev.data.consoleData.ptrLen = strnlen(ci,
            // MAX_EDIT_LINE - 1) + 1;
            ev.data.con_data.ptr_len = strnlen(ci, MAX_EDIT_LINE);
            ev.data.con_data.ptr    = hell_malloc(ev.data.con_data.ptr_len);
            // should copy a null at the end
            memcpy(ev.data.con_data.ptr, ci, ev.data.con_data.ptr_len);
            ev.time = hell_time();
            pushEvent(queue, ev);
        }
    }
    for (int i = 0; i < windowCount; i++)
    {
        hell_drain_window_events(queue, windows[i]);
    }
}

void 
hell_record_input(HellEventQueue* queue, HellArray* buffer)
{
    int iter = queue->tail;
    while (iter != queue->head) {
        HellEvent* event = &queue->queue[iter];
        // again, console events have pointers.. not worth dealing with most of
        // the time.
        if (event->type != HELL_EVENT_TYPE_CONSOLE) 
            hell_array_push(buffer, event);
        iter = (iter + 1) % MAX_QUEUE_EVENTS;
    }
}

void
hell_solve_input(HellEventQueue* queue, HellEvent* frame_event_stack,
                int* frame_event_count)
{
    const HellEvent* event;
    for (; queue->tail != queue->head;
         queue->tail = (queue->tail + 1) % MAX_QUEUE_EVENTS)
    {
        event              = &queue->queue[queue->tail];
        bool event_handled = false;
        // hell_announce("Event: type %d time %ld \n", event->type,
        // event->time);
        for (int i = 0; i < queue->subscriber_count; i++)
        {
            const HellSubscription sub = queue->subscriptions[i];
            if (sub.event_mask & event->mask)
            {
                // note the event may not have the window mask set and this
                // condition will still go through thus its up to the subscriber
                // to set the window bit if they way to only recieve events for
                // a cetain window
                if (sub.event_mask & HELL_EVENT_MASK_WINDOW_BIT)
                {
                    if (sub.window_id == event->data.win_data.window_id)
                    {
                        if (sub.func(event, sub.data))
                        {
                            event_handled = true;
                            break; // if func returns true the event break from
                                   // the loop
                        }
                    }
                }
                else
                {
                    if (sub.func(event, sub.data))
                    {
                        event_handled = true;
                        break; // if func returns true the event break from the
                               // loop
                    }
                }
            }
        }
        // dont send console events to frame stack because they require freeing
        // after they are used.
        //hell_print("event type: %d event time: %d", event->type, event->time);
        if (!event_handled && event->type != HELL_EVENT_TYPE_CONSOLE)
        {
            frame_event_stack[*frame_event_count] = *event;
            (*frame_event_count)++;
        }
        if (event->type == HELL_EVENT_TYPE_CONSOLE)
        {
            hell_free(event->data.con_data.ptr);
        }
    }
}

// not used yet... issue is we still have hell itself processing some events,
// especially console ones, which need additional freeing.
// so we dont want to give the client full access to the queue
const HellEvent*
hell_pull_event(HellEventQueue* queue)
{
    HellEvent* event = NULL;
    if (queue->tail != queue->head)
    {
    }
    return event;
}

void
hell_subscribe(HellEventQueue* queue, HellEventMask mask, HellWindowID winid,
               HellSubscriberFn func, void* data)
{
    queue->subscriptions[queue->subscriber_count++] = (HellSubscription){
        .data = data, .func = func, .window_id = winid, .event_mask = mask};
}

HellTick
hell_time()
{
#ifdef UNIX
    return getUnixNanoSeconds();
#elif defined(WIN32)
    return getWinMicroSeconds();
#endif
}

void
hell_push_mouse_wheel_down_event(HellEventQueue* queue, int16_t x, int16_t y, HellWindowID winid)
{
    HellEvent ev = {
        .type = HELL_EVENT_TYPE_MOUSEWHEELDOWN,
        .mask = HELL_EVENT_MASK_POINTER_BIT | HELL_EVENT_MASK_WINDOW_BIT,
        .time = hell_time(),
    };
    ev.data.win_data.data.mouse_data.x          = x;
    ev.data.win_data.data.mouse_data.y          = y;
    ev.data.win_data.window_id = winid;
    pushEvent(queue, ev);
}

void
hell_push_mouse_wheel_up_event(HellEventQueue* queue, int16_t x, int16_t y, HellWindowID winid)
{
    HellEvent ev = {
        .type = HELL_EVENT_TYPE_MOUSEWHEELUP,
        .mask = HELL_EVENT_MASK_POINTER_BIT | HELL_EVENT_MASK_WINDOW_BIT,
        .time = hell_time(),
    };
    ev.data.win_data.data.mouse_data.x          = x;
    ev.data.win_data.data.mouse_data.y          = y;
    ev.data.win_data.window_id = winid;
    pushEvent(queue, ev);
}

void
hell_push_mouse_down_event(HellEventQueue* queue, int16_t x, int16_t y,
                        uint8_t button_code, HellWindowID winid)
{
    HellEvent ev = {
        .type = HELL_EVENT_TYPE_MOUSEDOWN,
        .mask = HELL_EVENT_MASK_POINTER_BIT | HELL_EVENT_MASK_WINDOW_BIT,
        .time = hell_time(),
    };
    ev.data.win_data.data.mouse_data.x          = x;
    ev.data.win_data.data.mouse_data.y          = y;
    ev.data.win_data.data.mouse_data.button_code = button_code;
    ev.data.win_data.window_id                  = winid;
    pushEvent(queue, ev);
}

void
hell_push_stylus_event(HellEventQueue* queue, float pressure,
                     HellWindowID winid)
{
    HellEvent ev                            = {.type = HELL_EVENT_TYPE_STYLUS,
                                                .mask = HELL_EVENT_MASK_POINTER_BIT | HELL_EVENT_MASK_WINDOW_BIT,
                                                .time = hell_time()};
    ev.data.win_data.data.stylus_data.pressure = pressure;
    ev.data.win_data.window_id                 = winid;
    pushEvent(queue, ev);
}

// this doesn't work. pressure events can be completely separate from motion
// events. in other words, we can get stylus events with zeroed out position.
void
hell_push_stylus_event2(HellEventQueue* queue, int16_t x, int16_t y, uint8_t button_code, float pressure,
                     HellWindowID winid)
{
    HellEvent ev                            = {.type = HELL_EVENT_TYPE_STYLUS,
                                                .mask = HELL_EVENT_MASK_POINTER_BIT | HELL_EVENT_MASK_WINDOW_BIT,
                                                .time = hell_time()};
    ev.data.win_data.data.mouse_data.x          = x;
    ev.data.win_data.data.mouse_data.y          = y;
    ev.data.win_data.data.mouse_data.button_code = button_code;
    ev.data.win_data.data.stylus_data.pressure = pressure;
    ev.data.win_data.window_id                 = winid;
    hell_print("%d %d %d %f", x,y,button_code,pressure);
    pushEvent(queue, ev);
}


void
hell_push_mouse_up_event(HellEventQueue* queue, int16_t x, int16_t y,
                      uint8_t button_code, HellWindowID winid)
{
    HellEvent ev = {
        .type = HELL_EVENT_TYPE_MOUSEUP,
        .mask = HELL_EVENT_MASK_POINTER_BIT | HELL_EVENT_MASK_WINDOW_BIT,
        .time = hell_time(),
    };
    ev.data.win_data.data.mouse_data.x          = x;
    ev.data.win_data.data.mouse_data.y          = y;
    ev.data.win_data.data.mouse_data.button_code = button_code;
    ev.data.win_data.window_id                  = winid;
    pushEvent(queue, ev);
}

void
hell_push_mouse_motion_event(HellEventQueue* queue, int16_t x, int16_t y,
                          uint8_t button_code, HellWindowID winid)
{
    HellEvent ev = {
        .type = HELL_EVENT_TYPE_MOTION,
        .mask = HELL_EVENT_MASK_POINTER_BIT | HELL_EVENT_MASK_WINDOW_BIT,
        .time = hell_time(),
    };
    ev.data.win_data.data.mouse_data.x          = x;
    ev.data.win_data.data.mouse_data.y          = y;
    ev.data.win_data.data.mouse_data.button_code = button_code;
    ev.data.win_data.window_id                  = winid;
    pushEvent(queue, ev);
}

void
hell_push_key_down_event(HellEventQueue* queue, uint32_t key_code,
                      HellWindowID winid)
{
    HellEvent ev                        = {.type = HELL_EVENT_TYPE_KEYDOWN,
                                            .mask = HELL_EVENT_MASK_KEY_BIT | HELL_EVENT_MASK_WINDOW_BIT,
                                            .time = hell_time()};
    ev.data.win_data.data.key_data.key_code = key_code;
    ev.data.win_data.window_id             = winid;
    pushEvent(queue, ev);
}

void
hell_push_key_up_event(HellEventQueue* queue, uint32_t key_code,
                    HellWindowID winid)
{
    HellEvent ev                        = {.type = HELL_EVENT_TYPE_KEYUP,
                                            .mask = HELL_EVENT_MASK_KEY_BIT | HELL_EVENT_MASK_WINDOW_BIT,
                                            .time = hell_time()};
    ev.data.win_data.data.key_data.key_code = key_code;
    ev.data.win_data.window_id             = winid;
    pushEvent(queue, ev);
}

void
hell_push_window_resize_event(HellEventQueue* queue, unsigned int width,
                           unsigned int height, HellWindowID winid)
{
    HellEvent ev                          = {.time = hell_time(),
                                              .type = HELL_EVENT_TYPE_RESIZE,
                                              .mask = HELL_EVENT_MASK_WINDOW_BIT};
    ev.data.win_data.data.resize_data.width  = width;
    ev.data.win_data.data.resize_data.height = height;
    ev.data.win_data.window_id               = winid;
    pushEvent(queue, ev);
}

void
hell_push_empty_event(HellEventQueue* queue)
{
    HellEvent ev = {.time = hell_time()};
    pushEvent(queue, ev);
}

void hell_push_frame_event(HellEventQueue* queue, uint64_t frame_number)
{
    HellFrameEventData data = {.frame_number = frame_number};
    HellEvent ev = {.time = hell_time(), .data.frame_data = data};
    pushEvent(queue, ev);
}

void
hell_destroy_event_queue(HellEventQueue* queue)
{
    memset(queue, 0, sizeof(HellEventQueue));
}

void
hell_destroy_console(HellConsole* console)
{
    memset(console, 0, sizeof(HellConsole));
    globalConsoleCounter--;
    if (globalConsoleCounter == 0)
    {
#ifdef UNIX
        tcsetattr(0, TCSADRAIN, &origTc);
        fcntl(0, F_SETFL, fcntl(0, F_GETFL, 0) & ~FNDELAY);
#endif
        hell_announce("Terminal control released.\n");
    }
    hell_announce("Destroyed console.\n");
}

void
hell_unsubscribe(HellEventQueue* queue, const HellSubscriberFn fn)
{
    assert(queue->subscriber_count > 0);
    hell_d_print("Unsubscribing fn...\n");
    int fnIndex = -1;
    for (int i = 0; i < queue->subscriber_count; i++)
    {
        if (queue->subscriptions[i].func == fn)
        {
            fnIndex = i;
            break;
        }
    }
    if (fnIndex != -1)
        memmove(queue->subscriptions + fnIndex,
                queue->subscriptions + fnIndex + 1,
                (--queue->subscriber_count - fnIndex) *
                    sizeof(*queue->subscriptions)); // should only decrement the
                                                    // count if fnIndex is 0
}

uint64_t
hell_size_of_console(void)
{
    return sizeof(HellConsole);
}

uint64_t
hell_size_of_event_queue(void)
{
    return sizeof(HellEventQueue);
}

uint64_t
hell_size_of_window(void)
{
    return sizeof(HellWindow);
}

HellWindow*
hell_alloc_window(void)
{
    return hell_malloc(sizeof(HellWindow));
}

HellEventQueue*
hell_alloc_event_queue(void)
{
    return hell_malloc(sizeof(HellEventQueue));
}

HellConsole*
hell_alloc_console(void)
{
    return hell_malloc(sizeof(HellConsole));
}

uint16_t
hell_get_window_resize_width(const HellEvent* event)
{
    assert(event->type == HELL_EVENT_TYPE_RESIZE);
    return event->data.win_data.data.resize_data.width;
}

uint16_t
hell_get_window_resize_height(const HellEvent* event)
{
    assert(event->type == HELL_EVENT_TYPE_RESIZE);
    return event->data.win_data.data.resize_data.height;
}

int16_t
hell_get_mouse_x(const HellEvent* event)
{
    return event->data.win_data.data.mouse_data.x;
}
int16_t
hell_get_mouse_y(const HellEvent* event)
{
    return event->data.win_data.data.mouse_data.y;
}

uint8_t
hell_get_event_button_code(const HellEvent* event)
{
    return event->data.win_data.data.mouse_data.button_code;
}

uint8_t
hell_get_event_key_code(const HellEvent* event)
{
    return event->data.win_data.data.key_data.key_code;
}

void hell_event_print(const HellEvent* ev)
{
    // cast to these because i64 is defined differently on different platforms
    // and we need to pick a common format code
    unsigned long long time = ev->time;
    unsigned long long type = ev->type;
    printf("event type: %llu event time: %llu\n", type, time);
}
