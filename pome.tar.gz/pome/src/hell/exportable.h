#ifndef HELL_EXPORTABLE_H
#define HELL_EXPORTABLE_H

#include <stdint.h>

typedef struct hell Hell;
typedef struct HellWindow HellWindow;
typedef struct HellEventQueue HellEventQueue;

Hell* hell_alloc_hellmouth(void);

int32_t hell_open_mouth(uint32_t option_flags,
                        Hell* hm);

HellWindow* hell_hellmouth_add_window(Hell* hm, uint16_t w, uint16_t h,
                                     const char* name);

HellWindow* hell_get_window(Hell* hm, uint32_t window);

void hell_begin_frame(Hell* h);
void hell_end_frame(Hell* h);

int64_t hell_get_frame_number(Hell* h);
int64_t hell_get_frame_delta(Hell* h);

HellEventQueue* hell_get_event_queue(Hell* h);

#endif
