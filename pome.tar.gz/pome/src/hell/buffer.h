#ifndef HELL_DATA_STRUCTURES_H
#define HELL_DATA_STRUCTURES_H

// Data Structures

#define HELL_SIMPLE_TYPE_NAMES
#include "types.h"

typedef struct HellBuffer {
    Byte*  data;
    Size   max_size;
    Size   cur_size;
} HellBuffer;

void hell_buffer_init(HellBuffer* buf, Byte* data, Size length);

#endif /* end of include guard: HELL_DATA_H */
