#ifndef HELL_WINDOW_H
#define HELL_WINDOW_H

#include "types.h"
#include "private.h"
#ifdef WIN32
#include <windows.h>
// should be called in WinMain before trying to open a window.
void  hell_set_hinstance(HINSTANCE hinstance);
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct hell_window HellWindow;
typedef struct HellEventQueue HellEventQueue;

void hell_create_window(const uint16_t width, const uint16_t height, const char* name,
                  HellWindow* window);
void               hell_destroy_window(HellWindow*);
// does nothing if window is not active
void               hell_drain_window_events(HellEventQueue*, HellWindow*);
const void*        hell_get_xcb_connection(const HellWindow* window);

const void*        hell_get_xcb_window_ptr(const HellWindow* window);
HellWindowID      hell_get_window_i_d(const HellWindow* window);
void* hell_get_hinstance_ptr(const HellWindow* window);
void* hell_get_hwnd_ptr(const HellWindow* window);

uint32_t hell_get_window_width(const HellWindow* window);
uint32_t hell_get_window_height(const HellWindow* window);

#ifdef __cplusplus
}
#endif

#endif /* end of include guard: DISPLAY_H */
