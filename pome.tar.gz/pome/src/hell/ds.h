#ifndef HELL_DS_H
#define HELL_DS_H

#include "types.h"
#include "len.h"
#include "memory.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void* (*HellAllocFn)(u64 size);
// note that a proper realloc function needs to also handle case when size if 0
// since this will be called to free array
typedef void* (*HellReallocFn)(void*, u64 size);
typedef void  (*HellFreeFn)(void*);

typedef struct HellArray {
    u32           count;
    void*         elems;
    u32           capacity;
    u32           elem_size;
    HellReallocFn realloc_fn;
} HellArray;

typedef struct HellStackArray {
    u32           count;
    void*         elems;
    u32           capacity;
    u32           elem_size;
    HellReallocFn realloc_fn;
} HellStackArray;

typedef HellArray HellArray;

// if userAlloc or userRealloc is null will default to HellMalloc or HellRealloc
HellArray hell_create_array(size_t elem_size, size_t capacity, HellReallocFn);
void  hell_create_array_old(u32 capacity, u32 elemSize, HellAllocFn userAlloc, HellReallocFn userRealloc, HellArray* array);
int   hell_array_putc(HellArray*, char c);
void  hell_array_pop(HellArray*, void* target);

// set count back to 0 and zeroes out elems
void  hell_array_clear(HellArray* arr);
// if userAlloc is null will default to HellFree
void  hell_destroy_array(HellArray*, HellFreeFn userFree);

// returns ptr to element inside the array or null on error
void* hell_array_push(HellArray* arr, const void* elem);

// O(1) operation. does not preserve array order
void hell_array_remove_swap(HellArray* arr, size_t i);

void hell_array_free(HellArray* arr);

#define hell_array_get(arr, type, index) (((type*)arr.elems)[index])

// new array based on stbds_array

/*[[[cog
import cog
types = ['char', 'String']
for t in types:
    name = "HellArray" + f"{t}".capitalize()
    tlow = f"{t}".lower()
    s = f"""
    typedef struct {{
        {t}* elems;
        int  count;
        int  cap;
    }} {name};

    static inline void hell_array_{tlow}_push({name}* arr, {t} elem) 
    {{
        if (arr->count >= arr->cap) {{
            assert(arr->cap > 0);
            int newcap = arr->cap * 2;
            arr->elems = ({t}*)hell_realloc(arr->elems, sizeof({t}) * newcap);
            arr->cap = newcap;
        }}
        arr->elems[arr->count++] = elem;
    }}
    """
    cog.outl(s)
]]]*/

//[[[end]]]

#define HELL_STRING_BUF_LEN 8

typedef struct {
    union {
    char* elems_ptr;
    char  elems_buf[HELL_STRING_BUF_LEN];
    };
    HellReallocFn realloc_fn;
    unsigned int  count;
    unsigned int  cap;
    unsigned int using_buf : 1;
} HellString;

static inline HellString hell_string_create(unsigned int cap, HellReallocFn realloc_fn)
{
    assert(cap > 0);

    HellString arr = {0};
    arr.realloc_fn = realloc_fn;

    if (!arr.realloc_fn)
        arr.realloc_fn = hell_realloc;

    if (cap <= HELL_STRING_BUF_LEN) {
        arr.using_buf = true;
        arr.elems_buf[0] = '\0';
        cap = HELL_STRING_BUF_LEN;
    }
    else {
        arr.elems_ptr = (char*)arr.realloc_fn(arr.elems_ptr, sizeof(char) * cap);
        arr.elems_ptr[0] = '\0';
    }

    arr.cap = cap;
    arr.count = 1;
    return arr;
}

static inline void hell_string_push(HellString* arr, char elem) 
{
    if (arr->count >= arr->cap) {
        unsigned int newcap = arr->cap * 2;
        if (arr->using_buf && newcap > sizeof(arr->elems_buf)) {
            char tmp[HELL_STRING_BUF_LEN];
            assert(sizeof(tmp) == sizeof(arr->elems_buf));
            memcpy(tmp, arr->elems_buf, sizeof(tmp));
            arr->elems_ptr = (char*)arr->realloc_fn(NULL, sizeof(char) * newcap);
            memcpy(arr->elems_ptr, tmp, sizeof(tmp));
            arr->using_buf = false;
        }
        else
            arr->elems_ptr = (char*)arr->realloc_fn(arr->elems_ptr, sizeof(char) * newcap);
        arr->cap = newcap;
    }

    if (!arr->using_buf) {
        arr->elems_ptr[arr->count - 1] = elem;
        arr->elems_ptr[arr->count++] = '\0';
    }
    else {
        arr->elems_buf[arr->count - 1] = elem;
        arr->elems_buf[arr->count++] = '\0';
    }
}

static inline char* hell_string_elems(HellString* arr)
{
    if (arr->using_buf)
        return arr->elems_buf;
    return arr->elems_ptr;
}

static inline const char* hell_string_elems_const(const HellString* arr)
{
    return hell_string_elems((HellString*)arr);
}

static inline void hell_string_print(const HellString* arr)
{
    const char *elems = hell_string_elems_const(arr);
    for (unsigned int i = 0; i < arr->count; ++i) {
        putchar(elems[i]);
    }
    putchar('\n');
}

static inline void hell_string_fill(HellString* arr, const char* other)
{
    const int other_size = strlen(other);
    for (int i = 0; i < other_size; ++i) {
        hell_string_push(arr, other[i]);
    }
}

static inline void hell_string_free(HellString* arr)
{
    if (!arr->using_buf && arr->elems_ptr)
        arr->realloc_fn(arr->elems_ptr, 0);
    memset(arr, 0, sizeof(*arr));
}

typedef struct {
    HellString* elems;
    int  count;
    int  cap;
    HellReallocFn realloc_fn;
} HellArrayString;

static inline HellArrayString hell_array_string_create(unsigned int cap, HellReallocFn realloc_fn)
{
    HellArrayString arr = {0};
    arr.cap = cap;
    arr.realloc_fn = realloc_fn;
    if (!arr.realloc_fn)
        arr.realloc_fn = hell_realloc;
    arr.elems = (HellString*)arr.realloc_fn(arr.elems, sizeof(HellString) * cap);
    return arr;
}

static inline void hell_array_string_push(HellArrayString* arr, HellString elem) 
{
    if (arr->count >= arr->cap) {
        assert(arr->cap > 0);
        int newcap = arr->cap * 2;
        arr->elems = (HellString*)arr->realloc_fn(arr->elems, sizeof(HellString) * newcap);
        arr->cap = newcap;
    }
    arr->elems[arr->count++] = elem;
}

static inline void hell_array_string_free(HellArrayString* arr)
{
    if (arr->elems) {
        HellString* iter = arr->elems;
        for (int i = 0; i < arr->count; i++)
            hell_string_free(iter++);
        arr->realloc_fn(arr->elems, 0);
    }
    memset(arr, 0, sizeof(*arr));
}

static inline int hell_array_string_size(HellArrayString* arr)
{
    return arr->count;
}

typedef struct DynArray {
    int64_t count;
    int64_t cap;
    void *elems;
    HellReallocFn realloc;
} DynArray;

static inline void arr_set_cap(DynArray* ar, int64_t cap, int64_t esize)
{
    if (cap < ar->cap)
        ar->count = cap;
    assert(ar->realloc);
    ar->cap = cap;
    void* tmp = (void*)ar->realloc(ar->elems, ar->cap * esize);
    // tmp might be NULL if cap of 0 is given
    if (!tmp && cap) assert(0);
    ar->elems = tmp;
}

static inline void arr_init(HellReallocFn realloc_fn, DynArray* ar)
{
    memset(ar, 0, sizeof(*ar));
    if (!realloc_fn)
        realloc_fn = realloc;
    ar->realloc = realloc_fn;
    // need to initialize the pointer.
    // lots of these methods assume they can do pointer artihermetic, but this
    // is undefined for a null pointer.
    // ar->elems = ar->realloc(NULL, 0);
}

static inline DynArray arr_create(HellReallocFn realloc_fn)
{
    DynArray ar;
    arr_init(realloc_fn, &ar);
    return ar;
}

static inline void* arr_elem(DynArray* ar, int64_t index, int64_t esize)
{
    return (char*)ar->elems + index * esize;
}

static inline void arr_set(DynArray* ar, int64_t index, void* elem, int64_t esize)
{
    char* dst = (char*)ar->elems + index * esize;
    char* src = (char*)elem;
    for (int64_t i = 0; i < esize; ++i) {
        dst[i] = src[i];
    }
}

static inline int arr_push(DynArray* ar, void* elem, int64_t esize)
{
    if (ar->count == ar->cap) {
        arr_set_cap(ar, ar->cap * 2 + 1, esize);
    }
    arr_set(ar, ar->count++, elem, esize);
    return ar->count - 1;
}

static inline void arr_free(DynArray* ar)
{
    arr_set_cap(ar, 0, 1);
}

static inline void arr_set_count(DynArray* ar, int64_t count, int64_t esize)
{
    if (count > ar->cap)
        arr_set_cap(ar, count, esize);
    ar->count = count;
}

#define arr_foreach_mutable(ar, var) \
    for (typeof((ar).elems) var = (ar).elems; var < (ar).elems + (ar).count; ++var) 

#define arr_foreach(ar, var) \
    for (const typeof((ar).elems[0])* var = (ar).elems; var < (ar).elems + (ar).count; ++var) 

#define arr_iter_index(ar, iter) \
    (iter - ar.elems)

#define define_array_type(T, t) \
    typedef struct T##Array { \
        int64_t count; \
        int64_t cap; \
        T *elems; \
        HellReallocFn realloc; \
    } T##Array; \
    \
    static inline void t##_arr_set_cap(T##Array* ar, int64_t cap) { \
        arr_set_cap((DynArray*)ar, cap, sizeof(T)); \
    } \
    static inline void t##_arr_init(HellReallocFn realloc_fn, T##Array* ar) { \
        arr_init(realloc_fn, (DynArray*)ar); \
    } \
    static inline T##Array t##_arr_create(HellReallocFn realloc_fn) { \
        T##Array ar; \
        arr_init(realloc_fn, (DynArray*)&ar); \
        return ar; \
    } \
    static inline int64_t t##_arr_push(T##Array* ar, T elem) { \
        return arr_push((DynArray*)ar, &elem, sizeof(T)); \
    } \
    static inline void t##_arr_set_count(T##Array* ar, int64_t count) { \
        arr_set_count((DynArray*)ar, count, sizeof(T)); \
    } \
    static inline T* t##_arr_last(T##Array* ar) { \
        return ar->elems + ar->count - 1; \
    } \
    static inline const T* t##_arr_last_const(const T##Array* ar) { \
        return ar->elems + ar->count - 1; \
    } \
    static inline T* t##_arr_end(T##Array* ar) { \
        return ar->elems + ar->count; \
    } \
    static inline const T* t##_arr_end_const(const T##Array* ar) { \
        return ar->elems + ar->count; \
    } \
    static inline T* t##_arr_begin(T##Array* ar) { \
        return ar->elems; \
    } \
    static inline const T* t##_arr_begin_const(const T##Array* ar) { \
        return ar->elems; \
    } \
    static inline int64_t t##_arr_find(const T##Array* ar, const T* elem) { \
        for (int64_t i = 0; i < ar->count; ++i) { \
            if (memcmp(elem, ar->elems + i, sizeof(T)) == 0) \
                return i; \
        } \
        return -1; \
    } \
    static inline bool t##_arr_contains(const T##Array* ar, const T* elem) { \
        return (t##_arr_find(ar, elem) != -1); \
    } \
    static inline void t##_arr_free(T##Array* ar) { \
        arr_free((DynArray*)ar); \
    } \
    static inline void t##_arr_push_if_unique(T##Array* ar, const T* elem) { \
        if (! t##_arr_contains(ar, elem)) \
            t##_arr_push(ar, *elem); \
    }

#define define_static_array_type_named(name, T, t, N) \
    typedef struct { \
        int count; \
        T elems[N]; \
    } name; \
    \
    static inline int t##_starr_push(name* ar, T elem) { \
        assert(ar->count < N); \
        ar->elems[ar->count++] = elem; \
        return 0; \
    } \

#define define_static_array_type(T, t, N) \
    define_static_array_type_named(T##StArray, T, t, N)

typedef int Int;
define_array_type(Int, int);

typedef unsigned char byte;
typedef unsigned char Byte;
define_array_type(Byte, byte);

#ifdef __cplusplus
}
#endif

#endif /* end of include guard: HELL_DS_H */
