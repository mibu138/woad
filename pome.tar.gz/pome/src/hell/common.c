#include "common.h"
#include "cmd.h"
#include "input.h"
#include "io.h"
#include "len.h"
#include "platform.h"
#include "window.h"
#include <assert.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef UNIX
#include <dlfcn.h>
#include <unistd.h>
#elif defined(WIN32)
#include <winbase.h>
#endif

#define MAX_PRINT_MSG 256

static char errorMsgBuffer[MAX_PRINT_MSG];

#define HEADER "HELL: "

void
hell_print2(const char* fmt, ...)
{
    va_list argptr;
    char    msg[MAX_PRINT_MSG];
    int64_t c = 0;
    va_start(argptr, fmt);
    c += vsnprintf(msg + c, sizeof(msg), fmt, argptr);
    //c += sprintf(msg + c, "\n");
    va_end(argptr);
    fputs(msg, stdout);
#if WIN32
    OutputDebugString(msg);
#endif
    hell_write_to_log(msg);
}

void
hell_print(const char* fmt, ...)
{
    va_list argptr;
    char    msg[MAX_PRINT_MSG];
    int64_t c = 0;
    va_start(argptr, fmt);
    c += vsnprintf(msg + c, sizeof(msg), fmt, argptr);
    assert(c < MAX_PRINT_MSG - 2);
    c += sprintf(msg + c, "\n");
    va_end(argptr);
    fputs(msg, stdout);
#if WIN32
    OutputDebugString(msg);
#endif
    hell_write_to_log(msg);
}

void
hell_announce(const char* fmt, ...)
{
    va_list argptr;
    char    msg[MAX_PRINT_MSG];
    int     l = 0;
    l += sprintf(msg + l, HEADER);
    va_start(argptr, fmt);
    vsnprintf(msg + l, sizeof(msg) - l, fmt, argptr);
    va_end(argptr);
    fputs(msg, stdout);
#if WIN32
    OutputDebugString(msg);
#endif
    hell_write_to_log(msg);
}

void
hell_abort(void)
{
    abort();
}

void
hell_error(HellErrorCode errorCode, const char* fmt, ...)
{
    va_list       argptr;
    const int64_t len = sizeof(errorMsgBuffer);
    int64_t       c   = 0;
    c += sprintf(errorMsgBuffer + c, "***ERROR: ***\n");
    c += sprintf(errorMsgBuffer + c, "HELL: ");
    va_start(argptr, fmt);
    c += vsnprintf(errorMsgBuffer + c, len - c, fmt, argptr);
    va_end(argptr);
    c += snprintf(errorMsgBuffer + c, len - c, "Errno %d\n", errno);
    fputs(errorMsgBuffer, stderr);
#if WIN32
    OutputDebugString(errorMsgBuffer);
#endif
    hell_write_to_log(errorMsgBuffer);
    if (errorCode == HELL_ERR_FATAL)
        hell_abort();
}

void
hell_error_fatal_impl(const char* fmt, ...)
{
    va_list       argptr;
    const int64_t len = sizeof(errorMsgBuffer);
    int64_t       c   = 0;
    c += sprintf(errorMsgBuffer + c, "*** ERROR ***\n");
    va_start(argptr, fmt);
    c += vsnprintf(errorMsgBuffer + c, len - c, fmt, argptr);
    va_end(argptr);
    c += snprintf(errorMsgBuffer + c, len - c, "Errno %d\n", errno);
    fputs(errorMsgBuffer, stderr);
#if WIN32
    OutputDebugString(errorMsgBuffer);
#endif
    hell_write_to_log(errorMsgBuffer);
    hell_abort();
}

uint64_t
hell_align(const uint64_t quantity, const uint32_t alignment)
{
    assert(alignment != 0);
    if (quantity % alignment != 0) // not aligned
        return (quantity / alignment + 1) * alignment;
    else
        return quantity;
}

void
hell_bit_print(const void* const thing, const uint32_t bitcount)
{
    int mask;
    for (int i = bitcount - 1; i >= 0; i--)
    {
        mask = 1 << i;
        if (mask & *(int*)thing)
            putchar('1');
        else
            putchar('0');
    }
    putchar('\n');
}

void
hell_byte_print(const void* const thing, const uint32_t byteCount)
{
    int            mask;
    const uint8_t* base = (uint8_t*)thing;
    for (int i = byteCount - 1; i >= 0; i--)
    {
        for (int j = 8 - 1; j >= 0; j--)
        {
            mask = 1 << j;
            if (mask & *(base + i))
                putchar('1');
            else
                putchar('0');
        }
    }
    putchar('\n');
}

void
hell_print_vec3(const float v[3])
{
    hell_print("[ %f, %f, %f]", v[0], v[1], v[2]);
}

void
hell_print_mat4(const float m[4][4])
{
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            printf("%f ", m[i][j]);
        }
        printf("\n");
    }
}

void*
hell_load_library(const char* name)
{
#ifdef UNIX
    return dlopen(name, RTLD_LAZY);
#elif defined(WIN32)
    return LoadLibrary(name);
#endif
}

void*
hell_load_symbol(void* module, const char* symname)
{
#ifdef UNIX
    return dlsym(module, symname);
#elif defined(WIN32)
    return GetProcAddress(module, symname);
#endif
}

bool
hell_file_exists(const char* path)
{
#ifdef UNIX
    return (access(path, F_OK) == 0);
#elif defined(WIN32)
    WIN32_FIND_DATA findData;
    HANDLE          handle = FindFirstFile(path, &findData);
    bool            found  = handle != INVALID_HANDLE_VALUE;
    if (found)
        FindClose(handle);
    return found;
#endif
}

void
hell_sleep(double s)
{
    uint64_t us = (s * 1000000);
#ifdef UNIX
    usleep(us);
#elif defined(WIN32)
    Sleep(us / 1000);
#endif
}

void hell_nano_sleep(int64_t ns)
{
    time_t s = ns / 1000000000;
    long nanosecs = ns % 1000000000;
    struct timespec ts = {
        .tv_sec = s,
        .tv_nsec = nanosecs,
    };
    nanosleep(&ts, NULL);
}

void hell_micro_sleep(uint64_t us)
{
#ifdef UNIX
    usleep(us);
#elif defined(WIN32)
    Sleep(us / 1000);
#endif
}
