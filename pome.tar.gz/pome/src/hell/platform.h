#ifndef HELL_PLATFORM_H
#define HELL_PLATFORM_H

#ifdef WIN32
#elif UNIX
#else
#error "Platform not supported"
#endif

#endif // end of HELL_PLATHFORM_H include gaurd
