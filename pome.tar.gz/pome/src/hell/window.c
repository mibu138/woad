#include "window.h"
#include "common.h"
#include "evcodes.h"
#include "input.h"
#include "platform.h"
#include "private.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>

#if defined(UNIX)
#include "unix_window.h"
#elif defined(WIN32)
#include "win32_window.h"
#endif

// number of windows created since program start.
// start counter at 1 so 0 is free to have special meaning
static HellWindowID globalWindowCounter = 1; 

static bool onWindowResize(const HellEvent* event, void* windowPtr)
{
    if (event->type != HELL_EVENT_TYPE_RESIZE)
        return false;
    HellWindow* window = (HellWindow*)windowPtr;
    window->width = event->data.win_data.data.resize_data.width;
    window->height = event->data.win_data.data.resize_data.height;
    // do not consume event 
    return false;
}

void
hell_create_window(const uint16_t width, const uint16_t height, const char* name,
                  HellWindow* window)
{
    // once we support other platforms we can put a switch in here
    memset(window, 0, sizeof(HellWindow));
    window->id = globalWindowCounter++;
#if defined(UNIX)
    createXcbWindow(width, height, name, window);
#elif defined(WIN32)
    createWin32Window(queue, width, height, name, window);
#endif
    assert(globalWindowCounter < HELL_WINDOW_ID_MAX);
}

void
hell_drain_window_events(HellEventQueue* queue, HellWindow* window)
{
#if defined(UNIX)
    drainXcbEventQueue(queue, window);
#elif defined(WIN32)
    drainMsEventQueue();
#endif
}

void
hell_destroy_window(HellWindow* window)
{
#if defined(UNIX)
    destroyXcbWindow(window);
#elif defined(WIN32)
    destroyWin32Window(window);
#endif
    memset(window, 0, sizeof(HellWindow));
    hell_announce("Display shutdown.\n");
}

#ifdef UNIX
const void*
hell_get_xcb_connection(const HellWindow* window)
{
    assert(window->type == HELL_WINDOW_XCB_TYPE);
    return ((HellXcbWindow*)window->type_specific_data)->connection;
}

const void*
hell_get_xcb_window_ptr(const HellWindow* window)
{
    assert(window->type == HELL_WINDOW_XCB_TYPE);
    return &((HellXcbWindow*)window->type_specific_data)->window;
}
#elif WIN32
void*
hell_get_hinstance_ptr(const HellWindow* window)
{
    assert(window->type == HELL_WINDOW_WIN32_TYPE);
    return &((Win32Window*)window->type_specific_data)->hinstance;
}
void*
hell_get_hwnd_ptr(const HellWindow* window)
{
    assert(window->type == HELL_WINDOW_WIN32_TYPE);
    return &((Win32Window*)window->type_specific_data)->hwnd;
}
void 
hell_set_hinstance(HINSTANCE hinstance)
{
    winVars.instance = hinstance;
}
#endif

HellWindowID 
hell_get_window_i_d(const HellWindow* window)
{
    return window->id;
}

uint32_t hell_get_window_width(const HellWindow* window)
{
    return window->width;
}

uint32_t hell_get_window_height(const HellWindow* window)
{
    return window->height;
}
