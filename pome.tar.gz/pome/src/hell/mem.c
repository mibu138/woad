#include "common.h"
#include <string.h>
#include <stdlib.h>

void* hell_malloc(size_t size)
{
    void* ptr = malloc(size);
    if (!ptr)
        hell_error(HELL_ERR_FATAL, "Allocation failed\n");
    return ptr;
}

void hell_free(void* ptr)
{
    free(ptr);
}

void* hell_realloc(void* ptr, size_t size)
{
    void* newptr = realloc(ptr, size);
    if (!newptr && size != 0)
        hell_error(HELL_ERR_FATAL, "Allocation failed\n");
    ptr = newptr;
    return ptr;
}

char* hell_copy_string(const char* in)
{
    char* out = hell_malloc(strlen(in) + 1);
    strcpy(out, in); //includes the terminating null
    return out;
}

// DO NOT USE. BAD. CAUSES ILLEGAL INSTRUCTIONS IN ZIG.
// POSSIBLE ALIGNMENT ISSUES
//struct hell_stack_allocator hell_create_stack_allocator()
//{
//    struct hell_stack_allocator a = {
//        .mark = 0,
//    };
//    return a;
//}
//
//void *hell_stack_alloc(struct hell_stack_allocator *allocator, size_t size)
//{
//    assert(allocator->mark + size < sizeof(allocator->buf));
//    void *ret = allocator->buf + allocator->mark;
//    allocator->mark += size;
//    return ret;
//}
