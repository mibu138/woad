#ifndef HELL_COMMON_H
#define HELL_COMMON_H

#include "cmd.h"
#include "input.h"
#include "memory.h"
#include "types.h"
#include "window.h"
#include <stdbool.h>
#include <stddef.h>

typedef enum { HELL_ERR_FATAL, HELL_ERR_MILD } HellErrorCode;

typedef void (*HellFrameFn)(HellFrame frameNumber,
                            HellTick  dt /*microseconds*/);
typedef void (*HellShutDownFn)(void);

typedef enum {
    HELL_OPTION_RECORD_INPUT_BIT       = 1 << 0,
    HELL_OPTION_ENABLE_TTY_CONSOLE_BIT = 1 << 1
} HellOptionFlagBits;

typedef struct hell_window HellWindow;
typedef struct hell {
    HellGrimoire   *grimoire;
    HellEventQueue *eventqueue;
    HellConsole    *console;
    HellWindow    **windows;
    uint32_t        window_count;
    HellFrameFn     user_frame;
    HellShutDownFn  user_shut_down;
    i64             frame_count;
    i64             target_frame_duration;
    HellTick        frame_start;
    HellTick        frame_delta;
    HellEvent      *frame_event_stack;
    int             frame_event_count;
    uint32_t        options;
    HellArray       recorded_input;
    // for performance analysis
    HellTick        last_frame_application_time;
} Hell;

typedef struct hell_allocator {
    void *user_data;
    void *(*alloc)(void *user_data, size_t size);
    void  (*free)(void *user_data, void *memory, size_t size);
} HellAllocator;

typedef Hell      HellMouth;
typedef HellMouth HellContext;

void hell_print(const char *fmt, ...);
// this one will insert a new line automatically
void hell_print(const char *fmt, ...);
void hell_print_vec3(const float[3]);
void hell_print_mat4(const float[4][4]);
void hell_announce(const char *fmt, ...);
void hell_error(HellErrorCode code, const char *fmt, ...);
void hell_error_fatal_impl(const char *fmt, ...);

// the ## makes the variable args optional (otherwise you need to give at least
// 1)
#define hell_error_fatal(fmt, ...)                                             \
    hell_error_fatal_impl("%s:%d:%s() ...\n%s\n", __FILE__, __LINE__,          \
                          __func__, fmt, ##__VA_ARGS__)

// returns time since epoch in microseconds
HellTick hell_time(void);

void hell_nano_sleep(int64_t ns);

// return a smallest integer greater than or equal to quantity that satisfies
// alignment
uint64_t hell_align(const uint64_t quantity, const uint32_t alignment);
void     hell_bit_print(const void *const thing, const uint32_t bitcount);
void     hell_byte_print(const void *const thing, const uint32_t byteCount);
void        hell_exit(int code);
// sleep for s seconds
void        hell_sleep(double s);
void        hell_micro_sleep(uint64_t us);


HellEventQueue *hell_get_event_queue(Hell *h);

// platform agnostic library loading
void *hell_load_library(const char *name);
void *hell_load_symbol(void *module, const char *symname);

bool hell_file_exists(const char *path);

uint64_t hell_size_of_grimoire(void);
uint64_t hell_size_of_console(void);
uint64_t hell_size_of_event_queue(void);
uint64_t hell_size_of_window(void);
uint64_t hell_size_of_hellmouth(void);

static inline bool hell_is_power_of_two(int64_t x)
{
    return x && (!(x & (x - 1)));
}

#ifdef HELL_SIMPLE_NAMES
#define HELL_SIMPLE_FUNCTION_NAMES
#define HELL_SIMPLE_TYPE_NAMES
#endif

#ifdef HELL_SIMPLE_FUNC_NAMES
#define HELL_SIMPLE_FUNCTION_NAMES
#endif
#ifdef HELL_SIMPLE_FUNCTION_NAMES
#define Print(...) hell_print(__VA_ARGS__)
#define OpenMouth(...) hell_open_mouth(__VA_ARGS__)
#define OpenHellmouth_NoConsole(...) hell_open_hellmouth_no_console(__VA_ARGS__)
#define Loop(...) hell_loop(__VA_ARGS__)
#define error_fatal hell_error_fatal
#define print hell_print
#define malloc hell_malloc
#define free hell_free
#endif

#ifdef hell_array_alloc2
#error "hell_array_alloc already defined!"
#else
#define hell_array_alloc(arr, count)                                           \
    ((arr) = hell_malloc(sizeof(arr[0]) * (count)))
#endif

#ifdef HELL_SIMPLE_TYPE_NAMES
typedef HellMouth Hellmouth;
typedef HellMouth Mouth;
typedef HellEvent Event;
#endif

#endif /* end of include guard: HELL_COM_H */
