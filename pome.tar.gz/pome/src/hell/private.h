#ifndef HELL_PRIVATE_H
#define HELL_PRIVATE_H

#include "types.h"

typedef enum {
    HELL_WINDOW_XCB_TYPE,
    HELL_WINDOW_WIN32_TYPE
} HellWindowType;

typedef struct hell_window {
    uint16_t       width;
    uint16_t       height;
    HellWindowID   id;
    HellWindowType type;
    void*           type_specific_data;
} HellWindow;

#endif /* end of include guard: HELL_PRIVATE_H */
