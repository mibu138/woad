// client

#include "common.h"

void cl_Init(void)
{
    hell_announce("Client initialized.\n");
}
