#ifndef HELL_GRAPH_H
#define HELL_GRAPH_H

#include "ds.h"

/// pi is the parent of the vertex
/// the adj list contains the children
typedef struct {
    struct {
        int d, f, color, pi, distance;
    } md;
    IntArray adj;
} HellVertex;

define_array_type(HellVertex, hell_vertex);

typedef struct {
    HellVertexArray verts;
    int time;
    bool cycle_found;
} HellGraph;

typedef struct {
    uint32_t prune_unconnected : 1;
} HellGraphSortingParms;

// its up to you to interpret the meaning of a vertex
// each vertex conceptually in an id but the id isn't explicitly stored in the graph anywhere.
// the vertex's id is its index in the vertex array, which remains constant.
void hell_create_graph(int number_of_verts, HellGraph* g);
void hell_destroy_graph(HellGraph* g);
void hell_graph_add_input_to_vertex(HellGraph* g, int vert, int input);
int hell_graph_dfs(HellGraph* g, int src_vert);
int* hell_graph_vert_children(const HellGraph* r, int parent, int *count);
// 0 on success, -1 on error
int  hell_graph_build_edges(HellGraph *g, void *user_data,
                            bool (*create_edge)(int parent, int child,
                                               void *user_data));
// note is directed, order matters
bool hell_graph_is_edge(const HellGraph* g, int p, int c);

bool hell_graph_is_orphan(const HellGraph *g, int v);

// caller must free these arrays
IntArray hell_graph_find_orphans(const HellGraph *g, int output);
IntArray hell_graph_topological_sort(HellGraph* g, int final_vert, HellGraphSortingParms parms);

#endif
