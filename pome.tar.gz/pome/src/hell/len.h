#ifndef HELL_LEN_H
#define HELL_LEN_H

#define LEN(x)  (sizeof(x) / sizeof((x)[0]))
#define bounds_check(ptr, arr) \
    (assert((char*)(ptr) - (char*)(arr) < sizeof(arr)))
#define MEMBER_SIZE(T, m) (sizeof(((T*)0)->m))
#define MEMBER_LEN(T, m) (MEMBER_SIZE(T,m) / sizeof(((T*)0)->m[0]))
#define zero(x) memset((x), 0, sizeof(*(x)))
#define structs_equal(s1, s2) (memcmp((s1), (s2), sizeof(*(s1))) == 0)

#define array_alloca(T, name, count) \
    T *name = alloca((count) * sizeof(T))

#endif
