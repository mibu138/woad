#ifndef HELL_ATTRIBUTES_H
#define HELL_ATTRIBUTES_H

#ifdef UNIX
#define HELL_UNUSED __attribute__((unused))
#define NODISCARD __attribute__((warn_unused_result))
#else 
#define HELL_UNUSED
#endif

#endif // HELL_ATTRIBUTE_H
