#include "common.h"
#define STB_DS_IMPLEMENTATION
#define STBDS_REALLOC(c,p,s) hell_realloc(p,s)
#define STBDS_FREE(c,p) hell_free(p)
#include "stb_ds.h"
#include "ds.h"
#include <string.h>
#include <assert.h>

static void growArray(HellArray* stack)
{
    assert(stack->capacity < UINT32_MAX / 2);
    u32 newCap = stack->capacity * 2;
    stack->elems = stack->realloc_fn(stack->elems, newCap * stack->elem_size);
    if (!stack->elems)
        hell_error(HELL_ERR_FATAL, "Stack growth failed.\n");
    stack->capacity = newCap;
}

static void* arrayPtr(HellArray* stack)
{
    return (u8*)stack->elems + stack->count * stack->elem_size;
}

static void* arrayLastElemPtr(HellArray* stack)
{
    return (u8*)stack->elems + (stack->count - 1) * stack->elem_size;
}

// if userAlloc is null will default to HellMalloc
void  hell_create_array_old(u32 capacity, u32 elem_size, HellAllocFn userAlloc, HellReallocFn userRealloc, HellArray* array)
{
    assert(array);
    assert(capacity > 0);
    assert(elem_size > 0);
    memset(array, 0, sizeof(*array));
    array->capacity = capacity;
    array->elem_size = elem_size;
    if (userRealloc)
        array->realloc_fn = userRealloc;
    else
        array->realloc_fn = hell_realloc;
    if (userAlloc)
        array->elems = userAlloc(capacity * elem_size);
    else
        array->elems = hell_malloc(capacity * elem_size);
    if (!array->elems)
        hell_error(HELL_ERR_FATAL, "Stack allocation failed.\n");
}

HellArray hell_create_array(size_t elem_size, size_t capacity, HellReallocFn reallocfn)
{
    HellArray arr = {0};
    hell_create_array_old(capacity, elem_size, NULL, reallocfn, &arr);
    return arr;
}

void* hell_array_push(HellArray* restrict arr, const void* restrict elem)
{
    void* stkptr = arrayPtr(arr);
    memcpy(stkptr, elem, arr->elem_size);
    arr->count++;
    if (arr->count >= arr->capacity)
    {
        growArray(arr);
        stkptr = arrayPtr(arr);
    }
    return stkptr;
}

void hell_array_remove_swap(HellArray* arr, size_t i)
{
    void* elem = (char*)arr->elems + i * arr->elem_size;
    void* last_elem = (char*)arr->elems + (arr->count - 1) * arr->elem_size;
    memcpy(elem, last_elem, arr->elem_size);
    --(arr->count);
}

int   hell_array_putc(HellArray* a, char c)
{
    assert(a->elem_size == 1);
    hell_array_push(a, &c);
    return 0;
}

void  hell_array_pop(HellArray* stack, void* target)
{
    assert(stack->count > 0);
    void* lastel= arrayLastElemPtr(stack);
    memcpy(target, lastel, stack->elem_size);
    stack->count--;
}

void  hell_array_clear(HellArray* arr)
{
    memset(arr->elems, 0, arr->capacity);
    arr->count = 0;
}

// if userAlloc is null will default to HellFree
void  hell_destroy_array(HellArray* stack, HellFreeFn userFree)
{
    if (userFree)
        userFree(stack->elems);
    else
        hell_free(stack->elems);
    memset(stack, 0, sizeof(*stack));
}

void hell_array_free(HellArray* arr)
{
    // check so that we don't accidentally free twice
    if (arr->elems)
        arr->realloc_fn(arr->elems, 0);
    memset(arr, 0, sizeof(*arr));
}
