#ifndef HELL_SERVER_H
#define HELL_SERVER_H

void sv_Init(void);

#endif /* end of include guard: HELL_SERVER_H */
