#ifndef HELL_ERROR_H
#define HELL_ERROR_H

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif

static inline void fatal_error_impl(
        const char* func,
        const char* file,
        int line,
        const char *fmt, ...)
{
    char buf[500];
    va_list args;
    va_start(args, fmt);
    vsprintf(buf, fmt, args);
    va_end(args);
    fprintf(stderr, "\nFatal error!\n\t%s()\n\t%s:%d\n\t%s\n",
           func, file, line, buf);
    abort();
}

static inline void warning_impl(
        const char* func,
        const char* file,
        int line,
        const char *fmt, ...)
{
    char buf[500];
    va_list args;
    va_start(args, fmt);
    vsprintf(buf, fmt, args);
    va_end(args);
    fprintf(stderr, "\nWarning!\n\t%s()\n\t%s:%d\n\t%s\n",
           func, file, line, buf);
}

// the ## before the __VA_ARGS__ allows it to be or not to be
#define fatal_error(fmt, ...) \
    do {\
        fatal_error_impl(__func__, __FILE__, __LINE__, \
                fmt, ##__VA_ARGS__); \
    } while(0)

#define fatal_condition(cond, fmt, ...) \
    do {\
        if (cond) \
            fatal_error_impl(__func__, __FILE__, __LINE__, \
                    fmt, ##__VA_ARGS__); \
    } while(0)

#define warning(fmt, ...) \
    do {\
        warning_impl(__func__, __FILE__, __LINE__, \
                fmt, ##__VA_ARGS__); \
    } while(0)

#ifdef __cplusplus
}
#endif

#endif
