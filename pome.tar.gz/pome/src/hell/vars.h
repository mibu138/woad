#define HELL_VAR_NAME_MAX_FPS "maxFps"
