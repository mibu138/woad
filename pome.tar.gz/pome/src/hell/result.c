#include "result.h"
#include <string.h>

HellResult hell_result_single_code(u64 code, HellResultCodeType type)
{
    HellResult res = {0};
    res.code_count = 1;
    res.codes[0].type = type;
    res.codes[0].code = code;

    return res;
}
