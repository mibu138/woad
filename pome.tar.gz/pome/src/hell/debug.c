#include "debug.h"
#include "common.h"
#include "cmd.h"
#include "io.h"

#include <assert.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>

#define MAX_FILTERED_TAGS 32
#define MAX_DEBUG_MSG_LEN 512

static const char* filteredDebugTags[MAX_FILTERED_TAGS];
static int filterTagCount;


void hell_add_filter_tag(const char* tag)
{
    for (int i = 0; i < filterTagCount; i++)
    {
        if (strcmp(filteredDebugTags[i], tag) == 0) // tag already in list
            return;
    }
    filteredDebugTags[filterTagCount++] = tag;
    assert(filterTagCount < MAX_FILTERED_TAGS);
}

void hell_add_filter_tags(const unsigned int count, const char* tags[])
{
    for (int j = 0; j < count; j++)
    {
        for (int i = 0; i < filterTagCount; i++)
        {
            if (strcmp(filteredDebugTags[i], tags[j]) == 0) // tag already in list
                goto next;
        }
        filteredDebugTags[filterTagCount++] = tags[j];
        assert(filterTagCount < MAX_FILTERED_TAGS);
next:
        continue;
    }
}

// idea here is we always call this function in group of 3.
// if we match the filter with one of our tags then we skip the next 2 calls.
#define VALVE_OFF_POSITION 2
void hell_debug_print_impl(const char* fmt, ...)
{
    char debugMsg[MAX_DEBUG_MSG_LEN];

    va_list args;
    va_start(args, fmt);

    vsnprintf(debugMsg, MAX_DEBUG_MSG_LEN, fmt, args);
    for (int i = 0; i < filterTagCount; i++)
        if (strstr(debugMsg, filteredDebugTags[i]))
            return;
    va_end(args);

    fputs(debugMsg, stderr);
//#if WIN32
//    OutputDebugString(debugMsg);
//#endif
//    hell_write_to_log(debugMsg);
}

