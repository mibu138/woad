#ifndef HELL_CMD_H
#define HELL_CMD_H

#include <stdbool.h>
#include <stdint.h>

typedef struct HellGrimoire   HellGrimoire;
typedef struct HellEventQueue HellEventQueue;
// Grimoire cannot be const because running a command may add/remove another
// command
typedef void (*HellCmdFn)(HellGrimoire*, void* data);

typedef enum {
    HELL_VAR_ARCHIVE_BIT = 1 << 0,
} HellVarFlagBits;

typedef uint32_t HellVarFlags;

#ifdef HELL_VAR_VALUE_64_BIT
typedef double HellVarValue;
#else
typedef float HellVarValue;
#endif

typedef struct HellVar {
    char*            name;
    HellVarFlags    flags;
    HellVarValue    value;
    struct HellVar* next;
} HellVar;

void        hell_create_grimoire(HellEventQueue* queue, HellGrimoire* grim);
void        hell_destroy_grimoire(HellGrimoire* grim);
void        hell_add_command(HellGrimoire*, const char* cmdName, HellCmdFn,
                            void* data);
void        hell_add_command2(HellGrimoire* grim, const char* cmdName,
                             HellCmdFn function, void* data, uint32_t dataSize);
void        hell_remove_command(HellGrimoire* grim, const char* cmdName);
void        hell_add_text(HellGrimoire*, const char* text);
void        hell_add_n_text(HellGrimoire*, const char* text, unsigned int len);
void        hell_add_char(HellGrimoire*, const char c);
const char* hell_get_arg(const HellGrimoire* grim, unsigned int i);
int         hell_get_arg_c(const HellGrimoire* grim);
void        hell_incantate(HellGrimoire*);
void        hell_set_var(HellGrimoire*, const char* name, double value,
                        HellVarFlags flags);
HellVar* hell_get_var(HellGrimoire*, const char* name, double value,
                            HellVarFlags flags);
HellGrimoire   *hell_alloc_grimoire(void);

#endif /* end of include guard: HYDROGEN_CMD_H */
