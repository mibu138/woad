#include "common.h"
#include "input.h"
#include "private.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef HellCmdFn CommandFn;

#define MAX_CMD_NAME_LEN 32

typedef uint32_t VarFlags;

typedef struct Cmd {
    struct Cmd* next;
    char        name[MAX_CMD_NAME_LEN];
    void*       data;
    CommandFn   function;
} Cmd;

typedef HellVar Var;

#define MAX_CMD_BUFFER 16384
#define MAX_CMD_LINE 1024

#define MAX_TOKENS 4 // max tokens resulting from Cmd_TokenizeString
#define MAX_TOKEN_SIZE 64

typedef struct HellGrimoire {
    Cmd* commands;
    Var* variables;

    char cmd_text_buf[MAX_CMD_BUFFER];
    int  cmd_text_cursor;

    int      cmd_argc;
    char*    cmd_argv[MAX_TOKENS];
    char     cmd_tokenized[MAX_TOKEN_SIZE * MAX_TOKENS];
    uint32_t dirt;
} HellGrimoire;

// so we can rename the struct without having to change the signatures
typedef HellGrimoire Grim;

static Var*
findVar(const Grim* grim, const char* name)
{
    for (Var* var = grim->variables; var; var = var->next)
    {
        if (strcmp(name, var->name) == 0)
            return var;
    }
    return NULL;
}

static void
cmdListFn(HellGrimoire* grim, void* data)
{
    // could filter based on 2nd argument at some point
    // char* match = NULL;
    // if (cmdArgc > 1)
    //     match = cmdArgv[1];

    for (Cmd* cmd = grim->commands; cmd; cmd = cmd->next)
        hell_print("%s\n", cmd->name);
}

static void
cmdEchoFn(HellGrimoire* grim, void* data)
{
    for (int i = 1; i < grim->cmd_argc; i++)
        hell_print("%s ", grim->cmd_argv[i]);
    hell_print("\n");
}

static void
cmdSetVarFn(HellGrimoire* grim, void* data)
{
    const char* varname = hell_get_arg(grim, 1);
    const char* varval  = hell_get_arg(grim, 2);
    const Var*  var     = findVar(grim, varname);
    if (!var)
    {
        hell_print("Var %s does not exist\n", varname);
    }
    double val = strtof(varval, NULL);
    hell_set_var(grim, varname, val, 0);
}

static void
varListFn(HellGrimoire* grim, void* data)
{
    for (Var* var = grim->variables; var; var = var->next)
    {
        hell_print("%s: %f\n", var->name, var->value);
    }
}

static void
varSetFn(HellGrimoire* grim, void* data)
{
}

static void
tokenizeString(Grim* grim, const char* text)
{
    assert(text);
    grim->cmd_argc = 0;
    char* textOut = grim->cmd_tokenized;
    while (1) // text will be NUL terminated
    {
        while (*text && *text <= ' ') // skip whitespace
            text++;
        if (!*text) // all tokens parsed
            return;

        grim->cmd_argv[grim->cmd_argc++] = textOut;
        if (grim->cmd_argc > MAX_TOKENS)
        {
            hell_print("Too many tokens.\n");
            return;
        }

        while (*text > ' ') // while we are not on whitespace
            *textOut++ = *text++;

        *textOut++ = 0; // end on 0
        assert(textOut - grim->cmd_tokenized < MAX_TOKEN_SIZE * MAX_TOKENS);
        if (!*text)
            return;
    }
}

static void
execute(Grim* grim, const char* line)
{
    Cmd *cmd, **prev;
    tokenizeString(grim, line);
    if (!grim->cmd_argc)
    {
        return;
    }

    for (prev = &grim->commands; *prev; prev = &cmd->next)
    {
        cmd = *prev;
        if (strncmp(grim->cmd_argv[0], cmd->name, MAX_CMD_NAME_LEN) == 0)
        {
            // rearrange the links so that the command will be
            // near the head of the list next time it is used
            *prev          = cmd->next;
            cmd->next      = grim->commands;
            grim->commands = cmd;

            // perform the action
            if (!cmd->function)
            {
                // let the cgame or game handle it
                break;
            }
            else
            {
                cmd->function(grim, cmd->data);
            }
            return;
        }
    }
}

static void
cmdInit(Grim* grim)
{
    hell_add_command(grim, "cmdlist", cmdListFn, grim);
    hell_add_command(grim, "echo", cmdEchoFn, grim);
    hell_add_command(grim, "setvar", cmdSetVarFn, grim);
}

static void
varInit(Grim* grim)
{
    hell_add_command(grim, "varlist", varListFn, grim);
    hell_add_command(grim, "set", varSetFn, grim);
}

static bool
consoleEventHandler(const HellEvent* event, void* pGrimoire)
{
    HellGrimoire* grim = (HellGrimoire*)pGrimoire;
    hell_add_n_text(grim, event->data.con_data.ptr, event->data.con_data.ptr_len);
    hell_add_char(grim, '\n');
    return true;
}

const char*
hell_get_arg(const Grim* grim, unsigned int i)
{
    if (i >= grim->cmd_argc)
        return ""; // we set to empty string so user can just go straight to
                   // strncmp'ing
    return grim->cmd_argv[i];
}

int
hell_get_arg_c(const Grim* grim)
{
    return grim->cmd_argc;
}

void
hell_add_command(HellGrimoire* grim, const char* cmdName, HellCmdFn function,
                void* data)
{
    assert(strnlen(cmdName, MAX_CMD_NAME_LEN) < MAX_CMD_NAME_LEN);
    Cmd* cmd;
    for (cmd = grim->commands; cmd; cmd = cmd->next)
    {
        if (!strncmp(cmdName, cmd->name, MAX_CMD_NAME_LEN))
        {
            hell_print("Cmd_AddCommand: %s already defined\n", cmdName);
            return;
        }
    }

    cmd = hell_malloc(sizeof(Cmd));
    strncpy(cmd->name, cmdName, MAX_CMD_NAME_LEN);
    cmd->function = function;
    cmd->data     = data;

    /* link the command in by name order */
    Cmd** pos = &grim->commands;
    while (*pos && strcmp((*pos)->name, cmdName) < 0)
        pos = &(*pos)->next;
    cmd->next = *pos;
    *pos      = cmd;
}

void
hell_remove_command(HellGrimoire* grim, const char* cmdName)
{
    assert(strnlen(cmdName, MAX_CMD_NAME_LEN) < MAX_CMD_NAME_LEN);
    Cmd *cmd, *prev;
    cmd  = grim->commands;
    prev = NULL;
    while (cmd)
    {
        if (strncmp(cmdName, cmd->name, MAX_CMD_NAME_LEN) == 0)
        {
            prev->next = cmd->next;
            hell_free(cmd);
            return;
        }
        prev = cmd;
        cmd  = cmd->next;
    }
}

void
hell_add_command2(HellGrimoire* grim, const char* cmdName, HellCmdFn function,
                 void* data, uint32_t dataSize)
{
    assert(strnlen(cmdName, MAX_CMD_NAME_LEN) < MAX_CMD_NAME_LEN);
    Cmd* cmd;
    for (cmd = grim->commands; cmd; cmd = cmd->next)
    {
        if (!strncmp(cmdName, cmd->name, MAX_CMD_NAME_LEN))
        {
            hell_print("Cmd_AddCommand: %s already defined\n", cmdName);
            return;
        }
    }

    cmd = hell_malloc(sizeof(Cmd));
    strncpy(cmd->name, cmdName, MAX_CMD_NAME_LEN);
    cmd->function = function;
    cmd->data     = hell_malloc(dataSize);
    memcpy(cmd->data, data, dataSize);

    /* link the command in by name order */
    Cmd** pos = &grim->commands;
    while (*pos && strcmp((*pos)->name, cmdName) < 0)
        pos = &(*pos)->next;
    cmd->next = *pos;
    *pos      = cmd;
}

void
hell_set_var(HellGrimoire* grim, const char* name, double value,
            const HellVarFlags flags)
{
    Var* var = findVar(grim, name);

    if (var)
    {
        var->value = value;
        var->flags |= flags;
        return;
    }

    var        = hell_malloc(sizeof(Var));
    var->name  = hell_copy_string(name);
    var->value = value;

    Var** pos = &grim->variables;
    while (*pos && strcmp((*pos)->name, var->name) < 0)
        pos = &(*pos)->next;
    var->next = *pos;
    *pos      = var;

    var->flags = flags;
}

Var*
hell_get_var(Grim* grim, const char* name, double value,
            const HellVarFlags flags)
{
    Var* var = findVar(grim, name);
    if (var)
    {
        var->flags |= flags;
        return var;
    }

    var        = hell_malloc(sizeof(Var));
    var->name  = hell_copy_string(name);
    var->value = value;

    Var** pos = &grim->variables;
    while (*pos && strcmp((*pos)->name, var->name) < 0)
        pos = &(*pos)->next;
    var->next = *pos;
    *pos      = var;

    var->flags = flags;
    return var;
}

void
hell_add_text(Grim* grim, const char* text)
{
    int l = strnlen(text, MAX_EDIT_LINE);

    if (grim->cmd_text_cursor + l >= MAX_CMD_BUFFER)
    {
        hell_error(0, "Cmd text buffer overflow");
    }
    memcpy(grim->cmd_text_buf + grim->cmd_text_cursor, text, l);
    grim->cmd_text_cursor += l;
}

void
hell_add_n_text(Grim* grim, const char* text, unsigned int l)
{
    if (grim->cmd_text_cursor + l >= MAX_CMD_BUFFER)
    {
        hell_error(0, "Cmd text buffer overflow");
    }
    memcpy(grim->cmd_text_buf + grim->cmd_text_cursor, text, l);
    grim->cmd_text_cursor += l;
}

void
hell_add_char(Grim* grim, const char c)
{
    if (grim->cmd_text_cursor + 1 >= MAX_CMD_BUFFER)
        hell_error(0, "%s cmd text buffer overflow", __FUNCTION__);
    grim->cmd_text_buf[grim->cmd_text_cursor++] = c;
}

void
hell_create_grimoire(HellEventQueue* queue, Grim* grim)
{
    memset(grim, 0, sizeof(HellGrimoire));
    cmdInit(grim);
    varInit(grim);
    hell_subscribe(queue, HELL_EVENT_MASK_CONSOLE_BIT, 0, consoleEventHandler,
                   grim);
}

void
hell_incantate(Grim* grim)
{
    int i = 0;
    while (grim->cmd_text_cursor)
    {
        char line[MAX_CMD_LINE];
        for (i = 0; i < grim->cmd_text_cursor; i++)
        {
            if (grim->cmd_text_buf[i] == '\n')
                break;
        }
        assert(i < MAX_CMD_LINE);
        memcpy(line, grim->cmd_text_buf, i);
        line[i] = 0;

        if (i == grim->cmd_text_cursor)
            grim->cmd_text_cursor = 0;
        else
        {
            i++;
            grim->cmd_text_cursor -= i;
            memmove(grim->cmd_text_buf, grim->cmd_text_buf + i,
                    grim->cmd_text_cursor);
        }

        execute(grim, line);
    }
}

void
hell_destroy_grimoire(Grim* grim)
{
    memset(grim, 0, sizeof(HellGrimoire));
}

uint64_t
hell_size_of_grimoire(void)
{
    return sizeof(HellGrimoire);
}

HellGrimoire*
hell_alloc_grimoire(void)
{
    return hell_malloc(sizeof(HellGrimoire));
}
