#ifndef HELL_XCB_WINDOW_TYPE_H
#define HELL_XCB_WINDOW_TYPE_H

#endif /* end of include guard: HELL_XCB_WINDOW_TYPE_H */
