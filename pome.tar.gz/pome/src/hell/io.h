#ifndef HELL_IO_H
#define HELL_IO_H

#include "error.h"
#include <stdint.h>
#include "ds.h"

#ifdef __cplusplus
extern "C" {
#endif

// if an error occurs, array does not need to be freed.
// otherwise it must be freed by caller.
int hell_read_file(const char *filepath, ByteArray *array);

int hell_write_file(const char *filepath, const void *bytes, size_t byte_count);

void hell_init_logger(void);
void hell_shutdown_logger(void);
void hell_write_to_log(const char* msg);

#ifdef __cplusplus
}
#endif

#endif /* end of include guard: HELL_IO_H */
