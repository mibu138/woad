// basic types. no include guard so that we can simplify the names at will.
// should only be simple typedefs otherwise we well get redefinition errors.

#include <stddef.h>
#include <stdbool.h>

#include "numerictypes.h"

typedef uint8_t  HellByte;
typedef uint64_t HellSize;
typedef int64_t HellTick;
typedef int64_t HellFrame;
typedef uint16_t HellWindowID;
#define HELL_WINDOW_ID_MAX UINT16_MAX

#ifdef HELL_SIMPLE_TYPE_NAMES
typedef HellByte Byte;
typedef HellSize Size;
typedef HellTick Tick;
typedef HellFrame Frame;
#endif

