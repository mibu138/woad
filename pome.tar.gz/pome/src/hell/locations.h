#ifndef HELL_LOCATIONS_H
#define HELL_LOCATIONS_H


#ifndef ROOT
#define ROOT "."
#endif

#endif /* end of include guard: HELL_LOCATIONS_H */
