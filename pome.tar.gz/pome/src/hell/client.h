#ifndef HELL_CLIENT_H
#define HELL_CLIENT_H

void cl_Init(void);

#endif /* end of include guard: HELL_CLIENT_H */

