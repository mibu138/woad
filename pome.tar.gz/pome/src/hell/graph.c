#include "graph.h"

enum {
    WHITE,
    GREY,
    BLACK
};

static const int NIL = -1;
static const int INF = INT32_MAX;

typedef HellVertex Vert;
typedef HellGraph Graph;

static int vert_color(const Vert* v)
{
    return v->md.color;
}

static int vert_distance(const Vert* v)
{
    return v->md.distance;
}

static int vert_predecessor(const Vert* v)
{
    return v->md.pi;
}

static void vert_set_predescessor(Vert* v, int i)
{
    v->md.pi = i;
}

static void vert_set_color(Vert* v, int color)
{
    v->md.color = color;
}

static void vert_set_distance(Vert* v, int dist)
{
    v->md.distance = dist;
}

static int nverts(const Graph* g)
{
    return g->verts.count;
}

static Vert* get_vert(Graph* g, int i)
{
    assert(i < g->verts.count);
    return &g->verts.elems[i];
}

static const Vert* get_vert_(const Graph* g, int i)
{
    assert(i < g->verts.count);
    return &g->verts.elems[i];
}

static void
vert_reset(Vert* v)
{
    memset(&v->md, 0, sizeof(v->md));
    vert_set_color(v, WHITE);
    vert_set_predescessor(v, NIL);
    vert_set_distance(v, INF);
}

static void
reset_vert(Graph* g, int id)
{
    Vert* v = get_vert(g, id);
    vert_reset(v);
}

static const Vert* get_vert_const(const Graph* g, int i)
{
    return get_vert_(g, i);
}

static void
dfsVisit(Graph* g, int uid)
{
    g->time++;
    Vert* u = get_vert(g, uid);
    u->md.d = g->time;
    u->md.color = GREY;
    arr_foreach(u->adj, pvid) {
        int vid = *pvid;
        Vert* v = get_vert(g, vid);
        if (v->md.color == WHITE) {
            v->md.pi = uid;
            dfsVisit(g, vid);
        } else if (v->md.color == GREY) {
#if 1
            printf("Cycle found at %d\n", vid);
#endif
            g->cycle_found = true;
            return;
        }
    }
    u->md.color = BLACK;
    g->time++;
    u->md.f = g->time;
}

// does not clear adjacency list
static void
reset_all_verts(Graph* g)
{
    int n = nverts(g);
    for (int i = 0; i < n; ++i) {
        reset_vert(g, i);
    }
}


void hell_create_graph(int n_verts, HellGraph* g)
{
    memset(g, 0, sizeof(*g));
    hell_vertex_arr_init(NULL, &g->verts);
    hell_vertex_arr_set_count(&g->verts, n_verts);
    for (int i = 0; i < n_verts; ++i) {
        int_arr_init(NULL, &g->verts.elems[i].adj);
    }
    reset_all_verts(g);
}

void hell_destroy_graph(HellGraph* g)
{
    for (int i = 0; i < g->verts.count; ++i) {
        int_arr_free(&g->verts.elems[i].adj);
    }
    hell_vertex_arr_free(&g->verts);
}

static void
check_for_cylces(HellGraph* g, int node)
{
    reset_all_verts(g);
    hell_graph_dfs(g, node);
}

void hell_graph_add_input_to_vertex(HellGraph* g, int node, int input)
{
    assert(node != input);
    int_arr_push_if_unique(&g->verts.elems[node].adj, &input);
    check_for_cylces(g, node);
}

int hell_graph_dfs(Graph* g, int src)
{
    assert(src >= 0);
    g->time = 0;
    g->cycle_found = false;
    Vert* v = get_vert(g, src);
    assert(v->md.color == WHITE);
    dfsVisit(g, src);
    if (g->cycle_found) {
        assert(0 && "Cycle found\n");
        return -1;
    }
    return 0;
}

int* hell_graph_vert_children(const HellGraph* r, int parent, int *count)
{
    assert(parent < r->verts.count);
    const Vert* p = get_vert_const(r, parent);
    *count = p->adj.count;
    return p->adj.elems;
}

bool
hell_graph_is_orphan(const HellGraph *g, int v)
{
    // search all the verts for v in their adj list.
    for (int i = 0; i < g->verts.count; ++i) {
        const Vert *vert = get_vert_(g, i);
        for (int i = 0; i < vert->adj.count; ++i) {
            int u = vert->adj.elems[i];
            if (u == v)
                return false;
        }
    }
    return true;
}

IntArray
hell_graph_find_orphans(const HellGraph *g, int output)
{
    IntArray out = int_arr_create(NULL);
    for (int v = 0, n = g->verts.count; v < n; ++v) {
        if (v == output)
            continue;
        if (hell_graph_is_orphan(g, v))
            int_arr_push(&out, v);
    }
    return out;
}

IntArray
hell_graph_topological_sort(HellGraph* g, int output, HellGraphSortingParms parms)
{
    assert(output >= 0);
    reset_all_verts(g);
    hell_graph_dfs(g, output);
    IntArray out = int_arr_create(NULL);
    int_arr_set_count(&out, g->verts.count);
    int *elems = out.elems;
    for (int i = 0; i < out.count; ++i) {
        elems[i] = i;
    }
    for (int j = 1; j < out.count; ++j) {
        int id = elems[j];
        int f  = get_vert(g, id)->md.f;
        int i  = j - 1;
        while (i >= 0 && get_vert(g, elems[i])->md.f > f) {
            elems[i + 1] = elems[i];
            i--;
        }
        elems[i + 1] = id;
    }
    if (parms.prune_unconnected) {
        IntArray newout = int_arr_create(NULL);
        for (int i = 0; i < out.count; ++i) {
            int v = elems[i];
            if (get_vert(g, v)->md.pi == NIL && v != output)
                continue;
            int_arr_push(&newout, v);
        }
        int_arr_free(&out);
        out = newout;
    }
    return out;
}

typedef struct {
    // increase monotonically
    int head, tail;
    int nelem;
    int *elems;
} Queue;

static void
queue_create(Queue* q, int nelem)
{
    memset(q, 0, sizeof(*q));
    q->elems = calloc(nelem, sizeof(*q->elems));
}

static void
queue_destory(Queue* q)
{
    free(q->elems);
}

static void
queue_push(Queue* q, int elem)
{
    assert(q->head - q->tail >= 0);
    assert(q->head - q->tail < q->nelem);
    int idx = q->head++;
    idx = idx % q->nelem;
    q->elems[idx] = elem;
}

static int
queue_pop(Queue* q)
{
    assert(q->head > q->tail);
    int idx = q->tail++;
    idx = idx % q->nelem;
    return q->elems[idx];
}

static bool 
queue_has_elems(const Queue* q)
{
    return q->head > q->tail;
}

typedef bool (*create_edge_fn)(int parent, int child, void *user_data);

int hell_graph_bfs(HellGraph *g, int root)
{
    assert(root < g->verts.count);
    reset_all_verts(g);
    Queue queue, *q = &queue;
    Vert* s = get_vert(g, root);
    vert_set_color(s, GREY);
    vert_set_distance(s, 0);
    vert_set_predescessor(s, NIL);

    queue_create(q, nverts(g));
    queue_push(q, root);

    while (queue_has_elems(q)) {
        int uid = queue_pop(q);
        Vert* u = get_vert(g, uid);
        for (int vid = 0; vid < u->adj.count; ++vid) {
            Vert* v = get_vert(g, vid);
            if (vert_color(v) != WHITE)
                continue;
            vert_set_color(v, GREY);
            vert_set_distance(v, vert_distance(u) + 1);
            vert_set_predescessor(v, uid);
            queue_push(q, vid);
        }
        vert_set_color(u, BLACK);
    }

    queue_destory(q);
    return 0;
}

int  hell_graph_build_edges(HellGraph *g, void *user_data, create_edge_fn create_edge)
{
    for (int u = 0; u < g->verts.count; ++u) {
        for (int v = 0; v < g->verts.count; ++v) {
            if (create_edge(u, v, user_data)) {
                hell_graph_add_input_to_vertex(g, u, v);
            }
        }
    }
    return 0;
}

bool hell_graph_is_edge(const HellGraph* g, int p, int c)
{
    const Vert* v = get_vert_const(g, p);
    return int_arr_contains(&v->adj, &c);
}
