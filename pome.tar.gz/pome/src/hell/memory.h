#ifndef HELL_MEMORY_H
#define HELL_MEMORY_H

#include "types.h"

// will error if allocation fails
void* hell_malloc(size_t size);
// will error if allocation fails
void* hell_realloc(void* ptr, size_t size);
void  hell_free(void* ptr);
char* hell_copy_string(const char* in);

/// Do not use this. It seems to have issues with aligning things.
/// Causes illegal instructions to be issued when running on zig
//typedef struct hell_stack_allocator {
//    int           mark;
//    unsigned char buf[1024];
//} HellStackAllocator;

//struct hell_stack_allocator hell_create_stack_allocator();
//void *hell_stack_alloc(struct hell_stack_allocator *allocator, size_t size);

#endif
