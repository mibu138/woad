#define HELL_SIMPLE_TYPE_NAMES
#define HELL_SIMPLE_FUNCTION_NAMES
#include "frame.h"
#include "client.h"
#include "cmd.h"
#include "common.h"
#include "input.h"
#include "io.h"
#include "minmax.h"
#include "private.h"
#include "server.h"
#include "stdlib.h"
#include "types.h"
#include "vars.h"
#include "window.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

typedef HellVar Var;

static void dummyUserFrame(HellFrame fi, HellTick dt)
{
    // no op we call in case user frame is not provided
    // may be an optimization? gets rid of an if statement in the loop
    // because we always call something
}

static Tick fpsToFrameDur(double fps) { return (1.0 / fps) * 1e9; }

static int hell_save_recorded_input(HellMouth *hm, const char *filepath)
{
    int   err = 0, num;
    FILE *fp  = fopen(filepath, "wb");
    if (!fp) {
        err = -1;
        goto end;
    }

    HellEvent *events = hm->recorded_input.elems;
    int        count  = hm->recorded_input.count;

    for (int i = 0; i < count; ++i) {
        num = fwrite(events + i, sizeof(*events), 1, fp);
        if (num != 1) {
            err = -1;
            goto end;
        }
    }

end:
    if (fp)
        fclose(fp);
    return err;
}

static void save_input_cmd(HellGrimoire *grim, void *data)
{
    hell_save_recorded_input(data, "recorded_input.hell");
}

int hell_open_mouth(uint32_t option_flags, HellMouth *hm)
{
    memset(hm, 0, sizeof(*hm));
    hm->eventqueue     = hell_alloc_event_queue();
    hm->grimoire       = hell_alloc_grimoire();
    hm->recorded_input = hell_create_array(sizeof(HellEvent), 4, hell_realloc);
    hm->console        = NULL;

    hell_create_event_queue(hm->eventqueue);
    hell_create_grimoire(hm->eventqueue, hm->grimoire);

    if ((option_flags & HELL_OPTION_ENABLE_TTY_CONSOLE_BIT)) {
        hm->console = hell_alloc_console();
        hell_create_console(hm->console);
    } else {
        Print("HELL_NO_TTY defined! No terminal\n");
        hm->console = NULL;
    }

    hell_add_command(hm->grimoire, "quit", hell_quit, hm);
    hell_add_command(hm->grimoire, "save_input", save_input_cmd, hm);
    const HellVar *dedicated = hell_get_var(hm->grimoire, "dedicated", 0, 0);
    sv_Init();
    if (!dedicated->value)
        cl_Init();
    hell_announce("Hellmouth created.\n");

    hm->frame_event_stack = hell_malloc(sizeof(HellEvent) * MAX_QUEUE_EVENTS);
    hell_start_clock();
    hm->frame_start = hell_time();
    return 0;
}

HellWindow *hell_hellmouth_add_window(HellMouth *hm, u16 w, u16 h,
                                      const char *name)
{
    const u32 i = hm->window_count++;
    // note realloc behaves as malloc if hm->windows == 0
    printf("Windows mem: %p\n", hm->windows);
    hm->windows =
        hell_realloc(hm->windows, hm->window_count * sizeof(HellWindow *));
    hm->windows[i] = hell_alloc_window();
    hell_create_window(w, h, name, hm->windows[i]);
    return hm->windows[i];
}

HellWindow *hell_get_window(HellMouth *hm, uint32_t window)
{
    assert(window < hm->window_count);
    return hm->windows[window];
}

void hell_frame(HellMouth *h)
{
    hell_push_frame_event(h->eventqueue, h->frame_count);
    hell_coagulate_input(h->eventqueue, h->console, h->window_count,
                         h->windows);
    hell_record_input(h->eventqueue, &h->recorded_input);
    hell_solve_input(h->eventqueue, h->frame_event_stack,
                     &h->frame_event_count);
    hell_incantate(h->grimoire);
}

const HellEvent *hell_get_events(HellMouth *h, int32_t *event_count)
{
    *event_count = h->frame_event_count;
    return h->frame_event_stack;
}

void hell_begin_frame(Hell *h)
{
    HellTick cur_time    = hell_time();
    h->frame_delta       = cur_time - h->frame_start;
    h->frame_start       = cur_time;
    h->frame_event_count = 0;
    hell_frame(h);
}

void hell_end_frame(Hell *h)
{
    // const HellVar* var_fps = hell_get_var(h->grimoire, "fps", 60.0, 0);
    h->last_frame_application_time = hell_time() - h->frame_start;
    h->frame_count++;
    // h->frame_delta = hell_time() - h->frame_start;
    // Tick target = fpsToFrameDur(var_fps->value);
    // hell_nano_sleep(MAX(target - h->frame_delta, 0));
    // h->frame_delta = hell_time() - h->frame_start;
}

void hell_destroy_hellmouth(HellMouth *h)
{
    for (int i = 0; i < h->window_count; i++) {
        hell_destroy_window(h->windows[i]);
    }
    hell_destroy_grimoire(h->grimoire);
    hell_destroy_event_queue(h->eventqueue);
    hell_destroy_console(h->console);
    hell_announce("Shut Down.\n");
    hell_shutdown_logger();
}

void hell_quit(HellGrimoire *grim, void *hellmouthvoid)
{
    HellMouth *hellmouth = (HellMouth *)hellmouthvoid;
    if (hellmouth->user_shut_down)
        hellmouth->user_shut_down();
    hell_destroy_hellmouth(hellmouth);
    exit(0);
}

void hell_exit(int code) { exit(code); }

void hell_close_hellmouth(HellMouth *hellmouth)
{
    if (hellmouth->user_shut_down)
        hellmouth->user_shut_down();
    hell_destroy_hellmouth(hellmouth);
}

void hell_close_and_exit(HellMouth *hm)
{
    hell_close_hellmouth(hm);
    hell_exit(0);
}

uint64_t hell_size_of_hellmouth(void) { return sizeof(HellMouth); }

HellMouth *hell_alloc_hellmouth(void) { return hell_malloc(sizeof(HellMouth)); }

int64_t hell_get_frame_number(Hell* h)
{
    return h->frame_count;
}

int64_t hell_get_frame_delta(Hell* h)
{
    return h->frame_delta;
}

HellEventQueue* hell_get_event_queue(Hell* h)
{
    return h->eventqueue;
}

void hell_loop(Hell* h, HellFrameFn user_frame)
{
    Tick start, delta, target;
    h->frame_event_stack = malloc(sizeof(HellEvent) * MAX_QUEUE_EVENTS);

    // vars should never be removed once an application starts, so it is safe to
    // hold onto a pointer to one.
    const HellVar* var_fps = hell_get_var(h->grimoire, "fps", 60.0, 0);

    hell_start_clock();
    hell_announce("Entering Hell Loop.\n");
    delta = fpsToFrameDur(var_fps->value);

    for (;;) {
        start = hell_time();
        h->frame_event_count = 0;
        hell_frame(h);
        user_frame(h->frame_count, delta);
        h->frame_count++;
        delta = hell_time() - start;
        target = fpsToFrameDur(var_fps->value);
        hell_nano_sleep(MAX(target - delta, 0));
        delta = hell_time() - start;
    }
}

