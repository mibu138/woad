#include "imgui/imgui.h"
#include "imgui/backends/imgui_impl_vulkan.h"
#include "imgui-filebrowser/imfilebrowser.h"
#include <onyx/onyx.h>

struct CruxContext {
    ImGuiContext* imgui_ctx = nullptr;
    VkDescriptorPool desc_pool = 0;
    std::unique_ptr<ImGui::FileBrowser> file_browser = nullptr;
    VkDevice device;
    VkRenderPass renderpass = nullptr;
    std::array<VkFramebuffer, MAX_SWAPCHAIN_IMAGES> framebuffers;
    uint32_t cur_width;
    uint32_t cur_height;
    uint64_t last_frame_uuid;
    uint8_t cur_framebuffer;
};

typedef CruxContext Ctx;

constexpr static VkImageLayout expected_initial_layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

static ImGuiKey_ imgui_key(uint8_t hell_key);
static void init_dark_theme(CruxContext *ctx);

static void on_window_size_change(CruxContext* ctx, const OnyxSwapchainImage *frame)
{
    auto& fb = ctx->framebuffers[frame->index];

    if (fb != VK_NULL_HANDLE)
        vkDestroyFramebuffer(ctx->device, fb, nullptr);

    CoalIvec2 dim = onyx_swapchain_image_dimensions(frame);
    VkImageView view = onyx_swapchain_image_view(frame);
    onyx_create_framebuffer(ctx->device,
            1, &view, dim.width, dim.height,
            ctx->renderpass, &fb);

    ctx->cur_width = dim.width;
    ctx->cur_height = dim.height;
}

extern "C" {

void crux_create_context(CruxContext* ctx, OnyxContext* onyx, const OnyxSwapchain *swap)
{
    *ctx = CruxContext();
    onyx_create_descriptor_pool(onyx->device, (OnyxDescriptorPoolParms){ 1000, 1000, 1000, 1000, 1000, 1000, 0},
                              &ctx->desc_pool);

    ctx->device = onyx->device;

    OnyxRenderPassDependencyInfo dep = {};
    dep.src.access_mask = VK_ACCESS_MEMORY_WRITE_BIT | VK_ACCESS_MEMORY_READ_BIT;
    dep.src.stage_mask = VK_PIPELINE_STAGE_ALL_COMMANDS_BIT;
    dep.dst.access_mask = VK_ACCESS_MEMORY_WRITE_BIT | VK_ACCESS_MEMORY_READ_BIT;;
    dep.dst.stage_mask = VK_PIPELINE_STAGE_ALL_COMMANDS_BIT;

    onyx_create_render_pass_color_(
            ctx->device, expected_initial_layout,
            VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
            VK_ATTACHMENT_LOAD_OP_LOAD,
            onyx_get_swapchain_format(swap),
            dep,
            &ctx->renderpass);

    for (int i = 0; i < ctx->framebuffers.size(); ++i) {
        ctx->framebuffers[i] = VK_NULL_HANDLE;
    }

    ctx->imgui_ctx = ImGui::CreateContext();
    ImGui_ImplVulkan_InitInfo iivi = {};
    iivi.Instance                  = *onyx_get_vk_instance(onyx->instance);
    iivi.PhysicalDevice            = onyx_get_physical_device(onyx->instance);
    iivi.Device                    = (VkDevice)onyx->device;
    iivi.QueueFamily = onyx_queue_family_index(onyx->instance, ONYX_QUEUE_GRAPHICS_TYPE);
    iivi.Queue = onyx_get_graphics_queue(onyx->instance, 0);
    iivi.DescriptorPool = ctx->desc_pool;
    iivi.MinImageCount  = 2;
    iivi.ImageCount     = swap->image_count;
    ImGui_ImplVulkan_Init(&iivi, ctx->renderpass);
    OnyxCommand cmd =
        onyx_create_command(onyx->instance, ONYX_QUEUE_GRAPHICS_TYPE);
    onyx_begin_command_buffer_one_time_submit(cmd.buffer);
    ImGui_ImplVulkan_CreateFontsTexture(cmd.buffer);
    onyx_end_command_buffer(cmd.buffer);
    onyx_submit_and_wait(&cmd, 0);
    onyx_destroy_command(cmd);
    ImGui_ImplVulkan_DestroyFontUploadObjects();

    init_dark_theme(ctx);
}

CruxContext* crux_allocate_context()
{
    return new CruxContext;
}

void crux_new_frame(CruxContext* ctx, const OnyxSwapchainImage *frame, float dt)
{
    if (onyx_swapchain_image_uuid(frame) != ctx->last_frame_uuid)
    {
        on_window_size_change(ctx, frame);
        ctx->last_frame_uuid = onyx_swapchain_image_uuid(frame);
    }
    ctx->cur_framebuffer = frame->index;

    ImGui_ImplVulkan_NewFrame();

    CoalIvec2 dim = onyx_swapchain_image_dimensions(frame);
    ImVec2 display_size(dim.x, dim.y);
    ImGuiIO& io            = ImGui::GetIO();
    io.DisplaySize         = display_size;
    io.DeltaTime           = (float)dt / 1e9f;
    ImGui::NewFrame();
}

bool crux_feed_input(CruxContext* ctx, const HellEvent* event)
{
    ImGuiIO& io = ImGui::GetIO();
    // printf("Got event: mask: %d type: %d\n", event->mask, event->type);
    if (event->mask & HELL_EVENT_MASK_POINTER_BIT)
    {
        int x, y;
        x             = hell_get_mouse_x(event);
        y             = hell_get_mouse_y(event);
        // not all pointer events have valid x and y
        // like stylus events for instance
        if (event->type == HELL_EVENT_TYPE_MOTION) {
            io.AddMousePosEvent(x, y);
        }
        int button    = 0;
        switch (hell_get_event_button_code(event))
        {
        case HELL_MOUSE_LEFT:
            button = 0;
            break;
        case HELL_MOUSE_MID:
            button = 2;
            break;
        case HELL_MOUSE_RIGHT:
            button = 1;
            break;
        }
        if (event->type == HELL_EVENT_TYPE_MOUSEDOWN)
            io.AddMouseButtonEvent(button, true);
        if (event->type == HELL_EVENT_TYPE_MOUSEUP)
            io.AddMouseButtonEvent(button, false);
        if (event->type == HELL_EVENT_TYPE_MOUSEWHEELUP)
            io.AddMouseWheelEvent(0.0, 0.25);
        if (event->type == HELL_EVENT_TYPE_MOUSEWHEELDOWN)
            io.AddMouseWheelEvent(0.0, -0.25);
    }
    if (event->mask & HELL_EVENT_MASK_KEY_BIT)
    {
        u8 key = hell_get_event_key_code(event);
        //hell_print("Get key event. %d\n", key);
        if (event->type == HELL_EVENT_TYPE_KEYDOWN) {
            io.AddKeyEvent(imgui_key(key), true);
            io.AddInputCharacter(key);
        }
        else
            io.AddKeyEvent(imgui_key(key), false);
    }
    if (io.WantCaptureMouse || io.WantCaptureKeyboard)
        return true;
    return false;
}

bool crux_begin_main_menu_bar(CruxContext* ctx)
{
    return ImGui::BeginMainMenuBar();
}

void crux_end_main_menu_bar(CruxContext* ctx)
{
    ImGui::EndMainMenuBar();
}

bool crux_begin_menu(CruxContext* ctx, const char* label)
{
    return ImGui::BeginMenu(label);
}

void crux_end_menu(Ctx* ctx)
{
    ImGui::EndMenu();
}

bool crux_menu_item(Ctx* ctx, const char* label, const char* shortcut)
{
    return ImGui::MenuItem(label, shortcut);
}

void crux_demo_window(Ctx* ctx, bool* open)
{
    ImGui::ShowDemoWindow(open);
}

bool crux_begin_window(CruxContext* ctx, const char* name, bool* open, int flags)
{
    return ImGui::Begin(name, open);
}

bool crux_button(CruxContext* ctx, const char* label, const float size[2])
{
    if (!size)
        return ImGui::Button(label);
    ImVec2 s(size[0], size[1]);
    return ImGui::Button(label, s);
}

bool crux_header(CruxContext* ctx, const char* label)
{
    return ImGui::CollapsingHeader(label);
}

void crux_same_line(CruxContext* ctx)
{
    ImGui::SameLine();
}

void crux_new_line(CruxContext* ctx)
{
    ImGui::NewLine();
}

bool crux_radio_button(CruxContext* ctx, const char* label, int32_t *val, int32_t button_number)
{
    ImGui::RadioButton(label, val, button_number);
}

void crux_file_browser(Ctx* ctx)
{
    if (!ctx->file_browser)
        ctx->file_browser = std::make_unique<ImGui::FileBrowser>(
            ImGuiFileBrowserFlags_MultipleSelection);
    if (!ctx->file_browser->IsOpened())
        ctx->file_browser->Open();
}

HellArrayString crux_get_selected_files(Ctx* ctx)
{
    HellArrayString arr = hell_array_string_create(5, NULL);
    if (!ctx->file_browser)
        return arr;
    if (!ctx->file_browser->HasSelected())
        return arr;
    std::vector<std::filesystem::path> paths = ctx->file_browser->GetMultiSelected();
    assert(paths.size() > 0);
    for (const auto& path : paths) 
    {
        HellString str = hell_string_create(8, NULL);
        hell_string_fill(&str, path.c_str());
        hell_array_string_push(&arr, str);
    }
    ctx->file_browser->ClearSelected();
    return arr;
}

void crux_end_window(CruxContext* ctx)
{
    ImGui::End();
}

void crux_text(const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    ImGui::TextV(fmt, args);
    //ImGui::Text("%d %d", 5, 10);
    va_end(args);
}

bool crux_toggle(Ctx *ctx, const char* label, bool *v)
{
    return ImGui::Checkbox(label, v);
}

bool crux_color_picker_3(Ctx* ctx, const char* label, float col[3])
{
    return ImGui::ColorPicker3(label, col);
}

bool crux_color_picker_4(Ctx* ctx, const char* label, float col[4])
{
    return ImGui::ColorPicker4(label, col, ImGuiColorEditFlags_AlphaBar);
}

bool crux_color_edit_3(Ctx* ctx, const char* label, float col[3])
{
    return ImGui::ColorEdit3(label, col);
}

bool crux_drag(Ctx* ctx, const char* label, float speed, float *val)
{
    return ImGui::DragFloat(label, val, speed);
}

bool crux_slider(Ctx* ctx, const char* label, float* value, float min, float max)
{
    return ImGui::SliderFloat(label, value, min, max);
}

bool crux_slider_4f(Ctx* ctx, const char* label, float* value, float min, float max)
{
    //return ImGui::Sl
    return false;
}

bool crux_slider_n(CruxContext* ctx, const char* label, float* values, int32_t count, float min, float max)
{
    return ImGui::SliderScalarN(label, ImGuiDataType_Float, values, count, &min, &max);
}

bool crux_input_float_n(CruxContext* ctx, const char* label, float* values, int32_t count)
{
    return ImGui::InputScalarN(label, ImGuiDataType_Float, values, count, NULL, NULL, "%.3f", 0);
}

void crux_render(CruxContext* ctx, VkCommandBuffer cmdbuf)
{
    VkRenderPassBeginInfo rpi  = {VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};

    rpi.renderPass = ctx->renderpass;
    rpi.renderArea.extent = {ctx->cur_width, ctx->cur_height};
    rpi.renderArea.offset = {0, 0};
    rpi.clearValueCount = 0;
    rpi.framebuffer = ctx->framebuffers[ctx->cur_framebuffer];

    vkCmdBeginRenderPass(cmdbuf, &rpi, VK_SUBPASS_CONTENTS_INLINE);

    if (ctx->file_browser)
        ctx->file_browser->Display();
    ImGui::Render();
    ImDrawData* draw_data = ImGui::GetDrawData();
    ImGui_ImplVulkan_RenderDrawData(draw_data, cmdbuf);

    vkCmdEndRenderPass(cmdbuf);
}

} // end extern "C"

static ImGuiKey_
imgui_key(uint8_t hell_key)
{
    switch (hell_key) {
        case HELL_KEY_SPACE: return ImGuiKey_Space;
        case HELL_KEY_CTRL: return ImGuiKey_ModCtrl;
        case HELL_KEY_ESC: return ImGuiKey_Escape;
        case HELL_KEY_ENTER: return ImGuiKey_Enter;
        case HELL_KEY_DELETE: return ImGuiKey_Delete;
        case HELL_KEY_BACKSPACE: return ImGuiKey_Backspace;
        case HELL_KEY_PERIOD: return ImGuiKey_Period;
        case HELL_KEY_MINUS: return ImGuiKey_Minus;

        case HELL_KEY_A: return ImGuiKey_A;
        case HELL_KEY_B: return ImGuiKey_B;
        case HELL_KEY_C: return ImGuiKey_C;
        case HELL_KEY_D: return ImGuiKey_D;
        case HELL_KEY_E: return ImGuiKey_E;
        case HELL_KEY_F: return ImGuiKey_F;
        case HELL_KEY_G: return ImGuiKey_G;
        case HELL_KEY_H: return ImGuiKey_H;
        case HELL_KEY_I: return ImGuiKey_I;
        case HELL_KEY_J: return ImGuiKey_J;
        case HELL_KEY_K: return ImGuiKey_K;
        case HELL_KEY_L: return ImGuiKey_L;
        case HELL_KEY_M: return ImGuiKey_M;
        case HELL_KEY_N: return ImGuiKey_N;
        case HELL_KEY_O: return ImGuiKey_O;
        case HELL_KEY_P: return ImGuiKey_P;
        case HELL_KEY_Q: return ImGuiKey_Q;
        case HELL_KEY_R: return ImGuiKey_R;
        case HELL_KEY_S: return ImGuiKey_S;
        case HELL_KEY_T: return ImGuiKey_T;
        case HELL_KEY_U: return ImGuiKey_U;
        case HELL_KEY_V: return ImGuiKey_V;
        case HELL_KEY_W: return ImGuiKey_W;
        case HELL_KEY_X: return ImGuiKey_X;
        case HELL_KEY_Y: return ImGuiKey_Y;
        case HELL_KEY_Z: return ImGuiKey_Z;
        case HELL_KEY_0: return ImGuiKey_0;
        case HELL_KEY_1: return ImGuiKey_1;
        case HELL_KEY_2: return ImGuiKey_2;
        case HELL_KEY_3: return ImGuiKey_3;
        case HELL_KEY_4: return ImGuiKey_4;
        case HELL_KEY_5: return ImGuiKey_5;
        case HELL_KEY_6: return ImGuiKey_6;
        case HELL_KEY_7: return ImGuiKey_7;
        case HELL_KEY_8: return ImGuiKey_8;
        case HELL_KEY_9: return ImGuiKey_9;
    }
    hell_error_fatal("Key not implemented");
    return ImGuiKey_F;
}

static void init_dark_theme(CruxContext *ctx)
{
    ImGui::SetCurrentContext(ctx->imgui_ctx);
    ImVec4* colors = ImGui::GetStyle().Colors;
    colors[ImGuiCol_Text]                   = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    colors[ImGuiCol_TextDisabled]           = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
    colors[ImGuiCol_WindowBg]               = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
    colors[ImGuiCol_ChildBg]                = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_PopupBg]                = ImVec4(0.19f, 0.19f, 0.19f, 0.92f);
    colors[ImGuiCol_Border]                 = ImVec4(0.19f, 0.19f, 0.19f, 0.29f);
    colors[ImGuiCol_BorderShadow]           = ImVec4(0.00f, 0.00f, 0.00f, 0.24f);
    colors[ImGuiCol_FrameBg]                = ImVec4(0.05f, 0.05f, 0.05f, 0.54f);
    colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.19f, 0.19f, 0.19f, 0.54f);
    colors[ImGuiCol_FrameBgActive]          = ImVec4(0.20f, 0.22f, 0.23f, 1.00f);
    colors[ImGuiCol_TitleBg]                = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_TitleBgActive]          = ImVec4(0.06f, 0.06f, 0.06f, 1.00f);
    colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_MenuBarBg]              = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
    colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.05f, 0.05f, 0.05f, 0.54f);
    colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.34f, 0.34f, 0.34f, 0.54f);
    colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.40f, 0.40f, 0.40f, 0.54f);
    colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(0.56f, 0.56f, 0.56f, 0.54f);
    colors[ImGuiCol_CheckMark]              = ImVec4(0.33f, 0.67f, 0.86f, 1.00f);
    colors[ImGuiCol_SliderGrab]             = ImVec4(0.34f, 0.34f, 0.34f, 0.54f);
    colors[ImGuiCol_SliderGrabActive]       = ImVec4(0.56f, 0.56f, 0.56f, 0.54f);
    colors[ImGuiCol_Button]                 = ImVec4(0.05f, 0.05f, 0.05f, 0.54f);
    colors[ImGuiCol_ButtonHovered]          = ImVec4(0.19f, 0.19f, 0.19f, 0.54f);
    colors[ImGuiCol_ButtonActive]           = ImVec4(0.20f, 0.22f, 0.23f, 1.00f);
    colors[ImGuiCol_Header]                 = ImVec4(0.00f, 0.00f, 0.00f, 0.52f);
    colors[ImGuiCol_HeaderHovered]          = ImVec4(0.00f, 0.00f, 0.00f, 0.36f);
    colors[ImGuiCol_HeaderActive]           = ImVec4(0.20f, 0.22f, 0.23f, 0.33f);
    colors[ImGuiCol_Separator]              = ImVec4(0.28f, 0.28f, 0.28f, 0.29f);
    colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.44f, 0.44f, 0.44f, 0.29f);
    colors[ImGuiCol_SeparatorActive]        = ImVec4(0.40f, 0.44f, 0.47f, 1.00f);
    colors[ImGuiCol_ResizeGrip]             = ImVec4(0.28f, 0.28f, 0.28f, 0.29f);
    colors[ImGuiCol_ResizeGripHovered]      = ImVec4(0.44f, 0.44f, 0.44f, 0.29f);
    colors[ImGuiCol_ResizeGripActive]       = ImVec4(0.40f, 0.44f, 0.47f, 1.00f);
    colors[ImGuiCol_Tab]                    = ImVec4(0.00f, 0.00f, 0.00f, 0.52f);
    colors[ImGuiCol_TabHovered]             = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
    colors[ImGuiCol_TabActive]              = ImVec4(0.20f, 0.20f, 0.20f, 0.36f);
    colors[ImGuiCol_TabUnfocused]           = ImVec4(0.00f, 0.00f, 0.00f, 0.52f);
    colors[ImGuiCol_TabUnfocusedActive]     = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
    colors[ImGuiCol_DockingPreview]         = ImVec4(0.33f, 0.67f, 0.86f, 1.00f);
    colors[ImGuiCol_DockingEmptyBg]         = ImVec4(1.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotLines]              = ImVec4(1.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotLinesHovered]       = ImVec4(1.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotHistogram]          = ImVec4(1.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_TableHeaderBg]          = ImVec4(0.00f, 0.00f, 0.00f, 0.52f);
    colors[ImGuiCol_TableBorderStrong]      = ImVec4(0.00f, 0.00f, 0.00f, 0.52f);
    colors[ImGuiCol_TableBorderLight]       = ImVec4(0.28f, 0.28f, 0.28f, 0.29f);
    colors[ImGuiCol_TableRowBg]             = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_TableRowBgAlt]          = ImVec4(1.00f, 1.00f, 1.00f, 0.06f);
    colors[ImGuiCol_TextSelectedBg]         = ImVec4(0.20f, 0.22f, 0.23f, 1.00f);
    colors[ImGuiCol_DragDropTarget]         = ImVec4(0.33f, 0.67f, 0.86f, 1.00f);
    colors[ImGuiCol_NavHighlight]           = ImVec4(1.00f, 0.00f, 0.00f, 1.00f);
    colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(1.00f, 0.00f, 0.00f, 0.70f);
    colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(1.00f, 0.00f, 0.00f, 0.20f);
    colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(1.00f, 0.00f, 0.00f, 0.35f);

    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowPadding                     = ImVec2(8.00f, 8.00f);
    style.FramePadding                      = ImVec2(5.00f, 2.00f);
    style.CellPadding                       = ImVec2(6.00f, 6.00f);
    style.ItemSpacing                       = ImVec2(6.00f, 6.00f);
    style.ItemInnerSpacing                  = ImVec2(6.00f, 6.00f);
    style.TouchExtraPadding                 = ImVec2(0.00f, 0.00f);
    style.IndentSpacing                     = 25;
    style.ScrollbarSize                     = 15;
    style.GrabMinSize                       = 10;
    style.WindowBorderSize                  = 1;
    style.ChildBorderSize                   = 1;
    style.PopupBorderSize                   = 1;
    style.FrameBorderSize                   = 1;
    style.TabBorderSize                     = 1;
    style.WindowRounding                    = 7;
    style.ChildRounding                     = 4;
    style.FrameRounding                     = 3;
    style.PopupRounding                     = 4;
    style.ScrollbarRounding                 = 9;
    style.GrabRounding                      = 3;
    style.LogSliderDeadzone                 = 4;
    style.TabRounding                       = 4;
}
