#ifndef CRUX_EXPORTABLE_H
#define CRUX_EXPORTABLE_H

typedef struct CruxContext Crux;
typedef struct onyx_graph OnyxGraph;

Crux* crux_allocate_context();

Crux* crux_create_graph_context_(OnyxGraph* g);

void crux_new_frame(Crux* ctx, float w, float h, float dt);

#endif
