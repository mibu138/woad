#ifndef CRUX_H
#define CRUX_H

#include <onyx/onyx.h>

typedef struct CruxContext CruxContext;
typedef struct CruxContext Crux;

CruxContext* crux_allocate_context();
void crux_create_context(CruxContext* ctx, OnyxContext* onyx, const OnyxSwapchain* swap);

void crux_new_frame(CruxContext* ctx, const OnyxFrame *frame, float dt);
bool crux_feed_input(CruxContext* ctx, const HellEvent* event);
bool crux_drag(CruxContext* ctx, const char* label, float speed, float *val);
void crux_render(CruxContext* ctx, VkCommandBuffer cmdbuf);
bool crux_begin_main_menu_bar(CruxContext* ctx);
void crux_end_main_menu_bar(CruxContext* ctx);
bool crux_begin_menu(CruxContext* ctx, const char* label);
void crux_end_menu(CruxContext* ctx);
bool crux_menu_item(CruxContext* ctx, const char* label, const char* shortcut);
bool crux_toggle(CruxContext* ctx, const char* label, bool *v);
bool crux_color_picker_3(CruxContext* ctx, const char* label, float col[3]);
bool crux_color_picker_4(CruxContext* ctx, const char* label, float col[4]);
bool crux_color_edit_3(CruxContext* ctx, const char* label, float col[3]);
void crux_demo_window(CruxContext* ctx, bool* open);
bool crux_begin_window(CruxContext* ctx, const char* name, bool* open, int flags);
void crux_end_window(CruxContext* ctx);
void crux_text(const char* fmt, ...);
bool crux_slider(CruxContext* ctx, const char* label, float* value, float min, float max);
bool crux_slider_n(CruxContext* ctx, const char* label, float* value, int32_t count, float min, float max);
bool crux_input_float_n(CruxContext* ctx, const char* label, float* value, int32_t count);
bool crux_button(CruxContext* ctx, const char* label, const float size[2]);
bool crux_header(CruxContext* ctx, const char* label);
bool crux_radio_button(CruxContext* ctx, const char* label, int32_t *val, int32_t button_number);
void crux_same_line(CruxContext* ctx);
void crux_new_line(CruxContext* ctx);
void crux_file_browser(CruxContext* ctx);
HellArrayString crux_get_selected_files(CruxContext* ctx);

#ifdef CRUX_SIMPLE_NAMES
#define begin_main_menu_bar(...) crux_begin_main_menu_bar(__VA_ARGS__) 
#define end_main_menu_bar(...)   crux_end_main_menu_bar(__VA_ARGS__)   
#define begin_menu(...)          crux_begin_menu(__VA_ARGS__)          
#define end_menu(...)            crux_end_menu(__VA_ARGS__)            
#define menu_item(...)           crux_menu_item(__VA_ARGS__)           
#define begin_window(...)        crux_begin_window(__VA_ARGS__)
#define end_window(...)          crux_end_window(__VA_ARGS__)
#define slider(...)              crux_slider(__VA_ARGS__)
#define button(...)              crux_button(__VA_ARGS__)
#endif

#endif
