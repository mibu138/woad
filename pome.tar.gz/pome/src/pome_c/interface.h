#ifndef POME_INTERFACE_H
#define POME_INTERFACE_H

#include "types.h"

#include <stdint.h>

struct pome;
typedef struct pome Pome;

struct pome_frame_data {
    int64_t frame_number;
    int64_t frame_delta;
    uint32_t window_width;
    uint32_t window_height;
    bool swapchain_dirty;
};

Pome* pome_alloc();
void pome_init(PomeSettings settings, Pome* pome);
PomeSettings pome_standard_settings(int window_width, int window_height);

// call after setting up what ever you need to before entering the loop
void pome_app_start(Pome* pome);

struct pome_frame_data pome_begin_frame(Pome*);
void pome_end_frame(Pome*);

#endif
