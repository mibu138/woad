#ifndef POME_TYPES_H
#define POME_TYPES_H

#include <onyx/interface_types.h>

// most of these setting should be optional
typedef struct pome_settings {
    _Bool            enable_tty_console;
    _Bool            disable_swapchain_framebuffers;
    _Bool            no_ui;
    _Bool            disable_validation;
    struct onyx_memory_sizes onyx_mem_sizes;
    int             window_width;
    int             window_height;
} PomeSettings;

#endif
