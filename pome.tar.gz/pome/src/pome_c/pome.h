#ifndef POME_H
#define POME_H

#ifdef __cplusplus
extern "C" {
#endif

#include "interface.h"

#include <crux/crux.h>
#include <hell/hell.h>
#include <onyx/onyx.h>

typedef struct pome {
    OnyxContext              onyx;
    HellContext              hell;
    OnyxSwapchain            swapchain;
    Crux                    *crux;
    VkSemaphore              img_acquired_semaphores[3];
    VkFence                  img_acquired_fence[3];
} Pome;

void pome_run(Pome* pome, HellFrameFn);
const OnyxFrame* pome_acquire_frame(Pome* p, int64_t fi, VkSemaphore* image_acquired);
void pome_begin_swapchain_renderpass(Pome* p, VkCommandBuffer cb, float bg_color[3]);
void pome_end_renderpass(VkCommandBuffer cb);
void pome_present_frame(Pome* p, int count, VkSemaphore wait_semas[/*count*/]);
// sets "reasonable" values for memory sizes and things like that. should be
// good for most quick projects.

void pome_render(Pome* pome, const OnyxGraphExecuteArgs* args);

HellEventQueue* pome_event_queue(Pome* p);
HellWindow*     pome_main_window(Pome* p);
HellGrimoire*   pome_grimoire(Pome* p);
VkDevice        pome_device(Pome* p);

void pome_handle_events(Pome* p, bool (*handler)(const HellEvent* event));
void pome_main_menu(Pome* p, void (*app_menu_fn)(Crux* crux));

OnyxGraph* pome_init_frame_graph(Pome* p, const OnyxReflection* refl);

void pome_graph_bake(Pome* p, const char* output_image);

#ifdef __cplusplus
}
#endif

#endif /* ifndef POME_H */
