#include "pome.h"
#include <hell/len.h>

#ifdef POME_SHADER_REFLECTION
#include <reflection.h>
#endif

typedef enum PomeSettingsFlagBits {
    NO_FRAME_DATA_BIT = 1 << 0
} PomeSettingsFlagBits;

typedef struct FrameInfo {
    OnyxRasterizationReflection *subpass_reflection;
} FrameInfo;

static void pome_init_graphical(Pome *pome, FrameInfo *fi);

static int get_cur_frame_index(const Pome *p)
{
    return p->hell.frame_count % p->swapchain.image_count;
}

Pome* pome_alloc()
{
    return malloc(sizeof(Pome));
}

void pome_init(PomeSettings s, Pome *pome)
{
    memset(pome, 0, sizeof(*pome));

    OnyxInstanceParms ip = {
        .disable_validation = s.disable_validation,
    };
    OnyxSettings onyx_settings = {.ip = &ip, .memory_sizes = s.onyx_mem_sizes};

    pome->onyx = onyx_create_context(onyx_settings);

    uint32_t hell_options = 0;
    if (s.enable_tty_console)
        hell_options |= HELL_OPTION_ENABLE_TTY_CONSOLE_BIT;

    hell_open_mouth(hell_options, &pome->hell);

    hell_hellmouth_add_window(&pome->hell, s.window_width, s.window_height,
                              NULL);

    onyx_create_swapchain(
        pome->onyx.instance, pome->onyx.memory, pome->hell.eventqueue,
        pome->hell.windows[0], VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_STORAGE_BIT,
        0, NULL, &pome->swapchain);

    for (uint32_t i = 0; i < pome->swapchain.image_count; ++i) {
        onyx_create_fence(pome->onyx.device, true, &pome->img_acquired_fence[i]);
        onyx_create_semaphore(pome->onyx.device, &pome->img_acquired_semaphores[i]);
    }
}

void pome_run(Pome *pome, HellFrameFn frame)
{
    //pome_app_start(pome);
    for (;;) {
        pome_begin_frame(pome);
        frame(pome->hell.frame_count, pome->hell.frame_delta);
        pome_end_frame(pome);
    }
}

void pome_present_frame(Pome *p, int count, VkSemaphore wait_semas[/*count*/])
{
    onyx_present_frame(&p->swapchain, count, wait_semas);
}

void pome_end_renderpass(VkCommandBuffer cb) { onyx_cmd_end_render_pass(cb); }

HellEventQueue *pome_event_queue(Pome *p) { return p->hell.eventqueue; }

HellWindow *pome_main_window(Pome *p) { return p->hell.windows[0]; }

HellGrimoire *pome_grimoire(Pome *p) { return p->hell.grimoire; }

VkDevice pome_device(Pome *p) { return p->onyx.device; }

PomeSettings pome_standard_settings(int window_width, int window_height)
{
    PomeSettings ps = {
        .enable_tty_console = false,
        .onyx_mem_sizes = 
            (OnyxMemorySizes){
               .device_graphics_buffer_mb = 100,
               .host_graphics_buffer_mb   = 20,
               .device_graphics_image_mb  = 100,
               .host_transfer_buffer_mb   = 20,
            },
        .window_width = window_width,
        .window_height = window_height,
    };

    return ps;
} 

struct pome_frame_data pome_begin_frame(Pome* p)
{
    hell_begin_frame(&p->hell);
    int cur = get_cur_frame_index(p);
    const OnyxFrame *frame = onyx_acquire_swapchain_frame(&p->swapchain, 
            p->img_acquired_fence[cur], 
            p->img_acquired_semaphores[cur]);
    //crux_new_frame(p->crux, frame->width, frame->height, p->hell.frame_delta);
    return (struct pome_frame_data){
        .frame_number = p->hell.frame_count, 
        .frame_delta = p->hell.frame_delta,
        .window_width = frame->width,
        .window_height = frame->height,
        .swapchain_dirty = frame->dirty,
    };
}

void pome_handle_events(Pome* p, bool (*handler)(const HellEvent* event))
{
    int              event_count;
    const HellEvent *events = hell_get_events(&p->hell, &event_count);
    for (int i = 0; i < event_count; ++i) {
        const HellEvent* ev = events + i;
        if (ev->type == HELL_EVENT_TYPE_KEYDOWN) {
            uint32_t key = ev->data.win_data.data.key_data.key_code;
            if (key == HELL_KEY_Q)
                hell_exit(0);
        }
        if (crux_feed_input(p->crux, ev))
            continue;
        if (handler && handler(ev))
            continue;
    }
}

void pome_main_menu(Pome* p, void (*app_menu_fn)(Crux* crux))
{
    Crux* crux = p->crux;
    static bool demo_window_open;
    if (crux_begin_main_menu_bar(crux)) {
        if (crux_begin_menu(crux, "Main")) {
            if (crux_menu_item(crux, "Quit", "q"))
                hell_exit(0);
            if (crux_menu_item(crux, "Load Image", ""))
                crux_file_browser(crux);
            demo_window_open = crux_menu_item(crux, "Demo", "");
            crux_end_menu(crux);
        }
        if (app_menu_fn)
            app_menu_fn(crux);
        crux_end_main_menu_bar(crux);
    }
    if (demo_window_open)
        crux_demo_window(crux, &demo_window_open);
}

void pome_render(Pome* pome, const OnyxGraphExecuteArgs* args)
{
    //onyx_graph_execute(&pome->graph, args);
}

void pome_end_frame(Pome* pome)
{
    hell_end_frame(&pome->hell);
}
