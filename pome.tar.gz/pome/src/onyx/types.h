#ifndef ONYX_TYPES_H
#define ONYX_TYPES_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#include "exportable.h"
#include "vulkan.h"
#include "limits.h"

#define MAX_BLOCKS 1000

typedef enum {
    ONYX_RESOURCE_USAGE_READ_BIT = 1 << 0,
    ONYX_RESOURCE_USAGE_WRITE_BIT = 1 << 1,
} OnyxResourceUsageFlags;

typedef struct OnyxMemBlock {
    VkDeviceSize   size; // note this is the actual available space at this block. the resource might not be using all of it.
    VkDeviceSize   offset;
    _Bool          inUse;
    uint32_t       id; // global unique identifier
} OnyxMemBlock;

typedef struct onyx_memory_pool {
    char                 name[16]; // for debugging
    VkDeviceSize         totalSize;
    VkDeviceSize         usedSize;
    VkDeviceSize         alignment;
    VkDeviceAddress      bufferAddress;
    uint32_t             count;
    uint32_t             cur;
    uint32_t             nextBlockId;
    VkDeviceMemory       vkmemory;
    VkBuffer             buffer;
    VkBufferUsageFlags   bufferFlags;
    uint8_t*             hostData;
    OnyxMemBlock        blocks[MAX_BLOCKS];
    struct onyx_memory*  memory;
} OnyxMemoryPool;

typedef struct OnyxQueueFamily {
    VkQueueFlags flags;
    uint32_t queue_count;
    VkQueue  queues[ONYX_MAX_DEVICE_QUEUES];
} OnyxQueueFamily;

typedef struct onyx_instance {
    VkInstance                                         vkinstance;
    VkPhysicalDevice                                   physical_device;
    VkDevice                                           device;
    uint32_t                                           queue_family_count;
    OnyxQueueFamily                                    queue_families[8];
    VkQueue                                            present_queue;
    VkDebugUtilsMessengerEXT                           debug_messenger;
    VkPhysicalDeviceRayTracingPipelinePropertiesKHR    rt_properties;
    VkPhysicalDeviceAccelerationStructurePropertiesKHR accel_struct_properties;
    VkPhysicalDeviceProperties                         device_properties;
} OnyxInstance;

typedef struct onyx_memory {
    VkPhysicalDeviceMemoryProperties properties;
    OnyxMemoryPool                       blockChainHostGraphicsBuffer;
    OnyxMemoryPool                       blockChainDeviceGraphicsBuffer;
    OnyxMemoryPool                       blockChainDeviceGraphicsImage;
    OnyxMemoryPool                       blockChainHostTransferBuffer;
    OnyxMemoryPool                       blockChainExternalDeviceGraphicsImage;

    const VkPhysicalDeviceProperties* deviceProperties;

    uint32_t hostVisibleCoherentTypeIndex;
    uint32_t deviceLocalTypeIndex;

    const OnyxInstance* instance;
} OnyxMemory;

typedef enum {
    ONYX_QUEUE_GRAPHICS_TYPE,
    ONYX_QUEUE_TRANSFER_TYPE,
    ONYX_QUEUE_COMPUTE_TYPE,
} OnyxQueueType;

typedef enum OnyxSurfaceType {
    ONYX_SURFACE_TYPE_NO_WINDOW,
    ONYX_SURFACE_TYPE_XCB,
    ONYX_SURFACE_TYPE_WIN32
} OnyxSurfaceType;

struct OnyxV_Command;

typedef uint32_t OnyxMask;
typedef uint32_t OnyxFlags;

typedef enum {
    ONYX_SUCCESS = 1,
    ONYX_ERROR_GENERIC = -1,
    ONYX_ERROR_INSTANCE_EXTENSION_NOT_PRESENT = -2,
    ONYX_ERROR_DEVICE_EXTENSION_NOT_PRESENT = -3,
} OnyxResult;

typedef enum OnyxShaderType {
    ONYX_SHADER_TYPE_VERTEX,
    ONYX_SHADER_TYPE_FRAGMENT,
    ONYX_SHADER_TYPE_COMPUTE,
    ONYX_SHADER_TYPE_GEOMETRY,
    ONYX_SHADER_TYPE_TESS_CONTROL,
    ONYX_SHADER_TYPE_TESS_EVALUATION,
    ONYX_SHADER_TYPE_RAY_GEN,
    ONYX_SHADER_TYPE_ANY_HIT,
    ONYX_SHADER_TYPE_CLOSEST_HIT,
    ONYX_SHADER_TYPE_MISS,
} OnyxShaderType;


typedef struct onyx_spirv_compile_info {
    const char* shader_string;
    const char* entry_point;
    const char* name;
    OnyxShaderType shader_type;
} OnyxSpirvCompileInfo;

typedef OnyxSpirvCompileInfo SpirvCompileInfo;

typedef enum OnyxBlendMode {
    ONYX_BLEND_MODE_NONE,
    ONYX_BLEND_MODE_OVER,
    ONYX_BLEND_MODE_OVER_NO_PREMUL, 
    ONYX_BLEND_MODE_ERASE,
    ONYX_BLEND_MODE_OVER_MONOCHROME,
    ONYX_BLEND_MODE_OVER_NO_PREMUL_MONOCHROME,
    ONYX_BLEND_MODE_ERASE_MONOCHROME,
} OnyxBlendMode;

typedef enum OnyxProgramType {
    ONYX_PROGRAM_TYPE_RENDERPASS,
    ONYX_PROGRAM_TYPE_COMPUTE,
    ONYX_PROGRAM_TYPE_RAYTRACE,
} OnyxProgramType;

typedef struct {
    VkPipelineShaderStageCreateFlags    flags;
    VkShaderStageFlagBits               stage;
    uint32_t                            byte_count;
    uint32_t                           *code;
    const char*                         entry_point;
    const char*                         name;
    VkSpecializationInfo                specialization_info;
} OnyxShaderInfo;


typedef struct OnyxShaderReflection {
    VkDescriptorSet       *descriptor_sets;
    VkDescriptorSetLayout *descriptor_set_layouts;
    VkPipelineLayout       pipeline_layout;
} OnyxShaderReflection;

typedef struct OnyxVertexInputAttributeReflection {
    int location;
    const char *name;
    int n_components;
} OnyxVertexInputAttributeReflection; 

typedef struct {
    int color_attachment_count;
    int vertex_shader_index;
    int fragment_shader_index;
    int vertex_input_count;
    OnyxVertexInputAttributeReflection vertex_inputs[ONYX_MAX_VERTEX_ATTRIBUTES_PER_SHADER];
} OnyxRasterizationReflection;

typedef struct {
    int shader_index;
    int local_x;
    int local_y;
    int local_z;
} OnyxComputeReflection;

/// how the descriptor is refererred in the shader.
/// contains only the information that can be garnered from the shader itself,
/// like set and binding number, readonly/writeonly, but not things about the
/// descriptor itself like the size, what stages it is used in, etc.
/// unline other elements of ProgramReflection, this stores its index into the
/// pipedes descriptor array internally.
///
/// in order to get the actual descriptor that this is referencing, use the
/// set_index to index into the pipedes descriptor set array. then, use the
/// binding as the index into that descriptor set's descriptor array. that index
/// is the index into the descriptors array for this reference.
typedef struct {
    int set_index; // set index into pipedes array
    int set; // number in the shader (used in vkCmdBindDescriptorSets)
    int binding; // binding in the set
    bool non_readable;
    bool non_writeable;
    const char *name;
} OnyxDescriptorReference;

typedef struct OnyxProgramReflection {
    OnyxProgramType type;
    int pipeline_layout_index;
    int shader_count;
    int shader_indices[ONYX_PROGRAM_MAX_SHADERS];
    int push_constant_count;
    int push_constant_indices[ONYX_PROGRAM_MAX_PUSH_CONSTANTS];
    int descriptor_count;
    const char* name;
    OnyxDescriptorReference descriptor_references[ONYX_PROGRAM_MAX_DESCRIPTORS];
    union {
        OnyxRasterizationReflection rasterize;
        OnyxComputeReflection    compute;
    };
} OnyxProgramReflection;

typedef struct OnyxSyncScope {
    VkAccessFlags        access_mask;
    VkPipelineStageFlags stage_mask;
} OnyxSyncScope;

typedef struct {
    OnyxSyncScope src;
    OnyxSyncScope dst;
} OnyxBarrierScopes;

typedef struct {
    OnyxBarrierScopes scopes;
    VkImageLayout     initial_layout;
    VkImageLayout     final_layout;
    uint32_t          mip_levels;
} OnyxImageBarrierScopes;

typedef struct {
    int count;
    VkDescriptorType type;
    VkShaderStageFlags stages;
    VkDescriptorBindingFlags binding_flags; //optional
    int struct_info_index;
    int image_info_index;
} OnyxDescriptor;

typedef struct {
    int descriptor_count;
    // index in this array == binding number
    // unused bindings should be set to -1
    int descriptors[ONYX_MAX_DESCRIPTORS_PER_SET];
} OnyxDescriptorSet;

typedef struct {
    int descriptor_set_count;
    int descriptor_set_indices[ONYX_PIPELINE_LAYOUT_MAX_DESCRIPTOR_SETS];
    int push_constant_count;
    int push_constant_indices[ONYX_PIPELINE_LAYOUT_MAX_PUSH_CONSTANTS];
} OnyxPipelineLayout;

typedef struct {
    VkShaderStageFlags stages;
    int struct_info_index;
} OnyxPushConstantInfo;

typedef struct {
    const char* name;
    uint32_t size;
} OnyxPipelineStructInfo;

typedef struct {
    uint32_t placeholder;
} OnyxPipelineImageInfo;

typedef struct {
    int                         descriptor_count;
    OnyxDescriptor              descriptors[ONYX_MAX_DESCRIPTORS];
    int                         descriptor_set_count;
    OnyxDescriptorSet           descriptor_sets[ONYX_MAX_DESCRIPTOR_SETS];
    int                         pipeline_layout_count;
    OnyxPipelineLayout          pipeline_layouts[ONYX_MAX_PIPELINE_LAYOUTS];
    int                         shader_count;
    OnyxShaderInfo              shader_infos[ONYX_MAX_SHADERS];
    int                         push_constant_count;
    OnyxPushConstantInfo        push_constant_infos[ONYX_MAX_PUSH_CONSTANTS];
    int                         struct_info_count;
    OnyxPipelineStructInfo      struct_infos[ONYX_MAX_PIPELINE_STRUCT_INFOS ];
    int                         image_info_count;
    OnyxPipelineImageInfo       image_infos[ONYX_MAX_PIPELINE_IMAGE_INFOS ];
} OnyxPipedes;

static inline VkPushConstantRange
onyx_pipedes_get_push_constant_range(const OnyxPipedes* p,
        int pc_index)
{
    assert(pc_index < p->push_constant_count);
    int strind = p->push_constant_infos[pc_index].struct_info_index;
    assert(strind < ONYX_MAX_PIPELINE_IMAGE_INFOS);

    VkPushConstantRange r = {
        .stageFlags = p->push_constant_infos[pc_index].stages,
        .offset = 0,
        .size = p->struct_infos[strind].size,
    };

    return r;
}

static inline const OnyxDescriptor*
onyx_pipedes_get_descriptor(
        const OnyxPipedes *p, int set_index, int binding)
{
    assert(set_index < p->descriptor_set_count);
    assert(binding < p->descriptor_sets[set_index].descriptor_count);

    return &p->descriptors[
        p->descriptor_sets[set_index].descriptors[binding]];
}

static inline const OnyxDescriptor*
onyx_pipedes_get_descriptors(
        const OnyxPipedes *p, int* count)
{
    *count = p->descriptor_count;
    return p->descriptors;
}

static inline const OnyxDescriptorSet*
onyx_pipedes_get_descriptor_sets(
        const OnyxPipedes *p, int* count)
{
    *count = p->descriptor_set_count;
    return p->descriptor_sets;
}

static inline const OnyxPipelineLayout*
onyx_pipedes_get_pipeline_layout(
        const OnyxPipedes *p, int* count)
{
    *count = p->pipeline_layout_count;
    return p->pipeline_layouts;
}

static inline const OnyxShaderInfo*
onyx_pipedes_get_shader_infos(
        const OnyxPipedes *p, int* count)
{
    *count = p->shader_count;
    return p->shader_infos;
}

typedef struct onyx_reflection {
    int                      program_count;
    OnyxProgramReflection    programs[ONYX_MAX_PROGRAMS];
    OnyxPipedes description;
} OnyxReflection;

static inline void onyx_reflection_add_program(OnyxReflection       *refl,
                                               OnyxProgramReflection program)
{
    refl->programs[refl->program_count++] = program;
}

#endif /* end of include guard: ONYX_TYPES_H */
