#include "renderpass.h"
#include "render.h"
#include "video.h"
#include <hell/len.h>
#include <stdlib.h>

void onyx_subpass_create(
        // will copy
        const OnyxRasterizationReflection* refl,
        int color_attachment_count,
        // will get copied into subpass object
        const OnyxColorAttachmentReference *color_attachments,
        const OnyxDepthAttachmentReference *depth_attachments,
        OnyxSyncScope scope,
        OnyxSubpass *sp)
{
    assert(color_attachment_count == refl->color_attachment_count);
    zero(sp);
    
    sp->scope = scope;
    memcpy(sp->color_attachments, color_attachments,
           color_attachment_count * sizeof(*color_attachments));
    if (depth_attachments) {
        sp->has_depth = true;
        sp->depth_attachment = *depth_attachments;
    }
}

VkRenderPass onyx_render_pass_create_vk(const OnyxRenderPass* rp, VkDevice dev)
{
    const int attachment_count = rp->attachment_count;
    const OnyxAttachment *attachments = rp->attachments;
    const int subpass_count = rp->subpass_count;
    const OnyxSubpass *subpasses = rp->subpasses;
    const OnyxRenderPassDependencyInfo dep_info = rp->dep_info;

    array_alloca(VkAttachmentDescription, attachment_descs, attachment_count);
    for (int i = 0; i < attachment_count; ++i) {
        const OnyxAttachment *attachment = attachments + i;
        VkAttachmentDescription desc = {
            .flags = 0,
            .format = attachment->image_template.format,
            .samples = attachment->image_template.sample_count,
            .loadOp = attachment->load_op,
            .storeOp = attachment->store_op,
            .initialLayout = attachment->initial_layout,
            .finalLayout = attachment->final_layout,
        };

        attachment_descs[i] = desc;
    }

    //VkSubpassDescription* subpass_descs = malloc(sizeof(VkSubpassDescription) * subpass_count);
    array_alloca(VkSubpassDescription, subpass_descs, subpass_count);
    for (int i = 0; i < subpass_count; ++i) {
        const OnyxSubpass *sp = subpasses + i;
        // this should be fine. alloca allocation persists until function return
        int cc = onyx_subpass_get_color_attachment_count(sp);
        //VkAttachmentReference* colrefs = malloc(1100);
        array_alloca(VkAttachmentReference, colrefs, cc);
        array_alloca(VkAttachmentReference, resolverefs, cc);
        for (int i = 0; i < cc; ++i) {
            OnyxColorAttachmentReference cr = sp->color_attachments[i];
            OnyxAttachmentReference ref = cr.ref;
            colrefs[i].attachment = ref.framebuffer_index;
            colrefs[i].layout = ref.layout;
            if (cr.has_resolve) {
                assert(cr.resolve_index < sp->resolve_attachment_count);
                resolverefs[i].attachment = sp->resolve_attachments[cr.resolve_index].ref.framebuffer_index;
                resolverefs[i].layout = sp->resolve_attachments[cr.resolve_index].ref.layout;
            } else {
                resolverefs[i].attachment = VK_ATTACHMENT_UNUSED;
                resolverefs[i].layout = VK_IMAGE_LAYOUT_UNDEFINED;
            }
        }
        VkAttachmentReference* depth_ref = NULL;
        if (sp->has_depth) {
            depth_ref = alloca(sizeof(VkAttachmentReference));
            memset(depth_ref, 0, sizeof(*depth_ref));
            depth_ref->attachment = sp->depth_attachment.ref.framebuffer_index;
            depth_ref->layout = sp->depth_attachment.ref.layout;
        }
        VkSubpassDescription desc = {
            .pipelineBindPoint    = VK_PIPELINE_BIND_POINT_GRAPHICS,
            .colorAttachmentCount = cc,
            // these indices map to the location numbers in the fragment shader
            .pColorAttachments    = colrefs,
            .pDepthStencilAttachment = depth_ref,
            .pResolveAttachments = resolverefs,
        };
        subpass_descs[i] = desc;
    }

    // for now constrain to strict supbass order
    array_alloca(VkSubpassDependency, deps, subpass_count + 1);
    for (int i = 0; i < subpass_count + 1; ++i) {
        bool first = i == 0;
        bool last = i == subpass_count;

        const OnyxSubpass *sp = subpasses;

        deps[i] = (VkSubpassDependency){
            .srcSubpass = first ? VK_SUBPASS_EXTERNAL : i - 1,
            .dstSubpass = last ? VK_SUBPASS_EXTERNAL : i,
            .srcStageMask = first ? dep_info.src.stage_mask : deps[i - 1].dstStageMask,
            .dstStageMask = last ? dep_info.dst.stage_mask : sp[i].scope.stage_mask,
            .srcAccessMask =  first ? dep_info.src.access_mask : deps[i - 1].dstAccessMask,
            .dstAccessMask = last ? dep_info.dst.access_mask : sp[i].scope.access_mask,
            .dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT
        };
    }

    VkRenderPassCreateInfo ci = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
        .attachmentCount = attachment_count,
        .pAttachments = attachment_descs,
        .subpassCount = subpass_count,
        .pSubpasses = subpass_descs,
        .dependencyCount = subpass_count + 1,
        .pDependencies = deps
    };

    VkRenderPass vkrp;
    V_ASSERT( vkCreateRenderPass(dev, &ci, NULL, &vkrp) );

    return vkrp;
}

void onyx_render_pass_create(
        const int attachment_count,
        const OnyxAttachment *attachments,
        const int subpass_count,
        const OnyxSubpass *subpasses,
        const OnyxRenderPassDependencyInfo dep_info,
        OnyxRenderPass *rp)
{
    // some how pure garbage happens below
    assert(attachment_count < LEN(rp->attachments));
    assert(attachment_count > 0);
    assert(subpass_count < LEN(rp->subpasses));
    assert(subpass_count > 0);
    
    memset(rp, 0, sizeof(*rp));
    rp->attachment_count = attachment_count;
    memcpy(rp->attachments, attachments, attachment_count * sizeof(rp->attachments[0]));
    rp->subpass_count = subpass_count;
    memcpy(rp->subpasses, subpasses, subpass_count * sizeof(rp->subpasses[0]));
    rp->dep_info = dep_info;

}

void onyx_create_render_pass_color(VkDevice device, const VkImageLayout initialLayout, 
        const VkImageLayout finalLayout,
        const VkAttachmentLoadOp loadOp, 
        const VkFormat colorFormat,
        VkRenderPass* pRenderPass)
{
    OnyxRenderPassDependencyInfo dep_info = {
        .src = {
            .access_mask = 0,
            .stage_mask = VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT
        },
        .dst = {
            .access_mask = 0,
            .stage_mask = VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
        }
    };

    onyx_create_render_pass_color_(
            device,
            initialLayout,
            finalLayout,
            loadOp,
            colorFormat,
            dep_info,
            pRenderPass);
}

void onyx_create_render_pass_color_(VkDevice device, const VkImageLayout initialLayout, 
        const VkImageLayout finalLayout,
        const VkAttachmentLoadOp loadOp, 
        const VkFormat colorFormat,
        const OnyxRenderPassDependencyInfo depInfo,
        VkRenderPass* pRenderPass)
{
    VkAttachmentDescription attachment = {
        .flags = 0,
        .format = colorFormat,
        .samples = VK_SAMPLE_COUNT_1_BIT,
        .loadOp = loadOp,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = initialLayout,
        .finalLayout = finalLayout};

    const VkAttachmentReference referenceColor = {
        .attachment = 0,
        .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL };

    VkSubpassDescription subpass = {
        .pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS,
        .colorAttachmentCount = 1,
        .pColorAttachments    = &referenceColor,
        .pDepthStencilAttachment = NULL,
        .inputAttachmentCount = 0,
        .preserveAttachmentCount = 0 };

    VkSubpassDependency dep1 = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .dstSubpass = 0,
        .srcStageMask = depInfo.src.stage_mask,
        .dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .srcAccessMask = depInfo.src.access_mask,
        // need to include the READ access in case of a load
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_COLOR_ATTACHMENT_READ_BIT,
        .dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT };

    VkSubpassDependency dep2 = {
        .srcSubpass = 0,
        .dstSubpass = VK_SUBPASS_EXTERNAL,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .dstStageMask = depInfo.dst.stage_mask,
        .srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | depInfo.src.access_mask,
        .dstAccessMask = depInfo.dst.access_mask,
        .dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT };

    VkSubpassDependency deps[] = {dep1, dep2};

    VkRenderPassCreateInfo rpiInfo = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .attachmentCount = 1,
        .pAttachments = &attachment,
        .subpassCount = 1,
        .pSubpasses = &subpass,
        .dependencyCount = LEN(deps),
        .pDependencies = deps };

    V_ASSERT( vkCreateRenderPass(device, &rpiInfo, NULL, pRenderPass) );
}

void onyx_create_render_pass_color_depth(VkDevice device,
        const VkImageLayout colorInitialLayout, const VkImageLayout colorFinalLayout,
        const VkImageLayout depthInitialLayout, const VkImageLayout depthFinalLayout,
        const VkAttachmentLoadOp  colorLoadOp, const VkAttachmentStoreOp colorStoreOp,
        const VkAttachmentLoadOp  depthLoadOp, const VkAttachmentStoreOp depthStoreOp,
        const VkFormat colorFormat,
        const VkFormat depthFormat,
        VkRenderPass* pRenderPass)
{
    const VkAttachmentDescription attachmentColor = {
        .format         = colorFormat,
        .samples        = VK_SAMPLE_COUNT_1_BIT, // TODO look into what this means
        .loadOp         = colorLoadOp,
        .storeOp        = colorStoreOp,
        .stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout  = colorInitialLayout,
        .finalLayout    = colorFinalLayout,
    };

    const VkAttachmentDescription attachmentDepth = {
        .format         = depthFormat,
        .samples        = VK_SAMPLE_COUNT_1_BIT, // TODO look into what this means
        .loadOp         = depthLoadOp,
        .storeOp        = depthStoreOp,
        .stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout  = depthInitialLayout,
        .finalLayout    = depthFinalLayout,
    };

    const VkAttachmentReference referenceColor = {
        .attachment = 0,
        .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL
    };

    const VkAttachmentReference referenceDepth = {
        .attachment = 1,
        .layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
    };

    VkSubpassDescription subpass = {
        .pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS,
        .colorAttachmentCount = 1,
        .pColorAttachments    = &referenceColor,
        .pDepthStencilAttachment = &referenceDepth,
        .inputAttachmentCount = 0,
        .preserveAttachmentCount = 0,
    };

    const VkSubpassDependency dependency1 = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .dstSubpass = 0,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT |
            VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT,
        // because we are clearing them the source is write
        .srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT |
            VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT
            | VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
        .dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT |
            VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
    };

    const VkSubpassDependency dependency2 = {
        .srcSubpass = 0,
        .dstSubpass = VK_SUBPASS_EXTERNAL,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT
            | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT,
        .srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT |
            VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
        .dstAccessMask = 0,
    };

    VkAttachmentDescription attachments[] = {
        attachmentColor,
        attachmentDepth,
    };

    const VkSubpassDependency dependencies[] = {
        dependency1, dependency2
    };

    VkRenderPassCreateInfo ci = {
        .subpassCount = 1,
        .pSubpasses = &subpass,
        .attachmentCount = 2,
        .pAttachments = attachments,
        .dependencyCount = LEN(dependencies),
        .pDependencies = dependencies,
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO
    };

    V_ASSERT( vkCreateRenderPass(device, &ci, NULL, pRenderPass) );
}

void onyx_create_render_pass_color_depth_m_s_a_a(
    VkDevice device, const VkSampleCountFlags sampleCount,
    const VkAttachmentLoadOp loadOp, const VkImageLayout initialLayout,
    const VkImageLayout finalLayout, const VkFormat colorFormat,
    const VkFormat depthFormat, VkRenderPass *pRenderPass)
{
    const VkAttachmentDescription attachmentColor = {
        .format = colorFormat,
        .samples = sampleCount, // TODO look into what this means
        .loadOp = loadOp,
        .storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = initialLayout,
        .finalLayout = VK_IMAGE_LAYOUT_GENERAL,
    };

    const VkAttachmentDescription attachmentDepth = {
        .format = depthFormat,
        .samples = sampleCount, // TODO look into what this means
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
    };

    const VkAttachmentDescription attachmentPresent = {
        .format = colorFormat,
        .samples = VK_SAMPLE_COUNT_1_BIT, // TODO look into what this means
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = finalLayout,
    };

    VkAttachmentDescription attachments[] = {
        attachmentColor,
        attachmentDepth,
        attachmentPresent
    };

    const VkAttachmentReference referenceColor = {
        .attachment = 0,
        .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL
    };

    const VkAttachmentReference referenceDepth = {
        .attachment = 1,
        .layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
    };

    const VkAttachmentReference referenceResolve = {
        .attachment = 2,
        .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
    };

    VkSubpassDescription subpass = {
        .pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS,
        .colorAttachmentCount = 1,
        .pResolveAttachments  = &referenceResolve,
        .pColorAttachments    = &referenceColor,
        .pDepthStencilAttachment = &referenceDepth,
        .inputAttachmentCount = 0,
        .preserveAttachmentCount = 0,
    };

    const VkSubpassDependency dependency0 = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .dstSubpass = 0,
        .srcStageMask = VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .srcAccessMask = VK_ACCESS_MEMORY_READ_BIT,
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,
        .dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT
    };

    const VkSubpassDependency dependency1 = {
        .srcSubpass = 0,
        .dstSubpass = VK_SUBPASS_EXTERNAL,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
        .srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,
        .dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT
    };

    VkSubpassDependency dependencies[] = {
        dependency0, dependency1
    };

    VkRenderPassCreateInfo ci = {
        .subpassCount = 1,
        .pSubpasses = &subpass,
        .attachmentCount = 3,
        .pAttachments = attachments,
        .dependencyCount = 2,
        .pDependencies = dependencies,
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO
    };

    V_ASSERT( vkCreateRenderPass(device, &ci, NULL, pRenderPass) );
}

