#ifndef ONYX_R_API_H
#define ONYX_R_API_H

#include "scene.h"

typedef struct {
    VkSemaphore    (*renderUi)(VkSemaphore waitSemephore);
    bool           (*presentFrame)(VkSemaphore waitSemephore);
    //VkExtent2D  (*getWindowDimensions)(void); now window dimensions are parts of the scene
} OnyxR_Import;

typedef struct {
    void        (*init)(const OnyxS_Scene* scene, VkImageLayout finalImageLayout, bool openglStyle);
    uint8_t     (*getMaxFramesInFlight)(void);
    VkSemaphore (*render)(uint32_t frameIndex, VkSemaphore waitSemephore);
    void        (*cleanUp)(void);
} OnyxR_Export;

typedef OnyxR_Export (*OnyxR_Handshake)(OnyxR_Import import);

#endif /* end of include guard: ONYX_R_API_H */
