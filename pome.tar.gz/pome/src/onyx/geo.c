#define COAL_SIMPLE_TYPE_NAMES
#include "attribute.h"
#include "dtags.h"
#include "geo.h"
#include "memory.h"
#include "mikktspace.h"

#include "render.h"
#include <hell/common.h>
#include <hell/debug.h>
#include <hell/io.h>
#include <hell/len.h>
#include <hell/minmax.h>
#include <stdlib.h>
#include <string.h>

#define CGLTF_IMPLEMENTATION
#include "cgltf.h"

const int CW = 1;

typedef OnyxGeoAttributeSize AttrSize;
typedef OnyxGeometry         Geo;

typedef OnyxGeometry Geometry;

#define DPRINT(fmt, ...)                                                       \
    hell_debug_print(ONYX_DEBUG_TAG_GEO, fmt, ##__VA_ARGS__)

static uint8_t *get_attribute_sizes_ptr(OnyxGeometryTemplate *geo)
{
    return geo->attribute_sizes;
}

static OnyxAttributeType *get_attribute_types_ptr(OnyxGeometryTemplate *geo)
{
    return geo->attribute_types;
}

static const uint8_t *
get_attribute_sizes_ptr_const(const OnyxGeometryTemplate *geo)
{
    return geo->attribute_sizes;
}

static const OnyxAttributeType *
get_attribute_types_ptr_const(const OnyxGeometryTemplate *geo)
{
    return geo->attribute_types;
}

static bool template_has_indices(const OnyxGeometryTemplate *geo)
{
    return ~geo->flags & ONYX_GEOMETRY_FLAG_UNINDEXED;
}

static bool has_indices(const OnyxGeometry *geo)
{
    return template_has_indices(&geo->templ);
}

static uint8_t get_index_size(const OnyxGeometryTemplate *geo)
{
    if (geo->flags & ONYX_GEOMETRY_FLAG_INDEX_SIZE_SHORT)
        return 2;
    else
        return 4;
}

static size_t get_vertex_size(const OnyxGeometryTemplate *geo)
{
    const uint8_t *attr_sizes  = get_attribute_sizes_ptr_const(geo);
    u32            vertex_size = 0;
    for (u32 i = 0; i < geo->attribute_count; i++) {
        vertex_size += attr_sizes[i];
    }
    return vertex_size;
}

// TODO this is sketchy. make sure this actually is correct and that there isn't
// any padding issues that could screw up the number
static size_t get_vertex_count(const Geometry *geo)
{
    uint32_t vs = get_vertex_size(&geo->templ);
    return geo->vertex_buffer_region.size / vs;
}

static size_t get_attribute_array_internal_offset(const Geometry *geo,
                                                  int             index)
{
    assert(~geo->templ.flags & ONYX_GEOMETRY_FLAG_ARRAY_OF_STRUCTS);
    assert(index < geo->templ.attribute_count);
    assert(geo->vertex_buffer_region.host_data);
    const uint8_t *attr_sizes = get_attribute_sizes_ptr_const(&geo->templ);
    uint32_t       vc         = get_vertex_count(geo);
    size_t         offset     = 0;
    for (int i = 0; i < index; ++i) {
        offset += vc * attr_sizes[i];
    }
    return offset;
}

static VkDeviceSize get_attribute_array_buffer_offset(const Geometry *geo,
                                                      int             index)
{
    return get_attribute_array_internal_offset(geo, index) +
           geo->vertex_buffer_region.offset;
}

static void *get_attribute_array_ptr(const Geometry *geo, int index)
{
    size_t offset = get_attribute_array_internal_offset(geo, index);
    return geo->vertex_buffer_region.host_data + offset;
}

static const void *get_attribute_array_ptr_const(const Geometry *geo, int index)
{
    size_t offset = get_attribute_array_internal_offset(geo, index);
    return geo->vertex_buffer_region.host_data + offset;
}

static int template_get_attribute_count(const OnyxGeometryTemplate *t)
{
    return t->attribute_count;
}

static int geo_get_attribute_count(const Geometry *geo)
{
    return template_get_attribute_count(&geo->templ);
}

static const void *find_attribute_array_ptr_const(const Geometry *geo,
                                                  uint8_t         attrib_type)
{
    const uint8_t *types;
    bool           found = false;
    int            i, cnt;
    types = get_attribute_types_ptr_const(&geo->templ);
    cnt   = geo_get_attribute_count(geo);
    for (i = 0; i < cnt; ++i) {
        if (types[i] == attrib_type) {
            found = true;
            break;
        }
    }
    if (!found)
        return NULL;
    size_t offset = get_attribute_array_internal_offset(geo, i);
    return geo->vertex_buffer_region.host_data + offset;
}

static void *find_attribute_array_ptr(Geometry *geo, uint8_t attrib_type)
{
    void *ptr = (void *)find_attribute_array_ptr_const(geo, attrib_type);
    return ptr;
}

static uint32_t *get_indices_ptr(Geometry *geo)
{
    assert(~geo->templ.flags & ONYX_GEOMETRY_FLAG_INDEX_SIZE_SHORT);
    assert(has_indices(geo));
    assert(geo->index_buffer_region.host_data);
    return (uint32_t *)geo->index_buffer_region.host_data;
}

// mikkt callbacks
static int mikkt_GetNumFaces(const SMikkTSpaceContext *ctx)
{
    const OnyxGeometry *geo = ctx->m_pUserData;
    return onyx_get_geo_triangle_count(geo);
}

static int mikkt_GetNumVerticesOfFace(const SMikkTSpaceContext *ctx,
                                      const int                 iFace)
{
    return 3;
}

static void mikkt_GetPosition(const SMikkTSpaceContext *ctx, float fvPosOut[],
                              const int iFace, const int iVert)
{
    const OnyxGeometry *geo   = ctx->m_pUserData;
    int                 index = iFace * 3 + iVert;
    int                 v = ((int *)geo->index_buffer_region.host_data)[index];

    const Vec3 *arr =
        find_attribute_array_ptr_const(geo, ONYX_ATTRIBUTE_TYPE_POS);
    assert(arr);
    fvPosOut[0] = arr[v].x;
    fvPosOut[1] = arr[v].y;
    fvPosOut[2] = arr[v].z;
}

static void mikkt_GetNormal(const SMikkTSpaceContext *pContext,
                            float fvNormOut[], const int iFace, const int iVert)
{
    const OnyxGeometry *geo   = pContext->m_pUserData;
    int                 index = iFace * 3 + iVert;
    int                 v = ((int *)geo->index_buffer_region.host_data)[index];

    const Vec3 *arr =
        find_attribute_array_ptr_const(geo, ONYX_ATTRIBUTE_TYPE_NORMAL);
    assert(arr);
    fvNormOut[0] = arr[v].x;
    fvNormOut[1] = arr[v].y;
    fvNormOut[2] = arr[v].z;
}

static void mikkt_GetTexCoord(const SMikkTSpaceContext *pContext,
                              float fvTexcOut[], const int iFace,
                              const int iVert)
{
    const OnyxGeometry *geo   = pContext->m_pUserData;
    int                 index = iFace * 3 + iVert;
    int                 v = ((int *)geo->index_buffer_region.host_data)[index];

    const Vec2 *arr =
        find_attribute_array_ptr_const(geo, ONYX_ATTRIBUTE_TYPE_UV);
    assert(arr);
    fvTexcOut[0] = arr[v].x;
    fvTexcOut[1] = arr[v].y;
}

static void mikkt_SetTSpaceBasic(const SMikkTSpaceContext *pContext,
                                 const float fvTangent[], const float fSign,
                                 const int iFace, const int iVert)
{
    OnyxGeometry *geo   = pContext->m_pUserData;
    int           index = iFace * 3 + iVert;
    int           v     = ((int *)geo->index_buffer_region.host_data)[index];

    Vec3 *tangents = find_attribute_array_ptr(geo, ONYX_ATTRIBUTE_TYPE_TANGENT);
    float *signs   = find_attribute_array_ptr(geo, ONYX_ATTRIBUTE_TYPE_SIGN);

    tangents[v].x = fvTangent[0];
    tangents[v].y = fvTangent[1];
    tangents[v].z = fvTangent[2];
    signs[v]      = fSign;
}

static void printPrim(const Geo *geo)
{
    hell_print(">>> printing Fprim info...");
    hell_print(">>> vertex count %d", onyx_get_geo_vertex_count(geo));
    hell_print(">>> attrCount %d", geo->templ.attribute_count);
    const OnyxAttributeType *attr_types;
    const OnyxAttributeSize *attr_sizes;
    attr_types    = get_attribute_types_ptr_const(&geo->templ);
    attr_sizes    = get_attribute_sizes_ptr_const(&geo->templ);
    const int cnt = geo_get_attribute_count(geo);
    for (int i = 0; i < cnt; ++i) {
        hell_print(">>> attr type %d attr size %d ", attr_types[i],
                   attr_sizes[i]);
    }
    if (has_indices(geo))
        hell_print(">>> index count %d ", onyx_get_geo_index_count(geo));
}

static VkFormat getFormat(const OnyxGeoAttributeSize attrSize,
                          const OnyxAttributeType    attrType)
{
    switch (attrType) {
        case ONYX_ATTRIBUTE_TYPE_POS:
        case ONYX_ATTRIBUTE_TYPE_UV:
        case ONYX_ATTRIBUTE_TYPE_NORMAL:
        case ONYX_ATTRIBUTE_TYPE_TANGENT:
        case ONYX_ATTRIBUTE_TYPE_BITANGENT:
        case ONYX_ATTRIBUTE_TYPE_SIGN:
        case ONYX_ATTRIBUTE_TYPE_COLOR:
            switch (attrSize) {
                case 4:
                    return VK_FORMAT_R32_SFLOAT;
                case 8:
                    return VK_FORMAT_R32G32_SFLOAT;
                case 12:
                    return VK_FORMAT_R32G32B32_SFLOAT;
                case 16:
                    return VK_FORMAT_R32G32B32A32_SFLOAT;
                default:
                    assert(0 && "Attribute size not supported");
            }
        case ONYX_ATTRIBUTE_TYPE_INDEX:
            switch (attrSize) {
                case 4:
                    return VK_FORMAT_R32_SINT;
                default:
                    assert(0 && "Attribute size not supported");
            }
        default:
            assert(0 && "Attribute type not supported");
    }
}

void onyx_print_geo(const OnyxGeometry *prim) { printPrim(prim); }

void onyx_transfer_geo_to_device(OnyxMemory *memory, OnyxGeometry *geo)
{
    onyx_transfer_to_device(memory, &geo->vertex_buffer_region);
    if (has_indices(geo)) {
        onyx_transfer_to_device(memory, &geo->index_buffer_region);
    }
}

OnyxGeometry onyx_create_triangle(OnyxMemory *memory)
{
    OnyxCreateGeometryInfo gi = {
        .templ = onyx_create_geometry_template(
            ONYX_GEOMETRY_TYPE_TRIANGLES, 0, 2, (uint8_t[2]){12, 12},
            (uint8_t[2]){ONYX_ATTRIBUTE_TYPE_POS, ONYX_ATTRIBUTE_TYPE_COLOR}),
        .index_count  = 3,
        .vertex_count = 3,
        .memory       = memory,
        .memtype      = ONYX_MEMORY_HOST_GRAPHICS_TYPE,
    };

    OnyxGeometry geo = onyx_create_geometry(&gi);

    Vec3 positions[] = {
        {0.0, 0.5, 0.0},
        {0.5, -0.5, 0.0},
        {-0.5, -0.5, 0.0},
    };

    Vec3 colors[] = {{0.0, 0.9, 0.0}, {0.9, 0.5, 0.0}, {0.5, 0.3, 0.9}};

    OnyxGeoIndex indices[] = {0, 1, 2};

    void *posData   = get_attribute_array_ptr(&geo, 0);
    void *colData   = get_attribute_array_ptr(&geo, 1);
    void *indexData = geo.index_buffer_region.host_data;

    memcpy(posData, positions, sizeof(positions));
    memcpy(colData, colors, sizeof(colors));
    memcpy(indexData, indices, sizeof(indices));

    _Static_assert(sizeof(indices) == 4 * 3, "");

    return geo;
}

OnyxGeometry onyx_create_cube(OnyxMemory *memory, const bool isClockWise)
{
    const uint32_t vertCount  = 24;
    const uint32_t indexCount = 36;
    const uint32_t attrCount  = 3; // position, normals, uvw

    OnyxCreateGeometryInfo gi = {
        .templ = onyx_create_geometry_template(
            ONYX_GEOMETRY_TYPE_TRIANGLES, 0, attrCount, (uint8_t[]){12, 12, 8},
            (uint8_t[]){ONYX_ATTRIBUTE_TYPE_POS, ONYX_ATTRIBUTE_TYPE_NORMAL,
                        ONYX_ATTRIBUTE_TYPE_UV}),
        .memory       = memory,
        .memtype      = ONYX_MEMORY_HOST_GRAPHICS_TYPE,
        .vertex_count = vertCount,
        .index_count  = indexCount};

    Geometry geo = onyx_create_geometry(&gi);

    Vec3 *pPositions = get_attribute_array_ptr(&geo, 0);
    Vec3 *pNormals   = get_attribute_array_ptr(&geo, 1);
    Vec2 *pUvws      = get_attribute_array_ptr(&geo, 2);

    const Vec3 points[8] = {
        {-0.5, 0.5, 0.5},  {-0.5, -0.5, 0.5}, {0.5, -0.5, 0.5},
        {0.5, 0.5, 0.5},   {-0.5, 0.5, -0.5}, {-0.5, -0.5, -0.5},
        {0.5, -0.5, -0.5}, {0.5, 0.5, -0.5},
    };

    const Vec3 normals[6] = {
        {0.0, 0.0, 1.0},  {0.0, 0.0, -1.0}, {0.0, 1.0, 0.0},
        {0.0, -1.0, 0.0}, {1.0, 0.0, 0.0},  {-1.0, 0.0, 0.0},
    };

    const Vec2 uvws[4] = {{0.0, 0.0}, {1.0, 0.0}, {0.0, 1.0}, {1.0, 1.0}};

    // face 0: +Z
    pPositions[0]  = points[0];
    pPositions[1]  = points[1];
    pPositions[2]  = points[2];
    pPositions[3]  = points[3];
    // face 1: -Z
    pPositions[4]  = points[7];
    pPositions[5]  = points[6];
    pPositions[6]  = points[5];
    pPositions[7]  = points[4];
    // face 2: -X
    pPositions[8]  = points[0];
    pPositions[9]  = points[4];
    pPositions[10] = points[5];
    pPositions[11] = points[1];
    // face 3: +X
    pPositions[12] = points[3];
    pPositions[13] = points[2];
    pPositions[14] = points[6];
    pPositions[15] = points[7];
    // face 4: +Y
    pPositions[16] = points[0];
    pPositions[17] = points[3];
    pPositions[18] = points[7];
    pPositions[19] = points[4];
    // face 5: -Y
    pPositions[20] = points[2];
    pPositions[21] = points[1];
    pPositions[22] = points[5];
    pPositions[23] = points[6];

    pNormals[0]  = normals[0];
    pNormals[1]  = normals[0];
    pNormals[2]  = normals[0];
    pNormals[3]  = normals[0];
    // pNormals -Z
    pNormals[4]  = normals[1];
    pNormals[5]  = normals[1];
    pNormals[6]  = normals[1];
    pNormals[7]  = normals[1];
    // pNormals -X
    pNormals[8]  = normals[5];
    pNormals[9]  = normals[5];
    pNormals[10] = normals[5];
    pNormals[11] = normals[5];
    // pNormals +X
    pNormals[12] = normals[4];
    pNormals[13] = normals[4];
    pNormals[14] = normals[4];
    pNormals[15] = normals[4];
    // pNormals +Y
    pNormals[16] = normals[2];
    pNormals[17] = normals[2];
    pNormals[18] = normals[2];
    pNormals[19] = normals[2];
    // pNormals -Y
    pNormals[20] = normals[3];
    pNormals[21] = normals[3];
    pNormals[22] = normals[3];
    pNormals[23] = normals[3];

    for (int i = 0; i < vertCount; i += 4) {
        pUvws[i + 1] = uvws[0];
        pUvws[i + 0] = uvws[1];
        pUvws[i + 2] = uvws[2];
        pUvws[i + 3] = uvws[3];
    }

    uint32_t *indices = get_indices_ptr(&geo);

    if (isClockWise)
        for (int face = 0; face < indexCount / 6; face++) {
            indices[face * 6 + 2] = 4 * face + 0;
            indices[face * 6 + 1] = 4 * face + 1;
            indices[face * 6 + 0] = 4 * face + 2;
            indices[face * 6 + 5] = 4 * face + 0;
            indices[face * 6 + 4] = 4 * face + 2;
            indices[face * 6 + 3] = 4 * face + 3;
        }
    else
        for (int face = 0; face < indexCount / 6; face++) {
            indices[face * 6 + 0] = 4 * face + 0;
            indices[face * 6 + 1] = 4 * face + 1;
            indices[face * 6 + 2] = 4 * face + 2;
            indices[face * 6 + 3] = 4 * face + 0;
            indices[face * 6 + 4] = 4 * face + 2;
            indices[face * 6 + 5] = 4 * face + 3;
        }

    // onyx_v_TransferToDevice(&prim.vertexRegion);
    // onyx_v_TransferToDevice(&prim.indexRegion);

    return geo;
}

OnyxGeometry onyx_create_cube_with_tangents(OnyxMemory *memory,
                                            const bool  isClockWise)
{
    const uint32_t vertCount  = 24;
    const uint32_t indexCount = 36;
    const uint32_t attrCount  = 5; // position, normals, tan, sign, uvw

    OnyxCreateGeometryInfo gi = {
        .templ = onyx_create_geometry_template(
            ONYX_GEOMETRY_TYPE_TRIANGLES, 0, attrCount,
            (uint8_t[]){12, 12, 12, 4, 8},
            (uint8_t[]){ONYX_ATTRIBUTE_TYPE_POS, ONYX_ATTRIBUTE_TYPE_NORMAL,
                        ONYX_ATTRIBUTE_TYPE_TANGENT, ONYX_ATTRIBUTE_TYPE_SIGN,
                        ONYX_ATTRIBUTE_TYPE_UV}),
        .memory       = memory,
        .memtype      = ONYX_MEMORY_HOST_GRAPHICS_TYPE,
        .vertex_count = vertCount,
        .index_count  = indexCount};

    Geometry geo = onyx_create_geometry(&gi);

    Vec3 *pPositions = get_attribute_array_ptr(&geo, 0);
    Vec3 *pNormals   = get_attribute_array_ptr(&geo, 1);
    Vec2 *pUvws      = get_attribute_array_ptr(&geo, 2);

    const Vec3 points[8] = {
        {-0.5, 0.5, 0.5},  {-0.5, -0.5, 0.5}, {0.5, -0.5, 0.5},
        {0.5, 0.5, 0.5},   {-0.5, 0.5, -0.5}, {-0.5, -0.5, -0.5},
        {0.5, -0.5, -0.5}, {0.5, 0.5, -0.5},
    };

    const Vec3 normals[6] = {
        {0.0, 0.0, 1.0},  {0.0, 0.0, -1.0}, {0.0, 1.0, 0.0},
        {0.0, -1.0, 0.0}, {1.0, 0.0, 0.0},  {-1.0, 0.0, 0.0},
    };

    const Vec2 uvws[4] = {{0.0, 0.0}, {1.0, 0.0}, {0.0, 1.0}, {1.0, 1.0}};

    // face 0: +Z
    pPositions[0]  = points[0];
    pPositions[1]  = points[1];
    pPositions[2]  = points[2];
    pPositions[3]  = points[3];
    // face 1: -Z
    pPositions[4]  = points[7];
    pPositions[5]  = points[6];
    pPositions[6]  = points[5];
    pPositions[7]  = points[4];
    // face 2: -X
    pPositions[8]  = points[0];
    pPositions[9]  = points[4];
    pPositions[10] = points[5];
    pPositions[11] = points[1];
    // face 3: +X
    pPositions[12] = points[3];
    pPositions[13] = points[2];
    pPositions[14] = points[6];
    pPositions[15] = points[7];
    // face 4: +Y
    pPositions[16] = points[0];
    pPositions[17] = points[3];
    pPositions[18] = points[7];
    pPositions[19] = points[4];
    // face 5: -Y
    pPositions[20] = points[2];
    pPositions[21] = points[1];
    pPositions[22] = points[5];
    pPositions[23] = points[6];

    pNormals[0]  = normals[0];
    pNormals[1]  = normals[0];
    pNormals[2]  = normals[0];
    pNormals[3]  = normals[0];
    // pNormals -Z
    pNormals[4]  = normals[1];
    pNormals[5]  = normals[1];
    pNormals[6]  = normals[1];
    pNormals[7]  = normals[1];
    // pNormals -X
    pNormals[8]  = normals[5];
    pNormals[9]  = normals[5];
    pNormals[10] = normals[5];
    pNormals[11] = normals[5];
    // pNormals +X
    pNormals[12] = normals[4];
    pNormals[13] = normals[4];
    pNormals[14] = normals[4];
    pNormals[15] = normals[4];
    // pNormals +Y
    pNormals[16] = normals[2];
    pNormals[17] = normals[2];
    pNormals[18] = normals[2];
    pNormals[19] = normals[2];
    // pNormals -Y
    pNormals[20] = normals[3];
    pNormals[21] = normals[3];
    pNormals[22] = normals[3];
    pNormals[23] = normals[3];

    for (int i = 0; i < vertCount; i += 4) {
        pUvws[i + 1] = uvws[0];
        pUvws[i + 0] = uvws[1];
        pUvws[i + 2] = uvws[2];
        pUvws[i + 3] = uvws[3];
    }

    OnyxGeoIndex *indices = onyx_get_geo_indices(&geo);

    if (isClockWise)
        for (int face = 0; face < indexCount / 6; face++) {
            indices[face * 6 + 2] = 4 * face + 0;
            indices[face * 6 + 1] = 4 * face + 1;
            indices[face * 6 + 0] = 4 * face + 2;
            indices[face * 6 + 5] = 4 * face + 0;
            indices[face * 6 + 4] = 4 * face + 2;
            indices[face * 6 + 3] = 4 * face + 3;
        }
    else
        for (int face = 0; face < indexCount / 6; face++) {
            indices[face * 6 + 0] = 4 * face + 0;
            indices[face * 6 + 1] = 4 * face + 1;
            indices[face * 6 + 2] = 4 * face + 2;
            indices[face * 6 + 3] = 4 * face + 0;
            indices[face * 6 + 4] = 4 * face + 2;
            indices[face * 6 + 5] = 4 * face + 3;
        }

    SMikkTSpaceInterface mikkt_interface = {
        .m_getNumFaces          = mikkt_GetNumFaces,
        .m_getNormal            = mikkt_GetNormal,
        .m_getNumVerticesOfFace = mikkt_GetNumVerticesOfFace,
        .m_getPosition          = mikkt_GetPosition,
        .m_getTexCoord          = mikkt_GetTexCoord,
        .m_setTSpaceBasic       = mikkt_SetTSpaceBasic,
    };

    SMikkTSpaceContext mikkt_context = {.m_pInterface = &mikkt_interface,
                                        .m_pUserData  = &geo};

    onyx_print_geo(&geo);
    tbool r = genTangSpaceDefault(&mikkt_context);
    assert(r);

    onyx_print_geo(&geo);

    // onyx_v_TransferToDevice(&prim.vertexRegion);
    // onyx_v_TransferToDevice(&prim.indexRegion);

    return geo;
}

OnyxGeometry onyx_create_points(OnyxMemory *memory, OnyxMemoryType memtype,
                                const uint32_t count, int attr_count,
                                const uint8_t *attr_sizes,
                                const uint8_t *attr_types)
{
    OnyxCreateGeometryInfo gi = {
        .templ = onyx_create_geometry_template(
            ONYX_GEOMETRY_TYPE_POINTS, ONYX_GEOMETRY_FLAG_UNINDEXED, attr_count,
            attr_sizes, attr_types),
        .vertex_count = count,
        .memtype      = memtype,
        .memory       = memory,
    };

    OnyxGeometry geo = onyx_create_geometry(&gi);
    return geo;
}

OnyxGeometry onyx_create_curve(OnyxMemory *memory, const uint32_t vertCount,
                               const uint32_t patchSize,
                               const uint32_t restartOffset)
{
    assert(0 && "Need to imnplement");
    // assert(patchSize < vertCount);
    // assert(restartOffset < patchSize);

    // OnyxGeometry prim = {
    //     .attrCount   = 2,
    //     .attrSizes   = {12, 12},
    //     .indexCount  = vertCount * patchSize, // to handle maximum
    //     restartOffset .vertexCount = vertCount,
    // };

    // initPrimBuffers(memory, 0x0, &prim);

    // Vec3* positions = onyx_get_geo_attribute(&prim, 0);
    // Vec3* colors    = onyx_get_geo_attribute(&prim, 1);

    // for (int i = 0; i < vertCount; i++)
    //{
    //     positions[i] = (Vec3){0, 0, 0};
    //     colors[i]    = (Vec3){1, 0, 0};
    // }

    // OnyxGeoIndex* indices = onyx_get_geo_indices(&prim);

    // for (int i = 0, vertid = 0; vertid < prim.vertexCount;)
    //{
    //     assert(i < prim.indexCount);
    //     assert(vertid <= i);
    //     indices[i] = vertid++;
    //     i++;
    //     if (i % patchSize == 0)
    //         vertid -= restartOffset;
    //     assert(vertid >= 0);
    // }

    // return prim;
}

OnyxGeometry onyx_create_quad_n_d_c(OnyxMemory *memory, const float x,
                                    const float y, const float width,
                                    const float height)
{
    assert(0 && "Need to imnplement");
    // OnyxGeometry prim = {.attrCount   = 2,
    //                       .indexCount  = 6,
    //                       .vertexCount = 4,
    //                       .attrSizes   = {12, 12}};

    // initPrimBuffers(memory, 0x0, &prim);

    // Vec3* pos = onyx_get_geo_attribute(&prim, 0);
    //// upper left. x, y
    // pos[0]    = (Vec3){x, y, 0};
    // pos[1]    = (Vec3){x, y + height, 0};
    // pos[2]    = (Vec3){x + width, y, 0};
    // pos[3]    = (Vec3){x + width, y + height, 0};

    // Vec3* uvw = onyx_get_geo_attribute(&prim, 1);
    // uvw[0]    = (Vec3){0, 0, 0};
    // uvw[1]    = (Vec3){0, 1, 0};
    // uvw[2]    = (Vec3){1, 0, 0};
    // uvw[3]    = (Vec3){1, 1, 0};

    // OnyxGeoIndex* index = onyx_get_geo_indices(&prim);
    // index[0]             = 0;
    // index[1]             = 1;
    // index[2]             = 2;
    // index[3]             = 2;
    // index[4]             = 1;
    // index[5]             = 3;

    // return prim;
}

OnyxGeometry onyx_create_quad_ndc_pos8_uv8(OnyxMemory *memory, const float x,
                                           const float y, const float width,
                                           const float height, u32 flags)
{
    struct onyx_geometry_template templ = onyx_create_geometry_template(
        ONYX_GEOMETRY_TYPE_TRIANGLES, flags, 2, (uint8_t[2]){8, 8},
        (uint8_t[2]){ONYX_ATTRIBUTE_TYPE_POS, ONYX_ATTRIBUTE_TYPE_UV});

    OnyxCreateGeometryInfo gi = {
        .templ        = templ,
        .index_count  = 6,
        .vertex_count = 4,
        .memory       = memory,
        .memtype      = ONYX_MEMORY_HOST_GRAPHICS_TYPE,
    };

    OnyxGeometry geo = onyx_create_geometry(&gi);

    Vec2    *pos, *uvs;
    int32_t *indices;

    pos     = get_attribute_array_ptr(&geo, 0);
    uvs     = get_attribute_array_ptr(&geo, 1);
    indices = (int32_t *)geo.index_buffer_region.host_data;

    // initPrimBuffers(memory, 0x0, &prim);

    // Vec3* pos = onyx_get_geo_attribute(&prim, 0);
    //// upper left. x, y
    pos[0] = (Vec2){x, y};
    pos[1] = (Vec2){x, y + height};
    pos[2] = (Vec2){x + width, y};
    pos[3] = (Vec2){x + width, y + height};

    // Vec3* n = onyx_get_geo_attribute(&prim, 1);
    // n[0]    = (Vec3){0, 0, 1};
    // n[1]    = (Vec3){0, 0, 1};
    // n[2]    = (Vec3){0, 0, 1};
    // n[3]    = (Vec3){0, 0, 1};

    // Vec2* uvs = onyx_get_geo_attribute(&prim, 2);
    uvs[0] = (Vec2){0, 0};
    uvs[1] = (Vec2){0, 1};
    uvs[2] = (Vec2){1, 0};
    uvs[3] = (Vec2){1, 1};

    // OnyxGeoIndex* index = onyx_get_geo_indices(&prim);
    indices[0] = 0;
    indices[1] = 1;
    indices[2] = 2;
    indices[3] = 2;
    indices[4] = 1;
    indices[5] = 3;

    return geo;
    // return prim;
}

OnyxGeometry onyx_create_quad_n_d_c_2(OnyxMemory *memory, const float x,
                                      const float y, const float width,
                                      const float height)
{
    assert(0 && "Need to imnplement");
    // OnyxGeometry prim = {.attrCount   = 3,
    //                       .indexCount  = 6,
    //                       .vertexCount = 4,
    //                       .attrNames   = {POS_NAME, NORMAL_NAME, UV_NAME},
    //                       .attrSizes   = {12, 12, 8}};

    // initPrimBuffers(memory, 0x0, &prim);

    // Vec3* pos = onyx_get_geo_attribute(&prim, 0);
    //// upper left. x, y
    // pos[0]    = (Vec3){x, y, 0};
    // pos[1]    = (Vec3){x, y + height, 0};
    // pos[2]    = (Vec3){x + width, y, 0};
    // pos[3]    = (Vec3){x + width, y + height, 0};

    // Vec3* n = onyx_get_geo_attribute(&prim, 1);
    // n[0]    = (Vec3){0, 0, 1};
    // n[1]    = (Vec3){0, 0, 1};
    // n[2]    = (Vec3){0, 0, 1};
    // n[3]    = (Vec3){0, 0, 1};

    // Vec2* uvs = onyx_get_geo_attribute(&prim, 2);
    // uvs[0]    = (Vec2){0, 0};
    // uvs[1]    = (Vec2){0, 1};
    // uvs[2]    = (Vec2){1, 0};
    // uvs[3]    = (Vec2){1, 1};

    // OnyxGeoIndex* index = onyx_get_geo_indices(&prim);
    // index[0]             = 0;
    // index[1]             = 1;
    // index[2]             = 2;
    // index[3]             = 2;
    // index[4]             = 1;
    // index[5]             = 3;

    // return prim;
}

uint32_t onyx_get_geo_index_count(const OnyxGeometry *geo)
{
    assert(!(geo->templ.flags & ONYX_GEOMETRY_FLAG_UNINDEXED));
    return geo->index_buffer_region.size / get_index_size(&geo->templ);
}

uint32_t onyx_get_geo_vertex_count(const OnyxGeometry *geo)
{
    return geo->vertex_buffer_region.size / get_vertex_size(&geo->templ);
}

uint32_t onyx_get_geo_triangle_count(const OnyxGeometry *geo)
{
    assert(geo->templ.type & ONYX_GEOMETRY_TYPE_TRIANGLES);
    assert(!(geo->templ.flags & ONYX_GEOMETRY_FLAG_UNINDEXED));
    return onyx_get_geo_index_count(geo) / 3;
}

OnyxGeometryTemplate onyx_geo_template_create_base(int  attr_count,
                                                   bool no_types)
{
    OnyxGeometryTemplate templ = {
        .attribute_count = attr_count,
    };
    return templ;
}

void onyx_geo_template_set_attr_size(OnyxGeometryTemplate *t, int index,
                                     uint8_t size)
{
    uint8_t *sizes = get_attribute_sizes_ptr(t);
    sizes[index]   = size;
}

void onyx_geo_template_set_attr_type(OnyxGeometryTemplate *t, int index,
                                     OnyxAttributeType type)
{
    OnyxAttributeType *types = get_attribute_types_ptr(t);
    types[index]             = type;
}

OnyxGeometry onyx_create_geometry(const OnyxCreateGeometryInfo *c)
{
    assert(
        (c->index_count > 0 &&
         ~c->templ.flags & ONYX_GEOMETRY_FLAG_UNINDEXED) ||
        (c->index_count == 0 && c->templ.flags & ONYX_GEOMETRY_FLAG_UNINDEXED));
    assert(c->templ.attribute_count > 0);
    assert(c->vertex_count > 0);

    OnyxGeometryTemplate templ = c->templ;

    u32 vertex_size = 0;
    for (u32 i = 0; i < templ.attribute_count; i++) {
        // TODO make sure this is right
        vertex_size += templ.attribute_sizes[i];
    }

    const u32 vert_buf_size = vertex_size * c->vertex_count;

    OnyxGeometry geo = {.templ = templ};

    printf("Req vert\n");
    geo.vertex_buffer_region = onyx_request_buffer_region(
        c->memory, vert_buf_size, VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
        c->memtype);

    if (~templ.flags & ONYX_GEOMETRY_FLAG_UNINDEXED) {
        printf("Req index\n");
        assert(c->index_count > 0);
        const u32 index_buf_size = c->index_count * get_index_size(&templ);
        geo.index_buffer_region  = onyx_request_buffer_region(
            c->memory, index_buf_size, VK_BUFFER_USAGE_INDEX_BUFFER_BIT,
            c->memtype);
    }
    // TODO finish

    return geo;
}

void onyx_free_geometry(OnyxGeometry *geo)
{
    onyx_free_buffer(&geo->vertex_buffer_region);
    if (~geo->templ.flags & ONYX_GEOMETRY_FLAG_UNINDEXED)
        onyx_free_buffer(&geo->index_buffer_region);
    memset(geo, 0, sizeof(*geo));
}

OnyxVertexDescription
onyx_get_vertex_description(const uint32_t             attrCount,
                            const OnyxGeoAttributeSize attrSizes[])
{
    assert(attrCount < ONYX_R_MAX_VERT_ATTRIBUTES);
    OnyxVertexDescription desc = {.attribute_count = attrCount,
                                  .binding_count   = attrCount};

    for (int i = 0; i < desc.attribute_count; i++) {
        desc.binding_descriptions[i] = (VkVertexInputBindingDescription){
            .binding   = i,
            .stride    = attrSizes[i],
            .inputRate = VK_VERTEX_INPUT_RATE_VERTEX};

        desc.attribute_descriptions[i] = (VkVertexInputAttributeDescription){
            .binding  = i,
            .location = i,
            .format   = getFormat(attrSizes[i], ONYX_ATTRIBUTE_TYPE_POS),
            .offset   = 0};
    }

    return desc;
}

void *onyx_get_geo_attribute(OnyxGeometry *geo, const uint32_t index)
{
    return get_attribute_array_ptr(geo, index);
}

const void *onyx_get_geo_attribute_ro(const OnyxGeometry *geo,
                                      const uint32_t      index)
{
    return get_attribute_array_ptr(geo, index);
}

uint32_t *onyx_get_geo_indices(OnyxGeometry *geo)
{
    return get_indices_ptr(geo);
}

const uint32_t *onyx_get_geo_indices_ro(const OnyxGeometry *geo)
{
    return get_indices_ptr((OnyxGeometry *)geo);
}

void onyx_bind_geo(const VkCommandBuffer cmdBuf, const OnyxGeometry *prim)
{
    VkBuffer     vert_buffers[8];
    VkDeviceSize attr_offsets[8];
    assert(prim->templ.attribute_count <= 8);
    // for now
    assert(~prim->templ.flags & ONYX_GEOMETRY_FLAG_ARRAY_OF_STRUCTS);

    const int cnt = geo_get_attribute_count(prim);
    for (int i = 0; i < cnt; i++) {
        vert_buffers[i] = prim->vertex_buffer_region.buffer;
        attr_offsets[i] = get_attribute_array_buffer_offset(prim, i);
    }

    vkCmdBindVertexBuffers(cmdBuf, 0, cnt, vert_buffers, attr_offsets);

    if (has_indices(prim))
        vkCmdBindIndexBuffer(cmdBuf, prim->index_buffer_region.buffer,
                             prim->index_buffer_region.offset,
                             ONYX_VERT_INDEX_TYPE);
}

void onyx_draw_geo(const VkCommandBuffer cmdBuf, const OnyxGeometry *prim,
                   uint32_t instance_count)
{
    onyx_bind_geo(cmdBuf, prim);
    if (has_indices(prim))
        vkCmdDrawIndexed(cmdBuf, onyx_get_geo_index_count(prim), instance_count,
                         0, 0, 0);
    else
        vkCmdDraw(cmdBuf, get_vertex_count(prim), instance_count, 0, 0);
}

void onyx_draw_geo_elem_count(const VkCommandBuffer cmdBuf,
                              const OnyxGeometry *prim, uint32_t elem_count,
                              uint32_t instance_count)
{
    onyx_bind_geo(cmdBuf, prim);
    if (has_indices(prim)) {
        uint32_t geo_count = onyx_get_geo_index_count(prim);
        uint32_t count     = MIN(geo_count, elem_count);
        vkCmdDrawIndexed(cmdBuf, count, instance_count, 0, 0, 0);
    } else {
        uint32_t geo_count = get_vertex_count(prim);
        uint32_t count     = MIN(geo_count, elem_count);
        vkCmdDraw(cmdBuf, count, instance_count, 0, 0);
    }
}

int onyx_geo_template_get_attribute_size(const OnyxGeometryTemplate *t,
                                         int                         index)
{
    const uint8_t *sizes = get_attribute_sizes_ptr_const(t);
    return sizes[index];
}

int onyx_geo_template_get_attribute_type(const OnyxGeometryTemplate *t,
                                         int                         index)
{
    const uint8_t *types = get_attribute_types_ptr_const(t);
    return types[index];
}

int onyx_geo_template_get_vertex_size(const OnyxGeometryTemplate *t)
{
    return get_vertex_size(t);
}

int onyx_geo_get_vertex_size(const OnyxGeometry *geo)
{
    return onyx_geo_template_get_vertex_size(&geo->templ);
}

int onyx_geo_get_attribute_size(const OnyxGeometry *geo, int index)
{
    return onyx_geo_template_get_attribute_size(&geo->templ, index);
}

int onyx_geo_get_attribute_type(const OnyxGeometry *geo, int index)
{
    return onyx_geo_template_get_attribute_type(&geo->templ, index);
}

VkFormat onyx_geo_template_get_attribute_format(const OnyxGeometryTemplate *geo,
                                                int index)
{
    const uint8_t *sizes, *types;

    sizes = get_attribute_sizes_ptr_const(geo);
    types = get_attribute_types_ptr_const(geo);

    return getFormat(sizes[index], types[index]);
}

int onyx_geo_template_get_attribute_offset(const OnyxGeometryTemplate *templ,
                                           int                         index)
{
    assert(templ->flags & ONYX_GEOMETRY_FLAG_ARRAY_OF_STRUCTS);
    assert(index < templ->attribute_count);

    int            offset = 0;
    const uint8_t *sizes  = get_attribute_sizes_ptr_const(templ);
    for (int i = 0; i < index; ++i) {
        offset += sizes[i];
    }

    return offset;
}

OnyxGeometryTemplate onyx_create_geometry_template(enum onyx_geometry_type type,
                                                   uint32_t       flags,
                                                   uint32_t       attr_count,
                                                   const uint8_t *attr_sizes,
                                                   const uint8_t *attr_types)
{
    OnyxGeometryTemplate templ = onyx_geo_template_create_base(
        attr_count, flags & ONYX_GEOMETRY_FLAG_NO_TYPES);
    templ.flags = flags;
    templ.type  = type;

    memcpy(templ.attribute_sizes, attr_sizes, attr_count);

    if (~flags & ONYX_GEOMETRY_FLAG_NO_TYPES)
        memcpy(templ.attribute_types, attr_types, attr_count);

    return templ;
}

static void print_gltf_attr(const cgltf_attribute *attr)
{
    printf("Attr name: %s\n", attr->name);
    printf("Count count: %ld\n", attr->data->count);
    printf("Component type: %d\n", attr->data->component_type);
    printf("Vector type: %d\n", attr->data->type);
    printf("Stride: %ld\n", attr->data->stride);
}

int hell_gltf_init(const char *filepath, HellGltfData *data)
{
    int                  err = 0;
    struct cgltf_options options = {0};
    struct cgltf_data   *gltf_data = NULL;
//    ByteArray            buf = {0};
//
//    err = hell_read_file(filepath, &buf);
//    if (err)
//        return err;
//
//    err = cgltf_parse(&options, buf.elems, buf.count, &gltf_data);
    err = cgltf_parse_file(&options, filepath, &gltf_data);

    if (err != cgltf_result_success) {
        sprintf(data->err_msg, "cgltf failed to parse");
        goto end;
    }

    err = cgltf_validate(gltf_data);
    if (err != cgltf_result_success) {
        sprintf(data->err_msg, "cgltf_validate failed: %d\n", err);
        cgltf_free(gltf_data);
        goto end;
    }

    err = cgltf_load_buffers(&options, gltf_data, filepath);
    if (err != cgltf_result_success) {
        sprintf(data->err_msg, "cgltf_load_buffers failed: %d\n", err);
        cgltf_free(gltf_data);
        goto end;
    }

    printf("Read successful.\n");

    data->data = gltf_data;
end:
    //byte_arr_free(&buf);
    return err;
}

int hell_gltf_read_mesh(HellGltfData *gltf, OnyxMemory *mem,
                        const OnyxGeometryTemplate *reqt, OnyxGeometry *geo)
{
    static const int ATTR_TYPE_MAP[ONYX_ATTRIBUTE_TYPE_COUNT] = {
        cgltf_attribute_type_position, cgltf_attribute_type_texcoord,
        cgltf_attribute_type_color,    cgltf_attribute_type_normal,
        cgltf_attribute_type_tangent,  cgltf_attribute_type_invalid,
        cgltf_attribute_type_invalid,  cgltf_attribute_type_invalid,
    };

    _Static_assert(ONYX_ATTRIBUTE_TYPE_POS == 0,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_UV == 1,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_COLOR == 2,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_NORMAL == 3,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_TANGENT == 4,
                   "Attribute index changed. Must update map.");
    _Static_assert(cgltf_result_success == 0,
                   "Code relies on cgltf result being 0");

    cgltf_data *gltf_data = gltf->data;

    printf("Mesh count: %ld\n\
            Name: %s\n\
            Prim count: %ld\n",
           gltf_data->meshes_count, gltf_data->meshes[0].name,
           gltf_data->meshes[0].primitives_count);

    const struct cgltf_primitive *prim = &gltf_data->meshes[0].primitives[0];

    printf("Attr count: %ld\n", prim->attributes_count);
    printf("Attr available: %ld\n", prim->attributes_count);
    for (int i = 0; i < prim->attributes_count; ++i) {
        printf("%s\n", prim->attributes[i].name);
    }

    const cgltf_attribute *attr_map[ONYX_ATTRIBUTE_TYPE_COUNT] = {0};

    for (int j = 0; j < reqt->attribute_count; ++j) {
        enum onyx_attribute_type  ontyp = reqt->attribute_types[j];
        enum cgltf_attribute_type sktyp = ATTR_TYPE_MAP[ontyp];
        for (int i = 0; i < prim->attributes_count; ++i) {
            if (prim->attributes[i].type != sktyp)
                continue;
            // assert(cgltf_calc_size(prim->attributes[i].data->type,
            // prim->attributes[i].data->component_type) == size);
            attr_map[ontyp] = &prim->attributes[i];
        }
        // TODO add a parameter to optionally require all attributes are found
        // if (attr_map[ontyp] == NULL) {
        //     sprintf(gltf->err_msg, "ERROR: Attribute not found: %d\n", ontyp);
        //     return 1;
        // }
    }

    if (!attr_map[ONYX_ATTRIBUTE_TYPE_POS]) {
        printf("No position attribute found!");
        return 1;
    }

    const cgltf_attribute *pos_attr = attr_map[ONYX_ATTRIBUTE_TYPE_POS];
    print_gltf_attr(pos_attr);

    const cgltf_attribute *attr;
    if ((attr = attr_map[ONYX_ATTRIBUTE_TYPE_UV]))
        print_gltf_attr(attr);
    if ((attr = attr_map[ONYX_ATTRIBUTE_TYPE_NORMAL]))
        print_gltf_attr(attr);
    if ((attr = attr_map[ONYX_ATTRIBUTE_TYPE_COLOR]))
        print_gltf_attr(attr);

    const cgltf_accessor    *pos_acc  = pos_attr->data;
    const cgltf_accessor    *ind_acc  = prim->indices;
    const cgltf_buffer_view *pos_view = pos_acc->buffer_view;
    const cgltf_buffer_view *ind_view = ind_acc->buffer_view;

    const cgltf_buffer *pbuf = pos_view->buffer;
    const cgltf_buffer *ibuf = ind_view->buffer;

    printf("Buf uri: %s\n", pbuf->uri);

    assert(pbuf->data);
    assert(ibuf->data);

    printf("Index component type: %d\n", ind_acc->component_type);
    printf("Index stride: %ld\n", ind_acc->stride);

    cgltf_size fcount = cgltf_accessor_unpack_floats(pos_acc, NULL, 0);
    const int  nverts = fcount / 3;

    printf("Vert count: %d\n", nverts);

    OnyxCreateGeometryInfo ci = {
        .index_count  = prim->indices->count,
        .vertex_count = nverts,
        .memory       = mem,
        .memtype      = ONYX_MEMORY_HOST_GRAPHICS_TYPE,
        .templ        = *reqt,
    };

    *geo = onyx_create_geometry(&ci);

    uint32_t *indices = onyx_get_geo_indices(geo);

    for (int i = 0; i < ci.index_count; ++i) {
        indices[i] = cgltf_accessor_read_index(ind_acc, i);
    }

    // reading pos
    for (int i = 0; i < reqt->attribute_count; ++i) {
        float  stage[16];
        int    type  = onyx_geo_get_attribute_type(geo, i);
        if (attr_map[type] == NULL) {
            continue;
        }
        int    sz    = onyx_geo_get_attribute_size(geo, i) / sizeof(float);
        int    ncomp = cgltf_num_components(attr_map[type]->data->type);
        float *out   = onyx_get_geo_attribute(geo, i);
        printf("name: %s type: %d size: %d \n",
               onyx_geo_attribute_type_name(type), type, sz);
        for (int v = 0; v < nverts; ++v) {
            float *dst = out + v * sz;
            bool   b = cgltf_accessor_read_float(attr_map[type]->data, v, stage,
                                                 ncomp);
            fatal_condition(!b, "Failed to read float attrib: %s",
                            attr_map[type]->name);
            for (int i = 0; i < sz; ++i) {
                dst[i] = stage[i];
            }
        }
    }

    return 0;
}

uint32_t gltf_get_prim_vertex_count(const struct cgltf_primitive *prim)
{
    for (int i = 0; i < prim->attributes_count; ++i) {
        if (prim->attributes[i].type == cgltf_attribute_type_position) {
            cgltf_size fcount =
                cgltf_accessor_unpack_floats(prim->attributes[i].data, NULL, 0);
            const int nverts = fcount / 3;
            return nverts;
        }
    }
    fatal_error("No position attribute found!");
    return 0;
}

int hell_gltf_read_character(HellGltfData *gltf, HellCharacterData *character)
{
    cgltf_data *gltf_data = gltf->data;

    if (gltf_data->skins_count < 1) {
        printf("No skins available in gltf\n");
        return 1;
    }

    const cgltf_mesh      *mesh         = &gltf_data->meshes[0];
    const cgltf_primitive *prim         = &mesh->primitives[0];
    const cgltf_skin      *skin         = &gltf_data->skins[0];
    const cgltf_accessor  *bind_mat_acc = skin->inverse_bind_matrices;
    assert(bind_mat_acc && "Joint joint accessor, which we currently rely on");

    uint32_t joint_count = 0;
    // get joint count
    {
        cgltf_size fcount = cgltf_accessor_unpack_floats(bind_mat_acc, NULL, 0);
        int        ncomp  = cgltf_num_components(bind_mat_acc->type);

        assert(ncomp == 16);
        assert(fcount % 16 == 0);
        joint_count = fcount / 16;
    }

    assert(joint_count == skin->joints_count);

    for (uint32_t i = 0; i < gltf_data->nodes_count; i++) {
        printf("Node %d: %s\n", i, gltf_data->nodes[i].name);
    }
    // read joints into matrix array
    CoalMat4 *joints = malloc(joint_count * sizeof(*joints));
    char    (*joint_names)[JOINT_MAX_NAME_LEN] = malloc(joint_count * sizeof(*joint_names));
    for (uint32_t i = 0; i < joint_count; ++i) {
        CoalMat4 *dst = joints + i;
        char *name = joint_names[i];
        cgltf_accessor_read_float(bind_mat_acc, i, (float *)dst->e, 16);
        strncpy(name, skin->joints[i]->name, JOINT_MAX_NAME_LEN);
        printf("joint %d: %s\n", i, name);
    }

    const uint32_t  nverts      = gltf_get_prim_vertex_count(prim);
    HellWeightsMap *weights_map = malloc(nverts * sizeof(*weights_map));

    uint32_t              num_joint_acc   = 0;
    uint32_t              num_weights_acc = 0;
    const cgltf_accessor *joint_accs[MAX_CHARACTER_WEIGHTS / 4];
    const cgltf_accessor *weight_accs[MAX_CHARACTER_WEIGHTS / 4];

    for (int i = 0; i < prim->attributes_count; ++i) {
        printf("name %s index %d\n", prim->attributes[i].name,
               prim->attributes[i].index);
        int idx = prim->attributes[i].index;
        if (prim->attributes[i].type == cgltf_attribute_type_joints) {
            joint_accs[idx] = prim->attributes[i].data;
            num_joint_acc++;
        } else if (prim->attributes[i].type == cgltf_attribute_type_weights) {
            weight_accs[idx] = prim->attributes[i].data;
            num_weights_acc++;
        }
    }

    assert(num_joint_acc > 0 && num_joint_acc == num_weights_acc);

    printf("joint component type: %d\nweights component type: %d\n",
           joint_accs[0]->component_type, weight_accs[0]->component_type);
    printf("num joint acc: %d\n", num_joint_acc);

    for (int i = 0; i < num_joint_acc; ++i) {
        assert(joint_accs[1]->component_type == cgltf_component_type_r_16u);
    }
    assert(weight_accs[0]->component_type == cgltf_component_type_r_32f);
    assert(cgltf_num_components(joint_accs[0]->type) == 4);
    assert(cgltf_num_components(weight_accs[0]->type) == 4);

    // fill in vert data
    for (uint32_t vert_id = 0; vert_id < nverts; ++vert_id) {
        HellWeightsMap *map = weights_map + vert_id;
        map->nweights       = 0;
        for (uint32_t acc_id = 0; acc_id < num_joint_acc; ++acc_id) {
            const cgltf_accessor *joints, *weights;

            joints  = joint_accs[acc_id];
            weights = weight_accs[acc_id];

            assert(joints->count == weights->count);

            cgltf_uint j_out[4];
            float      w_out[4];

            cgltf_accessor_read_uint(joints, vert_id, j_out, 4);
            cgltf_accessor_read_float(weights, vert_id, w_out, 4);

            for (int i = 0; i < 4; ++i) {
                map->joints[4 * acc_id + i]  = j_out[i];
                map->weights[4 * acc_id + i] = w_out[i];
            }

            map->nweights += 4;
            assert(map->nweights <= MAX_CHARACTER_WEIGHTS);
        }
        if (vert_id < 10) {
            printf("Vert %d:\n ", vert_id);
            for (int i = 0; i < map->nweights; ++i) {
                printf("\tweight %f joint %d\n", map->weights[i], map->joints[i]);
            }
        }
    }
    printf("gltf nvertes: %d\n", nverts);

    assert(prim->indices && "For now, require indices for characters");

    zero(character);
    character->joint_count  = joint_count;
    character->vert_count   = nverts;
    character->joints       = joints;
    character->weights_data = weights_map;
    character->joints_names = joint_names;
    return 0;
}

void hell_gltf_term(HellGltfData *data) { cgltf_free(data->data); }

// TODO add an error message buffer
int onyx_load_gltf(const char *filepath, OnyxMemory *mem,
                   const OnyxGeometryTemplate *reqt, OnyxGeometry *geo,
                   char errmsg[256])
{
    HellGltfData gltf;
    int          err = 0;

    err = hell_gltf_init(filepath, &gltf);

    if (err) {
        printf("%s\n", gltf.err_msg);
        return err;
    }

    err = hell_gltf_read_mesh(&gltf, mem, reqt, geo);

    if (err) {
        printf("%s\n", gltf.err_msg);
        return err;
    }

    hell_gltf_term(&gltf);
    return 0;
}

const char *onyx_geo_attribute_type_name(enum onyx_attribute_type type)
{
    static const char *map[] = {
        POS_NAME,     UV_NAME,        COL_NAME,  NORMAL_NAME,
        TANGENT_NAME, BITANGENT_NAME, SIGN_NAME,
    };

    _Static_assert(ONYX_ATTRIBUTE_TYPE_POS == 0,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_UV == 1,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_COLOR == 2,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_NORMAL == 3,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_TANGENT == 4,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_BITANGENT == 5,
                   "Attribute index changed. Must update map.");
    _Static_assert(ONYX_ATTRIBUTE_TYPE_SIGN == 6,
                   "Attribute index changed. Must update map.");

    assert(type < ONYX_ATTRIBUTE_TYPE_COUNT);
    return map[type];
}

OnyxAttributeType
onyx_vert_input_attr_type(const OnyxVertexInputAttributeReflection *vi)
{
    char *res = NULL;

    res = strstr(vi->name, "pos");
    if (res)
        return ONYX_ATTRIBUTE_TYPE_POS;
    res = strstr(vi->name, "uv");
    if (res)
        return ONYX_ATTRIBUTE_TYPE_UV;
    res = strstr(vi->name, "norm");
    if (res)
        return ONYX_ATTRIBUTE_TYPE_NORMAL;
    res = strstr(vi->name, "index");
    if (res)
        return ONYX_ATTRIBUTE_TYPE_INDEX;
    fatal_error("Error: Could not identify attribute %s", vi->name);
    return 0;
}

OnyxAttributeSize
onyx_vert_input_attr_size(const OnyxVertexInputAttributeReflection *vi)
{
    return vi->n_components * sizeof(float);
}

bool onyx_geo_template_compatible_with_vertex_shader(
    OnyxGeometryTemplate templ, const OnyxRasterizationReflection *refl)
{
    for (int i = 0; i < templ.attribute_count; ++i) {
        bool              found = false;
        OnyxAttributeType type  = templ.attribute_types[i];
        OnyxAttributeSize size  = templ.attribute_sizes[i];
        for (int i = 0; i < refl->vertex_input_count; ++i) {
            const OnyxVertexInputAttributeReflection *vi =
                &refl->vertex_inputs[i];

            if (type != onyx_vert_input_attr_type(vi))
                continue;
            if (size != onyx_vert_input_attr_size(vi))
                continue;
            found = true;
            break;
        }
        if (!found)
            return false;
    }
    return true;
}
