#ifndef ONYX_H
#define ONYX_H

#ifdef __cplusplus
extern "C" {
#endif

#include "types.h"
#include "common.h"
#include "video.h"
#include "memory.h"
#include "image.h"
#include "swapchain.h"
#include "scene.h"
#include "render.h"
#include "raytrace.h"
#include "harfbuzz.h"
#include "renderpass.h"
#include "geo.h"
#include "pipeline.h"
#include "graph.h"
#include "interface_types.h"

typedef struct onyx_memory_sizes OnyxMemorySizes;

typedef void (*OnyxCreateReflectionFnPtr)(OnyxReflection *);

typedef struct OnyxSettings {
    OnyxInstanceParms ip;
    OnyxMemorySizes memory_sizes;
} OnyxSettings;

int onyx_create_orb(const OnyxInstanceParms* ip,
    const uint32_t hostGraphicsBufferMB,
    const uint32_t deviceGraphicsBufferMB,
    const uint32_t deviceGraphicsImageMB, const uint32_t hostTransferBufferMB,
    const uint32_t deviceExternalGraphicsImageMB,
    Onyx* orb);

OnyxContext onyx_create_context(OnyxSettings settings);

typedef struct OnyxDescriptionInterface {
    OnyxRasterizationReflection* (*get_final_subpass_reflection)(void *description);
    void *description;
} OnyxDescriptionInterface;

void onyx_create_context_(OnyxMemorySizes msizes, OnyxContext* ctx);
// must allocate members your self before passing in
void onyx_create_context__(OnyxMemorySizes msizes, OnyxContext* ctx);

OnyxContext* onyx_alloc_context();
OnyxContext* onyx_alloc_context_(HellAllocator *alloc);

#ifdef __cplusplus
}
#endif

#endif /* end of include guard: ONYX_H */
