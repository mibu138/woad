#define COAL_SIMPLE_TYPE_NAMES
#include "scene.h"
#include "coal/util.h"
#include "coal/linalg.h"
#include "hell/common.h"
#include <hell/ds.h>
#include "dtags.h"
#include <hell/debug.h>
#include "memory.h"
#include "common.h"
#include "geo.h"
#include "image.h"
#include <string.h>
#define ARCBALL_CAMERA_IMPLEMENTATION
#include "arcball_camera.h"

typedef OnyxPrimitive     Primitive;
typedef OnyxXform         Xform;
typedef OnyxScene         Scene;
typedef OnyxLight         Light;
typedef OnyxMaterial      Material;
typedef OnyxCamera        Camera;
typedef OnyxTexture       Texture;

typedef OnyxSceneObjectInt obint;

typedef OnyxPrimitiveHandle PrimitiveHandle;
typedef OnyxLightHandle LightHandle;
typedef OnyxMaterialHandle MaterialHandle;
typedef OnyxTextureHandle TextureHandle;

typedef OnyxPrimitiveList PrimitiveList;

#define INIT_PRIM_CAP 16
#define INIT_LIGHT_CAP 8
#define INIT_MATERIAL_CAP 8
#define INIT_TEXTURE_CAP 8

#define PRIM(scene, handle) scene->prims[scene->primMap.indices[handle.id]]
#define TEXTURE(scene, handle) scene->textures[scene->texMap.indices[handle.id]]
#define LIGHT(scene, handle) scene->lights[scene->lightMap.indices[handle.id]]
#define MATERIAL(scene, handle) scene->materials[scene->matMap.indices[handle.id]]

#define DPRINT(fmt, ...) hell_debug_print(ONYX_DEBUG_TAG_SCENE, fmt, ##__VA_ARGS__)

// lightMap is an indirection from Light Id to the actual light data in the scene.
// invariants are that the active lights in the scene are tightly packed and
// that the lights in the scene are ordered such that their indices are ordered
// within the map.

typedef struct {
    // an array of indices into the object buffers. a handle id is an index into
    // this.
    obint*  indices;
    // a stack of ids that are available for reuse. gets added to when we remove
    // an object and can reclaim its id. the bottom of the stack should always
    // be larger than any other Id used yet. in other words, we should always pull from this
    // stack for the next id
    HellArray availableIds;
} ObjectMap;

typedef struct OnyxScene {
    OnyxSceneDirtyFlags dirt;
    OnyxMemory*         memory;
    HellArray           dirtyTextures;
    HellArray           dirtyMaterials;
    HellArray           dirtyPrims;
    obint                primCount;
    obint                lightCount;
    obint                materialCount;
    obint                textureCount;
    OnyxCamera          camera;
    obint                primCapacity;
    OnyxPrimitive*      prims;
    obint                materialCapacity;
    OnyxMaterial*       materials;
    obint                textureCapacity;
    OnyxTexture*        textures;
    obint                lightCapacity;
    OnyxLight*          lights;
    OnyxGeometry        defaultGeo;
    OnyxImage           defaultImage;
    ObjectMap            primMap;
    ObjectMap            lightMap;
    ObjectMap            matMap;
    ObjectMap            texMap;
} OnyxScene;

static void addTextureToDirtyTextures(OnyxScene* s, TextureHandle handle)
{
    TextureHandle* texs = s->dirtyTextures.elems;
    for (int i = 0; i < s->dirtyTextures.count; i++)
    {
        if (texs[i].id == handle.id) return; // handle already in set
    }
    hell_array_push(&s->dirtyTextures, &handle);
}

static void addMaterialToDirtyMaterials(OnyxScene* s, MaterialHandle handle)
{
    MaterialHandle* mats = s->dirtyMaterials.elems;
    for (int i = 0; i < s->dirtyMaterials.count; i++)
    {
        if (mats[i].id == handle.id) return; // handle already in set
    }
    hell_array_push(&s->dirtyMaterials, &handle);
}

static void addPrimToDirtyPrims(OnyxScene* s, PrimitiveHandle handle)
{
    PrimitiveHandle* prims = s->dirtyPrims.elems;
    for (int i = 0; i < s->dirtyPrims.count; i++)
    {
        if (prims[i].id == handle.id) return; // handle already in set
    }
    hell_array_push(&s->dirtyPrims, &handle);
}

static void createObjectMap(u32 initObjectCap, u32 initIdStackCap, ObjectMap* map)
{
    map->indices = hell_malloc(sizeof(map->indices[0]) * initObjectCap);
    hell_create_array_old(initIdStackCap, sizeof(map->indices[0]), NULL, NULL, &map->availableIds);
}

static void growArray(void** curptr, obint* curcap, const u32 elemsize)
{
    assert(*curcap);
    assert(*curptr);
    uint32_t newcap = *curcap * 2;
    void* p = hell_realloc(*curptr, newcap * elemsize);
    if (!p)
        hell_error(HELL_ERR_FATAL, "Growing array capacity failed. Realloc returned Null\n");
    *curptr = p;
    *curcap = newcap;
}

static obint addSceneObject(const void* object, void* objectArray, obint* objectCount, obint* cap, const u32 elemSize, ObjectMap* map)
{
    const obint index = (*objectCount)++;
    if (index == *cap)
    {
        growArray(objectArray, cap, elemSize);
        growArray((void**)&map->indices, cap, elemSize);
    }
    assert(index < *cap);
    obint id = 0;
    if (map->availableIds.count == 0)
        id = index;
    else
        hell_array_pop(&map->availableIds, &id);
    map->indices[id] = index;
    void* dst = (u8*)(objectArray) + index * elemSize;
    memcpy(dst, object, elemSize);
    return id;
}

static void removeSceneObject(obint id, void* objectArray, obint* objectCount, const u32 elemSize, ObjectMap* map)
{
    void* const       dst   = (u8*)(objectArray) + map->indices[id] * elemSize;
    const void* const src   = (u8*)dst + elemSize;
    const u8* const   end   = (u8*)(objectArray) + *objectCount * elemSize;
    const u32         range = end - (u8*)src;
    memmove(dst, src, range);
    (*objectCount)--;
    hell_array_push(&map->availableIds, &id);
}

static PrimitiveHandle addPrim(Scene* s, OnyxPrimitive prim)
{
    obint id = addSceneObject(&prim, s->prims, &s->primCount, &s->primCapacity, sizeof(prim), &s->primMap);
    PrimitiveHandle handle = {id};
    addPrimToDirtyPrims(s, handle);
    PRIM(s, handle).dirt |= ONYX_PRIM_ADDED_BIT;
    s->dirt |= ONYX_SCENE_PRIMS_BIT;
    return handle;
}

static LightHandle addLight(Scene* s, Light light)
{
    obint id = addSceneObject(&light, s->lights, &s->lightCount, &s->lightCapacity, sizeof(light), &s->lightMap);
    LightHandle handle = {id};
    s->dirt |= ONYX_SCENE_LIGHTS_BIT;
    return handle;
}

static TextureHandle addTexture(Scene* s, OnyxTexture texture)
{
    obint id = addSceneObject(&texture, s->textures, &s->textureCount, &s->textureCapacity, sizeof(texture), &s->texMap);
    TextureHandle handle = {id};
    addTextureToDirtyTextures(s, handle);
    TEXTURE(s, handle).dirt |= ONYX_TEX_ADDED_BIT;
    s->dirt |= ONYX_SCENE_TEXTURES_BIT;
    return handle;
}

static MaterialHandle addMaterial(Scene* s, OnyxMaterial material)
{
    obint id = addSceneObject(&material, s->materials, &s->materialCount, &s->materialCapacity, sizeof(s->materials[0]), &s->matMap);
    MaterialHandle handle = {id};
    addMaterialToDirtyMaterials(s, handle);
    MATERIAL(s, handle).dirt |= ONYX_MAT_ADDED_BIT;
    s->dirt |= ONYX_SCENE_MATERIALS_BIT;
    return handle;
}

static void removePrim(Scene* s, OnyxPrimitiveHandle handle)
{
    assert(handle.id < s->primCapacity);
    assert(handle.id > 0); //cant remove the default prim
    PRIM(s, handle).dirt |= ONYX_PRIM_REMOVED_BIT;
    addPrimToDirtyPrims(s, handle);
    s->dirt |= ONYX_SCENE_PRIMS_BIT;
}

static void removeLight(Scene* s, OnyxLightHandle handle)
{
    assert(handle.id < s->lightCapacity);
    removeSceneObject(handle.id, s->lights, &s->lightCount, sizeof(s->lights[0]), &s->lightMap);
    s->dirt |= ONYX_SCENE_LIGHTS_BIT;
}

static void removeTexture(Scene* s, OnyxTextureHandle handle)
{
    assert(handle.id < s->textureCapacity);
    assert(handle.id > 0); //cant remove the default prim
    TEXTURE(s, handle).dirt |= ONYX_TEX_REMOVED_BIT;
    addTextureToDirtyTextures(s, handle);
    s->dirt |= ONYX_SCENE_TEXTURES_BIT;
}

static void removeMaterial(Scene* s, OnyxMaterialHandle handle)
{
    assert(handle.id < s->materialCapacity);
    removeSceneObject(handle.id, s->materials, &s->materialCount, sizeof(s->materials[0]), &s->matMap);
    s->dirt |= ONYX_SCENE_MATERIALS_BIT;
}

static LightHandle addDirectionLight(Scene* s, const CoalVec3 dir, const CoalVec3 color, const float intensity)
{
    Light light = {
        .type = ONYX_DIRECTION_LIGHT_TYPE,
        .intensity = intensity,
    };
    light.structure.direction_light.dir = dir;
    light.color = color;
    return addLight(s, light);
}

static LightHandle addPointLight(Scene* s, const CoalVec3 pos, const CoalVec3 color, const float intensity)
{
    Light light = {
        .type = ONYX_LIGHT_POINT_TYPE,
        .intensity = intensity
    };
    light.structure.point_light.pos = pos;
    light.color = color;
    return addLight(s, light);
}

#define DEFAULT_TEX_DIM 4

static void createDefaultTexture(Scene* scene, OnyxMemory* memory, Texture* texture)
{
    scene->defaultImage = onyx_create_image_and_sampler(
        memory, DEFAULT_TEX_DIM, DEFAULT_TEX_DIM, VK_FORMAT_R8G8B8A8_UNORM,
        VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
        VK_IMAGE_ASPECT_COLOR_BIT, VK_SAMPLE_COUNT_1_BIT, 1, VK_FILTER_LINEAR,
        ONYX_MEMORY_DEVICE_TYPE);

    OnyxCommand cmd = onyx_create_command(onyx_get_memory_instance(memory), ONYX_QUEUE_GRAPHICS_TYPE);

    onyx_begin_command_buffer_one_time_submit(cmd.buffer);

    OnyxBarrierScopes b = {};
    b.src.stage_mask = VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT;
    b.dst.stage_mask = VK_PIPELINE_STAGE_TRANSFER_BIT;
    b.src.access_mask = 0;
    b.dst.access_mask = VK_ACCESS_TRANSFER_WRITE_BIT;

    onyx_cmd_transition_image_layout(cmd.buffer, b, VK_IMAGE_LAYOUT_UNDEFINED,
            VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
            scene->defaultImage.mip_levels, scene->defaultImage.handle);

    onyx_cmd_clear_color_image(cmd.buffer, scene->defaultImage.handle,
            VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 0, 1, 1.0, 1.0, 1.0, 1.0);

    b.src.stage_mask = b.dst.stage_mask;
    b.dst.stage_mask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
    b.src.access_mask = b.dst.access_mask;
    b.dst.access_mask = VK_ACCESS_SHADER_READ_BIT;

    onyx_cmd_transition_image_layout(cmd.buffer, b,
            VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
            scene->defaultImage.mip_levels, scene->defaultImage.handle);

    onyx_end_command_buffer(cmd.buffer);

    onyx_submit_and_wait(&cmd, 0);

    onyx_destroy_command(cmd);

    texture->dev_image = &scene->defaultImage;
}

static void printPrimInfoCmd(HellGrimoire* grim, void* scene)
{
    onyx_print_prim_info(scene);
}

static void printTexInfoCmd(HellGrimoire* grim, void* scene)
{
    onyx_print_texture_info(scene);
}

static CoalMat4
projectionMatrix(float fov, float aspect_ratio, float n, float f)
{
    float p = fov / aspect_ratio;
    float q = -fov;
    float A = f / (n - f);
    float B = f * n / (n - f);
    Mat4 m = {
        p,   0,  0,  0,
        0,   q,  0,  0,
        0,   0,  A,  -1,
        0,   0,  B,  0
    };
    return m;
}

void
onyx_create_scene(HellGrimoire* grim, OnyxMemory* memory, float fov,
                 float aspect_ratio, float nearClip, float farClip, Scene* scene)
{
    memset(scene, 0, sizeof(*scene));
    scene->memory = memory;
    scene->camera.xform = coal_ident_mat4();
    scene->camera.view = coal_ident_mat4();
    Mat4 m = coal_look_at((Vec3){1, 1, 2}, (Vec3){0, 0, 0}, (Vec3){0, 1, 0});
    scene->camera.xform = m;
    scene->camera.view = coal_invert4x4(m);
    scene->camera.proj = projectionMatrix(fov, aspect_ratio, nearClip, farClip);
    // set all xforms to identity
    scene->primCapacity = INIT_PRIM_CAP;
    scene->lightCapacity = INIT_LIGHT_CAP;
    scene->materialCapacity = INIT_MATERIAL_CAP;
    scene->textureCapacity = INIT_TEXTURE_CAP;
    createObjectMap(scene->primCapacity, 8, &scene->primMap);
    createObjectMap(scene->lightCapacity, 8, &scene->lightMap);
    createObjectMap(scene->materialCapacity, 8, &scene->matMap);
    createObjectMap(scene->textureCapacity, 8, &scene->texMap);

    scene->prims = hell_malloc(scene->primCapacity * sizeof(scene->prims[0]));
    scene->lights = hell_malloc(scene->lightCapacity * sizeof(scene->lights[0]));
    scene->materials = hell_malloc(scene->materialCapacity * sizeof(scene->materials[0]));
    scene->textures = hell_malloc(scene->textureCapacity * sizeof(scene->textures[0]));

    // 8 is arbitrary initial capacity
    hell_create_array_old(8, sizeof(OnyxPrimitiveHandle), NULL, NULL, &scene->dirtyPrims);
    hell_create_array_old(8, sizeof(OnyxMaterialHandle), NULL, NULL, &scene->dirtyMaterials);
    hell_create_array_old(8, sizeof(OnyxTextureHandle), NULL, NULL, &scene->dirtyTextures);

    // create defaults
    Texture tex = {0};
    createDefaultTexture(scene, memory, &tex);
    TextureHandle texhandle = addTexture(scene, tex);
    MaterialHandle defaultMat = onyx_scene_create_material(scene, (Vec3){0, 0.937, 1.0}, 0.8, texhandle, NULL_TEXTURE, NULL_TEXTURE);
    OnyxPrimitive prim = {};
    scene->defaultGeo = onyx_create_cube(memory, false);
    prim.geo = &scene->defaultGeo;
    prim.xform = COAL_MAT4_IDENT;
    prim.material = defaultMat;
    prim.flags = ONYX_PRIM_INVISIBLE_BIT;
    addPrim(scene, prim);

    scene->dirt = -1; // dirty everything

    if (grim)
    {
        hell_add_command(grim, "priminfo", printPrimInfoCmd, scene);
        hell_add_command(grim, "texinfo", printTexInfoCmd, scene);
    }
}

void onyx_bind_prim_to_material(Scene* scene, OnyxPrimitiveHandle primhandle, OnyxMaterialHandle mathandle)
{
    assert(scene->materialCount > mathandle.id);
    PRIM(scene, primhandle).material = mathandle;

    scene->dirt |= ONYX_SCENE_PRIMS_BIT;
}

void onyx_bind_prim_to_material_direct(Scene* scene, uint32_t directIndex, OnyxMaterialHandle mathandle)
{
    assert(scene->materialCount > mathandle.id);
    scene->prims[directIndex].material = mathandle;

    scene->dirt |= ONYX_SCENE_PRIMS_BIT;
}

OnyxPrimitiveHandle onyx_scene_add_prim(Scene* scene, OnyxGeometry* geo, const CoalMat4 xform, MaterialHandle mat)
{
    OnyxPrimitive prim = {
        .geo = geo,
        .xform = COAL_MAT4_IDENT,
        .material = mat
    };
    prim.xform = xform;
    PrimitiveHandle handle = addPrim(scene, prim);

    return handle;
}

OnyxMaterialHandle onyx_scene_create_material(OnyxScene* scene, Vec3 color, float roughness,
        OnyxTextureHandle albedoId, OnyxTextureHandle roughnessId, OnyxTextureHandle normalId)
{
    OnyxMaterial mat = {0};

    mat.color = color;
    mat.roughness = roughness;
    mat.texture_albedo    = albedoId;
    mat.texture_roughness = roughnessId;
    mat.texture_normal    = normalId;

    return addMaterial(scene, mat);
}

OnyxLightHandle onyx_create_direction_light(Scene* scene, const Vec3 color, const Vec3 direction)
{
    return addDirectionLight(scene, direction, color, 1.0);
}

OnyxLightHandle onyx_scene_create_point_light(Scene* scene, const Vec3 color, const Vec3 position)
{
    return addPointLight(scene, position, color, 1.0);
}

#define HOME_POS    {0.0, 0.0, 1.0}
#define HOME_TARGET {0.0, 0.0, 0.0}
#define HOME_UP     {0.0, 1.0, 0.0}
#define ZOOM_RATE   0.005
#define PAN_RATE    0.2
#define TUMBLE_RATE 1.0

void onyx_update_camera_look_at(Scene* scene, Vec3 pos, Vec3 target, Vec3 up)
{
    scene->camera.xform = coal_look_at(pos, target, up);
    scene->camera.view  = coal_invert4x4(scene->camera.xform);
    scene->dirt |= ONYX_SCENE_CAMERA_VIEW_BIT;
}

void onyx_update_camera_arc_ball(Scene* scene, Vec3* target, int screenWidth, int screenHeight, float dt, int xprev, int x, int yprev, int y, bool panning, bool tumbling, bool zooming, bool home)
{
    Vec3 pos = coal_get_translation_mat4(scene->camera.xform);
    Vec3 up = coal_get_local_y_mat4(scene->camera.xform);
    int zoom_ticks = 0;
    if (zooming)
        zoom_ticks = x - xprev;
    else
        zoom_ticks = 0;
    if (home)
    {
        pos =    (Vec3)HOME_POS;
        *target = (Vec3)HOME_TARGET;
        up =     (Vec3)HOME_UP;
    }
    //pos = m_RotateY_Vec3(dt, &pos);
    CoalMat4 view_out;
    arcball_camera_update(pos.e, target->e, up.e, view_out.e, dt,
            ZOOM_RATE, PAN_RATE, TUMBLE_RATE, screenWidth, screenHeight, xprev, x, yprev, y,
            panning, tumbling, zoom_ticks, 0);
// NOTE coal_look_at function appears to be broken. Investigate.
#if 0
    Mat4 m = coal_look_at(pos, *target, up);
    scene->camera.xform = m;
    scene->camera.view  = coal_invert4x4(scene->camera.xform);
#else
    scene->camera.xform = coal_invert4x4(view_out);
    scene->camera.view  = view_out;
#endif
    scene->dirt |= ONYX_SCENE_CAMERA_VIEW_BIT;
}

void onyx_scene_update_camera_pos(OnyxScene* scene, float dx, float dy, float dz)
{
    scene->camera.xform = coal_translate_mat4((Vec3){dx, dy, dz}, scene->camera.xform);
    scene->camera.view  = coal_invert4x4(scene->camera.xform);
    scene->dirt |= ONYX_SCENE_CAMERA_VIEW_BIT;
}

void onyx_update_light(Scene* scene, LightHandle handle, float intensity)
{
    LIGHT(scene, handle).intensity = intensity;
    scene->dirt |= ONYX_SCENE_LIGHTS_BIT;
}

void onyx_update_prim_xform(Scene* scene, PrimitiveHandle handle, const Mat4 delta)
{
    CoalMat4 M = coal_mult_mat4(PRIM(scene, handle).xform, delta);
    PRIM(scene, handle).xform = M;
    scene->dirt |= ONYX_SCENE_XFORMS_BIT;
}

void onyx_set_prim_xform(OnyxScene* scene, OnyxPrimitiveHandle handle, Mat4 newXform)
{
    PRIM(scene, handle).xform = newXform;
    scene->dirt |= ONYX_SCENE_XFORMS_BIT;
}

OnyxPrimitiveList onyx_create_prim_list(uint32_t initial_cap)
{
    OnyxPrimitiveList pl = {};
    hell_create_array_old(initial_cap, sizeof(OnyxPrimitiveHandle), NULL, NULL, &pl.array);
    return pl;
}

void onyx_add_prim_to_list(OnyxPrimitiveHandle handle, OnyxPrimitiveList* list)
{
    hell_array_push(&list->array, &handle);
    // need to reset the pointer in case we realloc'd
}

void onyx_clear_prim_list(OnyxPrimitiveList* list)
{
    hell_array_clear(&list->array);
}

void onyx_destroy_scene(OnyxScene* scene)
{
    memset(scene, 0, sizeof(*scene));
}

void onyx_scene_remove_prim(OnyxScene* s, OnyxPrimitiveHandle handle)
{
    removePrim(s, handle);
}

OnyxLightHandle onyx_scene_add_direction_light(Scene* s, CoalVec3 dir, CoalVec3 color, float intensity)
{
    return addDirectionLight(s, dir, color, intensity);
}

OnyxLightHandle onyx_scene_add_point_light(Scene* s, CoalVec3 pos, CoalVec3 color, float intensity)
{
    return addPointLight(s, pos, color, intensity);
}

void onyx_scene_remove_light(Scene* s, LightHandle id)
{
    removeLight(s, id);
}

void onyx_print_light_info(const Scene* s)
{
    hell_print("====== Scene: light info =======\n");
    hell_print("Light count: %d\n", s->lightCount);
    for (int i = 0; i < s->lightCount; i++)
    {
        hell_print("Light index %d P ", i);
        hell_print_vec3(s->lights[i].structure.point_light.pos.e);
        hell_print(" C ");
        hell_print_vec3(s->lights[i].color.e);
        hell_print(" I  %f\n", s->lights[i].intensity);
    }
    hell_print("Light map: ");
    for (int i = 0; i < s->lightCapacity; i++)
    {
        hell_print(" %d:%d ", i, s->lightMap.indices[i]);
    }
    hell_print("\n");
}

void onyx_print_texture_info(const Scene* s)
{
    hell_print("====== Scene: texture info =======\n");
    hell_print("Texture count: %d\n", s->textureCount);
    for (int i = 0; i < s->textureCount; i++)
    {
        const Texture* tex = &s->textures[i];
        const OnyxImage* img = tex->dev_image;
        hell_print("Texture index %d\n", i);
        hell_print("Width %d Height %d Size %d \n", img->extent.width, img->extent.height, img->size);
        hell_print("Format %d \n", img->format);
        hell_print("\n");
    }
    hell_print("Texture map: ");
    for (int i = 0; i < s->textureCapacity; i++)
    {
        hell_print(" %d:%d ", i, s->texMap.indices[i]);
    }
    hell_print("\n");
}

void onyx_print_prim_info(const Scene* s)
{
    hell_print("====== Scene: primitive info =======\n");
    hell_print("Prim count: %d\n", s->primCount);
    for (int i = 0; i < s->primCount; i++)
    {
        hell_print("Prim %d material id %d\n", i, s->prims[i].material.id);
        const Material* mat = &MATERIAL(s, s->prims[i].material);
        hell_print("Material: handle id %d color %f %f %f roughness %f\n", s->prims[i].material.id, mat->color.r, mat->color.g, mat->color.b, mat->roughness);
        hell_print("Material: Albedo TextureHandle: %d\n", mat->texture_albedo.id);
        hell_print_mat4(s->prims[i].xform.e);
        hell_print("\n");
    }
    hell_print("Prim map: ");
    for (int i = 0; i < s->primCapacity; i++)
    {
        hell_print(" %d:%d ", i, s->primMap.indices[i]);
    }
    hell_print("\n");
}

void onyx_update_light_color(OnyxScene* scene, OnyxLightHandle handle, float r, float g, float b)
{
    LIGHT(scene, handle).color.r = r;
    LIGHT(scene, handle).color.g = g;
    LIGHT(scene, handle).color.b = b;
    scene->dirt |= ONYX_SCENE_LIGHTS_BIT;
}

void onyx_update_light_pos(OnyxScene* scene, OnyxLightHandle handle, float x, float y, float z)
{
    LIGHT(scene, handle).structure.point_light.pos.x = x;
    LIGHT(scene, handle).structure.point_light.pos.y = y;
    LIGHT(scene, handle).structure.point_light.pos.z = z;
    scene->dirt |= ONYX_SCENE_LIGHTS_BIT;
}

void onyx_update_light_intensity(OnyxScene* scene, OnyxLightHandle handle, float i)
{
    LIGHT(scene, handle).intensity = i;
    scene->dirt |= ONYX_SCENE_LIGHTS_BIT;
}

OnyxScene* onyx_alloc_scene(void)
{
    return hell_malloc(sizeof(Scene));
}

Mat4 onyx_scene_get_camera_view(const OnyxScene* scene)
{
    return scene->camera.view;
}

Mat4 onyx_scene_get_camera_projection(const OnyxScene* scene)
{
    return scene->camera.proj;
}

CoalMat4 onyx_scene_get_camera_xform(const OnyxScene* scene)
{
    return scene->camera.xform;
}

OnyxPrimitive* onyx_get_primitive(const OnyxScene* s, uint32_t id)
{
    PrimitiveHandle handle = {id};
    return &PRIM(s, handle);
}

uint32_t onyx_scene_get_prim_count(const OnyxScene* s)
{
    return s->primCount;
}

uint32_t onyx_scene_get_light_count(const OnyxScene* s)
{
    return s->lightCount;
}

OnyxLight* onyx_scene_get_lights(const OnyxScene* scene, uint32_t* count)
{
    *count = scene->lightCount;
    return scene->lights;
}

const OnyxLight* OnyxSceneGetLight(const OnyxScene* s, OnyxLightHandle h)
{
    return &LIGHT(s, h);
}

OnyxSceneDirtyFlags onyx_scene_get_dirt(const OnyxScene* s)
{
    return s->dirt;
}

void onyx_scene_end_frame(OnyxScene* s)
{
    if (s->dirt & ONYX_SCENE_TEXTURES_BIT)
    {
        u32 c = s->dirtyTextures.count;
        TextureHandle* handles = s->dirtyTextures.elems;
        for (u32 i = 0; i < c; i++)
        {
            if (TEXTURE(s, handles[i]).dirt & ONYX_TEX_REMOVED_BIT)
            {
                u32 matcount = s->materialCount;
                for (u32 j = 0; j < matcount; j++)
                {
                    if (s->materials[j].texture_albedo.id == handles[i].id)
                        s->materials[j].texture_albedo = NULL_TEXTURE;
                    if (s->materials[j].texture_roughness.id == handles[i].id)
                        s->materials[j].texture_roughness = NULL_TEXTURE;
                    if (s->materials[j].texture_normal.id == handles[i].id)
                        s->materials[j].texture_normal = NULL_TEXTURE;
                }
                removeSceneObject(handles[i].id, s->textures, &s->textureCount,
                                  sizeof(s->textures[0]), &s->texMap);
            }
            else
            {
                TEXTURE(s, handles[i]).dirt = 0;
            }
        }
    }
    if (s->dirt & ONYX_SCENE_MATERIALS_BIT)
    {
        u32 c = s->dirtyMaterials.count;
        MaterialHandle* handles = s->dirtyMaterials.elems;
        for (u32 i = 0; i < c; i++)
        {
            OnyxSceneObjectInt id = handles[i].id;
            if (MATERIAL(s, handles[i]).dirt & ONYX_MAT_REMOVED_BIT)
            {
                u32 primcount = s->primCount;
                for (u32 j = 0; j < primcount; j++)
                {
                    if (s->prims[j].material.id == id)
                        s->prims[j].material = NULL_MATERIAL;
                }
                removeSceneObject(id, s->materials, &s->materialCount,
                                  sizeof(s->materials[0]), &s->matMap);
            }
            else
            {
                MATERIAL(s, handles[i]).dirt = 0;
            }
        }
    }
    if (s->dirt & ONYX_SCENE_PRIMS_BIT)
    {
        u32 c = s->dirtyPrims.count;
        PrimitiveHandle* dp = s->dirtyPrims.elems;
        for (int i = 0; i < c; i++)
        {
            PrimitiveHandle handle = dp[i];
            // remove prims at the end of the frame so scene consumers can react to the prim
            // having the remove bit set
            if (PRIM(s, handle).dirt & ONYX_PRIM_REMOVED_BIT)
            {
                removeSceneObject(handle.id, s->prims, &s->primCount, sizeof(s->prims[0]), &s->primMap);
            }
            else
            {
                PRIM(s, dp[i]).dirt = 0;
            }
        }
    }
    s->dirt = 0;
    s->dirtyMaterials.count = 0;
    s->dirtyTextures.count = 0;
    s->dirtyPrims.count = 0;
}

OnyxTexture* onyx_get_texture(const OnyxScene* s, OnyxTextureHandle handle)
{
    return &TEXTURE(s, handle);
}

OnyxMaterial* onyx_get_material(const OnyxScene* s, OnyxMaterialHandle handle)
{
    return &MATERIAL(s, handle);
}

OnyxTextureHandle onyx_scene_add_texture(OnyxScene* scene, OnyxImage* image)
{
    OnyxTexture tex = {0};
    tex.dev_image = image;
    return addTexture(scene, tex);
}

void
onyx_scene_remove_texture(OnyxScene* scene, OnyxTextureHandle tex)
{
    removeTexture(scene, tex);
}

void
onyx_scene_remove_material(OnyxScene* scene, OnyxMaterialHandle mat)
{
    removeMaterial(scene, mat);
}

uint32_t onyx_scene_get_texture_count(const OnyxScene* s)
{
    return s->textureCount;
}

OnyxTexture* onyx_scene_get_textures(const OnyxScene* s, OnyxSceneObjectInt* count)
{
    *count = s->textureCount;
    return s->textures;
}

uint32_t       onyx_scene_get_material_count(const OnyxScene* s)
{
    return s->materialCount;
}

OnyxMaterial* onyx_scene_get_materials(const OnyxScene* s, OnyxSceneObjectInt* count)
{
    *count = s->materialCount;
    return s->materials;
}

uint32_t onyx_scene_get_material_index(const OnyxScene* s, OnyxMaterialHandle handle)
{
    return s->matMap.indices[handle.id];
}

uint32_t onyx_scene_get_texture_index(const OnyxScene* s, OnyxTextureHandle handle)
{
    return s->texMap.indices[handle.id];
}

void onyx_scene_dirty_textures(OnyxScene* s)
{
    s->dirt |= ONYX_SCENE_TEXTURES_BIT;
}

void onyx_scene_set_geo_direct(OnyxScene* s, OnyxGeometry* geo, u32 directIndex)
{
    s->prims[directIndex].geo = geo;
    s->dirt |= ONYX_SCENE_PRIMS_BIT;
}

void onyx_scene_free_geo_direct(OnyxScene* s, u32 directIndex)
{
    onyx_free_geometry(s->prims[directIndex].geo);
    memset(s->prims[directIndex].geo, 0, sizeof(*s->prims[directIndex].geo));;
    s->prims[directIndex].geo = NULL;
}

bool onyx_scene_has_geo_direct(OnyxScene* s, u32 directIndex)
{
    if (s->prims[0].geo) return true;
    return false;
}

void onyx_scene_set_camera_xform(OnyxScene* scene, const CoalMat4 m)
{
    scene->camera.xform = m;
    scene->camera.view = coal_invert4x4(m);
    scene->dirt |= ONYX_SCENE_CAMERA_VIEW_BIT;
}

void onyx_scene_set_camera_view(OnyxScene* scene, const CoalMat4 m)
{
    scene->camera.view = m;
    scene->camera.xform = coal_invert4x4(m);
    scene->dirt |= ONYX_SCENE_CAMERA_VIEW_BIT;
}

const OnyxCamera*
onyx_scene_get_camera(const OnyxScene* scene)
{
    return &scene->camera;
}

void onyx_scene_set_camera_projection(OnyxScene* scene, const CoalMat4 m)
{
    scene->camera.proj = m;
    scene->dirt |= ONYX_SCENE_CAMERA_PROJ_BIT;
}

OnyxGeometry* onyx_scene_get_prim_geo(OnyxScene* scene, PrimitiveHandle prim, OnyxPrimDirtyFlags flags)
{
    addPrimToDirtyPrims(scene, prim);
    PRIM(scene, prim).dirt |= flags;
    scene->dirt |= ONYX_SCENE_PRIMS_BIT;
    return PRIM(scene, prim).geo;
}

OnyxPrimitive*
onyx_scene_get_primitive(OnyxScene* s, OnyxPrimitiveHandle handle)
{
    return &PRIM(s, handle);
}

const OnyxPrimitive*
onyx_scene_get_primitive_const(const OnyxScene* s, OnyxPrimitiveHandle handle)
{
    return &PRIM(s, handle);
}

const OnyxPrimitive* onyx_scene_get_primitives(const OnyxScene* s, OnyxSceneObjectInt* count)
{
    *count = s->primCount;
    return s->prims;
}

void onyx_scene_dirty_all(OnyxScene* s)
{
    s->dirt = -1;
}

const OnyxPrimitiveHandle* onyx_scene_get_dirty_primitives(const OnyxScene* s, uint32_t* count)
{
    *count = s->dirtyPrims.count;
    return s->dirtyPrims.elems;
}

void onyx_scene_camera_update_aspect_ratio(OnyxScene* s, float ar)
{
    float fov = -s->camera.proj.e[1][1];
    float p   = fov / ar;
    s->camera.proj.e[0][0] = p;
    s->dirt |= ONYX_SCENE_CAMERA_PROJ_BIT;
}
