#ifndef ONYX_R_PIPELINE_H
#define ONYX_R_PIPELINE_H

#include "types.h"
#include "geo.h"
#include "raytrace.h"
#include "renderpass.h"

#define ONYX_MAX_PIPELINES 10
#define ONYX_MAX_BINDINGS 10

#define ONYX_FULL_SCREEN_VERT_SPV "full-screen.vert.spv"

typedef struct {
    VkDescriptorPool      descriptor_pool;
    VkDescriptorSet       descriptor_sets[ONYX_MAX_DESCRIPTOR_SETS];
    uint32_t              descriptor_set_count;
} OnyxR_Description;

typedef struct {
    size_t descriptor_set_count;
    const VkDescriptorSetLayout* descriptor_set_layouts;
    size_t push_constant_count;
    const VkPushConstantRange* push_constant_ranges;
} OnyxPipelineLayoutInfo;

typedef enum {
    ONYX_R_PIPELINE_RASTER_TYPE,
    ONYX_R_PIPELINE_RAYTRACE_TYPE
} OnyxR_PipelineType;

typedef struct OnyxPipelineColorBlendAttachment {
    bool          blend_enable;
    OnyxBlendMode blend_mode;
} OnyxPipelineColorBlendAttachment;

#ifndef __cplusplus
_Static_assert(ONYX_COMPARE_OP_LESS == VK_COMPARE_OP_LESS - 1, "Should be 1 less");
#else
static_assert(ONYX_COMPARE_OP_LESS == VK_COMPARE_OP_LESS - 1, "Should be 1 less");
#endif

typedef struct OnyxGraphicsPipelineInfo {
    VkPipelineLayout layout;
    VkRenderPass     render_pass;
    uint32_t         subpass;

    const VkPipeline      base_pipeline;
    uint32_t              base_pipeline_index;

    uint32_t                           shader_stage_count;
    // it is not clear why we need the modules array as well as the
    // shader_stages, since the latter can contain shader code.
    // TODO investigate
    const OnyxShaderInfo* shader_stages;
    const VkShaderModule* modules;

    // from VkPipelineInputAssemblyStateCreateInfo
    VkPrimitiveTopology topology;
    bool                primitive_restart_enable;

    // from VkPipelineVertexInputStateCreateInfo
    uint32_t                                 vertex_binding_description_count;
    const VkVertexInputBindingDescription*   vertex_binding_descriptions;
    uint32_t                                 vertex_attribute_description_count;
    const VkVertexInputAttributeDescription* vertex_attribute_descriptions;
    uint32_t                                 patch_control_points;

    // from VkPipelineViewportStateCreateInfo
    // can be ignored if both scissor and viewport are dynamic
    uint32_t viewport_width;
    uint32_t viewport_height;

    // from VkPipelineRasterizationStateCreateInfo
    bool            depth_clamp_enable;
    bool            rasterizer_discard_enable;
    // 0 == fill
    VkPolygonMode   polygon_mode;
    VkCullModeFlags cull_mode;
    // 0 == counter clock wise
    VkFrontFace     front_face;
    bool            depth_bias_enable;
    float           depth_bias_constant_factor;
    float           depth_bias_clamp;
    float           depth_bias_slope_factor;
    float           line_width;

    // from VkPipelineMultisampleStateCreateInfo
    // if this is 0, it will automatically be set to VK_SAMPLE_COUNT_1_BIT
    VkSampleCountFlags  rasterization_samples;
    // these can all be left at 0
    VkBool32            sample_shading_enable;
    float               min_sample_shading;
    const VkSampleMask* p_sample_mask;
    VkBool32            alpha_to_coverage_enable;
    VkBool32            alpha_to_one_enable;

    // from VkPipelineDepthStencilStateCreateInfo
    bool             depth_test_enable;
    bool             depth_write_enable;
    OnyxCompareOp    depth_compare_op;
    bool             depth_bounds_test_enable;
    bool             stencil_test_enable;
    VkStencilOpState front;
    VkStencilOpState back;
    float            min_depth_bounds;
    float            max_depth_bounds;

    // from VkPipelineColorBlendStateCreateInfo
    // if logic op is enabled, the operation applies to all attachments
    // and color blending is disabled. only valid for integer attachments.
    bool                              logic_op_enable;
    VkLogicOp                         logic_op;
    uint32_t                          attachment_count;
    OnyxPipelineColorBlendAttachment* attachment_blends;
    float                             blend_constants[4];

    //
    uint32_t        dynamic_state_count;
    VkDynamicState* dynamic_states;
} OnyxGraphicsPipelineInfo;

// TODO: create an actual pipeline object
// to maintain state on our end
typedef struct OnyxGraphicsPipelineInfo2 {
    uint32_t               sp_id;
    VkRenderPass           vkrp;
    VkSampleCountFlags     sample_count;
    OnyxGeometryTemplate   geo_template;
    OnyxGraphicsPipelineSettings settings;
    OnyxProgramReflection  program;
    OnyxSubpass            subpass;
    OnyxRasterizationReflection rprefl;
    const OnyxPipedes*     pipedes;
    int                    modules_count;
    VkShaderModule         modules[10];
    VkPipelineLayout       layout;
} OnyxGraphicsPipelineInfo2;

typedef struct OnyxComputePipelineInfo {
    VkPipelineCreateFlags       flags;
    VkPipelineLayout            layout;
    OnyxShaderInfo shader_stage;
    VkShaderModule              module;
    VkPipeline                  base_pipeline;
    int32_t                     base_pipeline_index;
} OnyxComputePipelineInfo;

typedef struct {
    VkPipelineLayout layout;
    uint8_t          raygen_count;
    char**           raygen_shaders;
    uint8_t          miss_count;
    char**           miss_shaders;
    uint8_t          chit_count;
    char**           chit_shaders;
} OnyxRayTracePipelineInfo;

void onyx_graphics_pipeline_create(
        const VkDevice device,
        const OnyxGraphicsPipelineInfo2 *,
        VkPipeline*);

void onyx_destroy_description(VkDevice device, OnyxR_Description*);

void onyx_create_descriptor_set_layout(
    VkDevice device,
    const int bindingCount,
    const OnyxDescriptor bindings[/*bindingCount*/],
    VkDescriptorSetLayout*         layout);

void onyx_create_pipeline_layouts(VkDevice, const uint8_t count, const OnyxPipelineLayoutInfo layoutInfos[/*static count*/], 
        VkPipelineLayout pipelineLayouts[/*count*/]);
void onyx_create_graphics_pipelines(VkDevice device, const uint8_t count, const OnyxGraphicsPipelineInfo pipelineInfos[/*count*/], VkPipeline pipelines[/*count*/]);
void onyx_clean_up_pipelines(void);
void onyx_create_ray_trace_pipelines(VkDevice device, OnyxMemory* memory, const uint8_t count, const OnyxRayTracePipelineInfo pipelineInfos[/*count*/], 
        VkPipeline pipelines[/*count*/], OnyxShaderBindingTable shaderBindingTables[/*count*/]);

// very simple pipeline. counter clockwise. only considers position attribute (3 floats).
void onyx_create_graphics_pipeline_taurus(VkDevice device, const VkRenderPass renderPass,
                                        const VkPipelineLayout layout,
                                        const VkPolygonMode mode,
                                        VkPipeline *pipeline);

void
onyx_create_graphics_pipeline(VkDevice device, const OnyxGraphicsPipelineInfo* s,
                              const VkPipelineCache cache, VkPipeline* pipeline);

void
onyx_create_compute_pipeline(VkDevice, VkPipelineCache, const OnyxComputePipelineInfo* s,
                            VkPipeline* pipeline);

void onyx_create_pipeline_layout(VkDevice device, const OnyxPipelineLayoutInfo* li,
        VkPipelineLayout* layout);

typedef struct {
        uint32_t uniformBufferCount;
        uint32_t dynamicUniformBufferCount;
      uint32_t combinedImageSamplerCount;
      uint32_t storageImageCount;
      uint32_t storageBufferCount;
      uint32_t inputAttachmentCount;
      uint32_t accelerationStructureCount;
} OnyxDescriptorPoolParms;

void onyx_create_descriptor_pool(VkDevice device,
        OnyxDescriptorPoolParms parms,
                          VkDescriptorPool* pool);

void onyx_allocate_descriptor_sets(VkDevice, VkDescriptorPool pool, uint32_t descSetCount,
                            const VkDescriptorSetLayout layouts[/*descSetCount*/],
                            VkDescriptorSet*      sets);

void onyx_set_runtime_spv_prefix(const char* prefix);

const char* onyx_get_full_screen_quad_shader_string(void);

// Creates a basic graphics pipeline.
// patchControlPoints will be ignored unless a tesselation shader stage is
// passed in. If dynamic_viewport is enabled, it doesnt matter what you put for
// viewport_width or viewport_height.
void onyx_create_graphics_pipeline_basic(VkDevice device, VkPipelineLayout layout,
        VkRenderPass renderPass, uint32_t subpass, 
        uint32_t stageCount, const VkPipelineShaderStageCreateInfo* pStages,
        const VkPipelineVertexInputStateCreateInfo* pVertexInputState,
        VkPrimitiveTopology topology, uint32_t patchControlPoints, uint32_t viewport_width,
        uint32_t viewport_height, bool dynamic_viewport,
        VkPolygonMode polygonMode, VkFrontFace frontFace, float lineWidth, bool depthTestEnable, 
        bool depthWriteEnable,
        OnyxBlendMode blendMode,
        VkPipeline* pipeline);

#endif /* end of include guard: R_PIPELINE_H */

