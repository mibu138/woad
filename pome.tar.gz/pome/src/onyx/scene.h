#ifndef ONYX_S_SCENE_H
#define ONYX_S_SCENE_H

#include "geo.h"
#include "types.h"
#include <coal/types.h>
#include <hell/cmd.h>
#include <hell/ds.h>

//#define ONYX_S_MAX_PRIMS     256
//#define ONYX_SCENE_MAX_PRIMS     32
//#define ONYX_SCENE_MAX_MATERIALS 16
//#define ONYX_SCENE_MAX_LIGHTS    8
//#define ONYX_SCENE_MAX_TEXTURES  16

typedef uint32_t  OnyxSceneObjectInt;
#ifdef ONYX_SIMPLE_TYPE_NAMES
typedef OnyxSceneObjectInt obint;
#endif
typedef CoalMat4 OnyxXform;

#define ONYX_DEFHANDLE(name)                                                   \
    typedef struct Onyx##name##Handle {                                       \
        OnyxSceneObjectInt id;                                                \
    } Onyx##name##Handle

ONYX_DEFHANDLE(Primitive);
ONYX_DEFHANDLE(Light);
ONYX_DEFHANDLE(Material);
ONYX_DEFHANDLE(Texture);

#define NULL_PRIM                                                              \
    (OnyxPrimitiveHandle) { 0 }
#define NULL_LIGHT                                                             \
    (OnyxLightHandle) { 0 }
#define NULL_MATERIAL                                                          \
    (OnyxMaterialHandle) { 0 }
#define NULL_TEXTURE                                                           \
    (OnyxTextureHandle) { 0 }

#define ONYX_S_NONE (uint32_t) - 1

typedef enum {
    ONYX_SCENE_CAMERA_VIEW_BIT = 1 << 0,
    ONYX_SCENE_CAMERA_PROJ_BIT = 1 << 1,
    ONYX_SCENE_LIGHTS_BIT      = 1 << 2,
    ONYX_SCENE_XFORMS_BIT      = 1 << 3,
    ONYX_SCENE_MATERIALS_BIT   = 1 << 4,
    ONYX_SCENE_TEXTURES_BIT    = 1 << 5,
    ONYX_SCENE_PRIMS_BIT       = 1 << 6,
    ONYX_SCENE_LAST_BIT_PLUS_1,
} OnyxSceneDirtyFlagBits;
typedef uint8_t OnyxSceneDirtyFlags;

typedef enum {
    ONYX_PRIM_ADDED_BIT            = 1 << 0,
    ONYX_PRIM_REMOVED_BIT          = 1 << 1,
    ONYX_PRIM_TOPOLOGY_CHANGED_BIT = 1 << 2,
    ONYX_PRIM_LAST_BIT_PLUS_1,
} OnyxPrimDirtyFlagBits;
typedef uint8_t OnyxPrimDirtyFlags;

typedef enum {
    ONYX_MAT_ADDED_BIT   = 1 << 0,
    ONYX_MAT_REMOVED_BIT = 1 << 1,
    ONYX_MAT_CHANGED_BIT = 1 << 2,
    ONYX_MAT_LAST_BIT_PLUS_1,
} OnyxMatDirtyFlagBits;
typedef uint8_t OnyxMatDirtyFlags;

typedef enum {
    ONYX_TEX_ADDED_BIT   = 1 << 0,
    ONYX_TEX_REMOVED_BIT = 1 << 1,
    ONYX_TEX_CHANGED_BIT = 1 << 2,
    ONYX_TEX_LAST_BIT_PLUS_1,
} OnyxTexDirtyFlagBits;
typedef uint8_t OnyxTexDirtyFlags;

#ifdef __cplusplus
#define STATIC_ASSERT static_assert
#else
#define STATIC_ASSERT _Static_assert
#endif
STATIC_ASSERT(ONYX_TEX_LAST_BIT_PLUS_1 < 255, "Tex dirty bits must fit in a byte.");
STATIC_ASSERT(ONYX_MAT_LAST_BIT_PLUS_1 < 255, "Mat dirty bits must fit in a byte.");
STATIC_ASSERT(ONYX_PRIM_LAST_BIT_PLUS_1 < 255, "Prim dirty bits must fit in a byte.");
STATIC_ASSERT(ONYX_SCENE_LAST_BIT_PLUS_1 < 255, "Scene dirty bits must fit in a byte.");

typedef enum {
    ONYX_PRIM_INVISIBLE_BIT           = 1 << 0,
} OnyxPrimFlagBits;
typedef OnyxFlags OnyxPrimFlags;

typedef struct {
    CoalMat4 xform;
    CoalMat4 view; // xform inverted
    CoalMat4 proj;
} OnyxCamera;

typedef enum {
    ONYX_LIGHT_POINT_TYPE,
    ONYX_DIRECTION_LIGHT_TYPE
} OnyxLightType;

typedef struct {
    CoalVec3 pos;
} OnyxPointLight;

typedef struct {
    CoalVec3 dir;
} OnyxDirectionLight;

typedef struct {
    OnyxGeometry*      geo;
    OnyxXform          xform;
    OnyxMaterialHandle material;
    OnyxPrimDirtyFlags dirt;
    OnyxPrimFlags      flags;
} OnyxPrimitive;

typedef union {
    OnyxPointLight     point_light;
    OnyxDirectionLight direction_light;
} OnyxLightStructure;

typedef struct {
    OnyxLightStructure structure;
    float               intensity;
    CoalVec3           color;
    OnyxLightType      type;
} OnyxLight;

typedef struct {
    OnyxImage*        dev_image;
    OnyxTexDirtyFlags dirt;
} OnyxTexture;

typedef struct {
    CoalVec3             color;
    float                 roughness;
    OnyxTextureHandle    texture_albedo;
    OnyxTextureHandle    texture_roughness;
    OnyxTextureHandle    texture_normal;
    OnyxMatDirtyFlagBits dirt;
} OnyxMaterial;

typedef struct OnyxScene OnyxScene;

// container to associate prim ids with pipelines
typedef struct {
    HellArray array; // backing array. should not need to access directly
} OnyxPrimitiveList;

static inline const OnyxPrimitiveHandle* onyx_get_primlist_prims(const OnyxPrimitiveList* list, u32* count)
{
    *count = list->array.count;
    return (OnyxPrimitiveHandle*)list->array.elems;
}

// New paradigm: scene does not own any gpu resources. Images, geo, anything backed by gpu memory
// Those things should be created and destroyed independently
// This allows us to avoid confusion when multiple entities are sharing a scene and hopefully 
// avoid double-freeing reources.
OnyxScene* onyx_alloc_scene(void);
void onyx_create_scene(HellGrimoire* grim, OnyxMemory* memory, float fov,
                 float aspectRatio, float nearDepth, float farClip, OnyxScene* scene);

// will update camera as well as target.
void onyx_update_camera_arc_ball(OnyxScene* scene, CoalVec3* target,
                               int screenWidth, int screenHeight, float dt,
                               int xprev, int x, int yprev, int y, bool panning,
                               bool tumbling, bool zooming, bool home);
void onyx_update_camera_look_at(OnyxScene* scene, CoalVec3 pos,
                              CoalVec3 target, CoalVec3 up);
void onyx_scene_update_camera_pos(OnyxScene* scene, float dx, float dy, float dz);
void onyx_create_empty_scene(OnyxScene* scene);
void onyx_update_light(OnyxScene* scene, OnyxLightHandle handle,
                      float intensity);
void onyx_bind_prim_to_material(OnyxScene*                scene,
                             const OnyxPrimitiveHandle OnyxPrimitiveHandle,
                             const OnyxMaterialHandle  matId);
// this does not go through the prim map. allows us to preemptively bind prims
// to materials before we have an actual handle to them. practically useful for
// texture painting to always bind a material to the first prim
void onyx_bind_prim_to_material_direct(OnyxScene* scene, uint32_t directIndex,
                                   OnyxMaterialHandle mathandle);

OnyxPrimitiveList onyx_create_prim_list(uint32_t initial_capacity);
void onyx_add_prim_to_list(const OnyxPrimitiveHandle, OnyxPrimitiveList*);
OnyxLightHandle onyx_scene_add_direction_light(OnyxScene* s, CoalVec3 dir, CoalVec3 color,
                            float intensity);
void onyx_clear_prim_list(OnyxPrimitiveList*);
void onyx_destroy_scene(OnyxScene* scene);
OnyxLightHandle onyx_scene_add_point_light(OnyxScene* s, CoalVec3 pos, CoalVec3 color,
                        float intensity);
void onyx_print_light_info(const OnyxScene* s);
void onyx_print_texture_info(const OnyxScene* s);
void onyx_print_prim_info(const OnyxScene* s);
void onyx_scene_remove_light(OnyxScene* s, OnyxLightHandle id);

// returns an array of prim handle and stores the count in count
const OnyxPrimitiveHandle* onyx_scene_get_dirty_primitives(const OnyxScene*,
                                                         uint32_t* count);

void onyx_scene_remove_texture(OnyxScene* scene, OnyxTextureHandle tex);

void onyx_scene_remove_material(OnyxScene* scene, OnyxMaterialHandle mat);

// Does not free geo
void onyx_scene_remove_prim(OnyxScene* s, OnyxPrimitiveHandle id);

// Does not own the geo. Will not free if prim is removed.
OnyxPrimitiveHandle onyx_scene_add_prim(OnyxScene* scene, OnyxGeometry* geo,
                                  const CoalMat4     xform,
                                  OnyxMaterialHandle mat);

OnyxLightHandle     onyx_create_direction_light(OnyxScene*     scene,
                                               const CoalVec3 color,
                                               const CoalVec3 direction);
OnyxLightHandle onyx_create_point_light(OnyxScene* scene, const CoalVec3 color,
                                       const CoalVec3 position);
// a texture id of 0 means no texture will be used
OnyxMaterialHandle onyx_scene_create_material(OnyxScene* scene, CoalVec3 color,
                                             float              roughness,
                                             OnyxTextureHandle albedoId,
                                             OnyxTextureHandle roughnessId,
                                             OnyxTextureHandle normalId);

// swaps an rprim into a scene. returns the rprim that was there.
OnyxGeometry onyx_swap_r_prim(OnyxScene* scene, const OnyxGeometry* newRprim,
                             const OnyxPrimitiveHandle id);

void onyx_update_light_color(OnyxScene* scene, OnyxLightHandle id, float r,
                           float g, float b);
void onyx_update_light_intensity(OnyxScene* scene, OnyxLightHandle id, float i);
void onyx_update_light_pos(OnyxScene* scene, OnyxLightHandle id, float x,
                         float y, float z);
void onyx_update_prim_xform(OnyxScene* scene, const OnyxPrimitiveHandle primId,
                          const CoalMat4 delta);
void onyx_set_prim_xform(OnyxScene* scene, OnyxPrimitiveHandle primId,
                       CoalMat4 newXform);

CoalMat4 onyx_scene_get_camera_view(const OnyxScene* scene);
CoalMat4 onyx_scene_get_camera_projection(const OnyxScene* scene);
CoalMat4 onyx_scene_get_camera_xform(const OnyxScene* scene);

void onyx_scene_set_camera_xform(OnyxScene* scene, const CoalMat4);
void onyx_scene_set_camera_view(OnyxScene* scene, const CoalMat4);
void onyx_scene_set_camera_projection(OnyxScene* scene, const CoalMat4);

OnyxPrimitive* onyx_get_primitive(const OnyxScene* s, uint32_t id);

uint32_t onyx_scene_get_prim_count(const OnyxScene*);
uint32_t onyx_scene_get_light_count(const OnyxScene*);

OnyxLight* onyx_scene_get_lights(const OnyxScene*, uint32_t* count);

const OnyxLight* OnyxSceneGetLight(const OnyxScene*, OnyxLightHandle);

OnyxSceneDirtyFlags onyx_scene_get_dirt(const OnyxScene*);

// sets dirt flags to 0 and resets dirty prim set
void onyx_scene_end_frame(OnyxScene*);

// Does not own the image
OnyxTextureHandle onyx_scene_add_texture(OnyxScene*  scene,
                                           OnyxImage* image);

OnyxMaterial* onyx_get_material(const OnyxScene*   s,
                                OnyxMaterialHandle handle);

// given a handle returns the index into the raw resource array
uint32_t onyx_scene_get_material_index(const OnyxScene*, OnyxMaterialHandle);

// given a handle returns the index into the raw resource array
uint32_t onyx_scene_get_texture_index(const OnyxScene*, OnyxTextureHandle);

uint32_t       onyx_scene_get_texture_count(const OnyxScene* s);
OnyxTexture*  onyx_scene_get_textures(const OnyxScene* s, OnyxSceneObjectInt* count);
uint32_t       onyx_scene_get_material_count(const OnyxScene* s);
OnyxMaterial* onyx_scene_get_materials(const OnyxScene* s, OnyxSceneObjectInt* count);

// a bit of a hack for dali
void onyx_scene_dirty_textures(OnyxScene* s);

void onyx_scene_set_geo_direct(OnyxScene* s, OnyxGeometry* geo,
                            uint32_t directIndex);

void onyx_scene_free_geo_direct(OnyxScene* s, uint32_t directIndex);

bool onyx_scene_has_geo_direct(OnyxScene* s, uint32_t directIndex);

const OnyxCamera* onyx_scene_get_camera(const OnyxScene* scene);

// Writeable access to the geo held by the prim. 
// Must pass flags to indicate how the geo will be modified.
// Can return NULL indicating prim has no geo yet.
OnyxGeometry* onyx_scene_get_prim_geo(OnyxScene*          scene,
                                    OnyxPrimitiveHandle prim,
                                    OnyxPrimDirtyFlags  flags);

OnyxPrimitive* 
onyx_scene_get_primitive(OnyxScene* s, OnyxPrimitiveHandle handle);

const OnyxPrimitive*
onyx_scene_get_primitive_const(const OnyxScene* s, OnyxPrimitiveHandle handle);

const OnyxPrimitive* onyx_scene_get_primitives(const OnyxScene* s, OnyxSceneObjectInt* count);

void onyx_scene_dirty_all(OnyxScene* s);

void onyx_scene_camera_update_aspect_ratio(OnyxScene* s, float ar);

static inline OnyxPrimitiveHandle onyx_create_primitive_handle(OnyxSceneObjectInt i) 
{
    return (OnyxPrimitiveHandle){.id = i}; 
}

static inline OnyxMaterialHandle onyx_create_material_handle(OnyxSceneObjectInt i) 
{
    return (OnyxMaterialHandle){.id = i}; 
}

static inline OnyxTextureHandle onyx_create_texture_handle(OnyxSceneObjectInt i) 
{
    return (OnyxTextureHandle){.id = i}; 
}

static inline OnyxLightHandle onyx_create_light_handle(OnyxSceneObjectInt i) 
{
    return (OnyxLightHandle){.id = i}; 
}

#endif /* end of include guard: ONYX_S_SCENE_H */
