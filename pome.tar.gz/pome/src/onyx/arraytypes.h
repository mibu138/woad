#ifndef ONYX_ARRAY_TYPES_H
#define ONYX_ARRAY_TYPES_H

#include "types.h"
#include <hell/ds.h>

//define_array_type(OnyxGraphicsPipelineSettings, 
//        onyx_graphics_pipeline_settings);

#endif // ONYX_ARRAY_TYPES_H
