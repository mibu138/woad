//
#include "command.h"
#include "common.h"
#include "dtags.h"
#include "loader.h"
#include "memory.h"
#include "video.h"
#include "vulkan.h"
#include <assert.h>
#include <hell/attributes.h>
#include <hell/common.h>
#include <hell/debug.h>
#include <hell/ds.h>
#include <hell/error.h>
#include <hell/io.h>
#include <hell/len.h>
#include <hell/platform.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define DPRINT_VK(fmt, ...)                                                    \
    hell_debug_print(ONYX_DEBUG_TAG_VK, fmt, ##__VA_ARGS__)

// typedef struct vk_ext_name {
//     char f[VK_MAX_EXTENSION_NAME_SIZE];
// } ExtName;

typedef const char *ExtName;

define_array_type(ExtName, ext_name);
define_array_type(VkValidationFeatureEnableEXT, val_feat);

typedef OnyxQueueFamily QueueFamily;

struct vulkan_struct_chain_node {
    VkStructureType                  s_type;
    struct vulkan_struct_chain_node *p_next;
};

struct requested_feature {
    const void *ptr;
    size_t      size;
};

#define REQUESTED_FEATURE(var)                                                 \
    {                                                                          \
        &(var), sizeof(var)                                                    \
    }

static struct vulkan_struct_chain_node *
vulkan_struct_chain_node_alloc(size_t      size,
                               const void *fill_with_this /*optional*/)
{
    // allocate one more at the end for stopping on
    struct vulkan_struct_chain_node *node = malloc(size + 1);

    if (fill_with_this)
        memcpy(node, fill_with_this, size);
    else
        memset(node, 0, size);
    memset((char *)node + size, 0xFF, 1);

    return node;
}

static bool feature_struct_end(void *iter)
{
    unsigned char *end = iter;
    return *end == 0xFF;
}

void vulkan_struct_chain_free(struct vulkan_struct_chain_node *chain)
{
    assert(chain);
    struct vulkan_struct_chain_node *iter, *next;

    iter = chain;
    do {
        next = iter->p_next;
        free(iter);
        iter = next;
    } while (iter);
}

void vulkan_struct_chain_append(struct vulkan_struct_chain_node *chain,
                                struct vulkan_struct_chain_node *node)
{
    struct vulkan_struct_chain_node *iter = chain;
    while (iter->p_next)
        iter = iter->p_next;
    iter->p_next = node;
}

#define vulkan_struct_chain_new_node(base)                                     \
    vulkan_struct_chain_node_alloc(sizeof(base), &(base))

static struct vulkan_struct_chain_node *
vulkan_struct_chain_new(const struct requested_feature *base)
{
    return vulkan_struct_chain_node_alloc(base->size, base->ptr);
}

// returns 0 if all features match, else it returned the "index" of the first
// bool that does not match (first index being 1)
// each feature struct past in must include sizeof(VkBool32) bytes at the end
// from which we know the size
static int missing_requested_feature(
    const struct vulkan_struct_chain_node *restrict existing_features,
    const struct vulkan_struct_chain_node *restrict requested_features)
{
    struct phy_dev_feat_base {
        VkStructureType s;
        void           *p;
    };

    static const int inioff = sizeof(struct phy_dev_feat_base);

    VkBool32 *exiter, *rqiter;

    exiter = (VkBool32 *)((char *)existing_features + inioff);
    rqiter = (VkBool32 *)((char *)requested_features + inioff);

    int v = 1;
    while (!feature_struct_end(exiter)) {
        if (*rqiter && (!*exiter))
            return v;
        rqiter++;
        exiter++;
        v++;
    }
    return 0;
}

// must be freed with vulkan_struct_chain_free
static VkPhysicalDeviceFeatures2 *
create_phy_dev_feature_list(VkPhysicalDevice                dev,
                            const struct requested_feature *requested_features,
                            int                             rqfcnt)
{
    struct vulkan_struct_chain_node *req_chain, *avail_chain;

    // pass the first requested feature in
    req_chain   = vulkan_struct_chain_new(requested_features);
    avail_chain = vulkan_struct_chain_new(requested_features);

    {
        struct vulkan_struct_chain_node *new;
        // skip the first one because that as already been used to initialize
        // the chain
        for (int i = 1; i < rqfcnt; ++i) {
            new = vulkan_struct_chain_node_alloc(requested_features[i].size,
                                                 requested_features[i].ptr);
            vulkan_struct_chain_append(req_chain, new);
            new = vulkan_struct_chain_node_alloc(requested_features[i].size,
                                                 requested_features[i].ptr);
            vulkan_struct_chain_append(avail_chain, new);
        }
    }

    vkGetPhysicalDeviceFeatures2(dev, (void *)avail_chain);

    struct vulkan_struct_chain_node *rqiter, *aviter;
    int                              mf = 0;

    rqiter = req_chain;
    aviter = avail_chain;
    do {
        mf = missing_requested_feature(aviter, rqiter);
        if (mf)
            fatal_error("Missing requested features. sType: %d offset: %d\n",
                        aviter->s_type, mf);
        rqiter = rqiter->p_next;
        aviter = aviter->p_next;
    } while (rqiter);

    vulkan_struct_chain_free(avail_chain);

    return (VkPhysicalDeviceFeatures2 *)req_chain;
}

static VkBool32
debugCallback(VkDebugUtilsMessageSeverityFlagBitsEXT      messageSeverity,
              VkDebugUtilsMessageTypeFlagsEXT             messageTypes,
              const VkDebugUtilsMessengerCallbackDataEXT *pCallbackData,
              void                                       *pUserData)
{
    DPRINT_VK("\n%s\n", pCallbackData->pMessage);
    return VK_FALSE; // application must return false;
}

static void checkForAvailableLayers(u32          enabledInstanceLayerCount,
                                    const char **ppEnabledInstanceLayerNames)
{
    uint32_t availableCount;
    vkEnumerateInstanceLayerProperties(&availableCount, NULL);
    VkLayerProperties *propertiesAvailable =
        hell_malloc(sizeof(VkLayerProperties) * availableCount);
    vkEnumerateInstanceLayerProperties(&availableCount, propertiesAvailable);
    const char *listAvailableLayers =
        getenv("ONYX_LIST_AVAILABLE_INSTANCE_LAYERS");
    if (listAvailableLayers) {
        DPRINT_VK("%s\n", "Vulkan Instance layers available:");
        const int padding = 90;
        for (int i = 0; i < padding; i++) {
            hell_print("-");
        }
        hell_print("\n");
        for (uint32_t i = 0; i < availableCount; i++) {
            const char *name = propertiesAvailable[i].layerName;
            const char *desc = propertiesAvailable[i].description;
            const int   pad  = padding - strlen(name);
            hell_print("%s%*s\n", name, pad, desc);
            for (int i = 0; i < padding; i++) {
                hell_print("-");
            }
            hell_print("\n");
        }
        hell_print("\n");
    }
    for (uint32_t i = 0; i < enabledInstanceLayerCount; i++) {
        bool        matched   = false;
        const char *layerName = ppEnabledInstanceLayerNames[i];
        for (uint32_t j = 0; j < availableCount; j++) {
            if (strcmp(layerName, propertiesAvailable[j].layerName) == 0) {
                matched = true;
            }
        }
        if (!matched) {
            onyx_announce(
                "WARNING: Requested Vulkan Instance Layer not available: %s\n",
                layerName);
        }
    }
    hell_free(propertiesAvailable);
}

static void
checkForAvailableExtensions(u32          enabledInstanceExentensionCount,
                            const char **ppEnabledInstanceExtensionNames)
{
    uint32_t availableCount;
    vkEnumerateInstanceExtensionProperties(NULL, &availableCount, NULL);
    VkExtensionProperties *propertiesAvailable =
        hell_malloc(sizeof(VkExtensionProperties) * availableCount);
    vkEnumerateInstanceExtensionProperties(NULL, &availableCount,
                                           propertiesAvailable);
    const char *listAvailableExtensions =
        getenv("ONYX_LIST_AVAILABLE_INSTANCE_EXTENSIONS");
    if (listAvailableExtensions) {
        onyx_announce("%s\n", "Vulkan Instance extensions available:");
        for (uint32_t i = 0; i < availableCount; i++) {
            hell_print("%s\n", propertiesAvailable[i].extensionName);
        }
        hell_print("\n");
    }
    for (uint32_t i = 0; i < enabledInstanceExentensionCount; i++) {
        bool        matched       = false;
        const char *extensionName = ppEnabledInstanceExtensionNames[i];
        for (uint32_t j = 0; j < availableCount; j++) {
            if (strcmp(extensionName, propertiesAvailable[j].extensionName) ==
                0) {
                matched = true;
            }
        }
        if (!matched) {
            onyx_announce("WARNING: Requested Vulkan Instance Extension not "
                          "available: %s\n",
                          extensionName);
        }
    }
    hell_free(propertiesAvailable);
}

static uint32_t getVkVersionAvailable(void)
{
    uint32_t v;
    vkEnumerateInstanceVersion(&v);
    uint32_t major = VK_VERSION_MAJOR(v);
    uint32_t minor = VK_VERSION_MINOR(v);
    uint32_t patch = VK_VERSION_PATCH(v);
    onyx_announce("Vulkan Version available: %d.%d.%d\n", major, minor, patch);
    return v;
}

static VkResult
initVkInstance(u32          enabledInstanceExentensionCount,
               const char **ppEnabledInstanceExtensionNames,
               u32          enabledInstanceLayerCount,
               const char **ppEnabledInstanceLayerNames, bool disableValidation,
               u32                                 validationFeaturesCount,
               const VkValidationFeatureEnableEXT *pEnabledValidationFeatures,
               VkInstance                         *instance)
{
    // uint32_t vulkver = getVkVersionAvailable();
    uint32_t vulkver = VK_API_VERSION_1_3;
    // printf("Choosing vulkan version: 1.2.0\n");

    const char appName[]    = "Hell";
    const char engineName[] = "Onyx";

    const VkApplicationInfo appInfo = {
        .sType              = VK_STRUCTURE_TYPE_APPLICATION_INFO,
        .pApplicationName   = appName,
        .applicationVersion = 1.0,
        .pEngineName        = engineName,
        .apiVersion         = vulkver,
    };

    checkForAvailableLayers(enabledInstanceLayerCount,
                            ppEnabledInstanceLayerNames);
    checkForAvailableExtensions(enabledInstanceExentensionCount,
                                ppEnabledInstanceExtensionNames);

    VkValidationFeaturesEXT extraValidation = (VkValidationFeaturesEXT){
        .sType = VK_STRUCTURE_TYPE_VALIDATION_FEATURES_EXT,
        .disabledValidationFeatureCount = 0,
        .enabledValidationFeatureCount  = validationFeaturesCount,
        .pEnabledValidationFeatures     = pEnabledValidationFeatures};

    VkValidationFeaturesEXT *pExtraValidation =
        validationFeaturesCount ? &extraValidation : NULL;

    VkInstanceCreateInfo instanceInfo = {
        .enabledLayerCount       = enabledInstanceLayerCount,
        .enabledExtensionCount   = enabledInstanceExentensionCount,
        .ppEnabledExtensionNames = ppEnabledInstanceExtensionNames,
        .ppEnabledLayerNames     = ppEnabledInstanceLayerNames,
        .pApplicationInfo        = &appInfo,
        .sType                   = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
        .pNext                   = pExtraValidation,
    };

    if (disableValidation) {
        instanceInfo.enabledLayerCount = 0; // disables layers
    }

    VkResult r = vkCreateInstance(&instanceInfo, NULL, instance);
    return r;
}

static void initDebugMessenger(const VkInstance          instance,
                               VkDebugUtilsMessengerEXT *debugMessenger)
{
    const VkDebugUtilsMessengerCreateInfoEXT ci = {
        .sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT,
        .messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT |
                           VK_DEBUG_UTILS_MESSAGE_SEVERITY_INFO_BIT_EXT |
#if 0
                           VK_DEBUG_UTILS_MESSAGE_SEVERITY_VERBOSE_BIT_EXT |
#endif
                           VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT,
        .messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT |
                       VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT |
                       VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT,
        .pfnUserCallback = (PFN_vkDebugUtilsMessengerCallbackEXT)debugCallback,

    };

    PFN_vkVoidFunction fn;
    fn = vkGetInstanceProcAddr(instance, "vkCreateDebugUtilsMessengerEXT");

    assert(fn);

    PFN_vkCreateDebugUtilsMessengerEXT func =
        (PFN_vkCreateDebugUtilsMessengerEXT)fn;

    V_ASSERT(func(instance, &ci, NULL, debugMessenger));
}

#define NVIDIA_ID 0x10DE
static VkPhysicalDevice
retrievePhysicalDevice(const VkInstance            instance,
                       VkPhysicalDeviceProperties *deviceProperties)
{
    uint32_t physdevcount;
    V_ASSERT(vkEnumeratePhysicalDevices(instance, &physdevcount, NULL));
    assert(physdevcount < 6); // TODO make robust
    VkPhysicalDevice devices[6];
    V_ASSERT(vkEnumeratePhysicalDevices(instance, &physdevcount, devices));
    VkPhysicalDeviceProperties props[6];
    DPRINT_VK("Physical device count: %d\n", physdevcount);
    DPRINT_VK("Physical device names:\n");
    int nvidiaCardIndex = -1;
    for (uint32_t i = 0; i < physdevcount; i++) {
        vkGetPhysicalDeviceProperties(devices[i], &props[i]);
        DPRINT_VK("Device %d: name: %s\t vendorID: %d\n", i,
                  props[i].deviceName, props[i].vendorID);
        if (props[i].vendorID == NVIDIA_ID)
            nvidiaCardIndex = i;
    }
    int selected = 0;
    if (nvidiaCardIndex != -1)
        selected = nvidiaCardIndex;
    onyx_announce("Selecting Device: %s\n", props[selected].deviceName);
    *deviceProperties = props[selected];
    return devices[selected];
}

static VkResult initDevice(OnyxInstance *ctx, const OnyxInstanceParms *parms)
{
    VkQueueFamilyProperties qfprops[LEN(ctx->queue_families)];
    VkDeviceQueueCreateInfo qcis[LEN(ctx->queue_families)];
    float                   queue_priorities[ONYX_MAX_DEVICE_QUEUES];
    uint32_t                qfcount;

    const bool enable_ray_tracing  = parms->enable_ray_tracing;
    bool       enable_present_wait = !parms->disable_present_wait;

    {
        char *env = getenv("ONYX_NO_PRESENT_WAIT");
        if (env)
            enable_present_wait = false;
    }

    for (int i = 0; i < ONYX_MAX_DEVICE_QUEUES; ++i) {
        queue_priorities[i] = 1.0;
    }

    vkGetPhysicalDeviceQueueFamilyProperties(ctx->physical_device, &qfcount,
                                             NULL);
    assert(qfcount < LEN(ctx->queue_families)); // TODO make robust

    vkGetPhysicalDeviceQueueFamilyProperties(ctx->physical_device, &qfcount,
                                             qfprops);

    for (uint32_t i = 0; i < qfcount; i++) {
        VkQueryControlFlags flags = qfprops[i].queueFlags;
        onyx_announce("Queue Family %d: count: %d flags: ", i,
                      qfprops[i].queueCount);
        if (flags & VK_QUEUE_GRAPHICS_BIT)
            hell_print(" Graphics ");
        if (flags & VK_QUEUE_COMPUTE_BIT)
            hell_print(" Compute ");
        if (flags & VK_QUEUE_TRANSFER_BIT)
            hell_print(" Tranfer ");
        hell_print("\n");
        assert(qfprops[i].queueCount < ONYX_MAX_DEVICE_QUEUES);
        ctx->queue_families[i].queue_count = qfprops[i].queueCount;
        ctx->queue_families[i].flags       = qfprops[i].queueFlags;

        qcis[i] = (VkDeviceQueueCreateInfo){
            .sType            = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
            .queueCount       = qfprops[i].queueCount,
            .queueFamilyIndex = i,
            .pQueuePriorities = queue_priorities,
        };
    }

    uint32_t propCount;
    V_ASSERT(vkEnumerateDeviceExtensionProperties(ctx->physical_device, NULL,
                                                  &propCount, NULL));
    VkExtensionProperties *properties =
        hell_malloc(sizeof(*properties) * propCount);
    V_ASSERT(vkEnumerateDeviceExtensionProperties(ctx->physical_device, NULL,
                                                  &propCount, properties));

#if VERBOSE > 1
    V1_PRINT("Device Extensions available: \n");
    for (int i = 0; i < propCount; i++) {
        DPRINT_VK("Name: %s    Spec Version: %d\n", properties[i].extensionName,
                  properties[i].specVersion);
    }
#endif

    VkPhysicalDeviceAccelerationStructurePropertiesKHR asProps = {
        .sType =
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ACCELERATION_STRUCTURE_PROPERTIES_KHR,
    };

    VkPhysicalDeviceRayTracingPipelinePropertiesKHR rayTracingProps = {
        .sType =
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_RAY_TRACING_PIPELINE_PROPERTIES_KHR,
        .pNext = &asProps};

    VkPhysicalDeviceProperties2 phsicalDeviceProperties2 = {
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2,
    };

    if (enable_ray_tracing)
        phsicalDeviceProperties2.pNext = &rayTracingProps;
    else
        phsicalDeviceProperties2.pNext = NULL;

    vkGetPhysicalDeviceProperties2(ctx->physical_device,
                                   &phsicalDeviceProperties2);

    if (enable_ray_tracing) {
        ctx->rt_properties           = rayTracingProps;
        ctx->accel_struct_properties = asProps;
    }

    ExtNameArray exts = ext_name_arr_create(NULL);

    ext_name_arr_push(&exts, VK_KHR_SWAPCHAIN_EXTENSION_NAME);

    VkPhysicalDeviceAccelerationStructureFeaturesKHR
        acceleration_struct_features = {
            .sType =
                VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ACCELERATION_STRUCTURE_FEATURES_KHR,
            .pNext = NULL,
        };

    VkPhysicalDeviceRayTracingPipelineFeaturesKHR ray_tracing_features = {
        .sType =
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_RAY_TRACING_PIPELINE_FEATURES_KHR,
        .pNext = NULL,
    };

    VkPhysicalDevicePresentIdFeaturesKHR present_id_features = {
        .sType     = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PRESENT_ID_FEATURES_KHR,
        .pNext     = NULL,
        .presentId = false,
    };

    VkPhysicalDevicePresentWaitFeaturesKHR present_wait_features = {
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PRESENT_WAIT_FEATURES_KHR,
        .pNext = NULL,
        .presentWait = false,
    };

    VkPhysicalDeviceVulkan11Features vulkan11_requested_features = {
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_FEATURES,
        .pNext = 0,
        .storageBuffer16BitAccess           = false,
        .uniformAndStorageBuffer16BitAccess = false,
        .storagePushConstant16              = false,
        .storageInputOutput16               = false,
        .multiview                          = false,
        .multiviewGeometryShader            = false,
        .multiviewTessellationShader        = false,
        .variablePointersStorageBuffer      = false,
        .variablePointers                   = false,
        .protectedMemory                    = false,
        .samplerYcbcrConversion             = false,
        .shaderDrawParameters               = false,
    };

    VkPhysicalDeviceVulkan12Features vulkan12_requested_features = {
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES,
        .pNext = 0,
        .samplerMirrorClampToEdge                           = false,
        .drawIndirectCount                                  = false,
        .storageBuffer8BitAccess                            = false,
        .uniformAndStorageBuffer8BitAccess                  = false,
        .storagePushConstant8                               = false,
        .shaderBufferInt64Atomics                           = false,
        .shaderSharedInt64Atomics                           = false,
        .shaderFloat16                                      = false,
        .shaderInt8                                         = false,
        .descriptorIndexing                                 = false,
        .shaderInputAttachmentArrayDynamicIndexing          = false,
        .shaderUniformTexelBufferArrayDynamicIndexing       = false,
        .shaderStorageTexelBufferArrayDynamicIndexing       = false,
        .shaderUniformBufferArrayNonUniformIndexing         = false,
        .shaderSampledImageArrayNonUniformIndexing          = false,
        .shaderStorageBufferArrayNonUniformIndexing         = false,
        .shaderStorageImageArrayNonUniformIndexing          = false,
        .shaderInputAttachmentArrayNonUniformIndexing       = false,
        .shaderUniformTexelBufferArrayNonUniformIndexing    = false,
        .shaderStorageTexelBufferArrayNonUniformIndexing    = false,
        .descriptorBindingUniformBufferUpdateAfterBind      = false,
        .descriptorBindingSampledImageUpdateAfterBind       = false,
        .descriptorBindingStorageImageUpdateAfterBind       = false,
        .descriptorBindingStorageBufferUpdateAfterBind      = false,
        .descriptorBindingUniformTexelBufferUpdateAfterBind = false,
        .descriptorBindingStorageTexelBufferUpdateAfterBind = false,
        .descriptorBindingUpdateUnusedWhilePending          = false,
        .descriptorBindingPartiallyBound                    = false,
        .descriptorBindingVariableDescriptorCount           = false,
        .runtimeDescriptorArray                             = false,
        .samplerFilterMinmax                                = false,
        .scalarBlockLayout                                  = true,
        .imagelessFramebuffer                               = false,
        .uniformBufferStandardLayout                        = false,
        .shaderSubgroupExtendedTypes                        = false,
        .separateDepthStencilLayouts                        = false,
        .hostQueryReset                                     = false,
        .timelineSemaphore                                  = true,
        .bufferDeviceAddress                                = true,
        .bufferDeviceAddressCaptureReplay                   = false,
        .bufferDeviceAddressMultiDevice                     = false,
        .vulkanMemoryModel                                  = false,
        .vulkanMemoryModelDeviceScope                       = false,
        .vulkanMemoryModelAvailabilityVisibilityChains      = false,
        .shaderOutputViewportIndex                          = false,
        .shaderOutputLayer                                  = false,
        .subgroupBroadcastDynamicId                         = false,
    };

    VkPhysicalDeviceVulkan13Features vulkan13_requested_features = {
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES,
        .pNext = 0,
        .robustImageAccess                                  = false,
        .inlineUniformBlock                                 = false,
        .descriptorBindingInlineUniformBlockUpdateAfterBind = false,
        .pipelineCreationCacheControl                       = false,
        .privateData                                        = false,
        .shaderDemoteToHelperInvocation                     = false,
        .shaderTerminateInvocation                          = false,
        .subgroupSizeControl                                = false,
        .computeFullSubgroups                               = false,
        .synchronization2                                   = false,
        .textureCompressionASTC_HDR                         = false,
        .shaderZeroInitializeWorkgroupMemory                = false,
        .dynamicRendering                                   = false,
        .shaderIntegerDotProduct                            = false,
        .maintenance4                                       = true,
    };

    VkPhysicalDeviceFeatures2 base_requested_features = {
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2,
        .pNext = NULL,
        .features =
            {
                .robustBufferAccess                      = false,
                .fullDrawIndexUint32                     = false,
                .imageCubeArray                          = false,
                .independentBlend                        = false,
                .geometryShader                          = false,
                .tessellationShader                      = false,
                .sampleRateShading                       = false,
                .dualSrcBlend                            = false,
                .logicOp                                 = false,
                .multiDrawIndirect                       = false,
                .drawIndirectFirstInstance               = false,
                .depthClamp                              = false,
                .depthBiasClamp                          = false,
                .fillModeNonSolid                        = true,
                .depthBounds                             = false,
                .wideLines                               = false,
                .largePoints                             = false,
                .alphaToOne                              = false,
                .multiViewport                           = false,
                .samplerAnisotropy                       = false,
                .textureCompressionETC2                  = false,
                .textureCompressionASTC_LDR              = false,
                .textureCompressionBC                    = false,
                .occlusionQueryPrecise                   = false,
                .pipelineStatisticsQuery                 = false,
                .vertexPipelineStoresAndAtomics          = false,
                .fragmentStoresAndAtomics                = false,
                .shaderTessellationAndGeometryPointSize  = false,
                .shaderImageGatherExtended               = false,
                .shaderStorageImageExtendedFormats       = false,
                .shaderStorageImageMultisample           = false,
                .shaderStorageImageReadWithoutFormat     = false,
                .shaderStorageImageWriteWithoutFormat    = false,
                .shaderUniformBufferArrayDynamicIndexing = false,
                .shaderSampledImageArrayDynamicIndexing  = false,
                .shaderStorageBufferArrayDynamicIndexing = false,
                .shaderStorageImageArrayDynamicIndexing  = false,
                .shaderClipDistance                      = false,
                .shaderCullDistance                      = false,
                .shaderFloat64                           = false,
                .shaderInt64                             = false,
                .shaderInt16                             = false,
                .shaderResourceResidency                 = false,
                .shaderResourceMinLod                    = false,
                .sparseBinding                           = false,
                .sparseResidencyBuffer                   = false,
                .sparseResidencyImage2D                  = false,
                .sparseResidencyImage3D                  = false,
                .sparseResidency2Samples                 = false,
                .sparseResidency4Samples                 = false,
                .sparseResidency8Samples                 = false,
                .sparseResidency16Samples                = false,
                .sparseResidencyAliased                  = false,
                .variableMultisampleRate                 = false,
                .inheritedQueries                        = false,
            },
    };

    if (enable_ray_tracing) {
        ext_name_arr_push(&exts, VK_KHR_RAY_TRACING_PIPELINE_EXTENSION_NAME);
        ext_name_arr_push(&exts, VK_KHR_ACCELERATION_STRUCTURE_EXTENSION_NAME);
        // not sure if these are actually needed
        ext_name_arr_push(&exts,
                          VK_KHR_DEFERRED_HOST_OPERATIONS_EXTENSION_NAME);
        ext_name_arr_push(&exts, VK_KHR_PIPELINE_LIBRARY_EXTENSION_NAME);
    }

    if (enable_present_wait) {
        ext_name_arr_push(&exts, VK_KHR_PRESENT_ID_EXTENSION_NAME);
        ext_name_arr_push(&exts, VK_KHR_PRESENT_WAIT_EXTENSION_NAME);
        present_id_features.presentId     = true;
        present_wait_features.presentWait = true;
    }

    if (enable_ray_tracing)
        assert(0 && "Need to implement");

    const struct requested_feature requested_features[] = {
        REQUESTED_FEATURE(base_requested_features),
        REQUESTED_FEATURE(vulkan13_requested_features),
        REQUESTED_FEATURE(vulkan12_requested_features),
        REQUESTED_FEATURE(vulkan11_requested_features),
        REQUESTED_FEATURE(present_id_features),
        REQUESTED_FEATURE(present_wait_features),
    };

    VkPhysicalDeviceFeatures2 *device_features = create_phy_dev_feature_list(
        ctx->physical_device, requested_features, LEN(requested_features));

    VkDeviceCreateInfo dci = {
        .sType                   = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
        .enabledLayerCount       = 0,
        .enabledExtensionCount   = exts.count,
        .ppEnabledExtensionNames = exts.elems,
        .pNext                   = device_features,
        .ppEnabledLayerNames     = NULL,
        .pEnabledFeatures        = NULL, // not used in newer vulkan versions
        .pQueueCreateInfos       = qcis,
        .queueCreateInfoCount    = qfcount,
    };

    ctx->queue_family_count = qfcount;

    VkResult r = vkCreateDevice(ctx->physical_device, &dci, NULL, &ctx->device);

    hell_free(properties);
    vulkan_struct_chain_free((void *)device_features);

    return r;
}

static void init_queues(OnyxInstance *ctx)
{
    assert(ctx->present_queue == 0);
    for (uint32_t i = 0; i < ctx->queue_family_count; i++) {
        // fill the queue array
        for (int q = 0; q < ctx->queue_families[i].queue_count; ++q)
            vkGetDeviceQueue(ctx->device, i, q,
                             &ctx->queue_families[i].queues[q]);
        if (ctx->present_queue == 0) {
            if (ctx->queue_families[i].flags & VK_QUEUE_GRAPHICS_BIT)
                ctx->present_queue = ctx->queue_families[i].queues[0];
        }
    }
    onyx_announce("Onyx: Queues Initialized\n");
}

void onyx_create_instance_basic(OnyxInstance *instance)
{
    OnyxInstanceParms ip = {
        .surface_type = ONYX_SURFACE_TYPE_XCB,
#ifndef NDEBUG
        .disable_validation = false,
#else
        .disable_validation = true,
#endif
    };

    onyx_create_instance(&ip, instance);
}

void onyx_create_instance(const OnyxInstanceParms *parms,
                          OnyxInstance            *instance)
{
    uint32_t i;

    memset(instance, 0, sizeof(OnyxInstance));
    ExtNameArray enabled_instance_extension_names = ext_name_arr_create(NULL);
    ExtNameArray enabled_instance_layer_names     = ext_name_arr_create(NULL);
    VkValidationFeatureEnableEXTArray enabled_validation_features =
        val_feat_arr_create(NULL);
    if (!parms->disable_validation) {
        VkValidationFeatureEnableEXT sync_validation =
            VK_VALIDATION_FEATURE_ENABLE_SYNCHRONIZATION_VALIDATION_EXT;
        ext_name_arr_push(&enabled_instance_layer_names,
                          "VK_LAYER_KHRONOS_validation");
        ext_name_arr_push(&enabled_instance_extension_names,
                          VK_EXT_DEBUG_UTILS_EXTENSION_NAME);
        val_feat_arr_push(&enabled_validation_features, sync_validation);
    }

    switch (parms->surface_type) {
        case ONYX_SURFACE_TYPE_XCB: {
            ext_name_arr_push(&enabled_instance_extension_names,
                              VK_KHR_SURFACE_EXTENSION_NAME);
            ext_name_arr_push(&enabled_instance_extension_names,
                              "VK_KHR_xcb_surface");
            break;
        }
        case ONYX_SURFACE_TYPE_WIN32: {
            ext_name_arr_push(&enabled_instance_extension_names,
                              VK_KHR_SURFACE_EXTENSION_NAME);
            ext_name_arr_push(&enabled_instance_extension_names,
                              "VK_KHR_win32_surface");
            break;
        }
        case ONYX_SURFACE_TYPE_NO_WINDOW:
            break;
    }
    VkResult r = initVkInstance(
        enabled_instance_extension_names.count,
        enabled_instance_extension_names.elems,
        enabled_instance_layer_names.count, enabled_instance_layer_names.elems,
        parms->disable_validation, enabled_validation_features.count,
        enabled_validation_features.elems, &instance->vkinstance);
    if (r != VK_SUCCESS) {
        hell_error(HELL_ERR_FATAL, "Could not initialize Vulkan instance. \n");
    }
    if (!parms->disable_validation) {
        initDebugMessenger(instance->vkinstance, &instance->debug_messenger);
    }
    onyx_announce("Vulkan Instance initilized.\n");
    instance->physical_device = retrievePhysicalDevice(
        instance->vkinstance, &instance->device_properties);
    r = initDevice(instance, parms);
    if (r != VK_SUCCESS) {
        hell_error(HELL_ERR_FATAL, "Could not initialize Vulkan device\n");
    }
    onyx_announce("Vulkan device initilized.\n");
    onyx_load_vulkan_functions(instance->device, parms->enable_ray_tracing);
    init_queues(instance);
    onyx_announce("Initialized Onyx Instance.\n");
    ext_name_arr_free(&enabled_instance_layer_names);
    ext_name_arr_free(&enabled_instance_extension_names);
    val_feat_arr_free(&enabled_validation_features);
}

void onyx_submit_to_queue_wait(const OnyxInstance    *instance,
                               const VkCommandBuffer *cmdBuf,
                               const OnyxQueueType    queueType,
                               const uint32_t         index)
{
    assert(ONYX_QUEUE_GRAPHICS_TYPE == queueType);

    uint32_t qfi = onyx_queue_family_index(instance, queueType);
    assert(instance->queue_families[qfi].queue_count > index);

    VkQueue queue = instance->queue_families[qfi].queues[index];

    const VkSubmitInfo info = {.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
                               .commandBufferCount   = 1,
                               .signalSemaphoreCount = 0,
                               .waitSemaphoreCount   = 0,
                               .pCommandBuffers      = cmdBuf};

    V_ASSERT(vkQueueSubmit(queue, 1, &info, VK_NULL_HANDLE));
    V_ASSERT(vkQueueWaitIdle(queue));
}

void onyx_destroy_instance(OnyxInstance *instance)
{
    PFN_vkDestroyDebugUtilsMessengerEXT vkDestroyDebugUtilsMessengerEXT =
        (PFN_vkDestroyDebugUtilsMessengerEXT)vkGetInstanceProcAddr(
            instance->vkinstance, "vkDestroyDebugUtilsMessengerEXT");

    vkDestroyDevice(instance->device, NULL);
    if (instance->debug_messenger != VK_NULL_HANDLE)
        vkDestroyDebugUtilsMessengerEXT(instance->vkinstance,
                                        instance->debug_messenger, NULL);
    vkDestroyInstance(instance->vkinstance, NULL);
    onyx_announce("Cleaned up.\n");
}

VkPhysicalDeviceRayTracingPipelinePropertiesKHR
onyx_get_physical_device_ray_tracing_properties(const OnyxInstance *instance)
{
    return instance->rt_properties;
}

VkDevice onyx_get_device(const OnyxInstance *instance)
{
    return instance->device;
}

VkQueue onyx_queue(const OnyxInstance *ctx, OnyxQueueType type, u32 index)
{
    uint32_t i = onyx_queue_family_index(ctx, type);
    return onyx_queue__(ctx, i, index);
}

VkQueue onyx_queue_(const OnyxInstance *ctx, VkQueueFlags flags, u32 index)
{
    uint32_t i = onyx_queue_family_index_(ctx, flags);
    return onyx_queue__(ctx, i, index);
}

VkQueue onyx_queue__(const OnyxInstance *ctx, u32 i, u32 index)
{
    fatal_condition(ctx->queue_families[i].queue_count <= index,
                    "Index out of range");
    return ctx->queue_families[i].queues[index];
}

VkQueue onyx_get_present_queue(const OnyxInstance *instance)
{
    return instance->present_queue;
}

VkQueue onyx_get_graphics_queue(const OnyxInstance *inst, u32 index)
{
    return onyx_queue(inst, ONYX_QUEUE_GRAPHICS_TYPE, index);
}

VkQueue onyx_get_transfer_queue(const OnyxInstance *inst, u32 index)
{
    return onyx_queue(inst, ONYX_QUEUE_TRANSFER_TYPE, index);
}

void onyx_submit_graphics_command(const OnyxInstance        *instance,
                                  const uint32_t             queueIndex,
                                  const VkPipelineStageFlags waitDstStageMask,
                                  uint32_t                   waitCount,
                                  VkSemaphore waitSemephores[/*waitCount*/],
                                  uint32_t    signalCount,
                                  VkSemaphore signalSemphores[/*signalCount*/],
                                  VkFence fence, const VkCommandBuffer cmdBuf)
{
    VkPipelineStageFlags waitDstStageMasks[] = {
        waitDstStageMask, waitDstStageMask, waitDstStageMask,
        waitDstStageMask}; // hack...
    VkSubmitInfo si = {.sType                = VK_STRUCTURE_TYPE_SUBMIT_INFO,
                       .pWaitDstStageMask    = waitDstStageMasks,
                       .waitSemaphoreCount   = waitCount,
                       .pWaitSemaphores      = waitSemephores,
                       .signalSemaphoreCount = signalCount,
                       .pSignalSemaphores    = signalSemphores,
                       .commandBufferCount   = 1,
                       .pCommandBuffers      = &cmdBuf};

    V_ASSERT(vkQueueSubmit(onyx_get_graphics_queue(instance, queueIndex), 1,
                           &si, fence));
}

void onyx_submit_transfer_command(const OnyxInstance        *instance,
                                  const uint32_t             queueIndex,
                                  const VkPipelineStageFlags waitDstStageMask,
                                  const VkSemaphore         *pWaitSemephore,
                                  VkFence fence, const OnyxCommand *cmd)
{
    VkSubmitInfo si = {
        .sType                = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .pWaitDstStageMask    = &waitDstStageMask,
        .waitSemaphoreCount   = pWaitSemephore == NULL ? 0 : 1,
        .pWaitSemaphores      = pWaitSemephore,
        .signalSemaphoreCount = 1,
        .pSignalSemaphores    = &cmd->semaphore,
        .commandBufferCount   = 1,
        .pCommandBuffers      = &cmd->buffer,
    };

    V_ASSERT(vkQueueSubmit(onyx_get_transfer_queue(instance, queueIndex), 1,
                           &si, fence));
}

VkPhysicalDevice onyx_get_physical_device(const OnyxInstance *instance)
{
    return instance->physical_device;
}

const VkPhysicalDeviceProperties *
onyx_get_physical_device_properties(const OnyxInstance *instance)
{
    return &instance->device_properties;
}

VkPhysicalDeviceAccelerationStructurePropertiesKHR
onyx_get_physical_device_acceleration_structure_properties(
    const OnyxInstance *instance)
{
    return instance->accel_struct_properties;
}

const VkInstance *onyx_get_vk_instance(const OnyxInstance *instance)
{
    return &instance->vkinstance;
}

void onyx_present_queue_wait_idle(const OnyxInstance *instance)
{
    vkQueueWaitIdle(instance->present_queue);
}

void onyx_device_wait_idle(const OnyxInstance *instance)
{
    vkDeviceWaitIdle(instance->device);
}

uint64_t onyx_size_of_instance(void) { return sizeof(OnyxInstance); }

OnyxInstance *onyx_alloc_instance(void)
{
    return hell_malloc(sizeof(OnyxInstance));
}

void onyx_queue_submit(VkQueue queue, uint32_t submitCount,
                       const VkSubmitInfo *pSubmits, VkFence fence)
{
    V_ASSERT(vkQueueSubmit(queue, submitCount, pSubmits, fence));
}

void onyx_queue_submit2(VkQueue queue, uint32_t submitCount,
                        const VkSubmitInfo2 *pSubmits, VkFence fence)
{
    hell_error(HELL_ERR_FATAL, "Not implemented yet\n");
    // V_ASSERT(vkQueueSubmit2(queue, submitCount, pSubmits, fence));
}

uint32_t onyx_queue_family_index(const OnyxInstance *ctx, OnyxQueueType type)
{
    VkFlags bits = 0;
    switch (type) {
        case ONYX_QUEUE_GRAPHICS_TYPE:
            bits = VK_QUEUE_GRAPHICS_BIT;
            break;
        case ONYX_QUEUE_COMPUTE_TYPE:
            bits = VK_QUEUE_COMPUTE_BIT;
            break;
        case ONYX_QUEUE_TRANSFER_TYPE:
            bits = VK_QUEUE_TRANSFER_BIT;
            break;
    }
    return onyx_queue_family_index_(ctx, bits);
}

uint32_t onyx_graphics_queue_family_index(const OnyxInstance *c)
{
    return onyx_queue_family_index(c, ONYX_QUEUE_GRAPHICS_TYPE);
}

uint32_t onyx_queue_family_index_(const OnyxInstance *ctx, VkQueueFlags bits)
{
    for (uint32_t i = 0; i < ctx->queue_family_count; ++i)
        if (ctx->queue_families[i].flags & bits)
            return i;
    return -1;
}
