#include "swapchain.h"
#include "common.h"
#include "dtags.h"
#include "hell/input.h"
#include "scene.h"
#include "command.h"
#include "video.h"
#include <hell/common.h>
#include <hell/debug.h>
#include <hell/minmax.h>
#include <hell/platform.h>
#include <hell/memory.h>
#include <hell/window.h>
#include <hell/io.h>
#include <string.h>
#ifdef UNIX
#include <hell/xcb_window_type.h>
#elif defined(WINDOWS)
#include <hell/win32_window.h>
#endif

#define DPRINT(fmt, ...)                                                       \
    hell_debug_print(ONYX_DEBUG_TAG_SWAP, fmt, ##__VA_ARGS__)

#define MAX_SWAP_RECREATE_FNS 8

#define SWAPCHAIN_DEFAULT_FORMAT VK_FORMAT_B8G8R8A8_UNORM

typedef OnyxSwapchain This;

static VkExtent2D
getCorrectedSwapchainDimensions(const VkSurfaceCapabilitiesKHR capabilities,
                                VkExtent2D                     hint)
{
    VkExtent2D dim = {0};
    if (capabilities.currentExtent.width != UINT32_MAX)
    {
        dim.width  = capabilities.currentExtent.width;
        dim.height = capabilities.currentExtent.height;
    }
    else
    {
        dim.width  = MAX(capabilities.minImageExtent.width,
                        MIN(capabilities.maxImageExtent.width, hint.width));
        dim.height = MAX(capabilities.minImageExtent.width,
                         MIN(capabilities.maxImageExtent.width, hint.height));
    }
    return dim;
}

#ifdef UNIX
static void
initSurfaceXcb(const VkInstance instance, const HellWindow* window, VkSurfaceKHR* surface)
{
    const VkXcbSurfaceCreateInfoKHR ci = {
        .sType      = VK_STRUCTURE_TYPE_XCB_SURFACE_CREATE_INFO_KHR,
        .connection = (xcb_connection_t*)hell_get_xcb_connection(window),
        .window     = *(xcb_window_t*)hell_get_xcb_window_ptr(window)
    };

    V_ASSERT(vkCreateXcbSurfaceKHR(instance, &ci, NULL, surface));
}
#endif

#ifdef WIN32
static void
initSurfaceWin32(const VkInstance instance, const HellWindow* window, VkSurfaceKHR* surface)
{
    HWND hwnd = *(HWND*)hell_get_hwnd_ptr(window);
    HINSTANCE hinstance = *(HINSTANCE*)hell_get_hinstance_ptr(window);
    VkWin32SurfaceCreateInfoKHR ci = {
        .sType     = VK_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO_KHR,
        .hinstance = hinstance,
        .hwnd      = hwnd
    };

    V_ASSERT(vkCreateWin32SurfaceKHR(instance, &ci, NULL, surface));
}
#endif

static void
init_surface(const VkInstance instance, const HellWindow* window, VkSurfaceKHR* surface)
{
    assert(window);
#ifdef UNIX
    initSurfaceXcb(instance, window, surface);
#elif defined(WIN32)
    initSurfaceWin32(instance, window, surface);
#endif
    onyx_announce("Vulkan Surface initialized.\n");
}

static VkFormat
chooseFormat(const VkPhysicalDevice physicalDevice, const VkSurfaceKHR surface)
{
    uint32_t formatsCount;
    vkGetPhysicalDeviceSurfaceFormatsKHR(physicalDevice, surface, &formatsCount,
                                         NULL);
    VkSurfaceFormatKHR* surfaceFormats = hell_malloc(sizeof(*surfaceFormats) * formatsCount);
    vkGetPhysicalDeviceSurfaceFormatsKHR(physicalDevice, surface, &formatsCount,
                                         surfaceFormats);

    DPRINT("Surface formats: \n");
    for (int i = 0; i < formatsCount; i++)
    {
        DPRINT("Format: %d   Colorspace: %d\n", surfaceFormats[i].format,
               surfaceFormats[i].colorSpace);
    }

    return SWAPCHAIN_DEFAULT_FORMAT; // TODO: actually choose a format based on
                                     // physical device;
}

static void initSwapchainPresentMode(const VkPhysicalDevice physicalDevice,
        const VkSurfaceKHR surface,
        OnyxSwapchain* swapchain)
{
    assert(surface);
    VkBool32               supported;
    vkGetPhysicalDeviceSurfaceSupportKHR(physicalDevice, 0, surface,
                                         &supported);

    assert(supported == VK_TRUE);

    uint32_t presentModeCount;
    vkGetPhysicalDeviceSurfacePresentModesKHR(physicalDevice, surface,
                                              &presentModeCount, NULL);
    assert(presentModeCount < 10); 
    VkPresentModeKHR presentModes[10];
    vkGetPhysicalDeviceSurfacePresentModesKHR(physicalDevice, surface,
                                              &presentModeCount, presentModes);

    // const VkPresentModeKHR presentMode = VK_PRESENT_MODE_FIFO_KHR; // i
    // already know its supported
    swapchain->present_mode =
        VK_PRESENT_MODE_FIFO_KHR; // only mode garuanteed by the spec
        //VK_PRESENT_MODE_IMMEDIATE_KHR; // I get less input lag with this mode
}

static void
create_swapchain_with_surface(OnyxSwapchain* swapchain,
                           const uint32_t widthHint,
                           const uint32_t heightHint)
{
    VkSurfaceCapabilitiesKHR capabilities;
    V_ASSERT(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(swapchain->physical_device, swapchain->surface,
                                                       &capabilities));

    assert(capabilities.supportedUsageFlags &
           VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT);
    DPRINT("Surface Capabilities: \
            Min swapchain image count: %d\n\
            Max swapchain image count: %d\n",
           capabilities.minImageCount,
           capabilities.maxImageCount);

    VkExtent2D swapDim = getCorrectedSwapchainDimensions(
        capabilities, (VkExtent2D){widthHint, heightHint});

    assert(capabilities.minImageCount <= 2);

    swapchain->width  = swapDim.width;
    swapchain->height = swapDim.height;
    swapchain->image_count = 2;
    assert(swapchain->image_count <= MAX_SWAPCHAIN_IMAGES);

    //assert(swapchain->image_count == 2); // for now

    const VkSwapchainCreateInfoKHR ci = {
        .sType                 = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR,
        .surface               = swapchain->surface,
        .minImageCount         = swapchain->image_count,
        .imageFormat           = swapchain->format,
        .imageColorSpace       = VK_COLOR_SPACE_SRGB_NONLINEAR_KHR,
        .imageExtent           = swapDim,
        // number of views in a multiview / stereo surface
        .imageArrayLayers      = 1,
        .imageUsage            = swapchain->image_usage_flags,
        // queue sharing. see
        // vkspec section 11.7.
        .imageSharingMode      = VK_SHARING_MODE_EXCLUSIVE,
        // dont need with exclusive sharing
        .queueFamilyIndexCount = 0,
        // ditto
        .pQueueFamilyIndices   = NULL,
        .preTransform          = capabilities.currentTransform,
        // dunno. may affect blending
        .compositeAlpha        = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR,
        .presentMode           = swapchain->present_mode,
        // allows pixels convered by another window to be
        // clipped. but will mess up saving the swap image.        .clipped =
        // VK_FALSE,

        .oldSwapchain = VK_NULL_HANDLE};

    V_ASSERT(vkCreateSwapchainKHR(swapchain->device, &ci, NULL, &swapchain->swapchain));

    DPRINT("Swapchain created successfully.\n");
}

static void 
createSwapchainOffscreen(OnyxSwapchain* swapchain,
        const uint32_t widthHint, const uint32_t heightHint)
{
    swapchain->width = widthHint;
    swapchain->height = heightHint;
}

static void
create_swapchain_images(OnyxSwapchain* swapchain)
{
    VkImage images[MAX_SWAPCHAIN_IMAGES];
    V_ASSERT(vkGetSwapchainImagesKHR(swapchain->device, swapchain->swapchain, &swapchain->image_count, NULL));
    V_ASSERT(vkGetSwapchainImagesKHR(swapchain->device, swapchain->swapchain, &swapchain->image_count, images));

    for (int i = 0; i < swapchain->image_count; i++)
    {
        VkImage image = images[i];

        VkImageSubresourceRange ssr = {.baseArrayLayer = 0,
                                       .layerCount     = 1,
                                       .baseMipLevel   = 0,
                                       .levelCount     = 1,
                                       .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT};

        VkImageViewCreateInfo image_view_info = {
            .sType            = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
            .subresourceRange = ssr,
            .format           = swapchain->format,
            .viewType         = VK_IMAGE_VIEW_TYPE_2D,
            .image            = image};

        V_ASSERT(vkCreateImageView(swapchain->device, &image_view_info, NULL, swapchain->image_views + i));
        // increment the uuid for this image
        swapchain->image_uuid[i] += MAX_SWAPCHAIN_IMAGES;
    }
    DPRINT("Swapchain framebuffers created successfully.\n");
}

static void 
recreate_swapchain(OnyxSwapchain* swapchain, const uint32_t widthHint,
                  const uint32_t heightHint)
{
    for (int i = 0; i < swapchain->image_count; i++)
    {
        vkDestroyImageView(swapchain->device, swapchain->image_views[i], NULL);
    }
    vkDestroySwapchainKHR(swapchain->device, swapchain->swapchain, NULL);
    create_swapchain_with_surface(
        swapchain, widthHint, heightHint);
    create_swapchain_images(swapchain);
}

void
onyx_swapchain_notify_window_resized(OnyxSwapchain *swapchain, u32 w, u32 h)
{
    swapchain->window_resize_occurred = true;
    swapchain->width = w;
    swapchain->height = h;
}

OnyxSwapchain* onyx_alloc_swapchain(void)
{
    return hell_malloc(sizeof(OnyxSwapchain));
}

void
onyx_create_swapchain(
        VkInstance instance,
        VkDevice device,
        VkPhysicalDevice physical_device,
                   const HellWindow*      hellWindow,
                   VkImageUsageFlags      usageFlags,
                   OnyxSwapchain*         swapchain)
{
    memset(swapchain, 0, sizeof(OnyxSwapchain));
    swapchain->device = device;
    swapchain->physical_device = physical_device;
    swapchain->image_usage_flags = usageFlags;
    swapchain->instance = instance;
    for (int i = 0; i < MAX_SWAPCHAIN_IMAGES; ++i) {
        swapchain->image_uuid[i] = i;
    }
    init_surface(instance, hellWindow, &swapchain->surface);
    swapchain->format = chooseFormat(physical_device, swapchain->surface);
    initSwapchainPresentMode(physical_device, swapchain->surface, swapchain);
    create_swapchain_with_surface(swapchain, hell_get_window_width(hellWindow), hell_get_window_height(hellWindow));
    create_swapchain_images(swapchain);
    for (int i = 0; i < swapchain->image_count; ++i) {
        onyx_create_semaphore(device, swapchain->image_acquired + i);
    }
    onyx_announce("Swapchain initialized.\n");
}

void
onyx_destroy_swapchain(OnyxSwapchain* swapchain)
{
    for (int i = 0; i < swapchain->image_count; i++)
    {
        vkDestroyImageView(swapchain->device, swapchain->image_views[i], NULL);
        onyx_destroy_semaphore(swapchain->device, swapchain->image_acquired[i]);
    }
    vkDestroySwapchainKHR(swapchain->device, swapchain->swapchain, NULL);
    vkDestroySurfaceKHR(swapchain->instance, swapchain->surface, NULL);
    memset(swapchain, 0, sizeof(*swapchain));
    onyx_announce("Swapchain shutdown.\n");
}

VkFormat
onyx_get_swapchain_format(const OnyxSwapchain* swapchain)
{
    return swapchain->format;
}

VkExtent2D
onyx_get_swapchain_extent(const OnyxSwapchain* swapchain)
{
    VkExtent2D ex = {.width = swapchain->width, .height = swapchain->height};
    return ex;
}

VkExtent3D      onyx_get_swapchain_extent3_d(const OnyxSwapchain* swapchain)
{
    VkExtent3D ex = {swapchain->width, swapchain->height, 1};
    return ex;
}

#define WAIT_TIME_NS 500000

OnyxSwapchainImage
onyx_acquire_swapchain_image(This* this)
{
    VkResult r;
retry:
    if (this->window_resize_occurred)
    {
        vkDeviceWaitIdle(this->device);
        recreate_swapchain(this,
            this->width, this->height);
        this->window_resize_occurred = false;
    }

    OnyxSwapchainImage ref = {
        .swapchain = this,
        .semaphore_index = this->next_semaphore_id,
    };
    this->next_semaphore_id = (this->next_semaphore_id + 1) % this->image_count;

    r = vkAcquireNextImageKHR(this->device, this->swapchain, WAIT_TIME_NS,
                              this->image_acquired[ref.semaphore_index], VK_NULL_HANDLE,
                              &ref.index);

    if (VK_ERROR_OUT_OF_DATE_KHR == r)
    {
        vkDeviceWaitIdle(this->device);
        recreate_swapchain(this, this->width, this->height);
        goto retry;
    }
    if (VK_SUBOPTIMAL_KHR == r)
    {
        DPRINT("Suboptimal swapchain\n");
    }
    if (VK_ERROR_DEVICE_LOST == r)
    {
        hell_error(HELL_ERR_FATAL, "Device lost\n");
    }

    this->acquired_image_index = ref.index;
    return ref;
}

int onyx_present_swapchains(VkQueue present_queue, uint32_t swapchain_count,
                            OnyxSwapchain *const *swapchains,
                            uint32_t              wait_semaphore_count,
                            VkSemaphore const    *wait_semas)
{
    uint32_t img_indices[4];
    VkSwapchainKHR vk_swapchains[4];
    VkResult results[4];
    uint64_t present_ids[4];
        //hell_stack_alloc(&alloc, swapchain_count * sizeof(*present_ids));

    for (int i = 0; i < swapchain_count; ++i) {
        vk_swapchains[i] = swapchains[i]->swapchain;
        img_indices[i]   = swapchains[i]->acquired_image_index;
        present_ids[i] = ++swapchains[i]->present_id;
    }

    VkPresentIdKHR present_id_struct = {
        .sType = VK_STRUCTURE_TYPE_PRESENT_ID_KHR,
        .pNext = NULL,
        .swapchainCount = swapchain_count,
        .pPresentIds = present_ids,
    };

    VkPresentInfoKHR info = {
        .sType              = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,
        .pNext              = &present_id_struct,
        .swapchainCount     = swapchain_count,
        .pSwapchains        = vk_swapchains,
        .waitSemaphoreCount = wait_semaphore_count,
        .pWaitSemaphores    = wait_semas,
        // pResults is for per swapchain results
        // we only use one so can put NULL
        .pResults           = results,
        .pImageIndices      = img_indices,
    };

    vkQueuePresentKHR(present_queue, &info);

    for (int i = 0; i < swapchain_count; ++i) {
        if (results[i] < VK_SUCCESS) {
            // this one seems to be ignoreable. happens when we are resizing.
            if (results[i] == VK_ERROR_OUT_OF_DATE_KHR)
                continue;
            fatal_condition(results[i] < VK_SUCCESS,
                            "Error preseinting swapchain %d: %d\n", i,
                            results[i]);
        }
    }

    return 0;
}

void
onyx_free_swapchain(OnyxSwapchain* swapchain)
{
    hell_free(swapchain);
}

unsigned
onyx_get_swapchain_width(const OnyxSwapchain* swapchain)
{
    return swapchain->width;
}

unsigned
onyx_get_swapchain_height(const OnyxSwapchain* swapchain)
{
    return swapchain->height;
}

VkImageView
onyx_get_swapchain_image_view(const OnyxSwapchain* swapchain, int index)
{
    return swapchain->image_views[index];
}

size_t
onyx_size_of_swapchain(void)
{
    return sizeof(OnyxSwapchain);
}

unsigned onyx_get_swapchain_image_count(const OnyxSwapchain* swapchain)
{
    return swapchain->image_count;
}

//const VkImageView* onyx_get_swapchain_image_views(const OnyxSwapchain* swapchain)
//{
//    return swapchain->colorImageViews;
//}
//
//VkImage onyx_get_swapchain_image(const OnyxSwapchain* swapchain, uint32_t index)
//{
//    assert(index < swapchain->imageCount);
//    return swapchain->colorImages[index];
//}

VkDeviceSize onyx_get_swapchain_image_size(const OnyxSwapchain *swapchain)
{
    return swapchain->width * swapchain->height * 4;
}

uint32_t onyx_get_swapchain_pixel_byte_count(const OnyxSwapchain* swapchain)
{
    return 4;
}

int
onyx_swapchain_wait_for_present(OnyxSwapchain* s, int64_t timeout_ns)
{
    if (s->present_id == 0)
        return 0;
    VkResult r = vkWaitForPresentKHR(s->device, s->swapchain, s->present_id, timeout_ns);
    if (r < 0) {
        if (r == VK_ERROR_OUT_OF_DATE_KHR) {
            warning("VK_ERROR_OUT_OF_DATE_KHR\n");
        } else {
            fatal_error("Failed wait for present failed. VkResult: %d\n", r);
        }
    }
    return r;
}
