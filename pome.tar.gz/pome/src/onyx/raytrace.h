#ifndef R_RAYTRACE_H
#define R_RAYTRACE_H

#include "video.h"
#include "render.h"
#include "geo.h"

typedef struct {
    VkAccelerationStructureKHR handle;
    OnyxBuffer        buffer_region;
} OnyxAccelerationStructure;

typedef struct {
    OnyxBuffer             buffer_regions;
    uint32_t                        group_count;
    VkStridedDeviceAddressRegionKHR raygen_table;
    VkStridedDeviceAddressRegionKHR miss_table;
    VkStridedDeviceAddressRegionKHR hit_table;
    VkStridedDeviceAddressRegionKHR callable_table;
} OnyxShaderBindingTable;

void onyx_build_blas(OnyxMemory*, const OnyxGeometry* prim, OnyxAccelerationStructure* blas);
void onyx_build_tlas(OnyxMemory*, const uint32_t count, const OnyxAccelerationStructure blasses[],
        const CoalMat4 xforms[],
        OnyxAccelerationStructure* tlas);
void onyx_create_shader_binding_table(OnyxMemory*, const uint32_t groupCount, const VkPipeline pipeline, OnyxShaderBindingTable* sbt);
void onyx_destroy_acceleration_struct(VkDevice device, OnyxAccelerationStructure* as);
void onyx_destroy_shader_binding_table(OnyxShaderBindingTable* sb);

#endif /* end of include guard: R_RAYTRACE_H */
