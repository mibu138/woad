#ifndef ONYX_GRAPH_H
#define ONYX_GRAPH_H

#include "arraytypes.h"
#include "exportable.h"
#include "geo.h"
#include "memory.h"
#include "onyx/pipeline.h"
#include "swapchain.h"
#include "types.h"
#include <hell/ds.h>
#include <hell/graph.h>

#define MAX_NAME_LEN 32
#define MAX_RESOURCES_PER_GRAPH 32
#define MAX_TASKS_PER_GRAPH 32
#define MAX_SUB_TASKS_PER_GRAPH 128
#define MAX_READS_PER_TASK 8
#define MAX_WRITES_PER_TASK 8

typedef uint32_t OnyxProgramIndex;

typedef int32_t OnyxTaskId;
typedef int32_t OnyxSubTaskId;

typedef struct onyx_resource_id {
    int id;
} OnyxResourceId;

typedef enum {
    ONYX_RESOURCE_TYPE_IMAGE,
    ONYX_RESOURCE_TYPE_BUFFER,
    ONYX_RESOURCE_TYPE_PUSH_CONSTANT,
    ONYX_RESOURCE_TYPE_GEOMETRY
} OnyxResourceType;

typedef struct {
    const OnyxGeometry *ptr;
} OnyxResourceGeo;

typedef struct {
    uint8_t                  target_data[128];
    OnyxPushConstantCallback callback;
} OnyxResourcePushConstant;

typedef struct {
    uint64_t size;
    union {
        const OnyxBuffer *ptr;
        int               index;
    };
} OnyxResourceBuffer;

typedef enum {
    ONYX_IMAGE_UNKNOWN_TYPE,
    ONYX_IMAGE_COLOR_TYPE,
    ONYX_IMAGE_DEPTH_TYPE
} OnyxImageType;

typedef struct {
    OnyxImageType      image_type;
    VkFormat           format;
    uint32_t           width;
    uint32_t           height;
    VkSampleCountFlags samples;
    union {
        const OnyxImage *ptr;
        int              index; // index into graph.images or graph.buffers
    } data;
} OnyxResourceImage;

// a logical resource
typedef struct {
    char             name[MAX_NAME_LEN];
    // bound means this resource has been assigned a physical resource
    bool bound;
    // 0 means app or swapchain owns the image and we refer to if through ptr
    bool graph_owned;
    OnyxResourceType type;
    union {
        OnyxResourceBuffer       buffer;
        OnyxResourceImage        image;
        OnyxResourceGeo          geo;
        OnyxResourcePushConstant pc;
    } rs;
} OnyxResource;

typedef enum {
    ONYX_RESOURCE_REFERENCE_TYPE_PUSH_CONSTANT,
    ONYX_RESOURCE_REFERENCE_TYPE_TRANSFER_TARGET,
    ONYX_RESOURCE_REFERENCE_TYPE_UNIFORM_BUFFER,
    ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_BUFFER,
    ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_IMAGE,
    ONYX_RESOURCE_REFERENCE_TYPE_PRESENT_IMAGE,
    ONYX_RESOURCE_REFERENCE_TYPE_TEXTURE,
    ONYX_RESOURCE_REFERENCE_TYPE_COLOR_ATTACHMENT,
    ONYX_RESOURCE_REFERENCE_TYPE_DEPTH_ATTACHMENT,
    ONYX_RESOURCE_REFERENCE_TYPE_RESOLVE_ATTACHMENT,
    ONYX_RESOURCE_REFERENCE_TYPE_INPUT_ATTACHMENT,
    ONYX_RESOURCE_REFERENCE_TYPE_GEOMETRY,
    ONYX_RESOURCE_REFERENCE_TYPE_VERTEX_BUFFER,
    ONYX_RESOURCE_REFERENCE_TYPE_INDEX_BUFFER,
    ONYX_RESOURCE_REFERENCE_TYPE_TOP_OF_PIPE,
    ONYX_RESOURCE_REFERENCE_TYPE_OUTPUT,
} OnyxResourceReferenceType;

typedef enum {
    ONYX_ATTACHMENT_LOAD_OP_DONT_CARE,
    ONYX_ATTACHMENT_LOAD_OP_LOAD,
    ONYX_ATTACHMENT_LOAD_OP_CLEAR,
} OnyxLoadOp;

typedef enum OnyxAttachmentType {
    ONYX_ATTACHMENT_COLOR_TYPE,
    ONYX_ATTACHMENT_DEPTH_TYPE,
    ONYX_ATTACHMENT_INPUT_TYPE,
    ONYX_ATTACHMENT_RESOLVE_TYPE,
} OnyxAttachmentType;

typedef struct {
    OnyxLoadOp         load_op;
    bool               store;
    VkClearValue       clear_val;
    OnyxAttachmentType type;
    union {
        // both color and depth MUST have ref as their first members
        OnyxAttachmentReference        ref;
        OnyxColorAttachmentReference   color;
        OnyxDepthAttachmentReference   depth;
        OnyxResolveAttachmentReference resolve;
    };
} OnyxAttachmentReferenceInfo;

typedef struct {
    // index into the graph's array of descriptor sets
    int index;
    int binding;
    // images used as descriptors 
    VkImageAspectFlags image_aspect;
} OnyxDescriptorReferenceInfo;

typedef struct {
    // will pass the id to the push constant callback
    int                size;
    int64_t            user_id;
    VkShaderStageFlags shader_stages;
} OnyxPushConstantReferenceInfo;

typedef struct {
    VkImageLayout img_layout;
} OnyxOutputReferenceInfo;

typedef struct {
    int32_t binding;
} OnyxVertexBufferReferenceInfo;

typedef struct {
    VkIndexType type;
} OnyxIndexBufferReferenceInfo;

#define ONYX_RESOURCE_USAGE_READ_WRITE_BITS                                    \
    (ONYX_RESOURCE_USAGE_READ_BIT | ONYX_RESOURCE_USAGE_WRITE_BIT)

typedef union {
    OnyxAttachmentReferenceInfo   attachment;
    OnyxDescriptorReferenceInfo   descriptor;
    OnyxVertexBufferReferenceInfo vertexbuffer;
    OnyxIndexBufferReferenceInfo  indexbuffer;
    OnyxPushConstantReferenceInfo pushconstant;
    OnyxOutputReferenceInfo       output;
} OnyxResourceReferenceInfo;

typedef struct {
    int                       rid;
    OnyxResourceReferenceType type;
    OnyxResourceUsageFlags    usage_flags;
    OnyxResourceReferenceInfo info;
} OnyxResourceReference;

define_array_type(OnyxResourceReference, onyx_res_ref);

typedef enum {
    ONYX_TASK_TYPE_RASTERIZE,
    ONYX_TASK_TYPE_COMPUTE,
    // copies from host memory to host memory
    // usually to update a ubo or push constant
    ONYX_TASK_TYPE_COPY,
    ONYX_TASK_TYPE_CUSTOM_RENDERPASS,
    ONYX_TASK_TYPE_CUSTOM,
    ONYX_TASK_TYPE_PRESENT,
    ONYX_TASK_TYPE_BARRIER,
    ONYX_TASK_TYPE_NULL,
    ONYX_TASK_TYPE_TOP_OF_PIPE
} OnyxTaskType;

typedef struct {
    int       pipeline;
    CoalIvec3 wg_sizes;
} OnyxTaskCompute;

typedef struct {
    int renderpass;
    // these could be the same
    int framebuffer;
    int attachment_count;
} OnyxTaskRenderPassHeader;

typedef enum {
    ONYX_GRAPH_DRAW_GEOMETRY_TYPE,
    ONYX_GRAPH_DRAW_BUFFER_TYPE,
} OnyxGraphDrawType;

typedef struct {
    OnyxGraphDrawType type;
    int32_t           rids[8];
} OnyxGraphDrawCall;

#define MAX_DRAW_CALLS 64

typedef struct {
    OnyxTaskRenderPassHeader head;
    int                      pipeline_settings_index;
    OnyxGeometryTemplate     geo_template;
    int                      pipeline;
    int                      vertex_shader_subtask_id;
    // TODO move this into an allocation object so that this type is not so fat
    int                      draw_count;
    int                      draw_to_subtask_map[MAX_DRAW_CALLS];
    uint32_t                 draw_elem_count[MAX_DRAW_CALLS]; // vertex or ind
    uint32_t                 draw_instance_count[MAX_DRAW_CALLS];
} OnyxTaskRasterize;

typedef struct {
    int src;
    int dst;
    // this only apply to buffer/image copies
    VkImageAspectFlags img_aspect;
} OnyxTaskCopy;

typedef struct {
    int image;
} OnyxTaskPresent;

typedef struct {
    OnyxSyncScope src;
    OnyxSyncScope dst;
    VkImageLayout old_layout;
    VkImageLayout new_layout;
    int           rid;
} OnyxTaskBarrier;

typedef struct {
    int                        tid;
    VkPipelineStageFlags       stage;
    OnyxResourceReferenceArray refs;
} OnyxSubTask;

typedef struct {
    OnyxTaskRenderPassHeader head;
    void                    *data;
    void (*fn)(VkCommandBuffer cb, void *data);
} OnyxTaskCustom;

define_array_type(OnyxSubTask, onyx_sub_task);

struct OnyxGraph;

typedef struct onyx_task {
    OnyxTaskType          type;
    struct OnyxGraph    *graph;
    OnyxProgramReflection reflection;
    IntArray              sub_tasks;
    union {
        // allows us to set the common members of different types
        // that use renderpass members
        OnyxTaskRenderPassHeader renderpass;
        OnyxTaskCopy             copy;
        OnyxTaskRasterize        rasterize;
        OnyxTaskCompute          compute;
        OnyxTaskCustom           custom;
        OnyxTaskBarrier          barrier;
    } ts;
} OnyxTask;

#define ONYX_MAX_PIPELINES_PER_GRAPH 32
#define ONYX_MAX_GEOMETRY_TEMPLATES_PER_GRAPH 32
#define ONYX_MAX_RENDERPASSES_PER_GRAPH 16

typedef struct {
    VkDescriptorPool      descriptor_pool;
    VkDescriptorSetLayout descriptor_set_layouts[ONYX_MAX_DESCRIPTOR_SETS];
    // we have a list of descriptor sets for each frame to allow for easier
    // double buffering
    VkDescriptorSet       descriptor_sets[ONYX_MAX_DESCRIPTOR_SETS];
    VkPipelineLayout      pipeline_layouts[ONYX_MAX_PIPELINE_LAYOUTS];
    VkShaderModule        shader_modules[ONYX_MAX_SHADERS];
    VkPipeline            pipelines[ONYX_MAX_PIPELINES_PER_GRAPH];
} VulkanHandles;

typedef struct onyx_frame_data {
    OnyxCommandPool cmdpool;
    VkFence         cmds_cmplt_fence;
    VkSemaphore     img_acquired_sem;
    VkSemaphore     cmds_cmplt_sem;
    int             cur_cmd_buf;
} OnyxFrameData;

typedef struct {
    int              attachment_index;
    const OnyxImage *img;
} OnyxAttachmentBinding;

typedef struct onyx_framebuffer {
    u32                   width;
    u32                   height;
    u32                   attachment_count;
    OnyxAttachmentBinding attachments[8];
    const OnyxRenderPass *rp;
    VkFramebuffer         handle;
} OnyxFramebuffer;

define_array_type(OnyxImage, onyx_image);
define_array_type(OnyxBuffer, onyx_buffer);
define_array_type(OnyxRenderPass, onyx_render_pass);
define_array_type(OnyxFramebuffer, onyx_framebuffer);

typedef struct {
    void (*callback)(struct OnyxGraph *g, void *data);
    void *data;
} OnyxBakeCallback;

union onyx_descriptor_info {
    VkDescriptorBufferInfo buf;
    VkDescriptorImageInfo  img;
};

typedef struct {
    union onyx_descriptor_info descriptors[ONYX_MAX_DESCRIPTOR_SETS]
                                          [ONYX_MAX_DESCRIPTORS_PER_SET];
} OnyxDescriptorWriteCache;

typedef void *HeapPointer;

define_array_type(HeapPointer, heap_ptr);

struct OnyxGraph {
    struct onyx          *onyx;
    int                   rsrc_count;
    OnyxResource          rsrcs[MAX_RESOURCES_PER_GRAPH];
    int                   task_count;
    OnyxTask              tasks[MAX_TASKS_PER_GRAPH];
    int                   sub_task_count;
    OnyxSubTask           sub_tasks[MAX_SUB_TASKS_PER_GRAPH];
    char                 *task_names[MAX_TASKS_PER_GRAPH];
    const OnyxPipedes    *pipedes;
    const OnyxReflection *reflection;
    VulkanHandles         vkdes;
    VkDevice              device;

    int pipeline_settings_count;
    // eventually this eventually with a OnyxPipeline type
    OnyxGraphicsPipelineSettings
        pipeline_settings[ONYX_MAX_PIPELINES_PER_GRAPH];

    int                  geometry_template_count;
    OnyxGeometryTemplate geo_templates[ONYX_MAX_GEOMETRY_TEMPLATES_PER_GRAPH];

    int                  final_sub_task;
    HellGraph            graph;
    OnyxImageArray       images;
    OnyxBufferArray      buffers;
    OnyxRenderPassArray  renderpasses;
    // make an actually useful pipeline type (that stores everything we need to
    // know about a pipeline to create it)
    // OnyxPipelineArray   pipelines;
    int                  pipeline_count;
    OnyxFramebufferArray framebuffers;

    OnyxBakeCallback         bake_callbacks[8];
    int                      bake_callback_count;
    // need to free all these on graph termination
    HeapPointerArray         need_to_free_list;
    OnyxDescriptorWriteCache descriptor_write_cache;
    bool                     baked;
    // we can compare this against a specific value to know whether or not the
    // graph has been initialized.
    uint64_t                 initialized_marker;
};

typedef struct {
    OnyxProgramIndex                    program;
    const OnyxGraphicsPipelineSettings *pipeline_settings;
    // we need to pass this because we cannot correctly infer binding order from
    // the shader - this seems to get stripped away one the pass from glsl ->
    // spirv
    OnyxGeometryTemplate                geometry_template;
} OnyxGraphRasterizationParms;

typedef enum OnyxComputeWorkGroupSizeType {
    ONYX_COMPUTE_WORKGROUP_SIZE_TYPE_STATIC,
    ONYX_COMPUTE_WORKGROUP_SIZE_TYPE_FROM_IMAGE,
    ONYX_COMPUTE_WORKGROUP_SIZE_TYPE_DYNAMIC, // will copy wg sizes from app
                                              // each frame
} OnyxComputeWorkGroupSizeType;

typedef struct {
    OnyxProgramIndex             program;
    OnyxComputeWorkGroupSizeType wg_size_type;
    union {
        CoalIvec3   size;
        const char *image_name;
    } wg_size;
} OnyxGraphComputeParms;

typedef struct {
    OnyxAttachmentReferenceInfo ref;
} OnyxResourceAttachmentParms;

typedef struct {
    VkPipelineStageFlags      stages;
    OnyxResourceReferenceType ref_type;
    OnyxResourceUsageFlags    res_usage;
} OnyxGraphResourceImageParms;

typedef struct {
    VkPipelineStageFlags stages;
    void                *data;
    void (*fn)(VkCommandBuffer, void *);
} OnyxGraphCustomTaskParms;

typedef union onyx_graph_binding_data {
    const OnyxImage         *img;
    const OnyxBuffer        *buffer;
    const OnyxGeometry      *geo;
    OnyxPushConstantCallback pc;
} OnyxGraphBindingData;

typedef struct onyx_graph_binding {
    const char          *name;
    OnyxGraphBindingData src;
} OnyxGraphBinding;

typedef struct onyx_graph_execute_args {
    int32_t                 binding_count;
    const OnyxGraphBinding *bindings;
} OnyxGraphExecuteArgs;

// it should be possible for reflection to have empty entries
void onyx_init_graph(Onyx *ctx, const OnyxReflection *reflection,
                     OnyxGraph *graph);

void onyx_term_graph(OnyxGraph *graph);

OnyxTaskId onyx_graph_add_rasterization_task(OnyxGraph *graph, const char *name,
                                             OnyxGraphRasterizationParms parms);

OnyxGeometryTemplate onyx_graph_get_geo_template_from_task(OnyxGraph *graph,
                                                           OnyxTaskId task);

OnyxTaskId onyx_graph_add_compute_task(OnyxGraph *graph, const char *name,
                                       OnyxGraphComputeParms parms);

int32_t onyx_graph_add_draw_call_to_task(OnyxGraph *g, OnyxTaskId tid,
                                         uint32_t elem_count,
                                         uint32_t instance_count);

// task should be a render pass (for now)
void onyx_graph_add_geometry_to_task(OnyxGraph *g, OnyxTaskId tid,
                                     const char *name, int32_t draw_call_id);

void onyx_graph_add_push_constant_to_task(OnyxGraph *g, OnyxTaskId tid,
                                          const char           *name,
                                          OnyxPushConstantParms pc_parms);

void onyx_graph_add_uniform_buffer_to_task(OnyxGraph *g, OnyxTaskId tid,
                                           const char *name, int set,
                                           int binding);

void onyx_graph_add_descriptor_to_task(OnyxGraph *g, OnyxTaskId tid,
                                       const char *name, int set, int binding,
                                       OnyxResourceType type);

void onyx_graph_add_image_descriptor_to_task(OnyxGraph *g, OnyxTaskId tid,
                                          const char *name, int set,
                                          int binding, VkImageAspectFlags aspect);

void onyx_graph_add_color_attachment_output_to_task(
    OnyxGraph *g, OnyxTaskId tid, const char *name,
    OnyxResourceAttachmentParms parms);

void onyx_graph_add_depth_attachment_to_task(OnyxGraph *g, OnyxTaskId tid,
                                             const char                 *name,
                                             OnyxResourceAttachmentParms parms);

void onyx_graph_add_attachment_to_task(OnyxGraph *g, OnyxTaskId tid,
                                       const char                 *name,
                                       OnyxResourceAttachmentParms parms);

void onyx_graph_add_resolve_attachment_to_task(
    OnyxGraph *g, OnyxTaskId tid, const char *name,
    OnyxResourceAttachmentParms parms);

void onyx_graph_set_resource_ownership(OnyxGraph *g, const char *name,
                                       bool graph_owned);

void onyx_graph_set_image_size(OnyxGraph *g, const char *name, uint32_t width,
                               uint32_t height);

void onyx_graph_add_image_output(OnyxGraph *g, const char *name,
                                 VkImageLayout layout);

void onyx_graph_add_buffer_output(OnyxGraph *g, const char *name);

void onyx_graph_set_image_properties(OnyxGraph *g, const char *name,
                                     OnyxImageType type, uint32_t width,
                                     uint32_t height, OnyxFormat format,
                                     VkSampleCountFlags samples,
                                     bool               graph_owned);

void onyx_graph_set_buffer_properties(OnyxGraph *g, const char *name,
                                      uint64_t size, bool graph_owned);

void onyx_graph_add_task_dependency(OnyxGraph *g, OnyxTaskId task,
                                    OnyxTaskId input);

OnyxTaskId onyx_graph_add_custom_task(OnyxGraph *g, const char *name,
                                      OnyxGraphCustomTaskParms parms);

OnyxTaskId
onyx_graph_add_custom_renderpass_task(OnyxGraph *g, const char *name,
                                      OnyxGraphCustomTaskParms parms);

OnyxTaskId onyx_graph_add_image_copy_task(OnyxGraph *g, const char *name,
                                          const char *src, const char *dst);

OnyxTaskId onyx_graph_add_copy_task(OnyxGraph *g, const char *name,
                                    const char *src, OnyxResourceType src_type,
                                    const char *dst, OnyxResourceType dst_type);

OnyxTaskId onyx_graph_add_copy_task_(OnyxGraph *g, const char *name,
                                    const char *src, OnyxResourceType src_type,
                                    const char *dst, OnyxResourceType dst_type,
                                    VkImageAspectFlags image_aspect
                                    );

void onyx_graph_add_image_to_task(OnyxGraph *g, OnyxTaskId task,
                                  const char *name,
                                  OnyxGraphResourceImageParms);

const OnyxRenderPass *onyx_graph_get_task_renderpass(const OnyxGraph *g,
                                                     OnyxTaskId       task_id);

void onyx_graph_bake(OnyxGraph *g);

// cb must be in recording state
void onyx_graph_execute(OnyxGraph *g, VkCommandBuffer cb,
                        const OnyxGraphExecuteArgs *args);

// runs callback after bake
void onyx_graph_add_bake_callback(OnyxGraph *g, OnyxBakeCallback cb);

OnyxTaskId onyx_graph_get_last_task(OnyxGraph *g);

const char *onyx_graph_get_output_image(const OnyxGraph *g);

void onyx_graph_add_present_task(OnyxGraph *g);

bool onyx_graph_is_baked(OnyxGraph *g);

void onyx_graph_update_draw_call(OnyxGraph *g, OnyxTaskId task,
                                 int32_t draw_call, uint32_t elem_count,
                                 uint32_t instance_count);

OnyxGeometryTemplate
onyx_graph_geo_template_from_program(const OnyxGraph *g, OnyxProgramIndex index,
                                     OnyxGeometryFlags geo_flags,
                                     OnyxGeometryType  geo_type);

#endif // onyx graph
