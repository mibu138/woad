#ifndef ONYX_LOCATIONS_H
#define ONYX_LOCATIONS_H

#define ONYX_MAX_PATH_LEN 512

const char* onyx_get_onyx_root(void);

#endif /* end of include guard: ONYX_LOCATIONS_H */
