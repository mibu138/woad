#ifndef ONYX_R_RENDERPASS_H
#define ONYX_R_RENDERPASS_H

#include "types.h"
#include <hell/len.h>
#include "image.h"

// Maps to VkAttachmentReference
typedef struct {
    int framebuffer_index;
    VkImageLayout layout;
} OnyxAttachmentReference;

typedef struct OnyxColorAttachmentReference {
    OnyxAttachmentReference ref;
    int shader_location;
    bool blend_enabled;
    bool has_resolve;
    int resolve_index;
    OnyxBlendMode blend_mode;
} OnyxColorAttachmentReference;

typedef struct OnyxDepthAttachmentReference {
    OnyxAttachmentReference ref;
    // other depth attachment options here
} OnyxDepthAttachmentReference;

typedef struct OnyxResolveAttachmentReference {
    OnyxAttachmentReference ref;
    // other depth attachment options here
} OnyxResolveAttachmentReference;

typedef struct OnyxRenderPassDependencyInfo {
    OnyxSyncScope src;
    OnyxSyncScope dst;
} OnyxRenderPassDependencyInfo;

typedef struct OnyxSubpass {
    int color_attachment_count;
    int resolve_attachment_count;
    bool has_depth;
    OnyxColorAttachmentReference    color_attachments[8];
    OnyxResolveAttachmentReference  resolve_attachments[8];
    OnyxDepthAttachmentReference    depth_attachment;
    OnyxSyncScope                   scope;
} OnyxSubpass;

void onyx_subpass_create(
        // will copy
        const OnyxRasterizationReflection*,
        int color_attachment_count,
        // will get copied into subpass object
        const OnyxColorAttachmentReference *color_attachments,
        // can be null
        const OnyxDepthAttachmentReference *depth_attachment,
        OnyxSyncScope scope,
        OnyxSubpass *subpass);

static inline int onyx_subpass_get_color_attachment_count(const OnyxSubpass *sp)
{
    return sp->color_attachment_count;
}

typedef struct OnyxAttachment {
    OnyxImageTemplate image_template;
    VkImageLayout initial_layout;
    VkImageLayout final_layout;
    VkAttachmentLoadOp load_op;
    VkAttachmentStoreOp store_op;
} OnyxAttachment;

define_array_type(OnyxAttachment, attachment);

typedef struct OnyxRenderPass {
    int attachment_count;
    OnyxAttachment attachments[8];
    int subpass_count;
    OnyxSubpass subpasses[8];
    OnyxRenderPassDependencyInfo dep_info;
    VkRenderPass vkhandle;
} OnyxRenderPass;

void onyx_render_pass_create(
        const int attachment_count,
        const OnyxAttachment *attachments,
        const int subpass_count,
        const OnyxSubpass *subpasses,
        const OnyxRenderPassDependencyInfo dep_info,
        OnyxRenderPass *rp);

VkRenderPass onyx_render_pass_create_vk(const OnyxRenderPass* rp, VkDevice dev);

void onyx_create_render_pass_color(VkDevice, const VkImageLayout initialLayout, 
        const VkImageLayout finalLayout,
        const VkAttachmentLoadOp loadOp, 
        const VkFormat colorFormat,
        VkRenderPass* pRenderPass);
void onyx_create_render_pass_color_(VkDevice, const VkImageLayout initialLayout, 
        const VkImageLayout finalLayout,
        const VkAttachmentLoadOp loadOp, 
        const VkFormat colorFormat,
        const OnyxRenderPassDependencyInfo depInfo,
        VkRenderPass* pRenderPass);
void onyx_create_render_pass_color_depth(VkDevice, 
        const VkImageLayout colorInitialLayout, const VkImageLayout colorFinalLayout,
        const VkImageLayout depthInitialLayout, const VkImageLayout depthFinalLayout,
        const VkAttachmentLoadOp  colorLoadOp, const VkAttachmentStoreOp colorStoreOp,
        const VkAttachmentLoadOp  depthLoadOp, const VkAttachmentStoreOp depthStoreOp,
        const VkFormat colorFormat,
        const VkFormat depthFormat,
        VkRenderPass* pRenderPass);

void onyx_create_render_pass_color_depth_m_s_a_a(VkDevice, const VkSampleCountFlags sampleCount, const VkAttachmentLoadOp loadOp, 
        const VkImageLayout initialLayout, const VkImageLayout finalLayout,
        const VkFormat colorFormat,
        const VkFormat depthFormat,
        VkRenderPass* pRenderPass);

#endif /* end of include guard: ONYX_R_RENDERPASS_H */
