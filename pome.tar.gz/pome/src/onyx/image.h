#ifndef ONYX_V_IMAGE_H
#define ONYX_V_IMAGE_H

/*
 * Utility functions for Onyx Images
 */

#include "memory.h"
#include "command.h"


typedef enum {
    ONYX_V_IMAGE_FILE_TYPE_PNG,
    ONYX_V_IMAGE_FILE_TYPE_JPG
} OnyxV_ImageFileType;

typedef struct OnyxImageTemplate {
    VkFormat format;
    VkSampleCountFlags sample_count;
} OnyxImageTemplate;

OnyxImage onyx_create_image_and_sampler(
    OnyxMemory* memory,
    const uint32_t width, 
    const uint32_t height,
    const VkFormat format,
    VkImageUsageFlags extraUsageFlags,
    const VkImageAspectFlags aspectMask,
    const VkSampleCountFlags sampleCount,
    const uint32_t mipLevels,
    const VkFilter filter,
    const OnyxMemoryType memType);

static inline OnyxImageTemplate onyx_image_get_template(const OnyxImage* img)
{
    OnyxImageTemplate t = {
        img->format,
        img->sample_count,
    };
    return t;
}

void onyx_transition_image_layout(const VkImageLayout oldLayout, const VkImageLayout newLayout, OnyxImage* image);

void onyx_copy_buffer_to_image(const OnyxBuffer* region,
        OnyxImage* image);

void onyx_cmd_copy_image_to_buffer(VkCommandBuffer cmdbuf, uint32_t miplevel, VkImageAspectFlags aspect_mask,
                          const OnyxImage* image, OnyxBuffer* region);

bool 
onyx_images_copy_compatible(const OnyxImage*, const OnyxImage*);

void
onyx_cmd_copy_image_full(VkCommandBuffer cmdbuf, uint32_t miplevel,
                          const OnyxImage* src, OnyxImage* dst);

bool 
onyx_images_blit_compatible(const OnyxImage*, const OnyxImage*);


// will copy if it can, otherwise will blit
void 
onyx_cmd_copy_or_blit_image_full(VkCommandBuffer cb, const OnyxImage *src,
                                       OnyxImage *dst, VkFilter filter);

void
onyx_cmd_blit_image_full(VkCommandBuffer cmdbuf, uint32_t src_mip_level, uint32_t dst_mip_level,
                          const OnyxImage* src, OnyxImage* dst, VkFilter filter);

VkImageBlit onyx_image_blit_simple_color(uint32_t srcWidth, uint32_t srcHeight, uint32_t dstWidth, uint32_t dstHeight, 
        uint32_t srcMipLevel, uint32_t dstMipLevel);

void onyx_cmd_copy_buffer_to_image(const VkCommandBuffer cmdbuf, uint32_t mipLevel, const OnyxBuffer* region,
        OnyxImage* image);

void onyx_cmd_transition_image_layout(const VkCommandBuffer cmdbuf, const OnyxBarrierScopes barrier, 
        const VkImageLayout oldLayout, const VkImageLayout newLayout, const uint32_t mipLevels, VkImage image);

void onyx_cmd_image_memory_barrier(const VkCommandBuffer cmdbuf, uint32_t count, const OnyxImageBarrierScopes* scopes, 
        OnyxImage* images);

// Does not check for existence of file at filepath.
// all images created on the graphic queue. for now.
// extraUsageFlags are additional usage flags that will be set on 
// top of the ones that are needed such as TRANSFER_DST and 
// TRANSFER_SRC if mip maps are needed. No harm in over specifying.
void onyx_load_image(OnyxMemory* memory, const char* filepath, const uint8_t channelCount, const VkFormat format,
    VkImageUsageFlags extraUsageFlags,
    const VkImageAspectFlags aspectMask,
    const VkSampleCountFlags sampleCount,
    const VkFilter filter,
    const VkImageLayout layout,
    const bool createMips,
    OnyxMemoryType memoryType,
    OnyxImage* image);

void onyx_load_image_data(OnyxMemory* memory, int w, int h, uint8_t channelCount, void* data, const VkFormat format,
    VkImageUsageFlags usageFlags,
    const VkImageAspectFlags aspectMask,
    const VkSampleCountFlags sampleCount,
    const VkFilter filter,
    const VkImageLayout layout,
    const bool createMips,
    OnyxMemoryType memoryType,
    OnyxImage* image);

int
onyx_write_image_to_png_buf(OnyxImage* img,
                            VkImageLayout layout,
                            uint8_t** png_buf,
                            int* png_buf_size);

int 
onyx_copy_png_buf_to_image(const uint8_t* png_buf,
                            const int png_buf_size,
                            OnyxMemory* memory,
                            VkImageLayout layout,
                            OnyxImage* img);

int onyx_copy_image_to_buffer(OnyxImage* image,
                              VkImageLayout orig_layout,
                              OnyxBuffer* region);


void onyx_save_image(OnyxMemory* memory, OnyxImage* image, OnyxV_ImageFileType fileType, VkImageLayout image_layout, 
        const char* filename);

void onyx_v_ClearColorImage(OnyxImage* image);

VkImageSubresourceRange onyx_get_image_subresource_range(const OnyxImage* img);

VkImageCopy
onyx_image_copy_simple_color(uint32_t width, uint32_t height, uint32_t srcOffsetX,
                          uint32_t srcOffsetY, uint32_t srcMipLevel,
                          uint32_t dstOffsetX, uint32_t dstOffsetY,
                          uint32_t dstMipLevel);

uint32_t onyx_calc_mip_levels_for_image(uint32_t width, uint32_t height);


#endif /* end of include guard: ONYX_V_IMAGE_H */
