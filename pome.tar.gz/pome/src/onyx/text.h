 #ifndef ONYX_TEXT_H
 #define ONYX_TEXT_H

#include "image.h"

void onyx_t_UpdateTextImage(OnyxMemory* memory, const size_t x, const size_t y, const char* text, OnyxImage* image);
OnyxImage onyx_t_CreateTextImage(OnyxMemory* memory, const size_t width, const size_t height, 
        const size_t x, const size_t y,
        const size_t fontSize, const char* text);
 
 #endif /* end of include guard: ONYX_TEXT_H */
