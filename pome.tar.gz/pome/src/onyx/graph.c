#include "common.h"
#include "graph.h"
#include "image.h"
#include "memory.h"
#include <hell/attributes.h>
#include <hell/ds.h>
#include <hell/graph.h>
#include <hell/io.h>
#include <hell/stb_ds.h>

#define DEPTH_FORMAT VK_FORMAT_D32_SFLOAT

static const int64_t INITIALIZED     = 0xcafebabe;
static const char   *FINAL_TASK_NAME = "_final_task";

typedef struct {
} OnyxGraphBakeResults;

typedef struct OnyxGraphCopyParms {
    const char      *src_name;
    OnyxResourceType src_type;
    const char      *dst_name;
    OnyxResourceType dst_type;
} OnyxGraphCopyParms;

typedef struct {
    int        count;
    const int *ids;
} Filter;

typedef OnyxGraph Graph;

static IntArray sort_tasks(Graph *g);
static IntArray sort_sub_tasks(Graph *g);

typedef OnyxGraphCopyParms CopyParms;

typedef OnyxGraphComputeParms ComputeParms;

typedef OnyxResource Resource;

typedef OnyxResourceReferenceInfo ResRefInfo;

static const OnyxGeometry *get_geometry(const Graph *g, int rid);
static const OnyxBuffer   *get_buffer(const Graph *g, int rid);
static const OnyxImage    *get_image(const Graph *g, int rid);

static bool resource_bound(const Resource *r) { return r->bound; }

typedef OnyxFrameData FrameData;

typedef struct frame_data_parms {
    int           bufcount;
    OnyxQueueType queuetype;
} FrameDataParms;

typedef OnyxTaskId                 TaskId;
typedef OnyxResourceId             ResId;
typedef OnyxResourceReference      ResRef;
typedef OnyxResourceReferenceArray ResRefArray;

typedef OnyxTask   Task;
static const char *task_name(const Task *t);
static void task_add_descriptor(Task *t, const int rid, int set, int binding, VkImageAspectFlags image_aspect);
static bool task_is_renderpass_type(const Task *t);
// return NULL if does not exist
static const ResRef *task_get_push_constant_ref(const Task *t);

typedef struct {
    char buf[64];
} NameBuffer;

typedef OnyxSubTask SubTask;

static NameBuffer sub_task_name(const Graph *g, int stid);

static const OnyxResourceReference *sub_task_get_res_ref(const SubTask *st,
                                                         int            rid);

typedef struct {
    int             stid;
    const SubTask  *st;
    const ResRef   *ref;
    const Resource *res;
} AttachmentInfo;

define_array_type(AttachmentInfo, attachment_info);

static const int R_BIT = (ONYX_RESOURCE_USAGE_READ_BIT);
static const int W_BIT = (ONYX_RESOURCE_USAGE_WRITE_BIT);
// static const int RW_BITS = (ONYX_RESOURCE_USAGE_READ_BIT |
// ONYX_RESOURCE_USAGE_WRITE_BIT);

static bool res_ref_read_only(const ResRef *r)
{
    return r->usage_flags == R_BIT;
}

static bool res_ref_reads(const ResRef *r) { return r->usage_flags & R_BIT; }

static bool res_ref_writes(const ResRef *r) { return r->usage_flags & W_BIT; }

static bool res_ref_write_only(const ResRef *r)
{
    return r->usage_flags == W_BIT;
}

#define handle_index(handle) (int64_t)(handle)

static const int NONE      = -1;
static const int NOT_FOUND = NONE;

NODISCARD
static Task *get_task_(Graph *g, int id)
{
    assert(id < MAX_TASKS_PER_GRAPH && id >= 0);
    assert(id < g->task_count);
    return g->tasks + id;
}

NODISCARD
static SubTask *get_sub_task(Graph *g, int id)
{
    assert(id < MAX_SUB_TASKS_PER_GRAPH && id >= 0);
    assert(id < g->sub_task_count);
    return &g->sub_tasks[id];
}

NODISCARD
static const SubTask *get_sub_task_const(const Graph *g, int id)
{
    assert(id < MAX_SUB_TASKS_PER_GRAPH && id >= 0);
    assert(id < g->sub_task_count);
    return &g->sub_tasks[id];
}

NODISCARD
static const Task *get_task_const_(const Graph *g, int id)
{
    assert(id < MAX_TASKS_PER_GRAPH && id >= 0);
    return g->tasks + id;
}

NODISCARD
static Resource *get_res_(Graph *g, int id)
{
    assert(id < MAX_TASKS_PER_GRAPH && id >= 0);
    return g->rsrcs + id;
}

NODISCARD
static const Resource *get_res_const_(const Graph *g, int id)
{
    assert(id < MAX_TASKS_PER_GRAPH && id >= 0);
    return g->rsrcs + id;
}

NODISCARD
static Task *get_task(Graph *g, TaskId i) { return get_task_(g, i); }

NODISCARD
static Resource *get_res(Graph *g, ResId i) { return get_res_(g, i.id); }

static Task *get_final_task(Graph *g)
{
    // final task is the first one.
    Task *t = g->tasks;
    assert(strcmp(task_name(t), FINAL_TASK_NAME) == 0);
    return t;
}

static int find_resource(Graph *fg, const char *name)
{
    const int n = fg->rsrc_count;
    for (int i = 0; i < n; ++i) {
        const Resource *res = fg->rsrcs + i;
        if (strcmp(res->name, name) == 0)
            return i;
    }
    return NOT_FOUND;
}

static const OnyxFramebuffer *task_get_framebuffer(const Task *t)
{
    assert(task_is_renderpass_type(t));
    return &t->graph->framebuffers.elems[t->ts.rasterize.head.framebuffer];
}

static const OnyxRenderPass *task_get_renderpass(const Task *t)
{
    assert(task_is_renderpass_type(t));
    assert(t->ts.renderpass.renderpass != NOT_FOUND);
    return &t->graph->renderpasses.elems[t->ts.renderpass.renderpass];
}

static void *graph_alloc(OnyxGraph *g, size_t nbytes)
{
    HeapPointer *ptr = malloc(nbytes);
    heap_ptr_arr_push(&g->need_to_free_list, ptr);
    return ptr;
}

static AttachmentInfo get_attachment_info(const Graph *g, const int stid);

static AttachmentInfoArray task_get_attachment_infos(const Task *t);

static int add_resource(Graph *fg, const char *name, OnyxResourceType type)
{
#ifndef NDEBUG
    // ensure name is unique
    for (int i = 0; i < fg->rsrc_count; ++i) {
        const char *other_name = get_res_const_(fg, i)->name;
        assert(strcmp(other_name, name));
    }
#endif
    const int n = strlen(name);
    assert(n < MAX_NAME_LEN);

    Resource *r = fg->rsrcs + fg->rsrc_count;
    zero(r);

    memcpy(r->name, name, n);
    r->type = type;

    return fg->rsrc_count++;
}

static int find_or_add_resource(Graph *fg, const char *name,
                                OnyxResourceType type)
{
    int s_id = find_resource(fg, name);
    if (s_id == NOT_FOUND)
        return add_resource(fg, name, type);
    Resource *r = get_res_(fg, s_id);
    if (r->type != type)
        fatal_error("adding %s. Resources of different types currently cannot "
                    "share a name.",
                    name);
    return s_id;
}

static OnyxGeometryTemplate
geo_templ_from_renderpass_refl(const OnyxRasterizationReflection *refl)
{
    OnyxGeometryTemplate temp =
        onyx_geo_template_create_base(refl->vertex_input_count, false);
    temp.attribute_count = refl->vertex_input_count;

    for (int i = 0; i < refl->vertex_input_count; ++i) {
        const OnyxVertexInputAttributeReflection *vi = refl->vertex_inputs + i;

        onyx_geo_template_set_attr_size(&temp, i,
                                        onyx_vert_input_attr_size(vi));
        onyx_geo_template_set_attr_type(&temp, i,
                                        onyx_vert_input_attr_type(vi));
    }

    return temp;
}

static bool
geo_is_compatible_with_renderpass(const OnyxRasterizationReflection *refl,
                                  const OnyxGeometry                *geo)
{
    return onyx_geo_template_compatible_with_vertex_shader(geo->templ, refl);
}

NODISCARD
static Task *new_task(Graph *g, const char *name)
{
    assert(g->task_count + 1 < MAX_TASKS_PER_GRAPH);
    char **dst = &g->task_names[g->task_count];
    *dst       = graph_alloc(g, strlen(name) + 1);
    strcpy(*dst, name);
    Task *t = g->tasks + g->task_count++;
    zero(t);
    int_arr_init(NULL, &t->sub_tasks);
    t->graph = g;
    return t;
}

static TaskId task_id_old(const Graph *g, const Task *t)
{
    int id = t - g->tasks;
    assert(id >= 0 && id < MAX_TASKS_PER_GRAPH);
    return (TaskId){id};
}

static TaskId task_id(const Task *t)
{
    int id = t - t->graph->tasks;
    assert(id >= 0 && id < MAX_TASKS_PER_GRAPH);
    return (TaskId){id};
}

static int sub_task_id(Graph *g, SubTask *st)
{
    assert(st >= g->sub_tasks);
    return st - g->sub_tasks;
}

static int add_sub_task(Graph *g, Task *t, VkPipelineStageFlags stage)
{
    assert(g->sub_task_count < MAX_SUB_TASKS_PER_GRAPH);

    SubTask *st = g->sub_tasks + g->sub_task_count++;

    st->stage = stage;
    st->tid   = t - g->tasks;
    onyx_res_ref_arr_init(NULL, &st->refs);

    int stid = st - g->sub_tasks;
    int_arr_push(&t->sub_tasks, stid);
    return stid;
}

static bool res_ref_is_attachment(const ResRef *rr)
{
    return rr->type == ONYX_RESOURCE_REFERENCE_TYPE_COLOR_ATTACHMENT ||
           rr->type == ONYX_RESOURCE_REFERENCE_TYPE_DEPTH_ATTACHMENT ||
           rr->type == ONYX_RESOURCE_REFERENCE_TYPE_RESOLVE_ATTACHMENT ||
           rr->type == ONYX_RESOURCE_REFERENCE_TYPE_INPUT_ATTACHMENT;
}

// there is actually no dependency inforamtion here since we don't track
// readonly/writeonly in the glsl, so all descriptors are taken to be
// read-write, and color attachments are always read-write.
// maybe in the future we can get more information out.
// static IntArray
// task_resources(const Task *t)
//{
//    IntArray arr = {0};
//    return &t->res.indices;
//}

static const ResRefArray *sub_task_res_refs(const SubTask *t)
{
    return &t->refs;
}

static ResRefArray get_all_res_refs(const OnyxGraph *g)
{
    ResRefArray outarr = onyx_res_ref_arr_create(NULL);
    for (int i = 0; i < g->sub_task_count; ++i) {
        const SubTask     *st   = g->sub_tasks + i;
        const ResRefArray *refs = sub_task_res_refs(st);
        arr_foreach(*refs, ref) { onyx_res_ref_arr_push(&outarr, *ref); }
    }
    return outarr;
}

static VkAccessFlags res_ref_access_flags(const ResRef *rr)
{
    int           ub    = rr->usage_flags;
    VkAccessFlags flags = 0;
    switch (rr->type) {
        case ONYX_RESOURCE_REFERENCE_TYPE_UNIFORM_BUFFER:
            flags |= VK_ACCESS_UNIFORM_READ_BIT;
            break;
        case ONYX_RESOURCE_REFERENCE_TYPE_COLOR_ATTACHMENT:
            if (ub & R_BIT)
                flags |= VK_ACCESS_COLOR_ATTACHMENT_READ_BIT;
            if (ub & W_BIT)
                flags |= VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
            break;
        case ONYX_RESOURCE_REFERENCE_TYPE_DEPTH_ATTACHMENT:
            if (ub & R_BIT)
                flags |= VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT;
            if (ub & W_BIT)
                flags |= VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
            break;
        case ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_IMAGE:
        case ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_BUFFER:
        case ONYX_RESOURCE_REFERENCE_TYPE_TEXTURE:
            if (ub & R_BIT)
                flags |= VK_ACCESS_SHADER_READ_BIT;
            if (ub & W_BIT)
                flags |= VK_ACCESS_SHADER_WRITE_BIT;
            break;
        case ONYX_RESOURCE_REFERENCE_TYPE_TRANSFER_TARGET:
            if (ub & R_BIT)
                flags |= VK_ACCESS_TRANSFER_READ_BIT;
            if (ub & W_BIT)
                flags |= VK_ACCESS_TRANSFER_WRITE_BIT;
            break;
        case ONYX_RESOURCE_REFERENCE_TYPE_TOP_OF_PIPE:
        case ONYX_RESOURCE_REFERENCE_TYPE_OUTPUT:
            break;
        default:
            fatal_error("Not implemented yet. Ref type: %d", rr->type);
    }
    return flags;
    ;
}

static VkImageLayout res_ref_image_layout(const ResRef *rr)
{
    if (rr->type == ONYX_RESOURCE_REFERENCE_TYPE_COLOR_ATTACHMENT)
        return VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    if (rr->type == ONYX_RESOURCE_REFERENCE_TYPE_RESOLVE_ATTACHMENT)
        return VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    if (rr->type == ONYX_RESOURCE_REFERENCE_TYPE_DEPTH_ATTACHMENT)
        return VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
    if (rr->type == ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_IMAGE)
        return VK_IMAGE_LAYOUT_GENERAL;
    if (rr->type == ONYX_RESOURCE_REFERENCE_TYPE_TEXTURE)
        return VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    if (rr->type == ONYX_RESOURCE_REFERENCE_TYPE_PRESENT_IMAGE)
        return VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    if (rr->type == ONYX_RESOURCE_REFERENCE_TYPE_TOP_OF_PIPE)
        return VK_IMAGE_LAYOUT_UNDEFINED;
    if (rr->type == ONYX_RESOURCE_REFERENCE_TYPE_TRANSFER_TARGET) {
        if (rr->usage_flags == ONYX_RESOURCE_USAGE_WRITE_BIT)
            return VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        else
            return VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    }
    if (rr->type == ONYX_RESOURCE_REFERENCE_TYPE_OUTPUT) {
        return rr->info.output.img_layout;
    }
    fatal_error("Not supported yet. Type %d usage %d\n", rr->type, rr->usage_flags);
    return -1;
}

static bool sub_task_uses_resource(const SubTask *t, int rid)
{
    for (int i = 0; i < t->refs.count; ++i) {
        if (t->refs.elems[i].rid == rid)
            return true;
    }
    return false;
}

static bool task_uses_resource(const Graph *g, const Task *t, int rid)
{
    for (int i = 0; i < t->sub_tasks.count; ++i) {
        if (sub_task_uses_resource(&g->sub_tasks[t->sub_tasks.elems[i]], rid))
            return true;
    }
    return false;
}

#if 0
static int
get_task_color_attachment_res(const Graph *g, const Task *t, int output)
{
    assert(t->type == ONYX_TASK_TYPE_RENDERPASS);
    assert(t->res.refs.count);
    assert(t->res.refs.count == t->res.indices.count);

    const ResRef *iter = t->res.refs.elems;
    for (int i = 0; i < t->res.refs.count; ++i, ++iter) {
        if (iter->type != ONYX_RESOURCE_REFERENCE_TYPE_COLOR_ATTACHMENT)
            continue;
        if (iter->info.attachment.output == output)
            return t->res.indices.elems[i];
    }
    return NONE;
}

static const Resource*
get_task_color_attachment_res_(const Graph *g, const Task *t, int output)
{
    assert(g->rsrcs[get_task_color_attachment_res(g, t, output)].type == ONYX_RESOURCE_TYPE_IMAGE);
    return &g->rsrcs[get_task_color_attachment_res(g, t, output)];
}
#endif

static bool filter(const Filter *f, int id)
{
    if (!f)
        return false;
    for (int i = 0; i < f->count; ++i) {
        if (id == f->ids[i])
            return true;
    }
    return false;
}

static IntArray get_sub_tasks_referencing_resource(const Graph *g, int rid,
                                                   const Filter *f)
{
    IntArray out = int_arr_create(NULL);
    for (int i = 0; i < g->sub_task_count; ++i) {
        if (filter(f, i))
            continue;
        const SubTask *t = g->sub_tasks + i;
        if (sub_task_uses_resource(t, rid))
            int_arr_push(&out, i);
    }
    return out;
}

static void sub_task_add_resource(Graph *g, int stid, int rid,
                                  OnyxResourceReferenceType type,
                                  OnyxResourceUsageFlags    usage,
                                  OnyxResourceReferenceInfo info)
{
    ResRef ref = {.rid = rid, .info = info, .type = type, .usage_flags = usage};

    SubTask *st = &g->sub_tasks[stid];
    onyx_res_ref_arr_push(&st->refs, ref);
}

static void task_add_resource(Graph *g, Task *t,
                              VkPipelineStageFlags stage_flags, int rid,
                              OnyxResourceReferenceType type,
                              OnyxResourceUsageFlags    usage,
                              OnyxResourceReferenceInfo info)
{
    int   *stid  = t->sub_tasks.elems;
    bool   found = false;
    ResRef ref = {.rid = rid, .info = info, .type = type, .usage_flags = usage};

    while (stid < int_arr_end(&t->sub_tasks)) {
        SubTask *st = &g->sub_tasks[(*stid)];
        if (stage_flags & st->stage) {
            onyx_res_ref_arr_push(&st->refs, ref);
            found = true;
        }
        stid++;
    }
    assert(found);
}

static void for_each_renderpass_task(Graph *g, void (*fp)(Task *rptask))
{
    for (int i = 0, n = g->task_count; i < n; ++i) {
        Task *t = get_task_(g, i);
        if (task_is_renderpass_type(t))
            fp(t);
    }
}

typedef OnyxImage Image;

static Image *resource_get_image_mut(const Resource *r, const Graph *g)
{
    assert(r->type == ONYX_RESOURCE_TYPE_IMAGE);
    assert(r->bound);
    const Image *img = NULL;
    if (!r->graph_owned)
        img = r->rs.image.data.ptr;
    else
        img = &g->images.elems[r->rs.image.data.index];
    assert(img);
    return (Image *)img;
}

static const Image *resource_get_image(const Resource *r, const Graph *g)
{
    return resource_get_image_mut(r, g);
}

static OnyxBuffer *resource_get_buffer_mut(const Resource *r, const Graph *g)
{
    assert(r->type == ONYX_RESOURCE_TYPE_BUFFER);
    assert(r->bound);
    if (r->graph_owned) {
        return &g->buffers.elems[r->rs.buffer.index];
    } else {
        return (OnyxBuffer *)r->rs.buffer.ptr;
    }
}

static const OnyxBuffer *resource_get_buffer(const Resource *r, const Graph *g)
{
    return resource_get_buffer_mut(r, g);
}

typedef OnyxAttachmentBinding AttachmentBinding;
define_array_type(AttachmentBinding, attachment_binding);

// frame index for double buffered
static AttachmentBindingArray task_renderpass_get_attachments(const Task *t)
{
    const Graph           *g   = t->graph;
    AttachmentBindingArray arr = attachment_binding_arr_create(NULL);
    AttachmentInfoArray    attachment_infos = task_get_attachment_infos(t);
    arr_foreach(attachment_infos, ai)
    {
        const Resource   *r       = ai->res;
        const Image      *ptr     = resource_get_image(r, g);
        // we should not have duplicate attachments in a single renderpass
        AttachmentBinding binding = {
            .img              = ptr,
            .attachment_index = ai->ref->info.attachment.ref.framebuffer_index};
        assert(binding.attachment_index != -1);
        assert(!attachment_binding_arr_contains(&arr, &binding));
        attachment_binding_arr_push(&arr, binding);
    }
    attachment_info_arr_free(&attachment_infos);
    return arr;
}

OnyxGraph *onyx_alloc_graph() { return malloc(sizeof(OnyxGraph)); }

#define set_res_id_array_to_none(array)                                        \
    do {                                                                       \
        int *flat = (int *)array;                                              \
        for (int i = 0; i < sizeof(array) / sizeof(int); ++i) {                \
            flat[i] = NONE;                                                    \
        }                                                                      \
    } while (0)

void onyx_init_graph(Onyx *ctx, const OnyxReflection *refl, OnyxGraph *graph)
{
    zero(graph);
    graph->onyx           = ctx;
    graph->device         = ctx->device;
    graph->pipedes        = &refl->description;
    graph->reflection     = refl;
    graph->final_sub_task = NONE;
    onyx_image_arr_init(NULL, &graph->images);
    onyx_buffer_arr_init(NULL, &graph->buffers);
    onyx_render_pass_arr_init(NULL, &graph->renderpasses);
    onyx_framebuffer_arr_init(NULL, &graph->framebuffers);
    heap_ptr_arr_init(NULL, &graph->need_to_free_list);
    // the graph will be built out of resource references
    hell_create_graph(MAX_SUB_TASKS_PER_GRAPH, &graph->graph);

    Task *t  = new_task(graph, FINAL_TASK_NAME);
    t->type  = ONYX_TASK_TYPE_NULL;
    int stid = add_sub_task(graph, t, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
    graph->final_sub_task = stid;

    graph->initialized_marker = INITIALIZED;
}

void onyx_term_graph(OnyxGraph *g)
{
    assert(g->initialized_marker == INITIALIZED);

    for (int i = 0; i < g->sub_task_count; ++i) {
        SubTask *st = get_sub_task(g, i);
        onyx_res_ref_arr_free(&st->refs);
    }

    for (int i = 0; i < g->task_count; ++i) {
        Task *t = get_task_(g, i);
        int_arr_free(&t->sub_tasks);
    }

    // TODO finihs this
    arr_foreach(g->need_to_free_list, ptr) { free(*ptr); }
    heap_ptr_arr_free(&g->need_to_free_list);

    for (int i = 0; i < g->images.count; ++i) {
        onyx_free_image(&g->images.elems[i]);
    }
    onyx_image_arr_free(&g->images);

    for (int i = 0; i < g->buffers.count; ++i) {
        onyx_free_buffer(&g->buffers.elems[i]);
    }
    onyx_buffer_arr_free(&g->buffers);

    for (int i = 0; i < g->renderpasses.count; ++i) {
        vkDestroyRenderPass(g->device, g->renderpasses.elems[i].vkhandle, NULL);
    }
    onyx_render_pass_arr_free(&g->renderpasses);

    for (int i = 0; i < g->framebuffers.count; ++i) {
        onyx_destroy_framebuffer(g->device, g->framebuffers.elems[i].handle);
    }
    onyx_framebuffer_arr_free(&g->framebuffers);

    hell_destroy_graph(&g->graph);
    zero(g);
}

TaskId onyx_graph_add_rasterization_task(Graph *g, const char *name,
                                         OnyxGraphRasterizationParms parms)
{
    Task *t       = new_task(g, name);
    t->type       = ONYX_TASK_TYPE_RASTERIZE;
    t->reflection = g->reflection->programs[parms.program];

    bool found = false;
    for (int i = 0; i < g->pipeline_settings_count; ++i) {
        if (structs_equal(parms.pipeline_settings, g->pipeline_settings + i)) {
            t->ts.rasterize.pipeline_settings_index = i;
            found                                   = true;
            break;
        }
    }
    if (!found) {
        t->ts.rasterize.pipeline_settings_index = g->pipeline_settings_count;
        g->pipeline_settings[g->pipeline_settings_count++] =
            *parms.pipeline_settings;
    }

    // validate geo template against shader
    {
        bool found = onyx_geo_template_compatible_with_vertex_shader(
            parms.geometry_template, &t->reflection.rasterize);
        if (!found) {
            fatal_error("Passed in geo template not compatible with program "
                        "shader definition.\n");
        }
    }

    t->ts.rasterize.geo_template = parms.geometry_template;

    int src, dst;
    src = add_sub_task(g, t, VK_PIPELINE_STAGE_VERTEX_SHADER_BIT);
    dst = add_sub_task(g, t, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);

    t->ts.rasterize.vertex_shader_subtask_id = src;

    hell_graph_add_input_to_vertex(&g->graph, dst, src);

    src = dst;
    dst = add_sub_task(g, t, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);

    hell_graph_add_input_to_vertex(&g->graph, dst, src);

    // create empty frame buffer
    OnyxFramebuffer fb   = {0};
    const int       fbid = onyx_framebuffer_arr_push(&g->framebuffers, fb);

    t->ts.renderpass.framebuffer = fbid;

    TaskId id = task_id_old(g, t);
    return id;
}

typedef struct {
    TaskId tid;
    Graph *graph;
    char   img_name[32];
} TaskImageToWorkgroupSizeData;

static void image_to_workgroup_size(VkCommandBuffer cb, void *data)
{
    TaskImageToWorkgroupSizeData *d = data;
    Task                         *t = get_task(d->graph, d->tid);
    assert(t->type == ONYX_TASK_TYPE_COMPUTE);

    int rid = find_resource(d->graph, d->img_name);
    if (rid == NOT_FOUND)
        fatal_error("Image by name %s not found", d->img_name);

    const OnyxImage *img = get_image(d->graph, rid);
    VkExtent3D       ext = img->extent;
    uint32_t         x, y, z;
    x                        = t->reflection.compute.local_x;
    y                        = t->reflection.compute.local_y;
    z                        = t->reflection.compute.local_z;
    // will round up if we cannot divide the image dim evenly by the local wg
    // size
    x                        = (ext.width / x) + ((ext.width % x) ? 1 : 0);
    y                        = (ext.height / y) + ((ext.height % y) ? 1 : 0);
    z                        = (ext.depth / z) + ((ext.depth % z) ? 1 : 0);
    t->ts.compute.wg_sizes.x = x;
    t->ts.compute.wg_sizes.y = y;
    t->ts.compute.wg_sizes.z = z;
}

OnyxTaskId onyx_graph_add_compute_task(OnyxGraph *g, const char *name,
                                       OnyxGraphComputeParms parms)
{
    Task *t       = new_task(g, name);
    t->type       = ONYX_TASK_TYPE_COMPUTE;
    t->reflection = g->reflection->programs[parms.program];

    TaskId tid = task_id(t);
    add_sub_task(g, t, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    switch (parms.wg_size_type) {
        case ONYX_COMPUTE_WORKGROUP_SIZE_TYPE_STATIC:
            t->ts.compute.wg_sizes = parms.wg_size.size;
            break;
        case ONYX_COMPUTE_WORKGROUP_SIZE_TYPE_FROM_IMAGE: {
            char buf[64];
            snprintf(buf, LEN(buf), "%s_copy_img_dim", name);
            TaskImageToWorkgroupSizeData *ptr =
                graph_alloc(g, sizeof(TaskImageToWorkgroupSizeData));
            ptr->graph = g;
            assert(strlen(name) < LEN(ptr->img_name));
            strcpy(ptr->img_name, parms.wg_size.image_name);
            ptr->tid        = tid;
            TaskId copy_tid = onyx_graph_add_custom_task(
                g, buf,
                (OnyxGraphCustomTaskParms){
                    .data   = ptr,
                    .fn     = image_to_workgroup_size,
                    .stages = (VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT)});
            onyx_graph_add_task_dependency(g, tid, copy_tid);
            break;
        }
        default:
            fatal_error("Not implemented yet");
    }

    return task_id_old(g, t);
}

void onyx_graph_bind_geometry(Graph *g, const char *name, OnyxGeometry *geo)
{
    const int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_GEOMETRY);

    for (int i = 0; i < g->task_count; ++i) {
        Task *t = g->tasks + i;
        if (t->type != ONYX_TASK_TYPE_RASTERIZE)
            continue;
        if (!task_uses_resource(g, t, rid))
            continue;
        if (geo_is_compatible_with_renderpass(&t->reflection.rasterize, geo))
            continue;
        fatal_error("geo %s is not compatible with task %d renderpass", name,
                    i);
    }

    Resource *r = get_res_(g, rid);
    assert(!r->bound);
    assert(!r->rs.geo.ptr);
    r->rs.geo.ptr = geo;
    r->bound      = true;
}

void onyx_graph_add_geometry_to_task(Graph *g, TaskId tid, const char *name,
                                     int32_t draw_call_id)
{
    Task *t = get_task(g, tid);
    assert(t->type == ONYX_TASK_TYPE_RASTERIZE);

    const int gid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_GEOMETRY);

    assert(draw_call_id < t->ts.rasterize.draw_count);
    OnyxSubTaskId stid = t->ts.rasterize.draw_to_subtask_map[draw_call_id];

    sub_task_add_resource(g, stid, gid, ONYX_RESOURCE_REFERENCE_TYPE_GEOMETRY,
                          R_BIT, (OnyxResourceReferenceInfo){});
}

int32_t onyx_graph_add_draw_call_to_task(Graph *g, TaskId tid,
                                         uint32_t elem_count,
                                         uint32_t instance_count)
{
    Task *t = get_task(g, tid);
    assert(t->type == ONYX_TASK_TYPE_RASTERIZE);

    int src, dst;
    src = add_sub_task(g, t, VK_PIPELINE_STAGE_VERTEX_INPUT_BIT);
    dst = t->ts.rasterize.vertex_shader_subtask_id;

    hell_graph_add_input_to_vertex(&g->graph, dst, src);

    int32_t dc = t->ts.rasterize.draw_count++;
    fatal_condition(dc >= LEN(t->ts.rasterize.draw_to_subtask_map),
                    "Too many draw calls: %d", dc);
    t->ts.rasterize.draw_to_subtask_map[dc] = src;
    t->ts.rasterize.draw_instance_count[dc] = instance_count;
    t->ts.rasterize.draw_elem_count[dc]     = elem_count;
    return dc;
}

void onyx_graph_add_vertex_buffer_to_task(Graph *g, TaskId tid,
                                          const char *name,
                                          int32_t draw_call_id, int32_t binding)
{
    Task *t = get_task(g, tid);
    assert(t->type == ONYX_TASK_TYPE_RASTERIZE);

    const int gid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_BUFFER);

    assert(draw_call_id < t->ts.rasterize.draw_count);
    OnyxSubTaskId stid = t->ts.rasterize.draw_to_subtask_map[draw_call_id];

    sub_task_add_resource(
        g, stid, gid, ONYX_RESOURCE_REFERENCE_TYPE_VERTEX_BUFFER, R_BIT,
        (OnyxResourceReferenceInfo){.vertexbuffer.binding = binding});
}

void onyx_graph_add_index_buffer_to_task(Graph *g, TaskId tid, const char *name,
                                         int32_t     draw_call_id,
                                         VkIndexType index_type)
{
    Task *t = get_task(g, tid);
    assert(t->type == ONYX_TASK_TYPE_RASTERIZE);

    const int gid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_BUFFER);

    assert(draw_call_id < t->ts.rasterize.draw_count);
    OnyxSubTaskId stid = t->ts.rasterize.draw_to_subtask_map[draw_call_id];

    sub_task_add_resource(g, stid, gid,
                          ONYX_RESOURCE_REFERENCE_TYPE_INDEX_BUFFER, R_BIT,
                          (OnyxResourceReferenceInfo){
                              .indexbuffer.type = index_type,
                          });
}

void onyx_graph_add_uniform_buffer_to_task(Graph *g, TaskId tid,
                                           const char *name, int set,
                                           int binding)
{
    const int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_BUFFER);

    Task *t = get_task(g, tid);
    task_add_descriptor(t, rid, set, binding, 0);
}

static int attachment_rw_bits(OnyxAttachmentReferenceInfo p)
{
    int r = 0;
    if (p.load_op == ONYX_ATTACHMENT_LOAD_OP_LOAD)
        r |= R_BIT;
    if (p.store)
        r |= W_BIT;
    return r;
}

void onyx_graph_add_attachment_to_task(Graph *g, TaskId tid, const char *name,
                                       OnyxResourceAttachmentParms parms)
{
    switch (parms.ref.type) {
        case ONYX_ATTACHMENT_COLOR_TYPE:
            onyx_graph_add_color_attachment_output_to_task(g, tid, name, parms);
            break;
        case ONYX_ATTACHMENT_DEPTH_TYPE:
            onyx_graph_add_depth_attachment_to_task(g, tid, name, parms);
            break;
        case ONYX_ATTACHMENT_RESOLVE_TYPE:
            onyx_graph_add_resolve_attachment_to_task(g, tid, name, parms);
            break;
        default:
            fatal_error("Unsupported");
    }
}

void onyx_graph_add_color_attachment_output_to_task(
    Graph *g, TaskId tid, const char *name, OnyxResourceAttachmentParms parms)
{
    Task *t = get_task(g, tid);
    assert(task_is_renderpass_type(t));
    if (parms.ref.type != ONYX_ATTACHMENT_COLOR_TYPE) {
        warning("parms.ref.type != ONYX_ATTACHMENT_COLOR_TYPE");
        parms.ref.type = ONYX_ATTACHMENT_COLOR_TYPE;
    }
    if (t->type == ONYX_TASK_TYPE_RASTERIZE)
        assert(parms.ref.color.shader_location <
               t->reflection.rasterize.color_attachment_count);

    const int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_IMAGE);
    parms.ref.color.ref.framebuffer_index = t->ts.renderpass.attachment_count++;
    parms.ref.color.ref.layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    task_add_resource(g, t, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, rid,
                      ONYX_RESOURCE_REFERENCE_TYPE_COLOR_ATTACHMENT,
                      attachment_rw_bits(parms.ref),
                      (ResRefInfo){.attachment = parms.ref});
    Resource *r            = get_res_(g, rid);
    r->rs.image.image_type = ONYX_IMAGE_COLOR_TYPE;

    // should reflect the image type information from the shader
}

void onyx_graph_add_resolve_attachment_to_task(
    OnyxGraph *g, OnyxTaskId tid, const char *name,
    OnyxResourceAttachmentParms parms)
{
    Task *t = get_task(g, tid);
    assert(task_is_renderpass_type(t));
    if (parms.ref.type != ONYX_ATTACHMENT_RESOLVE_TYPE) {
        warning("parms.ref.type != ONYX_ATTACHMENT_RESOLVE_TYPE");
        parms.ref.type = ONYX_ATTACHMENT_RESOLVE_TYPE;
    }

    const int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_IMAGE);
    parms.ref.color.ref.framebuffer_index = t->ts.renderpass.attachment_count++;
    parms.ref.color.ref.layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    task_add_resource(g, t, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, rid,
                      ONYX_RESOURCE_REFERENCE_TYPE_RESOLVE_ATTACHMENT,
                      attachment_rw_bits(parms.ref),
                      (ResRefInfo){.attachment = parms.ref});
    Resource *r            = get_res_(g, rid);
    r->rs.image.image_type = ONYX_IMAGE_COLOR_TYPE;
}

void onyx_graph_add_depth_attachment_to_task(OnyxGraph *g, OnyxTaskId tid,
                                             const char                 *name,
                                             OnyxResourceAttachmentParms parms)
{
    Task *t = get_task(g, tid);
    assert(task_is_renderpass_type(t));
    if (parms.ref.type != ONYX_ATTACHMENT_DEPTH_TYPE) {
        warning("parms.ref.type != ONYX_ATTACHMENT_DEPTH_TYPE");
        parms.ref.type = ONYX_ATTACHMENT_DEPTH_TYPE;
    }

    parms.ref.depth.ref.framebuffer_index = t->ts.renderpass.attachment_count++;
    parms.ref.depth.ref.layout =
        VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
    parms.ref.clear_val.depthStencil.depth = 1.0;
    parms.ref.clear_val.depthStencil.stencil = 0;
    const int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_IMAGE);
    task_add_resource(g, t, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, rid,
                      ONYX_RESOURCE_REFERENCE_TYPE_DEPTH_ATTACHMENT, W_BIT,
                      (ResRefInfo){.attachment = parms.ref});
    Resource *r            = get_res_(g, rid);
    r->rs.image.image_type = ONYX_IMAGE_DEPTH_TYPE;
}

static bool res_ref_is_descriptor_type(const ResRef *ref)
{
    switch (ref->type) {
        case ONYX_RESOURCE_REFERENCE_TYPE_UNIFORM_BUFFER:
        case ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_BUFFER:
        case ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_IMAGE:
        case ONYX_RESOURCE_REFERENCE_TYPE_TEXTURE:
            return true;
        default:
            return false;
    }
}

static void validata(const Graph *g)
{
    if (g->final_sub_task == NONE)
        fatal_error("Output task not set");
    ResRefArray refrefs = get_all_res_refs(g);
    arr_foreach(refrefs, ref)
    {
        if (!res_ref_is_descriptor_type(ref))
            continue;
        const int rid = ref->rid;
        arr_foreach(refrefs, oref)
        {
            if (!res_ref_is_descriptor_type(oref))
                continue;
            if (ref == oref)
                continue;
            if (rid == oref->rid)
                continue;
            if (oref->info.descriptor.index != ref->info.descriptor.index)
                continue;
            if (oref->info.descriptor.binding != ref->info.descriptor.binding)
                continue;
            fatal_error(
                "We have two different resource references to the same descriptor but with different resources. \n\
                    Consider using a dynamic uniform buffer.");
        }
    }
    onyx_res_ref_arr_free(&refrefs);

    const SubTask     *st   = get_sub_task_const(g, g->final_sub_task);
    const ResRefArray *refs = sub_task_res_refs(st);
    fatal_condition(refs->count == 0, "No output resources have been set");

    for (int stid = 0; stid < g->sub_task_count; ++stid) {
        if (g->final_sub_task == stid)
            continue;
        if (hell_graph_is_orphan(&g->graph, stid)) {
            NameBuffer buf = sub_task_name(g, stid);
            fatal_error("%s sub task has no parent sub task. You might need to "
                        "add a resource as an output",
                        buf.buf);
        }
    }
}

typedef struct {
    int tid;
    int ref;
} Pin;

typedef struct {
    int sub_task_src;
    int sub_task_dst;
} Wire;

static void add_task_dep(Graph *g, Wire w)
{
    hell_graph_add_input_to_vertex(&g->graph, w.sub_task_dst, w.sub_task_src);
}
//
// static void
// add_output_dependencies(Graph* g)
//{
//    assert(g->task_count);
//    assert(g->output_image != NONE);
//
//    const int ntasks = g->task_count;
//    const int outimg = g->output_image;
//
//    Task *t = NULL;
//    for (int i = 0; i < ntasks; ++i) {
//        t = get_task_(g, i);
//        TaskId id = task_id(g, t);
//        if (id.id == g->final_task)
//            continue;
//        const IntArray* out_rsrcs = task_resources(t);
//        if (!int_arr_contains(out_rsrcs, &outimg))
//           continue;
//        add_task_dep(g, g->final_task, id.id);
//    }
//}

static bool sub_task_writes_to_resource(const SubTask *st, int rid)
{
    const ResRefArray *refs = sub_task_res_refs(st);
    arr_foreach(*refs, ref)
    {
        if (ref->rid == rid && ref->usage_flags & W_BIT)
            return true;
    }
    return false;
}

static const ResRef *sub_task_get_res_ref(const SubTask *st, int rid)
{
    arr_foreach(st->refs, ref)
    {
        if (ref->rid == rid)
            return ref;
    }
    assert(0 && "No reference for that rid");
    return NULL;
}

static void add_implicit_dependencies_to_sub_task(Graph *g, const int stid)
{
    const SubTask     *st   = get_sub_task(g, stid);
    const ResRefArray *refs = sub_task_res_refs(st);
    for (int i = 0; i < refs->count; ++i) {
        const ResRef *myref = &refs->elems[i];
        // only consider read only references
        if (!res_ref_read_only(myref))
            continue;
        IntArray sub_tasks = get_sub_tasks_referencing_resource(
            g, myref->rid, &(Filter){.count = 1, .ids = &stid});
        arr_foreach(sub_tasks, ostid)
        {
            const SubTask     *ost       = get_sub_task(g, *ostid);
            const ResRefArray *otherrefs = sub_task_res_refs(ost);
            arr_foreach(*otherrefs, oref)
            {
                if (oref->rid == myref->rid && res_ref_writes(oref))
                    add_task_dep(g, (Wire){.sub_task_dst = stid,
                                           .sub_task_src = *ostid});
            }
        }
        int_arr_free(&sub_tasks);
    }
}

static void add_implicit_dependencies(Graph *g)
{
    for (int i = 0; i < g->sub_task_count; ++i) {
        add_implicit_dependencies_to_sub_task(g, i);
    }
}

static void create_descriptor_pool(Graph *g)
{
    // counts
    OnyxDescriptorPoolParms prms = {0};
    int                     desc_count;
    const OnyxDescriptor   *desc =
        onyx_pipedes_get_descriptors(g->pipedes, &desc_count);

    for (int i = 0; i < desc_count; ++i, ++desc) {
        switch (desc->type) {
            case VK_DESCRIPTOR_TYPE_STORAGE_BUFFER:
                prms.storageBufferCount++;
                break;
            case VK_DESCRIPTOR_TYPE_STORAGE_IMAGE:
                prms.storageImageCount++;
                break;
            case VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER:
                prms.uniformBufferCount++;
                break;
            default:
                assert(0 && "Descriptor type not supported yet");
        }
    }

    onyx_create_descriptor_pool(g->device, prms, &g->vkdes.descriptor_pool);
}

static void create_descriptor_set_layouts(
    VkDevice device, const OnyxPipedes *des,
    VkDescriptorSetLayout out[ONYX_MAX_DESCRIPTOR_SETS])
{
    int                      set_count;
    const OnyxDescriptorSet *set =
        onyx_pipedes_get_descriptor_sets(des, &set_count);

    for (int s = 0; s < set_count; ++s, ++set) {
        int bcnt = set->descriptor_count;

        array_alloca(VkDescriptorSetLayoutBinding, bindings, bcnt);

        for (int b = 0; b < bcnt; ++b) {
            const OnyxDescriptor *desc = onyx_pipedes_get_descriptor(des, s, b);

            VkDescriptorSetLayoutBinding binding = {0};
            binding.binding                      = b;
            binding.descriptorCount              = desc->count;
            binding.descriptorType               = desc->type;
            binding.stageFlags                   = desc->stages;

            bindings[b] = binding;
        }

        VkDescriptorSetLayoutCreateInfo layout = {
            .sType        = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO,
            .bindingCount = bcnt,
            .pBindings    = bindings};

        V_ASSERT(vkCreateDescriptorSetLayout(device, &layout, NULL, out + s));
    }
}

static void alloc_descriptor_sets(Graph *g)
{
    VkDescriptorSetAllocateInfo ai = {
        .sType              = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO,
        .descriptorPool     = g->vkdes.descriptor_pool,
        .descriptorSetCount = g->pipedes->descriptor_set_count,
        .pSetLayouts        = g->vkdes.descriptor_set_layouts};

    if (g->pipedes->descriptor_set_count == 0)
        return;

    V_ASSERT(
        vkAllocateDescriptorSets(g->device, &ai, g->vkdes.descriptor_sets));
}

static void create_pipeline_layouts(Graph *g)
{
    const OnyxPipedes *des = g->pipedes;

    int                       cnt;
    const OnyxPipelineLayout *layout =
        onyx_pipedes_get_pipeline_layout(g->pipedes, &cnt);
    for (int i = 0; i < cnt; ++i, ++layout) {
        int pccnt = layout->push_constant_count;
        int dscnt = layout->descriptor_set_count;

        array_alloca(VkPushConstantRange, pc_ranges, pccnt);
        array_alloca(VkDescriptorSetLayout, set_layouts, dscnt);

        for (int i = 0; i < pccnt; ++i) {
            pc_ranges[i] = onyx_pipedes_get_push_constant_range(
                des, layout->push_constant_indices[i]);
        }

        for (int i = 0; i < dscnt; ++i) {
            set_layouts[i] =
                g->vkdes
                    .descriptor_set_layouts[layout->descriptor_set_indices[i]];
        }

        VkPipelineLayoutCreateInfo ci = {
            .sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO,
            .pushConstantRangeCount = layout->push_constant_count,
            .pPushConstantRanges    = pc_ranges,
            .setLayoutCount         = dscnt,
            .pSetLayouts            = set_layouts,
        };

        V_ASSERT(vkCreatePipelineLayout(g->device, &ci, NULL,
                                        g->vkdes.pipeline_layouts + i));
    }
}

static void create_shader_modules(Graph *g)
{
    const OnyxPipedes *des = g->pipedes;

    int                   cnt;
    const OnyxShaderInfo *iter = onyx_pipedes_get_shader_infos(des, &cnt);
    for (int i = 0; i < cnt; ++i, ++iter) {
        VkShaderModuleCreateInfo ci = {
            .sType    = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
            .codeSize = iter->byte_count,
            .pCode    = iter->code,
        };

        V_ASSERT(vkCreateShaderModule(g->device, &ci, NULL,
                                      g->vkdes.shader_modules + i));
    }
}

static void create_vk_descriptors(Graph *g)
{
    create_descriptor_pool(g);
    create_descriptor_set_layouts(g->device, g->pipedes,
                                  g->vkdes.descriptor_set_layouts);
    alloc_descriptor_sets(g);
    create_pipeline_layouts(g);
    create_shader_modules(g);
}

static IntArray filter_task_types(const Graph *g, const IntArray tasks,
                                  OnyxTaskType type)
{
    IntArray out = int_arr_create(NULL);
    for (int i = 0; i < tasks.count; ++i) {
        int tid = tasks.elems[i];
        if (get_task_const_(g, tid)->type == type)
            int_arr_push(&out, tid);
    }
    return out;
}

static OnyxImageTemplate resource_image_template(const Graph             *g,
                                                 const OnyxResourceImage *img)
{
    OnyxImageTemplate templ = {.sample_count = img->samples};
    templ.format            = img->format;
    return templ;
}

#if 1
// returns NULL if no earlier task used the resouce
static const SubTask *last_task_to_write_to_resource(Graph *g, int stid,
                                                     int rid)
{
    // uses current sub task as the root
    IntArray sub_graph = hell_graph_topological_sort(
        &g->graph, stid, (HellGraphSortingParms){.prune_unconnected = true});

    const SubTask *last = NULL;
    for (int i = sub_graph.count; i-- > 0;) {
        const int id = sub_graph.elems[i];
        if (id == stid)
            continue;
        const SubTask *tmp = get_sub_task(g, sub_graph.elems[i]);
        if (sub_task_writes_to_resource(tmp, rid)) {
            last = tmp;
            break;
        }
    }
    int_arr_free(&sub_graph);
    return last;
}

static const SubTask *next_task_to_use_resource(Graph *g, int stid, int rid)
{
    IntArray ordered_tasks = hell_graph_topological_sort(
        &g->graph, g->final_sub_task,
        (HellGraphSortingParms){.prune_unconnected = true});
    assert(int_arr_contains(&ordered_tasks, &stid));

    const SubTask *myst = get_sub_task_const(g, stid);

    const SubTask *last = NULL;
    const int     *iter = int_arr_last_const(&ordered_tasks);
    for (; *iter != stid; --iter) {
        const SubTask *st = get_sub_task(g, *iter);
        if (!sub_task_uses_resource(st, rid))
            continue;
        if (myst->tid == st->tid)
            continue; // same task
        last = st;
    }
    int_arr_free(&ordered_tasks);
    return last;
}
#endif

static bool is_dep(const Graph *g, int tid, int otid)
{
    return hell_graph_is_edge(&g->graph, tid, otid);
}

// return -1 if not found
static int task_get_color_attachment_stid(const Task *t)
{
    assert(task_is_renderpass_type(t));
    arr_foreach(t->sub_tasks, stid)
    {
        const SubTask *st = get_sub_task_const(t->graph, *stid);
        if (st->stage != VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT)
            continue;
        return *stid;
    }
    return NOT_FOUND;
}

static int task_get_depth_attachment_stid(const Task *t)
{
    assert(task_is_renderpass_type(t));
    arr_foreach(t->sub_tasks, stid)
    {
        const SubTask *st = get_sub_task_const(t->graph, *stid);
        if (st->stage != VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT)
            continue;
        return *stid;
    }
    return NOT_FOUND;
}

static OnyxAttachmentArray create_attachments(OnyxGraph          *g,
                                              AttachmentInfoArray infos)
{
    OnyxAttachmentArray attachments = attachment_arr_create(NULL);
    arr_foreach(infos, ai)
    {
        AttachmentInfo cao = *ai;

        OnyxAttachment attach = {
            .image_template = resource_image_template(g, &cao.res->rs.image)};

        const SubTask *other_st =
            last_task_to_write_to_resource(g, cao.stid, cao.ref->rid);
        if (other_st == NULL) {
            attach.initial_layout = VK_IMAGE_LAYOUT_UNDEFINED;
        } else {
            const ResRef *rr = sub_task_get_res_ref(other_st, cao.ref->rid);
            attach.initial_layout = res_ref_image_layout(rr);
        }

        other_st = next_task_to_use_resource(g, cao.stid, cao.ref->rid);
        if (other_st == NULL) {
            // current layout
            attach.final_layout = cao.ref->info.attachment.ref.layout;
        } else {
            const ResRef *rr    = sub_task_get_res_ref(other_st, cao.ref->rid);
            attach.final_layout = res_ref_image_layout(rr);
        }

        attach.store_op = cao.ref->info.attachment.store
                              ? VK_ATTACHMENT_STORE_OP_STORE
                              : VK_ATTACHMENT_STORE_OP_DONT_CARE;

        switch (cao.ref->info.attachment.load_op) {
            case ONYX_ATTACHMENT_LOAD_OP_LOAD:
                attach.load_op = VK_ATTACHMENT_LOAD_OP_LOAD;
                break;
            case ONYX_ATTACHMENT_LOAD_OP_CLEAR:
                attach.load_op = VK_ATTACHMENT_LOAD_OP_CLEAR;
                break;
            case ONYX_ATTACHMENT_LOAD_OP_DONT_CARE:
                attach.load_op = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
                break;
        }

        attachment_arr_push(&attachments, attach);
    }

    return attachments;
}

static void create_renderpass(Task           *t,
                              OnyxRenderPass *rp) // stupidly based on one color
                                                  // attachment
{
    AttachmentInfoArray attachment_infos = task_get_attachment_infos(t);
    Graph              *g                = t->graph;

    OnyxAttachmentArray attachments = create_attachments(g, attachment_infos);

    // TODO be less heavy handed here
    VkPipelineStageFlags srcStageMas = VK_PIPELINE_STAGE_ALL_COMMANDS_BIT |
                                       VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT;
    VkPipelineStageFlags dstStageMask  = VK_PIPELINE_STAGE_ALL_COMMANDS_BIT;
    VkAccessFlags        srcAccessMask = VK_ACCESS_MEMORY_WRITE_BIT |
                                  VK_ACCESS_MEMORY_READ_BIT |
                                  VK_ACCESS_SHADER_WRITE_BIT;
    VkAccessFlags dstAccessMask =
        VK_ACCESS_MEMORY_WRITE_BIT | VK_ACCESS_MEMORY_READ_BIT;

    OnyxRenderPassDependencyInfo dep = {.src.access_mask = srcAccessMask,
                                        .src.stage_mask  = srcStageMas,
                                        .dst.stage_mask  = dstStageMask,
                                        .dst.access_mask = dstAccessMask};

    VkAccessFlags access_mask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT |
                                VK_ACCESS_COLOR_ATTACHMENT_READ_BIT;
    VkPipelineStageFlags stage_mask =
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;

    OnyxSubpass subpass = {
        .scope.access_mask = access_mask,
        .scope.stage_mask  = stage_mask,
    };

    for (int i = 0; i < attachment_infos.count; ++i) {
        const AttachmentInfo *ai = attachment_infos.elems + i;
        if (ai->ref->info.attachment.type == ONYX_ATTACHMENT_COLOR_TYPE) {
            subpass.color_attachments[subpass.color_attachment_count++] =
                ai->ref->info.attachment.color;
        } else if (ai->ref->info.attachment.type ==
                   ONYX_ATTACHMENT_DEPTH_TYPE) {
            assert(!subpass.has_depth);
            subpass.has_depth        = true;
            subpass.depth_attachment = ai->ref->info.attachment.depth;
        } else if (ai->ref->info.attachment.type ==
                   ONYX_ATTACHMENT_RESOLVE_TYPE) {
            subpass.resolve_attachments[subpass.resolve_attachment_count++] =
                ai->ref->info.attachment.resolve;
        } else
            fatal_error("Not implemented.");
    }

    if (subpass.has_depth) {
        // seems like a clear involves a read? removing the VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT
        // leads to validation errors in stencil test example
        subpass.scope.access_mask |=
            VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT;
        // VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT is needed it seems if we
        // attempt to do a copy from the depth/stencil buffer. again, stencil
        // test app is where the validation errors sprang up
        subpass.scope.stage_mask |= VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
    }

    onyx_render_pass_create(attachments.count, attachments.elems, 1, &subpass,
                            dep, rp);

    attachment_arr_free(&attachments);
    attachment_info_arr_free(&attachment_infos);
}

static void create_renderpasses(Graph *g)
{
    for (Task *t = g->tasks; t < (g->tasks + g->task_count); t++) {
        if (!task_is_renderpass_type(t))
            continue;

        if (t->type == ONYX_TASK_TYPE_CUSTOM_RENDERPASS) {
            const SubTask *st = get_sub_task_const(g, t->sub_tasks.elems[0]);
            if (st->stage ^ VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT)
                continue;
        }
        // make sure this does not contain any pointers
        OnyxRenderPass rp;
        create_renderpass(t, &rp);
        VkRenderPass vkrp = onyx_render_pass_create_vk(&rp, g->device);
        rp.vkhandle       = vkrp;
        int rpid          = onyx_render_pass_arr_push(&g->renderpasses, rp);
        t->ts.renderpass.renderpass = rpid;
    }
}

static VkPipelineLayout
get_vk_pipeline_layout(Graph *g, const OnyxProgramReflection *refl)
{
    return g->vkdes.pipeline_layouts[refl->pipeline_layout_index];
}

static void create_graphics_pipelines(Graph *g)
{
    for (Task *t = g->tasks; t < (g->tasks + g->task_count); t++) {
        if (t->type != ONYX_TASK_TYPE_RASTERIZE)
            continue;

        assert(t->ts.rasterize.pipeline_settings_index <
               g->pipeline_settings_count);
        const OnyxGraphicsPipelineSettings *pipe_settings =
            &g->pipeline_settings[t->ts.rasterize.pipeline_settings_index];

        const OnyxRasterizationReflection *rpr    = &t->reflection.rasterize;
        const VkShaderModule              *modarr = g->vkdes.shader_modules;

        const OnyxRenderPass     *rp  = task_get_renderpass(t);
        OnyxGraphicsPipelineInfo2 gpi = {
            .sp_id         = 0, // for now
            .vkrp          = rp->vkhandle,
            .sample_count  = rp->attachments[0].image_template.sample_count,
            .settings      = *pipe_settings,
            .geo_template  = t->ts.rasterize.geo_template,
            .pipedes       = g->pipedes,
            .subpass       = rp->subpasses[0],
            .rprefl        = t->reflection.rasterize,
            .modules_count = 2,
            .modules       = {modarr[rpr->vertex_shader_index],
                              modarr[rpr->fragment_shader_index]},
            .layout        = get_vk_pipeline_layout(g, &t->reflection)};

        VkPipeline pipeline;
        onyx_graphics_pipeline_create(g->device, &gpi, &pipeline);
        g->vkdes.pipelines[g->pipeline_count] = pipeline;
        t->ts.rasterize.pipeline              = g->pipeline_count++;
        assert(g->pipeline_count < LEN(g->vkdes.pipelines));
    }
}

static void create_compute_pipelines(Graph *g)
{
    for (Task *t = g->tasks; t < (g->tasks + g->task_count); t++) {
        if (t->type != ONYX_TASK_TYPE_COMPUTE)
            continue;

        int            shader_index = t->reflection.compute.shader_index;
        VkShaderModule sm           = g->vkdes.shader_modules[shader_index];
        OnyxComputePipelineInfo pi  = {
             .layout       = get_vk_pipeline_layout(g, &t->reflection),
             .module       = sm,
             .shader_stage = g->pipedes->shader_infos[shader_index],
        };
        VkPipeline pipeline;
        onyx_create_compute_pipeline(g->device, VK_NULL_HANDLE, &pi, &pipeline);
        g->vkdes.pipelines[g->pipeline_count] = pipeline;
        t->ts.compute.pipeline                = g->pipeline_count++;
        assert(g->pipeline_count < LEN(g->vkdes.pipelines));
    }
}

#if 0
static void
create_backend_resources(Graph* g, IntArray tasks)
{
    arr_foreach(tasks, tid) {
        Task* t = get_task_(g, *tid); 
        if (t->type == ONYX_TASK_TYPE_RENDERPASS) {
            const Resource* r = get_task_color_attachment_res_(g, t, 0);
            assert(r->type == ONYX_RESOURCE_TYPE_IMAGE);
            if (!resource_bound(r)) {
            }
        }
    }
}
#endif

static NameBuffer sub_task_name(const Graph *g, int stid)
{
    NameBuffer buf;
    zero(buf.buf);
    const SubTask *st       = get_sub_task_const(g, stid);
    const char    *taskname = g->task_names[st->tid];
    const char    *stname   = "";
    switch (st->stage) {
        case VK_PIPELINE_STAGE_VERTEX_INPUT_BIT:
            stname = "_vetex_input";
            break;
        case VK_PIPELINE_STAGE_VERTEX_SHADER_BIT:
            stname = "_vertex_shader";
            break;
        case VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT:
            stname = "_fragment_shader";
            break;
        case VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT:
            stname = "_color_output";
            break;
        case VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT:
            stname = "_compute_shader";
            break;
        case VK_PIPELINE_STAGE_TRANSFER_BIT:
            stname = "_transfer";
            break;
        case VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT:
            stname = "_top_of_pipe";
            break;
        case VK_PIPELINE_STAGE_NONE:
            stname = "_none";
            break;
        case VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT:
            stname = "_bottom_of_pipe";
            break;
        default:
            fatal_error("Not implemented: %d", st->stage);
    }
    snprintf(buf.buf, sizeof(buf) - 1, "%s%s", taskname, stname);
    return buf;
}

static void print_sub_task_name(const Graph *g, int stid)
{
    NameBuffer buf = sub_task_name(g, stid);
    printf("%d %s\n", stid, buf.buf);
}

static int create_buffer(Graph *g, int size, VkBufferUsageFlags usage_flags,
                         OnyxMemoryType memtype)
{
    OnyxBuffer buf =
        onyx_request_buffer_region(g->onyx->memory, size, usage_flags, memtype);
    return onyx_buffer_arr_push(&g->buffers, buf);
}

static int create_image(Graph *g, const uint32_t width, const uint32_t height,
                        const VkFormat           format,
                        const VkImageUsageFlags  usageFlags,
                        const VkImageAspectFlags aspectMask,
                        const VkSampleCountFlags sampleCount,
                        const uint32_t mipLevels, const OnyxMemoryType type)
{
    OnyxImage img =
        onyx_create_image(g->onyx->memory, width, height, format, usageFlags,
                          aspectMask, sampleCount, mipLevels, type);
    return onyx_image_arr_push(&g->images, img);
}

static int create_depth_image(Graph *g, const uint32_t width,
                              const uint32_t height)
{
    return create_image(g, width, height, DEPTH_FORMAT,
                        VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT,
                        VK_IMAGE_ASPECT_DEPTH_BIT, VK_SAMPLE_COUNT_1_BIT, 1,
                        ONYX_MEMORY_DEVICE_TYPE);
}

static IntArray sort_sub_tasks(Graph *g)
{
    return hell_graph_topological_sort(
        &g->graph, g->final_sub_task,
        (HellGraphSortingParms){.prune_unconnected = true});
}

static void reverse_int_array(IntArray *arr)
{
    for (int i = 0, j = arr->count - 1; i < j; i++, j--) {
        int tmp       = arr->elems[i];
        arr->elems[i] = arr->elems[j];
        arr->elems[j] = tmp;
    }
}

static IntArray sort_tasks(Graph *g)
{
    IntArray subtasks = sort_sub_tasks(g);

    reverse_int_array(&subtasks);

    // reverse
    IntArray tasks = int_arr_create(NULL);
    for (const int *iter = subtasks.elems, *const end = iter + subtasks.count;
         iter < end; ++iter) {
        int tid = g->sub_tasks[*iter].tid;
        int_arr_push_if_unique(&tasks, &tid);
    }

    reverse_int_array(&tasks);

    int_arr_free(&subtasks);
    return tasks;
}

static void attachment_binding_fill_views(const AttachmentBinding *bindings,
                                          int         bindings_count,
                                          VkImageView views[10])
{
    assert(10 >= bindings_count);
    for (int i = 0, n = bindings_count; i < n; ++i) {
        bool found = false;
        for (int j = 0, m = bindings_count; j < m; ++j) {
            AttachmentBinding b = bindings[j];
            if (i == b.attachment_index) {
                found    = true;
                views[i] = b.img->view;
            }
        }
        assert(found);
    }
}

// should not create framebuffer if it is already creatied
static void task_create_framebuffers(Task *t)
{
    assert(task_is_renderpass_type(t));
    Graph *g = t->graph;

    AttachmentBindingArray bindings = task_renderpass_get_attachments(t);

    assert(bindings.count > 0);
    assert(g->renderpasses.count > t->ts.renderpass.renderpass);

    OnyxFramebuffer fb = {.attachment_count = bindings.count,
                          .rp               = task_get_renderpass(t)};

    uint32_t width = 0, height = 0;
    for (int i = 0, n = bindings.count; i < n; ++i) {
        width             = bindings.elems[i].img->extent.width;
        height            = bindings.elems[i].img->extent.height;
        fb.attachments[i] = bindings.elems[i];
    }
    fb.width  = width;
    fb.height = height;

    int fbid = t->ts.renderpass.framebuffer;
    assert(fbid != NONE && fbid < g->framebuffers.count);
    OnyxFramebuffer *cur_fb = &g->framebuffers.elems[fbid];

    // for the sake of the equals comparison
    fb.handle = cur_fb->handle;

    if (structs_equal(cur_fb, &fb))
        return;
    else
        *cur_fb = fb;

    if (fb.handle)
        vkDestroyFramebuffer(t->graph->device, fb.handle, NULL);

    // fill the views array in the order given by the outputs
    VkImageView views[10];
    attachment_binding_fill_views(bindings.elems, bindings.count, views);

    VkFramebufferCreateInfo ci = {.sType =
                                      VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO,
                                  .attachmentCount = bindings.count,
                                  .pAttachments    = views,
                                  .width           = width,
                                  .height          = height,
                                  .layers          = 1,
                                  .renderPass      = fb.rp->vkhandle};

    attachment_binding_arr_free(&bindings);

    V_ASSERT(vkCreateFramebuffer(g->device, &ci, NULL,
                                 &g->framebuffers.elems[fbid].handle));
}

static VkAccessFlags sub_task_get_access_flags(const SubTask *st, int rid)
{
    const ResRef *ref = sub_task_get_res_ref(st, rid);
    assert(ref);
    return res_ref_access_flags(ref);
}

static void add_barrier_task(Graph *g, int rid, const SubTask *st,
                             const SubTask *next_st)
{
    const ResRef *ref      = sub_task_get_res_ref(st, rid);
    const ResRef *next_ref = sub_task_get_res_ref(next_st, rid);

    // attachments will automatically get synced by their renderpass
    if (res_ref_is_attachment(ref) || res_ref_is_attachment(next_ref))
        return;

    const Resource *r = get_res_const_(g, rid);

    char buf[64];
    snprintf(buf, LEN(buf), "barrier_%d", g->task_count);

    Task *t = new_task(g, buf);
    t->type = ONYX_TASK_TYPE_BARRIER;

    OnyxSyncScope src, dst;

    src.stage_mask  = st->stage;
    src.access_mask = res_ref_access_flags(ref);
    dst.stage_mask  = next_st->stage;
    dst.access_mask = res_ref_access_flags(next_ref);

    if (r->type == ONYX_RESOURCE_TYPE_IMAGE) {
        t->ts.barrier.old_layout = res_ref_image_layout(ref);
        t->ts.barrier.new_layout = res_ref_image_layout(next_ref);
    }

    t->ts.barrier.src = src;
    t->ts.barrier.dst = dst;
    t->ts.barrier.rid = rid;

    int stid   = add_sub_task(g, t, VK_PIPELINE_STAGE_NONE);
    int f_stid = st - g->sub_tasks;
    int d_stid = next_st - g->sub_tasks;

    Wire w = {
        .sub_task_src = f_stid,
        .sub_task_dst = stid,
    };

    add_task_dep(g, w);

    w.sub_task_src = w.sub_task_dst;
    w.sub_task_dst = d_stid;
    add_task_dep(g, w);
}

static void insert_barrier_tasks(Graph *g)
{
    for (int stid = 0; stid < g->sub_task_count; ++stid) {
        const SubTask *st = &g->sub_tasks[stid];
        // TODO use subtask res references? or maybe not to avoid duplicates?
        for (int rid = 0; rid < g->rsrc_count; ++rid) {
            if (!sub_task_uses_resource(st, rid))
                continue;
            const Resource *r = get_res_const_(g, rid);
            if (r->type == ONYX_RESOURCE_TYPE_PUSH_CONSTANT)
                continue;
            const SubTask *nst = next_task_to_use_resource(g, stid, rid);
            if (!nst)
                continue;
            const ResRef *ref      = sub_task_get_res_ref(st, rid);
            const ResRef *ref_next = sub_task_get_res_ref(nst, rid);
            if (res_ref_is_attachment(ref) || res_ref_is_attachment(ref_next))
                continue; // attachments transitions handled by renderpasses
            const Task *t, *nt;
            t  = get_task_(g, st->tid);
            nt = get_task_(g, nst->tid);
            if (t->type == ONYX_TASK_TYPE_COMPUTE ||
                nt->type == ONYX_TASK_TYPE_COMPUTE ||
                t->type == ONYX_TASK_TYPE_COPY ||
                nt->type == ONYX_TASK_TYPE_COPY)
                add_barrier_task(g, rid, st, nst);
        }
    }
}

static void add_top_of_pipe_task(Graph *g)
{
    Task *t = new_task(g, "top_of_pipe");
    t->type = ONYX_TASK_TYPE_TOP_OF_PIPE;

    int stid = add_sub_task(g, t, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT);
    for (int rid = 0; rid < g->rsrc_count; ++rid) {
        task_add_resource(g, t, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, rid,
                          ONYX_RESOURCE_REFERENCE_TYPE_TOP_OF_PIPE, 0,
                          (OnyxResourceReferenceInfo){});
    }

    // add as input to all subtasks
    Wire w         = {0};
    w.sub_task_src = stid;
    for (int i = 0, n = g->sub_task_count - 1; i < n; ++i) {
        w.sub_task_dst = i;
        add_task_dep(g, w);
    }
}

define_array_type(VkWriteDescriptorSet, vk_write_desc);

// will not update descriptors that have not changed since the last time.
static void update_descriptors(Graph *g)
{
    ResRefArray               refs   = get_all_res_refs(g);
    VkWriteDescriptorSetArray writes = vk_write_desc_arr_create(NULL);

    arr_foreach(refs, ref)
    {
        if (!res_ref_is_descriptor_type(ref))
            continue;
        const int       rid = ref->rid;
        const Resource *r   = get_res_(g, rid);
        assert(r->bound);

        VkDescriptorType type = 0;
        switch (ref->type) {
            case ONYX_RESOURCE_REFERENCE_TYPE_UNIFORM_BUFFER:
                type = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
                break;
            case ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_BUFFER:
                type = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
                break;
            case ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_IMAGE:
                type = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
                break;
            default:
                fatal_error("Unimplemented");
        }
        VkDescriptorBufferInfo *bi = NULL;
        VkDescriptorImageInfo  *ii = NULL;

        OnyxDescriptorReferenceInfo di = ref->info.descriptor;
        union onyx_descriptor_info *cached_info =
            &g->descriptor_write_cache.descriptors[di.index][di.binding];
        bounds_check(cached_info, g->descriptor_write_cache.descriptors);

        // Will check if descriptor info is the same as what we wrote last time.
        // If it is: skip it.

        if (r->type == ONYX_RESOURCE_TYPE_BUFFER) {
            const OnyxBuffer *buffer = get_buffer(g, rid);
            bi                       = alloca(sizeof(*bi));
            bi->buffer               = buffer->buffer;
            bi->offset               = buffer->offset;
            bi->range                = buffer->size;

            if (structs_equal(&cached_info->buf, bi))
                continue;
            else
                cached_info->buf = *bi;
        } else if (r->type == ONYX_RESOURCE_TYPE_IMAGE) {
            const OnyxImage *image = get_image(g, rid);
            //assert(image->aspect_mask & di.image_aspect);
            VkImageView view = image->view;

            if (di.image_aspect == VK_IMAGE_ASPECT_DEPTH_BIT) {
                assert(image->depth_only_view);
                view = image->depth_only_view;
            }
            if (di.image_aspect == VK_IMAGE_ASPECT_STENCIL_BIT) {
                assert(image->stencil_only_view);
                view = image->stencil_only_view;
            }

            ii                     = alloca(sizeof(*ii));
            ii->imageLayout        = res_ref_image_layout(ref);
            ii->imageView          = view;
            ii->sampler            = NULL; // for now

            if (structs_equal(&cached_info->img, ii))
                continue;
            else
                cached_info->img = *ii;
        } else {
            fatal_error("Not implemented");
        }

        VkWriteDescriptorSet write = {
            .sType      = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
            .dstSet     = g->vkdes.descriptor_sets[ref->info.descriptor.index],
            .dstBinding = ref->info.descriptor.binding,
            .descriptorType  = type,
            .descriptorCount = 1, // for now
            .dstArrayElement = 0,
            .pBufferInfo     = bi,
            .pImageInfo      = ii};

        vk_write_desc_arr_push(&writes, write);
    }

    vkUpdateDescriptorSets(g->device, writes.count, writes.elems, 0, NULL);
    vk_write_desc_arr_free(&writes);
    onyx_res_ref_arr_free(&refs);
}

static VkImageUsageFlags get_image_usage_flags(const Graph *g, int rid,
                                               const IntArray subtasks)
{
    VkImageUsageFlags usage_flags = 0;
    for (const int *stid = subtasks.elems, *const end = stid + subtasks.count;
         stid < end; stid++) {

        print_sub_task_name(g, *stid);
        const SubTask *st  = get_sub_task_const(g, *stid);
        // const Task    *t   = get_task_(g, st->tid);
        const ResRef  *ref = sub_task_get_res_ref(st, rid);

        if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_TOP_OF_PIPE)
            continue;
        if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_IMAGE)
            usage_flags |= VK_IMAGE_USAGE_STORAGE_BIT;
        else if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_TRANSFER_TARGET) {
            if (ref->usage_flags == ONYX_RESOURCE_USAGE_WRITE_BIT)
                usage_flags |= VK_IMAGE_USAGE_TRANSFER_DST_BIT;
            else if (ref->usage_flags == ONYX_RESOURCE_USAGE_READ_BIT)
                usage_flags |= VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
            else
                fatal_error(
                    "Usage can only be read or write for transfer tasks");
        } else if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_DEPTH_ATTACHMENT) {
            usage_flags |= VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
        } else if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_COLOR_ATTACHMENT) {
            usage_flags |= VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
        } else {
            fatal_error("Not implemented yet. ref type: %d", ref->type);
        }
    }
    return usage_flags;
}

static VkBufferUsageFlags get_buffer_usage_flags(const Graph *g, int rid,
                                                 const IntArray subtasks)
{
    VkBufferUsageFlags usage_flags = 0;
    for (const int *stid = subtasks.elems, *const end = stid + subtasks.count;
         stid < end; stid++) {
        const SubTask *st  = get_sub_task_const(g, *stid);
        const ResRef  *ref = sub_task_get_res_ref(st, rid);
        print_sub_task_name(g, *stid);
        if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_TOP_OF_PIPE)
            continue;
        if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_UNIFORM_BUFFER) {
            usage_flags |= VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT;
        } else if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_TRANSFER_TARGET) {
            if (ref->usage_flags == ONYX_RESOURCE_USAGE_WRITE_BIT)
                usage_flags |= VK_BUFFER_USAGE_TRANSFER_DST_BIT;
            else if (ref->usage_flags == ONYX_RESOURCE_USAGE_READ_BIT)
                usage_flags |= VK_BUFFER_USAGE_TRANSFER_SRC_BIT;
            else
                fatal_error(
                    "Usage can only be read or write for transfer tasks");
        } else {
            fatal_error("Not implemented yet");
        }
    }

    return usage_flags;
}

void onyx_graph_bake(Graph *g)
{
    // graph can only be baked once. build a new graph.
    assert(g->final_sub_task != NONE);
    if (g->baked)
        return;
    add_top_of_pipe_task(g);
    add_implicit_dependencies(g);
    validata(g);
    insert_barrier_tasks(g);

    IntArray sub_tasks = sort_sub_tasks(g);

    // for (int i = 0; i < sub_tasks.count; ++i) {
    //     int stid = sub_tasks.elems[i];
    //     print_sub_task_name(g, stid);
    // }

    int_arr_free(&sub_tasks);

    create_vk_descriptors(g);
    create_renderpasses(g);
    create_graphics_pipelines(g);
    create_compute_pipelines(g);

    // bind unbound resources
    for (int rid = 0; rid < g->rsrc_count; ++rid) {
        Resource *r = &g->rsrcs[rid];
        // printf("Resource name: %s bound ? %s\n", r->name,
        //        r->bound ? "yes" : "no");
        if (r->bound)
            continue;
        // we check here so we can also confirm non graph owned resources all
        // have subtasks assigned
        sub_tasks = get_sub_tasks_referencing_resource(g, rid, NULL);
        fatal_condition(sub_tasks.count < 1,
                        "No subtasks referencing resource %s\n", r->name);
        if (!r->graph_owned)
            continue;
        switch (r->type) {
            case ONYX_RESOURCE_TYPE_IMAGE: {
                fatal_condition(!(r->rs.image.width && r->rs.image.height &&
                                  r->rs.image.format),
                                "Image %s is graph owned and has not specified "
                                "either width, "
                                "height, or format",
                                r->name);

                VkImageUsageFlags usage_flags =
                    get_image_usage_flags(g, rid, sub_tasks);
                VkImageAspectFlags aspect = VK_IMAGE_ASPECT_COLOR_BIT;

                if (r->rs.image.image_type == ONYX_IMAGE_DEPTH_TYPE)
                    aspect = VK_IMAGE_ASPECT_DEPTH_BIT;
                int img_index = create_image(
                    g, r->rs.image.width, r->rs.image.height,
                    r->rs.image.format, usage_flags, aspect,
                    r->rs.image.samples, 1, ONYX_MEMORY_DEVICE_TYPE);
                r->rs.image.data.index = img_index;
                r->bound               = true;
                break;
            }
            case ONYX_RESOURCE_TYPE_BUFFER: {
                if (!r->rs.buffer.size) {
                    fatal_error("Buffer %s has not been given a size", r->name);
                }
                VkBufferUsageFlags usage_flags =
                    get_buffer_usage_flags(g, rid, sub_tasks);
                assert(usage_flags);
                int buf_index = create_buffer(g, r->rs.buffer.size, usage_flags,
                                              ONYX_MEMORY_HOST_GRAPHICS_TYPE);
                r->rs.buffer.index = buf_index;
                r->bound           = true;
                break;
            }
            case ONYX_RESOURCE_TYPE_GEOMETRY:
                assert(0 && "Not implemented yet");
                break;
            case ONYX_RESOURCE_TYPE_PUSH_CONSTANT:
                break;
        }
        int_arr_free(&sub_tasks);
    }

    for (const Resource *iter = g->rsrcs, *const end = iter + g->rsrc_count;
         iter < end; ++iter) {
        if (iter->graph_owned)
            if (!iter->bound)
                fatal_error("%s resource is graph owned but not bound.",
                            iter->name);
    }

    for (int i = 0; i < g->bake_callback_count; ++i) {
        g->bake_callbacks[i].callback(g, g->bake_callbacks[i].data);
    }

    g->baked = true;
}

typedef struct {
    VkCommandBuffer cmdbuf;
    Graph          *graph;
} TaskParms;

static VkDescriptorSet get_descriptor_set(const Graph *g, int index)
{
    return g->vkdes.descriptor_sets[index];
}

static void task_update_push_constant(TaskParms              p,
                                      const VkPipelineLayout pipelayout,
                                      const ResRef *pc_ref, int64_t id)
{
    assert(pc_ref->type == ONYX_RESOURCE_REFERENCE_TYPE_PUSH_CONSTANT);
    Resource *pc_res = get_res_((Graph *)p.graph, pc_ref->rid);
    assert(pc_res->bound);
    OnyxResourcePushConstant *pc = &pc_res->rs.pc;

    pc->callback.func(pc->target_data, pc_ref->info.pushconstant.user_id, id,
                      pc->callback.user_data);

    // only update the constant data if it has actually changed
    vkCmdPushConstants(p.cmdbuf, pipelayout,
                       pc_ref->info.pushconstant.shader_stages, 0,
                       pc_ref->info.pushconstant.size, pc->target_data);
}

static void task_run_renderpass(const Task *t, TaskParms p)
{
    assert(t->type == ONYX_TASK_TYPE_RASTERIZE);
    const OnyxTaskRasterize *rptask = &t->ts.rasterize;
    const Graph             *g      = p.graph;

    const OnyxFramebuffer *fb = task_get_framebuffer(t);
    const OnyxRenderPass  *rp = task_get_renderpass(t);

    assert(fb->attachment_count == rp->attachment_count);

    // need to set the last_known_layout so that potential future copies and
    // such work, since they look to this
    for (int i = 0; i < fb->attachment_count; ++i) {
        OnyxAttachmentBinding b = fb->attachments[i];
        ((OnyxImage*)b.img)->last_known_layout = rp->attachments[b.attachment_index].final_layout;
    }

    VkCommandBuffer cb = p.cmdbuf;

    const uint32_t width  = fb->width;
    const uint32_t height = fb->height;

    OnyxGraphicsPipelineSettings ps =
        g->pipeline_settings[t->ts.rasterize.pipeline_settings_index];

    if (ps.dynamic_state_count > 0) {
        bool found_vp = false, found_sc = false;
        for (int i = 0; i < LEN(ps.dynamic_states); ++i) {
            if (ps.dynamic_states[i] == VK_DYNAMIC_STATE_SCISSOR)
                found_sc = true;
            if (ps.dynamic_states[i] == VK_DYNAMIC_STATE_VIEWPORT)
                found_vp = true;
        }
        assert(found_vp && found_sc);
        onyx_cmd_set_viewport_scissor(cb, 0, 0, width, height);
    }

    VkClearValue        clear_vals[8];
    AttachmentInfoArray attach_infos = task_get_attachment_infos(t);
    assert(attach_infos.count <= LEN(clear_vals));
    for (int i = 0; i < attach_infos.count; ++i) {
        const AttachmentInfo *ai = attach_infos.elems + i;
        clear_vals[i]            = ai->ref->info.attachment.clear_val;
    }

    VkRenderPassBeginInfo rpbi = {
        .sType           = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
        .clearValueCount = rp->attachment_count,
        .pClearValues    = clear_vals,
        .renderArea  = {.offset = {0, 0}, .extent = {fb->width, fb->height}},
        .renderPass  = rp->vkhandle,
        .framebuffer = fb->handle};

    vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS,
                      p.graph->vkdes.pipelines[rptask->pipeline]);

    const VkPipelineLayout pipelayout =
        g->vkdes.pipeline_layouts[t->reflection.pipeline_layout_index];
    assert(pipelayout != VK_NULL_HANDLE);

    // should be VK_NULL_HANDLE termniated
    VkDescriptorSet sets[12];
    memset(sets, 0, sizeof(sets));

    for (int i = 0, n = t->reflection.descriptor_count; i < n; ++i) {
        OnyxDescriptorReference ref = t->reflection.descriptor_references[i];
        assert(ref.set < LEN(sets));
        sets[ref.set] = get_descriptor_set(g, ref.set_index);
    }

    int                    first = 0, count = 0;
    const VkDescriptorSet *iter = sets;

    while (*iter == VK_NULL_HANDLE && first < 10) {
        first++;
        iter++;
    }

    while (*iter++ != VK_NULL_HANDLE)
        count++;

    if (count > 0) {
        vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, pipelayout,
                                first, count, sets, 0, NULL);
    }

    vkCmdBeginRenderPass(cb, &rpbi, VK_SUBPASS_CONTENTS_INLINE);

    const int     ndraws = rptask->draw_count;
    const ResRef *pc_ref = task_get_push_constant_ref(t);
    for (int i = 0; i < ndraws; ++i) {
        const SubTask *vert_input =
            get_sub_task_const(p.graph, rptask->draw_to_subtask_map[i]);
        assert(vert_input->stage == VK_PIPELINE_STAGE_VERTEX_INPUT_BIT);

        int32_t elem_count     = rptask->draw_elem_count[i];
        int32_t instance_count = rptask->draw_instance_count[i];

        if (pc_ref) {
            task_update_push_constant(p, pipelayout, pc_ref, i);
        }

        int          vert_buffer_count   = 0;
        VkBuffer     vert_buffers[16]    = {0};
        VkDeviceSize vert_offsets[16]    = {0};
        VkBuffer     index_buffer        = VK_NULL_HANDLE;
        VkDeviceSize index_buffer_offset = 0;
        VkIndexType  index_type          = 0;

        bool drew = false;

        const int nrefs = vert_input->refs.count;
        for (int i = 0; i < nrefs; ++i) {
            const ResRef *ref = vert_input->refs.elems + i;

            if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_GEOMETRY) {
                // TODO make instance count part of the resource reference
                const OnyxGeometry *geo = get_geometry(g, ref->rid);
                onyx_draw_geo_elem_count(cb, geo, elem_count, instance_count);
                drew = true;
            } else if (ref->type ==
                       ONYX_RESOURCE_REFERENCE_TYPE_VERTEX_BUFFER) {
                const OnyxBuffer *buf = get_buffer(g, ref->rid);
                int32_t           b   = ref->info.vertexbuffer.binding;
                assert(
                    vert_buffers[b] == 0 &&
                    "Attempting to bind to the same vertex buffer slot twice");
                vert_buffers[b] = buf->buffer;
                vert_offsets[b] = buf->offset;
                vert_buffer_count++;
                assert(vert_buffer_count < LEN(vert_buffers));
            } else if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_INDEX_BUFFER) {
                assert(index_buffer == VK_NULL_HANDLE &&
                       "There can only be one index buffer per draw");
                const OnyxBuffer *buf = get_buffer(g, ref->rid);
                index_buffer          = buf->buffer;
                index_buffer_offset   = buf->offset;
                index_type            = ref->info.indexbuffer.type;
            }
        }

        // make sure we have no gaps in the bindings
        for (int i = 0; i < vert_buffer_count; ++i) {
            fatal_condition(vert_buffers[i] == 0,
                            "gap in vertex buffer binding");
            fatal_condition(vert_offsets[i] == 0, "gap in vertex offset");
        }

        if (vert_buffer_count)
            vkCmdBindVertexBuffers(cb, 0, vert_buffer_count, vert_buffers,
                                   vert_offsets);

        if (index_buffer)
            vkCmdBindIndexBuffer(cb, index_buffer, index_buffer_offset,
                                 index_type);

        if (vert_buffer_count && !index_buffer) {
            vkCmdDraw(cb, elem_count, instance_count, 0, 0);
            drew = true;
        } else if (index_buffer) {
            vkCmdDrawIndexed(cb, elem_count, instance_count, 0, 0, 0);
            drew = true;
        }

        fatal_condition(!drew && instance_count,
                        "Non-zero instance count, yet we never drew anything");
    }

    vkCmdEndRenderPass(cb);
}

static void task_run_custom_renderpass(const Task *t, TaskParms p)
{
    assert(t->type == ONYX_TASK_TYPE_CUSTOM_RENDERPASS);

    const OnyxFramebuffer *fb = task_get_framebuffer(t);

    VkCommandBuffer cb = p.cmdbuf;

    const uint32_t width  = fb->width;
    const uint32_t height = fb->height;

    VkRenderPassBeginInfo rpbi = {
        .sType           = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
        .clearValueCount = 0,
        .renderArea      = {.offset = {0, 0}, .extent = {width, height}},
        .renderPass      = fb->rp->vkhandle,
        .framebuffer     = fb->handle};

    vkCmdBeginRenderPass(cb, &rpbi, VK_SUBPASS_CONTENTS_INLINE);

    t->ts.custom.fn(p.cmdbuf, t->ts.custom.data);

    vkCmdEndRenderPass(cb);
}

static void task_run_custom(const Task *t, TaskParms p)
{
    t->ts.custom.fn(p.cmdbuf, t->ts.custom.data);
}

static void task_run_compute(const Task *t, TaskParms p)
{
    VkCommandBuffer cb = p.cmdbuf;
    OnyxGraph      *g  = t->graph;

    const OnyxTaskCompute *ct = &t->ts.compute;
    vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_COMPUTE,
                      g->vkdes.pipelines[ct->pipeline]);

    // should be VK_NULL_HANDLE termniated
    VkDescriptorSet sets[12];
    memset(sets, 0, sizeof(sets));

    for (int i = 0, n = t->reflection.descriptor_count; i < n; ++i) {
        OnyxDescriptorReference ref = t->reflection.descriptor_references[i];
        assert(ref.set < LEN(sets));
        sets[ref.set] = get_descriptor_set(g, ref.set_index);
    }

    int                    first = 0, count = 0;
    const VkDescriptorSet *iter = sets;

    while (*iter == VK_NULL_HANDLE) {
        first++;
        iter++;
    }

    while (*iter++ != VK_NULL_HANDLE)
        count++;

    const VkPipelineLayout pipelayout =
        g->vkdes.pipeline_layouts[t->reflection.pipeline_layout_index];
    if (count > 0) {
        vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_COMPUTE, pipelayout,
                                first, count, sets, 0, NULL);
    }

    const ResRef *pc_ref = task_get_push_constant_ref(t);
    if (pc_ref) {
        task_update_push_constant(p, pipelayout, pc_ref, 0);
    }

    vkCmdDispatch(cb, ct->wg_sizes.x, ct->wg_sizes.y, ct->wg_sizes.z);
}

static void insert_image_memeory_barrier(VkCommandBuffer        cb,
                                         const OnyxTaskBarrier *tb,
                                         const OnyxImage       *image)
{
    VkImageMemoryBarrier b = {
        .sType         = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
        .srcAccessMask = tb->src.access_mask,
        .dstAccessMask = tb->dst.access_mask,
        .image         = image->handle,
        .oldLayout     = tb->old_layout,
        .newLayout     = tb->new_layout,
        .subresourceRange =
            (VkImageSubresourceRange){.aspectMask   = image->aspect_mask,
                                      .levelCount   = image->mip_levels,
                                      .layerCount   = 1,
                                      .baseMipLevel = 0,
                                      .baseArrayLayer = 0},
    };
    vkCmdPipelineBarrier(cb, tb->src.stage_mask, tb->dst.stage_mask,
                         VK_DEPENDENCY_BY_REGION_BIT, 0, NULL, 0, NULL, 1, &b);
    ((OnyxImage *)image)->last_known_layout = tb->new_layout;
}

static void insert_buffer_member_barrier(VkCommandBuffer        cb,
                                         const OnyxTaskBarrier *tb,
                                         const OnyxBuffer      *buffer)
{
    VkBufferMemoryBarrier b = {
        .sType         = VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER,
        .srcAccessMask = tb->src.access_mask,
        .dstAccessMask = tb->dst.access_mask,
        .buffer        = buffer->buffer,
        .size          = buffer->size,
        .offset        = buffer->offset,
    };
    vkCmdPipelineBarrier(cb, tb->src.stage_mask, tb->dst.stage_mask, 0, 0, NULL,
                         1, &b, 0, NULL);
}

static void task_run_barrier(const Task *t, TaskParms p)
{
    assert(t->type == ONYX_TASK_TYPE_BARRIER);
    VkCommandBuffer        cb = p.cmdbuf;
    const Graph           *g  = p.graph;
    const OnyxTaskBarrier *tb = &t->ts.barrier;
    const Resource        *r  = get_res_const_(g, tb->rid);

    if (r->type == ONYX_RESOURCE_TYPE_IMAGE) {
        const OnyxImage *image = get_image(g, tb->rid);
        insert_image_memeory_barrier(cb, tb, image);
    } else if (r->type == ONYX_RESOURCE_TYPE_BUFFER) {
        const OnyxBuffer *buffer = resource_get_buffer(r, g);
        insert_buffer_member_barrier(cb, tb, buffer);
    } else {
        fatal_error("Unsupported");
    }
}

static void task_run_copy(const Task *t, TaskParms p)
{
    assert(t->type == ONYX_TASK_TYPE_COPY);
    OnyxGraph      *g  = p.graph;
    VkCommandBuffer cb = p.cmdbuf;

    const int       src_rid = t->ts.copy.src;
    const int       dst_rid = t->ts.copy.dst;
    const Resource *src     = get_res_const_(g, src_rid);
    const Resource *dst     = get_res_const_(g, dst_rid);

    if (src->type == ONYX_RESOURCE_TYPE_BUFFER) {
        const OnyxBuffer *buffer = resource_get_buffer(src, g);
        if (dst->type == ONYX_RESOURCE_TYPE_IMAGE) {
            OnyxImage *image = resource_get_image_mut(dst, g);
            onyx_cmd_copy_buffer_to_image(cb, 0, buffer, image);
        } else if (dst->type == ONYX_RESOURCE_TYPE_BUFFER) {
            OnyxBuffer *dst_buf = resource_get_buffer_mut(dst, g);
            onyx_cmd_copy_buffer(cb, buffer, dst_buf);
        } else {
            fatal_error("Unsupported");
        }
    } else if (src->type == ONYX_RESOURCE_TYPE_IMAGE) {
        const OnyxImage *src_image = resource_get_image(src, g);
        if (dst->type == ONYX_RESOURCE_TYPE_IMAGE) {
            OnyxImage *image = resource_get_image_mut(dst, g);
            onyx_cmd_copy_or_blit_image_full(cb, src_image, image,
                                             VK_FILTER_NEAREST);
        } else if (dst->type == ONYX_RESOURCE_TYPE_BUFFER) {
            OnyxBuffer *buffer = resource_get_buffer_mut(dst, g);
            onyx_cmd_copy_image_to_buffer(cb, 0, t->ts.copy.img_aspect, src_image, buffer);
        } else {
            fatal_error("Unsupported");
        }
    } else {
        fatal_error("Unsupported");
    }
}

static void task_run(const Task *t, TaskParms p)
{
    // const char *name = task_name(t);
    // printf("Running task %s\n", name);
    switch (t->type) {
        case ONYX_TASK_TYPE_RASTERIZE:
            return task_run_renderpass(t, p);
        case ONYX_TASK_TYPE_CUSTOM_RENDERPASS:
            return task_run_custom_renderpass(t, p);
        case ONYX_TASK_TYPE_CUSTOM:
            return task_run_custom(t, p);
        case ONYX_TASK_TYPE_BARRIER:
            return task_run_barrier(t, p);
        case ONYX_TASK_TYPE_COMPUTE:
            return task_run_compute(t, p);
        case ONYX_TASK_TYPE_COPY:
            return task_run_copy(t, p);
        case ONYX_TASK_TYPE_PRESENT:
        case ONYX_TASK_TYPE_TOP_OF_PIPE:
        case ONYX_TASK_TYPE_NULL:
            break;
    };
}

static void bind_buffer(Resource *r, const OnyxBuffer *src)
{
    assert(r->type == ONYX_RESOURCE_TYPE_BUFFER);
    // we do not need to know the size if buffer is not graph owned
    // assert(r->rs.buffer.size == src->size);
    r->rs.buffer.size = src->size;
    r->rs.buffer.ptr  = src;
    r->bound          = true;
}

static void bind_image(Resource *r, const OnyxImage *src)
{
    assert(r->type == ONYX_RESOURCE_TYPE_IMAGE);
    assert(r->rs.image.format == src->format);
    assert(r->rs.image.width == src->extent.width);
    assert(r->rs.image.height == src->extent.height);
    r->rs.image.data.ptr = src;
    r->bound             = true;
}

static void bind_geo(Resource *r, const OnyxGeometry *src)
{
    assert(r->type == ONYX_RESOURCE_TYPE_GEOMETRY);
    r->rs.geo.ptr = src;
    r->bound      = true;
}

static void bind_push_constant(Resource *r, const OnyxPushConstantCallback *src)
{
    assert(r->type == ONYX_RESOURCE_TYPE_PUSH_CONSTANT);
    r->rs.pc.callback = *src;
    r->bound          = true;
}

void onyx_graph_execute(OnyxGraph *g, VkCommandBuffer cb,
                        const OnyxGraphExecuteArgs *args)
{
    assert(g->baked);
    IntArray tasks = sort_tasks(g);

    // bind app owned resources
    for (int i = 0; i < args->binding_count; ++i) {
        const OnyxGraphBinding *b   = &args->bindings[i];
        int                     rid = find_resource(g, b->name);
        if (rid == NOT_FOUND)
            fatal_error("%s not found", b->name);
        Resource *r = get_res_(g, rid);
        if (r->graph_owned)
            fatal_error("%s is graph owned", b->name);
        if (r->bound)
            fatal_error("%s is already bound", b->name);
        switch (r->type) {
            case ONYX_RESOURCE_TYPE_BUFFER:
                bind_buffer(r, b->src.buffer);
                break;
            case ONYX_RESOURCE_TYPE_IMAGE:
                bind_image(r, b->src.img);
                break;
            case ONYX_RESOURCE_TYPE_GEOMETRY:
                bind_geo(r, b->src.geo);
                break;
            case ONYX_RESOURCE_TYPE_PUSH_CONSTANT:
                bind_push_constant(r, &b->src.pc);
                break;
        }
    }

    // initialize push_constants so that we at least run their callbacks one
    // time
    for (int i = 0, n = g->rsrc_count; i < n; ++i) {
        Resource *r = g->rsrcs + i;
        if (r->type == ONYX_RESOURCE_TYPE_PUSH_CONSTANT)
            memset(r->rs.pc.target_data, 0, sizeof(r->rs.pc.target_data));
        if (!r->bound)
            fatal_error("%s resource is not bound. All resources must be bound "
                        "at this point.",
                        r->name);
    }

    update_descriptors(g);
    for_each_renderpass_task(g, task_create_framebuffers);

    for (int i = 0, n = tasks.count; i < n; ++i) {
        int       tid = tasks.elems[i];
        OnyxTask *t   = get_task_(g, tid);

        task_run(t, (TaskParms){.cmdbuf = cb, .graph = g});
    }

    for (int i = 0, n = g->rsrc_count; i < n; ++i) {
        Resource *r = g->rsrcs + i;
        // clear the binding for next frame
        if (!r->graph_owned)
            r->bound = false;
    }
}

OnyxTaskId onyx_graph_add_custom_task(OnyxGraph *g, const char *name,
                                      OnyxGraphCustomTaskParms parms)
{
    assert(parms.data);
    assert(parms.fn);
    assert(parms.stages);

    Task *t           = new_task(g, name);
    t->type           = ONYX_TASK_TYPE_CUSTOM;
    t->ts.custom.data = parms.data;
    t->ts.custom.fn   = parms.fn;
    add_sub_task(g, t, parms.stages);

    return task_id_old(g, t);
}

void onyx_graph_add_image_to_task(OnyxGraph *g, OnyxTaskId tid,
                                  const char                 *name,
                                  OnyxGraphResourceImageParms parms)
{
    Task *t = get_task(g, tid);

    const int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_IMAGE);
    task_add_resource(g, t, parms.stages, rid, parms.ref_type, parms.res_usage,
                      (ResRefInfo){});
}

// should not need this, could infer from order (but maybe we don't want to)
void onyx_graph_add_task_dependency(OnyxGraph *g, OnyxTaskId dst_id,
                                    OnyxTaskId src_id)
{
    assert(dst_id < g->task_count && src_id < g->task_count);

    Task *src = get_task(g, src_id);
    Task *dst = get_task(g, dst_id);

    arr_foreach(dst->sub_tasks, dstid)
    {
        arr_foreach(src->sub_tasks, srcid)
        {
            Wire w = {.sub_task_dst = *dstid, .sub_task_src = *srcid};
            add_task_dep(g, w);
        }
    }
}

const OnyxRenderPass *onyx_graph_get_task_renderpass(const OnyxGraph *g,
                                                     OnyxTaskId       task_id)
{
    const Task *t = get_task_const_(g, task_id);
    return task_get_renderpass(t);
}

void onyx_graph_add_bake_callback(OnyxGraph *g, OnyxBakeCallback cb)
{
    assert(g->bake_callback_count < LEN(g->bake_callbacks));
    g->bake_callbacks[g->bake_callback_count++] = cb;
}

void onyx_graph_add_descriptor_to_task(OnyxGraph *g, OnyxTaskId tid,
                                       const char *name, int set, int binding,
                                       OnyxResourceType type)
{
    const int rid = find_or_add_resource(g, name, type);

    Task *t = get_task(g, tid);
    task_add_descriptor(t, rid, set, binding, 0);
}

static void task_add_descriptor(Task *t, const int rid, int set, int binding, VkImageAspectFlags image_aspect)
{
    assert(t->reflection.descriptor_count > 0);
    Graph *g = t->graph;

    const OnyxDescriptorReference *dref = NULL;
    for (int i = 0; i < t->reflection.descriptor_count; ++i) {
        if (t->reflection.descriptor_references[i].set == set &&
            t->reflection.descriptor_references[i].binding == binding) {
            dref = &t->reflection.descriptor_references[i];
            break;
        }
    }

    if (!dref)
        fatal_error(
            "No descriptor found to match %s with set %d and binding %d",
            g->rsrcs[rid].name, set, binding);

    const OnyxDescriptorSet *dset = &g->pipedes->descriptor_sets[dref->set_index];
    const OnyxDescriptor *d = &g->pipedes->descriptors[dset->descriptors[dref->binding]];

    VkPipelineStageFlags stages = 0;
    // this is dumb. need to either reflect this or have the user provide it and
    // then validate it.
    if (t->type == ONYX_TASK_TYPE_RASTERIZE)
        stages = VK_PIPELINE_STAGE_VERTEX_SHADER_BIT;
    else if (t->type == ONYX_TASK_TYPE_COMPUTE)
        stages = VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT;
    else {
        assert(0 && "Task cannot use a uniform buffer");
    }

    OnyxResourceReferenceType restype = -1;
    switch (d->type) {
        case VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER:
            restype = ONYX_RESOURCE_REFERENCE_TYPE_UNIFORM_BUFFER;
            break;
        case VK_DESCRIPTOR_TYPE_STORAGE_IMAGE: {
            restype = ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_IMAGE;
            assert(image_aspect && "If using a storage image descriptor you must specify an aspect of the image");
            break;
                                               }
        case VK_DESCRIPTOR_TYPE_STORAGE_BUFFER:
            restype = ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_BUFFER;
            break;
        default:
            assert(0 && "Not supported yet");
    }

    int rw_bits = 0;
    if (!dref->non_readable)
        rw_bits |= R_BIT;
    if (!dref->non_writeable)
        rw_bits |= W_BIT;

    task_add_resource(
        g, t, stages, rid, restype, rw_bits,
        (OnyxResourceReferenceInfo){
            .descriptor = {.index = dref->set_index, .binding = binding, .image_aspect = image_aspect}});
}

void onyx_graph_add_push_constant_to_task(OnyxGraph *g, OnyxTaskId tid,
                                          const char           *name,
                                          OnyxPushConstantParms pc_parms)
{
    const int rid =
        find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_PUSH_CONSTANT);

    Task *t = get_task(g, tid);
    assert(t->reflection.push_constant_count > 0);

    OnyxPushConstantInfo pci =
        g->pipedes->push_constant_infos[t->reflection.push_constant_indices[0]];
    assert(g->pipedes->struct_info_count > pci.struct_info_index);
    OnyxPipelineStructInfo si = g->pipedes->struct_infos[pci.struct_info_index];
    assert(si.size > 0);

    // TODO change these to just a initial recording stage
    VkPipelineStageFlags stages = 0;
    if (t->type == ONYX_TASK_TYPE_COMPUTE)
        stages = VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT;
    else if (t->type == ONYX_TASK_TYPE_RASTERIZE)
        stages = VK_PIPELINE_STAGE_VERTEX_SHADER_BIT;
    else
        assert(0 && "Not implemented yet");

    assert(si.size <= sizeof(((OnyxResourcePushConstant *)NULL)->target_data));
    task_add_resource(
        g, t, stages, rid, ONYX_RESOURCE_REFERENCE_TYPE_PUSH_CONSTANT,
        R_BIT | W_BIT,
        (OnyxResourceReferenceInfo){.pushconstant.size    = si.size,
                                    .pushconstant.user_id = pc_parms.user_id,
                                    .pushconstant.shader_stages = pci.stages});
}

void onyx_graph_bind_push_constant(OnyxGraph *g, const char *name,
                                   OnyxPushConstantCallback cb)
{
    const int rid = find_resource(g, name);

    OnyxResource *res = get_res_(g, rid);
    assert(res->type == ONYX_RESOURCE_TYPE_PUSH_CONSTANT);
    if (res->bound)
        fatal_error("Resource %s is already bound", name);
    res->rs.pc.callback = cb;
    res->bound          = true;
}

static bool task_is_renderpass_type(const Task *t)
{
    return (t->type == ONYX_TASK_TYPE_RASTERIZE) ||
           (t->type == ONYX_TASK_TYPE_CUSTOM_RENDERPASS);
}

static AttachmentInfo get_attachment_info(const Graph *g, const int stid)
{
    const SubTask *st = &g->sub_tasks[stid];
    assert(st->refs.count > 0);
    const ResRef *ref       = &st->refs.elems[0];
    const int     cao_0_rid = ref->rid;
    assert(ref->type == ONYX_RESOURCE_REFERENCE_TYPE_COLOR_ATTACHMENT);
    const Resource *res = get_res_const_(g, cao_0_rid);
    assert(res->type == ONYX_RESOURCE_TYPE_IMAGE);

    AttachmentInfo out = {.stid = stid, .st = st, .ref = ref, .res = res};
    return out;
}

static int task_index(const Task *t) { return t - t->graph->tasks; }

static const char *task_name(const Task *t)
{
    int tid = task_index(t);
    return t->graph->task_names[tid];
}

// caller must free
static AttachmentInfoArray task_get_attachment_infos(const Task *t)
{
    AttachmentInfoArray arr = attachment_info_arr_create(NULL);
    const Graph        *g   = t->graph;

    IntArray stids = t->sub_tasks;
    arr_foreach(stids, stid)
    {
        const SubTask *st = get_sub_task_const(g, *stid);
        for (int i = 0; i < st->refs.count; ++i) {
            const ResRef *ref = &st->refs.elems[i];
            if (!res_ref_is_attachment(ref))
                continue;
            const Resource *res = get_res_const_(g, ref->rid);
            assert(res->type == ONYX_RESOURCE_TYPE_IMAGE);

            AttachmentInfo info = {
                .stid = *stid, .st = st, .res = res, .ref = ref};
            attachment_info_arr_push(&arr, info);
        }
    }

    if (!arr.count)
        fatal_error("%s has no attachments", task_name(t));
    AttachmentInfoArray arr_sorted = attachment_info_arr_create(NULL);
    attachment_info_arr_set_cap(&arr_sorted, arr.count);
    arr_foreach(arr, ai)
    {
        assert(ai->ref->info.attachment.ref.framebuffer_index < arr.count);
        arr_sorted.elems[ai->ref->info.attachment.ref.framebuffer_index] = *ai;
        arr_sorted.count++;
    };

    attachment_info_arr_free(&arr);
    return arr_sorted;
}

static const OnyxGeometry *get_geometry(const Graph *g, int rid)
{
    const Resource *r = get_res_const_(g, rid);
    assert(r->type == ONYX_RESOURCE_TYPE_GEOMETRY);
    assert(r->bound);
    return r->rs.geo.ptr;
}

static const OnyxImage *get_image(const Graph *g, int rid)
{
    const Resource *r = get_res_const_(g, rid);
    assert(r->type == ONYX_RESOURCE_TYPE_IMAGE);
    assert(r->bound);
    return resource_get_image(r, g);
}

static const OnyxBuffer *get_buffer(const Graph *g, int rid)
{
    const Resource *r = get_res_const_(g, rid);
    assert(r->type == ONYX_RESOURCE_TYPE_BUFFER);
    assert(r->bound);
    return resource_get_buffer(r, g);
}

OnyxTaskId onyx_graph_get_last_task(OnyxGraph *g)
{
    IntArray tasks = sort_tasks(g);
    assert(tasks.count);
    int id = *int_arr_last(&tasks);
    int_arr_free(&tasks);
    return id;
}

static const ResRef *task_get_push_constant_ref(const Task *t)
{
    for (int i = 0; i < t->sub_tasks.count; ++i) {
        const SubTask *st = get_sub_task_const(t->graph, t->sub_tasks.elems[i]);
        const ResRefArray *refs = sub_task_res_refs(st);
        arr_foreach(*refs, ref)
        {
            if (ref->type == ONYX_RESOURCE_REFERENCE_TYPE_PUSH_CONSTANT)
                return ref;
        }
    }
    return NULL;
}

void onyx_graph_set_image_properties(OnyxGraph *g, const char *name,
                                     OnyxImageType type, uint32_t width,
                                     uint32_t height, OnyxFormat format,
                                     VkSampleCountFlags samples,
                                     bool               graph_owned)
{
    const int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_IMAGE);
    Resource *res = get_res_(g, rid);

    OnyxResourceImage img = {
        .image_type = type,
        .format     = (VkFormat)format,
        .width      = width,
        .height     = height,
        .samples    = samples,
    };
    res->rs.image    = img;
    res->graph_owned = graph_owned;
}

void onyx_graph_set_buffer_properties(OnyxGraph *g, const char *name,
                                      uint64_t size, bool graph_owned)
{
    const int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_BUFFER);
    Resource *res = get_res_(g, rid);

    OnyxResourceBuffer buf = {
        .size = size,
    };

    res->rs.buffer   = buf;
    res->graph_owned = graph_owned;
}

OnyxTaskId onyx_graph_add_image_copy_task(OnyxGraph *g, const char *name,
                                          const char *src, const char *dst)
{
    return onyx_graph_add_copy_task(g, name, src, ONYX_RESOURCE_TYPE_IMAGE, dst,
                                    ONYX_RESOURCE_TYPE_IMAGE);
}

OnyxTaskId onyx_graph_add_copy_task_(OnyxGraph *g, const char *name,
                                    const char *src, OnyxResourceType src_type,
                                    const char *dst, OnyxResourceType dst_type,
                                    VkImageAspectFlags image_aspect
                                    )
{
    Task *t = new_task(g, name);
    t->type = ONYX_TASK_TYPE_COPY;
    add_sub_task(g, t, VK_PIPELINE_STAGE_TRANSFER_BIT);

    if ((src_type == ONYX_RESOURCE_TYPE_BUFFER && dst_type == ONYX_RESOURCE_TYPE_IMAGE) ||
        (dst_type == ONYX_RESOURCE_TYPE_BUFFER && src_type == ONYX_RESOURCE_TYPE_IMAGE)) {
        assert(image_aspect && "Image aspect must be specified in the case of a buffer/image copy");
    }


    const int src_rid = find_or_add_resource(g, src, src_type);
    task_add_resource(g, t, VK_PIPELINE_STAGE_TRANSFER_BIT, src_rid,
                      ONYX_RESOURCE_REFERENCE_TYPE_TRANSFER_TARGET,
                      ONYX_RESOURCE_USAGE_READ_BIT, (ResRefInfo){});

    const int dst_rid = find_or_add_resource(g, dst, dst_type);
    task_add_resource(g, t, VK_PIPELINE_STAGE_TRANSFER_BIT, dst_rid,
                      ONYX_RESOURCE_REFERENCE_TYPE_TRANSFER_TARGET,
                      ONYX_RESOURCE_USAGE_WRITE_BIT, (ResRefInfo){});

    t->ts.copy.src = src_rid;
    t->ts.copy.dst = dst_rid;
    t->ts.copy.img_aspect = image_aspect;

    return task_id(t);
}

OnyxTaskId onyx_graph_add_copy_task(OnyxGraph *g, const char *name,
                                    const char *src, OnyxResourceType src_type,
                                    const char *dst, OnyxResourceType dst_type)
{
    return onyx_graph_add_copy_task_(g, name, src, src_type, dst, dst_type, 0);
}

int32_t onyx_graph_add_compute_task_for_image(OnyxGraph  *graph,
                                              const char *name,
                                              uint32_t    program_number,
                                              const char *image_name)
{
    OnyxGraphComputeParms parms = {
        .program            = program_number,
        .wg_size_type       = ONYX_COMPUTE_WORKGROUP_SIZE_TYPE_FROM_IMAGE,
        .wg_size.image_name = image_name,
    };

    OnyxGraphResourceImageParms img_parms = {
        .stages    = VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        .ref_type  = ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_IMAGE,
        .res_usage = ONYX_RESOURCE_USAGE_WRITE_BIT,
    };

    TaskId id = onyx_graph_add_compute_task(graph, name, parms);

    onyx_graph_add_image_to_task(graph, id, image_name, img_parms);

    return id;
}

void onyx_graph_add_push_constant_to_task_(OnyxGraph *g, int32_t tid,
                                           const char *name,
                                           uint64_t    user_data_id,
                                           OnyxPushConstantCallback callback)
{
    OnyxTaskId task = tid;
    onyx_graph_add_push_constant_to_task(
        g, task, name, (OnyxPushConstantParms){.user_id = user_data_id});

    onyx_graph_bind_push_constant(g, name, callback);
}

int32_t onyx_graph_add_image_copy_task_(OnyxGraph *g, const char *name,
                                        const char *src, const char *dst)
{
    TaskId tid = onyx_graph_add_image_copy_task(g, name, src, dst);
    return tid;
}

void onyx_graph_add_image_output(OnyxGraph *g, const char *name,
                                 VkImageLayout layout)
{
    Task *t = get_final_task(g);

    int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_IMAGE);
    task_add_resource(g, t, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, rid,
                      ONYX_RESOURCE_REFERENCE_TYPE_OUTPUT, R_BIT,
                      (ResRefInfo){.output.img_layout = layout});
}

void onyx_graph_add_buffer_output(OnyxGraph *g, const char *name)
{
    Task *t = get_final_task(g);

    int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_BUFFER);
    task_add_resource(g, t, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, rid,
                      ONYX_RESOURCE_REFERENCE_TYPE_OUTPUT, R_BIT,
                      (ResRefInfo){});
}

void onyx_graph_add_image_descriptor_to_task(OnyxGraph *g, OnyxTaskId tid,
                                          const char *name, int set,
                                          int binding, VkImageAspectFlags aspect)
{
    const int rid = find_or_add_resource(g, name, ONYX_RESOURCE_TYPE_IMAGE);

    Task *t = get_task(g, tid);
    task_add_descriptor(t, rid, set, binding, aspect);
}

OnyxGeometryTemplate
onyx_graph_geo_template_from_program(const OnyxGraph *g, OnyxProgramIndex index,
                                     OnyxGeometryFlags geo_flags,
                                     OnyxGeometryType  geo_type)
{
    const OnyxRasterizationReflection *refl =
        &g->reflection->programs[index].rasterize;
    OnyxGeometryTemplate geo_templ = geo_templ_from_renderpass_refl(refl);
    geo_templ.flags                = geo_flags;
    geo_templ.type                 = geo_type;

    return geo_templ;
}

void onyx_graph_update_draw_call(OnyxGraph *g, OnyxTaskId task, int32_t dc,
                                 uint32_t elem_count, uint32_t instance_count)
{
    Task *t = get_task(g, task);
    assert(t->type == ONYX_TASK_TYPE_RASTERIZE);
    assert(dc < t->ts.rasterize.draw_count);

    t->ts.rasterize.draw_elem_count[dc]     = elem_count;
    t->ts.rasterize.draw_instance_count[dc] = instance_count;
}
