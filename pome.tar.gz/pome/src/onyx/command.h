#ifndef ONYX_V_COMMAND_H
#define ONYX_V_COMMAND_H

#include "video.h"

typedef struct OnyxV_Command{
    VkCommandPool        pool;
    VkCommandBuffer      buffer;
    VkSemaphore          semaphore;
    VkFence              fence;
    uint32_t             queue_family;
    const OnyxInstance* instance;
} OnyxCommand;

typedef struct OnyxCommandPool {
    VkDevice         device;
    VkCommandPool    pool;
    VkCommandBuffer* cmdbufs;
    uint32_t         queue_family;
    uint32_t         cmdbuf_count;
} OnyxCommandPool;

OnyxCommand onyx_create_command(const OnyxInstance* instance, const OnyxQueueType);

int onyx_command_pool_create(Onyx* onyx, OnyxQueueType t, uint32_t bufcount, OnyxCommandPool* cp);
void onyx_command_pool_reset(OnyxCommandPool* p);

VkResult onyx_reset_command_pool(VkDevice device, VkCommandPool pool, VkCommandPoolResetFlags flags);

VkResult
onyx_create_command_pool(    
        const Onyx *onyx,
        uint32_t queueFamilyIndex,
        VkCommandPoolCreateFlags flags,
        VkCommandPool *pool);

VkResult
onyx_allocate_command_buffers(
        VkDevice device,
        VkCommandPool pool,
        uint32_t count,
        VkCommandBuffer *buffers);

OnyxCommandPool onyx_create_command_pool_(VkDevice device,
    uint32_t queueFamilyIndex,
    VkCommandPoolCreateFlags poolflags,
    uint32_t bufcount);
void onyx_destroy_command_pool(VkDevice device, OnyxCommandPool* pool);
void onyx_begin_command_buffer(VkCommandBuffer cmdBuf);
void onyx_begin_command_buffer_one_time_submit(VkCommandBuffer cmdBuf);
void onyx_end_command_buffer(VkCommandBuffer cmdBuf);

void onyx_submit_and_wait(OnyxCommand* cmd, const uint32_t queueIndex);

void onyx_destroy_command(OnyxCommand);

VkResult onyx_wait_for_fence_and_reset(VkDevice device, VkFence fence);
void onyx_wait_for_fence(VkDevice device, VkFence* fence);
void onyx_wait_for_fence_time_out(VkDevice device, VkFence* fence, uint64_t timeout_ns);
void onyx_reset_command(OnyxCommand* cmd);
void onyx_wait_for_fence_no_reset(VkDevice device, VkFence* fence);
void onyx_v_MemoryBarrier(
    VkCommandBuffer      commandBuffer,
    VkPipelineStageFlags srcStageMask,
    VkPipelineStageFlags dstStageMask,
    VkDependencyFlags    dependencyFlags,
    VkAccessFlags        srcAccessMask,
    VkAccessFlags        dstAccessMask);

void onyx_create_fence(VkDevice, bool signaled, VkFence* fence);
void onyx_create_fences(VkDevice device, bool signaled, int count, VkFence* fences);
void onyx_create_semaphore(VkDevice, VkSemaphore* semaphore);
void onyx_create_semaphores(VkDevice device, u32 count, VkSemaphore* semas);

void onyx_submit_command(OnyxCommand* cmd, VkSemaphore semaphore, VkFence fence);

void onyx_cmd_set_viewport_scissor(VkCommandBuffer cmdbuf, u32 x, u32 y, u32 w, u32 h);
void onyx_cmd_set_viewport_scissor_full(VkCommandBuffer cmdbuf, unsigned width, unsigned height);

void onyx_cmd_begin_render_pass_color_depth(VkCommandBuffer cmdbuf, 
        const VkRenderPass renderPass, const VkFramebuffer framebuffer,
        unsigned width, unsigned height,
        float r, float g, float b, float a);

void onyx_cmd_end_render_pass(VkCommandBuffer cmdbuf);

void onyx_destroy_fence(VkDevice device, VkFence fence);
void onyx_destroy_semaphore(VkDevice device, VkSemaphore semaphore);

void onyx_cmd_clear_color_image(VkCommandBuffer cmdbuf, VkImage image, VkImageLayout layout,
        uint32_t base_mip_level, uint32_t mip_level_count,
        float r, float g, float b, float a);

#endif /* end of include guard: ONYX_V_COMMAND_H */
