#ifndef ONYX_FORMAT_H
#define ONYX_FORMAT_H

#ifdef __cplusplus
extern "C" {
#endif

typedef VkFormat onyx_format;
typedef onyx_format OnyxFormat;

#ifdef __cplusplus
}
#endif

#endif
