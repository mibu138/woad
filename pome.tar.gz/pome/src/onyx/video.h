/*
video.c
 */
#ifndef ONYX_V_VIDEO_H
#define ONYX_V_VIDEO_H

#include "types.h"

uint64_t      onyx_size_of_instance(void);
OnyxInstance *onyx_alloc_instance(void);

// enabling/disabling validation and/or raytracing
// will automatically enable the required layers and
// extensions for those to be used effectively
typedef struct OnyxInstanceParms {
    bool                                disable_validation;
    bool                                enable_ray_tracing;
    bool                                disable_present_wait;
    OnyxSurfaceType                     surface_type;
} OnyxInstanceParms;

void              onyx_create_instance(const OnyxInstanceParms *parms,
                                       OnyxInstance            *instance);
const VkInstance *onyx_get_vk_instance(const OnyxInstance *);
void onyx_submit_to_queue(const OnyxInstance *, const VkCommandBuffer *buffer,
                          OnyxQueueType, uint32_t queueIndex);
void onyx_submit_to_queue_wait(const OnyxInstance *,
                               const VkCommandBuffer *buffer, OnyxQueueType,
                               uint32_t               queueIndex);

VkQueue onyx_queue(const OnyxInstance *ctx, OnyxQueueType type, u32 index);
VkQueue onyx_queue_(const OnyxInstance *ctx, VkQueueFlags flags, u32 index);
VkQueue onyx_queue__(const OnyxInstance *ctx, u32 family_index, u32 index);

uint32_t onyx_queue_family_index(const OnyxInstance *, OnyxQueueType type);

// -1 indicates no queue family found for given flags
uint32_t onyx_queue_family_index_(const OnyxInstance *, VkQueueFlags flags);

uint32_t onyx_graphics_queue_family_index(const OnyxInstance *);

void onyx_queue_submit(VkQueue queue, uint32_t submitCount,
                       const VkSubmitInfo *pSubmits, VkFence fence);
void onyx_destroy_instance(OnyxInstance *);
void onyx_submit_graphics_commands(const OnyxInstance *, uint32_t queueIndex,
                                   uint32_t            submitInfoCount,
                                   const VkSubmitInfo *submitInfos,
                                   VkFence             fence);
void onyx_submit_transfer_command(const OnyxInstance *, uint32_t queueIndex,
                                  VkPipelineStageFlags        waitDstStageMask,
                                  const VkSemaphore          *pWaitSemephore,
                                  VkFence                     fence,
                                  const struct OnyxV_Command *cmd);

void onyx_submit_graphics_command(const OnyxInstance *, uint32_t queueIndex,
                                  VkPipelineStageFlags waitDstStageMask,
                                  uint32_t             waitCount,
                                  VkSemaphore          waitSemephores[],
                                  uint32_t             signalCount,
                                  VkSemaphore signalSemphores[], VkFence fence,
                                  VkCommandBuffer cmdBuf);

VkDevice onyx_get_device(const OnyxInstance *);
VkQueue  onyx_get_present_queue(const OnyxInstance *);
VkQueue  onyx_get_graphics_queue(const OnyxInstance *, u32 index);
VkQueue  onyx_get_transfer_queue(const OnyxInstance *, u32 index);
VkPhysicalDevice onyx_get_physical_device(const OnyxInstance *);

void onyx_present_queue_wait_idle(const OnyxInstance *);

void onyx_device_wait_idle(const OnyxInstance *);

const VkPhysicalDeviceProperties *
onyx_get_physical_device_properties(const OnyxInstance *);

void onyx_queue_submit2(VkQueue queue, uint32_t submitCount,
                        const VkSubmitInfo2 *pSubmits, VkFence fence);

VkPhysicalDeviceRayTracingPipelinePropertiesKHR
onyx_get_physical_device_ray_tracing_properties(const OnyxInstance *);

VkPhysicalDeviceAccelerationStructurePropertiesKHR
onyx_get_physical_device_acceleration_structure_properties(
    const OnyxInstance *);

#endif /* end of include guard: V_VIDEO_H */
