#define COAL_SIMPLE_TYPE_NAMES
#include "raytrace.h"
#include "video.h"
#include "render.h"
#include "memory.h"
#include "command.h"
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <hell/debug.h>
#include "dtags.h"
#include "coal/types.h"
#include "coal/linalg.h"

typedef OnyxBuffer          BufferRegion;
typedef OnyxAccelerationStructure AccelerationStructure;
typedef OnyxCommand               Command;
typedef OnyxShaderBindingTable    ShaderBindingTable;

#define DPRINT(fmt, ...) hell_debug_print(ONYX_DEBUG_TAG_RAYTRACE, fmt, ##__VA_ARGS__)

void onyx_build_blas(OnyxMemory* memory, const OnyxGeometry* geo, AccelerationStructure* blas)
{
    VkBufferDeviceAddressInfo addr_info = {
        .sType  = VK_STRUCTURE_TYPE_BUFFER_DEVICE_ADDRESS_INFO,
        .buffer = geo->vertex_buffer_region.buffer,
    };

    const VkDeviceAddress vert_addr = vkGetBufferDeviceAddress(memory->instance->device, &addr_info) + geo->vertex_buffer_region.offset;

    addr_info.buffer = geo->index_buffer_region.buffer;
    
    const VkDeviceAddress index_addr = vkGetBufferDeviceAddress(memory->instance->device, &addr_info) + geo->index_buffer_region.offset;

    const VkAccelerationStructureGeometryTrianglesDataKHR tri_data = {
        .sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_TRIANGLES_DATA_KHR,
        .vertexFormat  = ONYX_VERT_POS_FORMAT,
        .vertexStride  = sizeof(Vec3),
        .indexType     = ONYX_VERT_INDEX_TYPE,
        .maxVertex     = onyx_get_geo_vertex_count(geo),
        .vertexData.deviceAddress = vert_addr,
        .indexData.deviceAddress = index_addr,
        .transformData = 0
    };

    const VkAccelerationStructureGeometryKHR as_geom = {
        .sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_KHR,
        .flags = VK_GEOMETRY_OPAQUE_BIT_KHR,
        .geometryType = VK_GEOMETRY_TYPE_TRIANGLES_KHR,
        .geometry.triangles = tri_data
    };

    // weird i need two
    VkAccelerationStructureBuildGeometryInfoKHR build_as = {
        .sType                     = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_GEOMETRY_INFO_KHR,
        .type                      = VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR,
        .flags                     = VK_BUILD_ACCELERATION_STRUCTURE_PREFER_FAST_TRACE_BIT_KHR,
        .geometryCount             = 1,
        .pGeometries               = &as_geom
    };

    VkAccelerationStructureBuildSizesInfoKHR build_sizes = {
        .sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_SIZES_INFO_KHR,
    };

    const uint32_t num_trianlges = onyx_get_geo_triangle_count(geo);

    vkGetAccelerationStructureBuildSizesKHR(memory->instance->device, VK_ACCELERATION_STRUCTURE_BUILD_TYPE_DEVICE_KHR, &build_as, &num_trianlges, &build_sizes); 

    blas->buffer_region = onyx_request_buffer_region(memory, build_sizes.accelerationStructureSize, 
            VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT, 
            ONYX_MEMORY_DEVICE_TYPE);

    const VkAccelerationStructureCreateInfoKHR accel_struct_info = {
        .sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_CREATE_INFO_KHR,
        .buffer = blas->buffer_region.buffer,
        .offset = blas->buffer_region.offset,
        .size   = blas->buffer_region.size,
        .type   = VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR
    };

    V_ASSERT( vkCreateAccelerationStructureKHR(memory->instance->device, &accel_struct_info, NULL, &blas->handle) );

    VkPhysicalDeviceAccelerationStructurePropertiesKHR accel_struct_props = onyx_get_physical_device_acceleration_structure_properties(memory->instance);

    OnyxBuffer scratch_buffer_region = onyx_request_buffer_region_aligned(memory, build_sizes.buildScratchSize, 
            accel_struct_props.minAccelerationStructureScratchOffsetAlignment,
            ONYX_MEMORY_DEVICE_TYPE);

    build_as.mode = VK_BUILD_ACCELERATION_STRUCTURE_MODE_BUILD_KHR;
    build_as.dstAccelerationStructure = blas->handle;
    build_as.scratchData.deviceAddress = onyx_get_buffer_region_address(&scratch_buffer_region);

    VkAccelerationStructureBuildRangeInfoKHR build_range = {
        .firstVertex = 0,
        .primitiveCount = num_trianlges,
        .primitiveOffset = 0,
        .transformOffset = 0
    };

    const VkAccelerationStructureBuildRangeInfoKHR* ranges[1] = {&build_range};

    Command cmd = onyx_create_command(memory->instance, ONYX_QUEUE_GRAPHICS_TYPE);

    onyx_begin_command_buffer(cmd.buffer);

    vkCmdBuildAccelerationStructuresKHR(cmd.buffer, 1, &build_as, ranges);

    onyx_end_command_buffer(cmd.buffer);

    onyx_submit_and_wait(&cmd, 0);

    onyx_destroy_command(cmd);

    onyx_free_buffer(&scratch_buffer_region);
}

void onyx_build_tlas(OnyxMemory* memory, const uint32_t count, const AccelerationStructure blasses[],
        const CoalMat4 xforms[],
        AccelerationStructure* tlas)
{
    //// Mat4 transform = m_Ident_Mat4();
    // instance transform member is a 4x3 row-major matrix
    // transform = m_Transpose_Mat4(&transform); // we don't need to because its identity, but leaving here to impress the point
    assert(xforms);
    assert(count > 0);

    VkAccelerationStructureInstanceKHR* instances = hell_malloc(sizeof(VkAccelerationStructureInstanceKHR) * count);
    memset(instances, 0, sizeof(instances[0]) * count);
    for (int i = 0; i < count; i++)
    {
        Mat4 xform_t = xforms[i];
        xform_t = coal_transpose_mat4(xform_t);
        VkTransformMatrixKHR transform;
        assert(sizeof(transform) == 12 * sizeof(float));
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                transform.matrix[i][j] = xform_t.e[i][j]; 
            }
        }
        instances[i].accelerationStructureReference = onyx_get_buffer_region_address(&blasses[i].buffer_region);
        instances[i].instanceCustomIndex = 0; // 0'th instance it
        instances[i].instanceShaderBindingTableRecordOffset = 0;
        instances[i].flags = VK_GEOMETRY_INSTANCE_TRIANGLE_FACING_CULL_DISABLE_BIT_KHR;
        instances[i].mask = 0xFF;
        instances[i].transform = transform;
    }


    BufferRegion inst_buffer = onyx_request_buffer_region(memory, sizeof(*instances) * count,
            VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
            ONYX_MEMORY_HOST_GRAPHICS_TYPE);

    assert(inst_buffer.host_data);
    memcpy(inst_buffer.host_data, instances, sizeof(instances[0]) * count);
    hell_free(instances);

    const VkAccelerationStructureGeometryInstancesDataKHR instance_data = {
        .sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_INSTANCES_DATA_KHR,
        .data.deviceAddress = onyx_get_buffer_region_address(&inst_buffer),
        .arrayOfPointers = VK_FALSE
    };

    const VkAccelerationStructureGeometryKHR top_as_geometry = {
        .sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_KHR,
        .geometry.instances = instance_data,
        .geometryType = VK_GEOMETRY_TYPE_INSTANCES_KHR,
        .flags = VK_GEOMETRY_OPAQUE_BIT_KHR // may not need
    };

    VkAccelerationStructureBuildGeometryInfoKHR top_as_info = {
        .sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_GEOMETRY_INFO_KHR,
        .flags = VK_BUILD_ACCELERATION_STRUCTURE_PREFER_FAST_TRACE_BIT_KHR,
        .type  = VK_ACCELERATION_STRUCTURE_TYPE_TOP_LEVEL_KHR,
        .geometryCount = 1,
        .pGeometries = &top_as_geometry,
    };

    const uint32_t max_prim_count = count; // if topAsInfo.geometryCount was > 1, this would be an array of counts

    VkAccelerationStructureBuildSizesInfoKHR build_sizes = {
        .sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_SIZES_INFO_KHR,
    };

    vkGetAccelerationStructureBuildSizesKHR(memory->instance->device, VK_ACCELERATION_STRUCTURE_BUILD_TYPE_DEVICE_KHR, &top_as_info, &max_prim_count, &build_sizes); 

    tlas->buffer_region = onyx_request_buffer_region(memory, build_sizes.accelerationStructureSize, 
            VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
            ONYX_MEMORY_DEVICE_TYPE);

    const VkAccelerationStructureCreateInfoKHR as_create_info = {
        .sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_CREATE_INFO_KHR,
        .type  = VK_ACCELERATION_STRUCTURE_TYPE_TOP_LEVEL_KHR,
        .buffer = tlas->buffer_region.buffer,
        .offset = tlas->buffer_region.offset,
        .size   = tlas->buffer_region.size,
    };

    V_ASSERT( vkCreateAccelerationStructureKHR(memory->instance->device, &as_create_info, NULL, &tlas->handle) );

    // allocate and bind memory

    BufferRegion scratch_buffer = onyx_request_buffer_region(memory, build_sizes.buildScratchSize,
            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
            ONYX_MEMORY_DEVICE_TYPE);

    top_as_info.mode = VK_BUILD_ACCELERATION_STRUCTURE_MODE_BUILD_KHR;
    top_as_info.dstAccelerationStructure = tlas->handle;
    top_as_info.scratchData.deviceAddress = onyx_get_buffer_region_address(&scratch_buffer);

    // so this is weird but ill break it down 
    // for each acceleration structure we want to build, we provide 
    // N buildRanges. This N is the same number as the geometryCount member of the
    // corresponding VkAccelerationStructureBuildGeometryInfoKHR. This means 
    // that each buildRange corresponds to a member of pGeometries in that struct.
    // the interpretation of the members of each buildRange depends on the 
    // VkAccelerationStructureGeometryKHR type that it ends up being paired with
    // For instance, firstVertex really only applies if that geometry type is triangles.
    // For instances, primitiveCount is the number or instances 
    const VkAccelerationStructureBuildRangeInfoKHR build_range = {
        .firstVertex = 0,
        .primitiveCount = count, 
        .primitiveOffset = 0,
        .transformOffset = 0 };

    const VkAccelerationStructureBuildRangeInfoKHR* ranges[1] = {&build_range};

    Command cmd = onyx_create_command(memory->instance, ONYX_QUEUE_GRAPHICS_TYPE);

    onyx_begin_command_buffer(cmd.buffer);

    vkCmdBuildAccelerationStructuresKHR(cmd.buffer, 1, &top_as_info, ranges);

    onyx_end_command_buffer(cmd.buffer);

    onyx_submit_and_wait(&cmd, ONYX_QUEUE_GRAPHICS_TYPE);

    onyx_destroy_command(cmd);
    onyx_free_buffer(&scratch_buffer);
    onyx_free_buffer(&inst_buffer);
}

void onyx_create_shader_binding_table(OnyxMemory* memory, const uint32_t groupCount, const VkPipeline pipeline, ShaderBindingTable* sbt)
{
    memset(sbt, 0, sizeof(*sbt));

    const VkPhysicalDeviceRayTracingPipelinePropertiesKHR rtprops = onyx_get_physical_device_ray_tracing_properties(memory->instance);
    const uint32_t groupHandleSize = rtprops.shaderGroupHandleSize;
    const uint32_t baseAlignment = rtprops.shaderGroupBaseAlignment;
    const uint32_t sbtSize = groupCount * baseAlignment; // 3 shader groups: raygen, miss, closest hit

    void* shaderHandleData = hell_malloc(sbtSize);

    DPRINT("ShaderGroup handle size: %d\n", groupHandleSize);
    DPRINT("ShaderGroup base alignment: %d\n", baseAlignment);
    DPRINT("ShaderGroups total size   : %d\n", sbtSize);

    VkResult r;
    r = vkGetRayTracingShaderGroupHandlesKHR(memory->instance->device, pipeline, 0, groupCount, sbtSize, shaderHandleData);
    assert( VK_SUCCESS == r );
    sbt->buffer_regions = onyx_request_buffer_region_aligned(memory, sbtSize, baseAlignment, ONYX_MEMORY_HOST_GRAPHICS_TYPE);
    sbt->group_count = groupCount;

    uint8_t* pSrc    = shaderHandleData;
    uint8_t* pTarget = sbt->buffer_regions.host_data;

    for (int i = 0; i < groupCount; i++) 
    {
        memcpy(pTarget, pSrc + i * groupHandleSize, groupHandleSize);
        pTarget += baseAlignment;
    }

    VkDeviceAddress bufferRegionAddress = onyx_get_buffer_region_address(&sbt->buffer_regions);
    sbt->raygen_table.deviceAddress = bufferRegionAddress;
    sbt->raygen_table.size          = baseAlignment;
    sbt->raygen_table.stride        = sbt->raygen_table.size; // must be this according to spec. stride not used for rgen.

    assert(groupHandleSize < baseAlignment); // for now.... 
    sbt->miss_table.deviceAddress = bufferRegionAddress + baseAlignment;
    sbt->miss_table.size          = baseAlignment;
    sbt->miss_table.stride        = baseAlignment;

    sbt->hit_table.deviceAddress = bufferRegionAddress + baseAlignment * 2;
    sbt->hit_table.size          = baseAlignment;
    sbt->hit_table.stride        = baseAlignment;

    hell_free(shaderHandleData);

    DPRINT("Created shader binding table\n");
}

void onyx_destroy_acceleration_struct(VkDevice device, AccelerationStructure* as)
{
    vkDestroyAccelerationStructureKHR(device, as->handle, NULL);
    onyx_free_buffer(&as->buffer_region);
    memset(as, 0, sizeof(*as));
}

void onyx_destroy_shader_binding_table(OnyxShaderBindingTable* sb)
{
    onyx_free_buffer(&sb->buffer_regions);
    memset(sb, 0, sizeof(*sb));
}

