#include "command.h"
#include "common.h"
#include "dtags.h"
#include "hell/io.h"
#include "memory.h"
#include "video.h"
#include <assert.h>
#include <hell/common.h>
#include <hell/debug.h>
#include <hell/minmax.h>
#include <stdlib.h>
#include <string.h>

// HVC = Host Visible and Coherent
// DL = Device Local
// #define MAX_BLOCKS 100000 we overflowed the stack...

#define MB 0x100000

typedef OnyxMemory   Memory;
typedef OnyxBuffer   BufferRegion;
typedef OnyxMemBlock Block;
//
// static uint32_t findMemoryType(uint32_t memoryTypeBitsRequirement)
// __attribute__ ((unused));
#if UNIX
static void printBufferMemoryReqs(const VkMemoryRequirements *reqs)
    __attribute__((unused));
static void printBlockChainInfo(const OnyxMemoryPool *chain)
    __attribute__((unused));
#endif

#if 0
#define DPRINT(fmt, ...)                                                       \
    hell_debug_print(ONYX_DEBUG_TAG_MEM, fmt, ##__VA_ARGS__)
#else
#define DPRINT(fmt, ...)
#endif

static void printBufferMemoryReqs(const VkMemoryRequirements *reqs)
{
    DPRINT("Size: %zu\tAlignment: %zu\n", reqs->size, reqs->alignment);
}

static void printBlockChainInfo(const OnyxMemoryPool *chain)
{
    DPRINT("BlockChain %s:\n", chain->name);
    DPRINT("totalSize: %zu\t count: %d\t cur: %d\t nextBlockId: %d\n",
           chain->totalSize, chain->count, chain->cur, chain->nextBlockId);
    DPRINT("memory: %p\t buffer: %p\t hostData: %p\n", chain->memory,
           chain->buffer, chain->hostData);
    DPRINT("Blocks: \n");
    for (int i = 0; i < chain->count; i++) {
        const OnyxMemBlock *block = &chain->blocks[i];
        (void)block;
        DPRINT(
            "\t{ Block %d: size = %zu, offset = %zu, inUse = %s, id: %d}, \n",
            i, block->size, block->offset, block->inUse ? "true" : "false",
            block->id);
    }
    DPRINT("\n");
}

static uint32_t findMemoryType(const OnyxMemory *memory,
                               uint32_t          memoryTypeBitsRequirement)
{
    const uint32_t memoryCount = memory->properties.memoryTypeCount;
    for (uint32_t memoryIndex = 0; memoryIndex < memoryCount; ++memoryIndex) {
        const uint32_t memoryTypeBits = (1 << memoryIndex);
        if (memoryTypeBits & memoryTypeBitsRequirement)
            return memoryIndex;
    }
    return -1;
}

static uint32_t alignmentForBufferUsage(const OnyxMemory  *memory,
                                        VkBufferUsageFlags flags)
{
    uint32_t alignment = 16; // arbitrary default alignment for all allocations.
                             // should test lower values.
    if (VK_BUFFER_USAGE_STORAGE_BUFFER_BIT & flags)
        alignment = MAX(
            memory->deviceProperties->limits.minStorageBufferOffsetAlignment,
            alignment);
    if (VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT & flags)
        alignment = MAX(
            memory->deviceProperties->limits.minUniformBufferOffsetAlignment,
            alignment);
    if (VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR & flags)
        alignment =
            MAX(256,
                alignment); // 256 comes from spec for
                            // VkAccelerationStructureCreateInfoKHR - see offset
    return alignment;
}

static void initBlockChain(OnyxMemory *memory, const OnyxMemoryType memType,
                           const VkDeviceSize       memorySize,
                           const uint32_t           memTypeIndex,
                           const VkBufferUsageFlags bufferUsageFlags,
                           const bool mapBuffer, const char *name,
                           struct onyx_memory_pool *chain)
{
    memset(chain, 0, sizeof(OnyxMemoryPool));
    strcpy(chain->name, name);
    if (memorySize == 0)
        return; // basically saying we arent using this memory type
    if (memorySize % 0x40 != 0)
        hell_error(HELL_ERR_FATAL,
                   "Failed to initialize %s block chain because requested %zu "
                   "bytes is not divisible by 0x40\n",
                   name, memorySize);
    assert(memorySize % 0x40 ==
           0); // make sure memorysize is 64 byte aligned (arbitrary choice)
    chain->memory           = memory;
    chain->count            = 1;
    chain->cur              = 0;
    chain->totalSize        = memorySize;
    chain->usedSize         = 0;
    chain->nextBlockId      = 1;
    chain->alignment        = 4;
    chain->bufferFlags      = bufferUsageFlags;
    chain->blocks[0].inUse  = false;
    chain->blocks[0].offset = 0;
    chain->blocks[0].size   = memorySize;
    chain->blocks[0].id     = 0;
    assert(strlen(name) < 16);
    strcpy(chain->name, name);

    if (chain->totalSize == 0)
        return; // nothing else to do

    VkExportMemoryAllocateInfo exportMemoryAllocInfo;
    const void                *pNext = NULL;
    if (memType == ONYX_MEMORY_EXTERNAL_DEVICE_TYPE) {
        exportMemoryAllocInfo.sType =
            VK_STRUCTURE_TYPE_EXPORT_MEMORY_ALLOCATE_INFO;
#ifdef WIN32
        exportMemoryAllocInfo.handleTypes =
            VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_WIN32_BIT;
#else
        exportMemoryAllocInfo.handleTypes =
            VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT;
#endif
        exportMemoryAllocInfo.pNext = NULL;
        pNext                       = &exportMemoryAllocInfo;
    }

    const VkMemoryAllocateFlagsInfo allocFlagsInfo = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_FLAGS_INFO,
#ifndef ONYX_NO_BUFFER_DEVICE_ADDRESS
        .flags = VK_MEMORY_ALLOCATE_DEVICE_ADDRESS_BIT,
#endif
        .pNext = pNext};

    const VkMemoryAllocateInfo allocInfo = {
        .sType           = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
        .pNext           = &allocFlagsInfo,
        .allocationSize  = memorySize,
        .memoryTypeIndex = memTypeIndex,
    };

    V_ASSERT(vkAllocateMemory(memory->instance->device, &allocInfo, NULL,
                              &chain->vkmemory));

    if (bufferUsageFlags) {

        uint32_t queueFamilyIndex;
        switch (memType) {
            case ONYX_MEMORY_HOST_GRAPHICS_TYPE:
                queueFamilyIndex = onyx_queue_family_index(
                    memory->instance, ONYX_QUEUE_GRAPHICS_TYPE);
                break;
            case ONYX_MEMORY_HOST_TRANSFER_TYPE:
                queueFamilyIndex = onyx_queue_family_index(
                    memory->instance, ONYX_QUEUE_TRANSFER_TYPE);
                break;
            case ONYX_MEMORY_DEVICE_TYPE:
                queueFamilyIndex = onyx_queue_family_index(
                    memory->instance, ONYX_QUEUE_GRAPHICS_TYPE);
                break;
            case ONYX_MEMORY_EXTERNAL_DEVICE_TYPE:
                queueFamilyIndex = onyx_queue_family_index(
                    memory->instance, ONYX_QUEUE_GRAPHICS_TYPE);
                break;
            default:
                assert(0);
                break;
        }

        VkBufferCreateInfo ci = {
            .sType                 = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
            .usage                 = bufferUsageFlags,
            .queueFamilyIndexCount = 1,
            .pQueueFamilyIndices   = &queueFamilyIndex,
            .sharingMode = VK_SHARING_MODE_EXCLUSIVE, // queue family determined
                                                      // by first use
            // TODO this sharing mode is why we need to expand OnyxV_MemoryType
            // to specify queue usage as well. So we do need graphics type,
            // transfer type, and compute types
            .size        = memorySize};

        V_ASSERT(vkCreateBuffer(memory->instance->device, &ci, NULL,
                                &chain->buffer));

        V_ASSERT(vkBindBufferMemory(memory->instance->device, chain->buffer,
                                    chain->vkmemory, 0));

        VkMemoryRequirements memReqs;

        vkGetBufferMemoryRequirements(memory->instance->device, chain->buffer,
                                      &memReqs);

        // chain->defaultAlignment = memReqs.alignment;

        DPRINT("Host Buffer ALIGNMENT: %zu\n", memReqs.alignment);

#ifndef ONYX_NO_BUFFER_DEVICE_ADDRESS
        const VkBufferDeviceAddressInfo addrInfo = {
            .sType  = VK_STRUCTURE_TYPE_BUFFER_DEVICE_ADDRESS_INFO,
            .buffer = chain->buffer};

        chain->bufferAddress =
            vkGetBufferDeviceAddress(memory->instance->device, &addrInfo);
#endif

        if (mapBuffer)
            V_ASSERT(vkMapMemory(memory->instance->device, chain->vkmemory, 0,
                                 VK_WHOLE_SIZE, 0, (void **)&chain->hostData));
        else
            chain->hostData = NULL;
    } else {
        chain->buffer   = VK_NULL_HANDLE;
        chain->hostData = NULL;
    }
}

static void freeBlockChain(OnyxMemory *memory, struct onyx_memory_pool *chain)
{
    memset(chain->blocks, 0, MAX_BLOCKS * sizeof(OnyxMemBlock));
    if (chain->buffer != VK_NULL_HANDLE) {
        vkDestroyBuffer(memory->instance->device, chain->buffer, NULL);
        if (chain->hostData != NULL)
            vkUnmapMemory(memory->instance->device, chain->vkmemory);
        chain->buffer = VK_NULL_HANDLE;
    }
    vkFreeMemory(memory->instance->device, chain->vkmemory, NULL);
    memset(chain, 0, sizeof(*chain));
}

typedef struct AvailabilityInfo {
    bool found_block;
    u32  index;
    u64  new_offset;
} AvailabilityInfo;

static AvailabilityInfo findAvailableBlockIndex(struct onyx_memory_pool *chain,
                                                VkDeviceSize             size,
                                                VkDeviceSize alignment)
{
    const int count = chain->count;
    DPRINT(">>> requesting block of size %d from chain %s with totalSize %zu\n",
           size, chain->name, chain->totalSize);
    assert(size < chain->totalSize);
    assert(count > 0);
    assert(alignment != 0);
    for (u32 i = 0; i < count; i++) {
        const OnyxMemBlock *block = &chain->blocks[i];
        if (block->inUse || block->size < size)
            continue;
        // nextPossibleOffset may be the same as or greater than block->offset.
        u64 nextPossibleOffset = hell_align(block->offset, alignment);
        u64 blockEnd           = block->offset + block->size;
        if (nextPossibleOffset > blockEnd)
            continue;
        if (blockEnd - nextPossibleOffset < size)
            continue;
        return (AvailabilityInfo){true, i, nextPossibleOffset};
        // block's new size will be greater than or equal to the resource size;
    }
    return (AvailabilityInfo){false};
}

// from i = firstIndex to i = lastIndex - 1, swap block i with block i + 1
// note this can operate on indices beyond chain->count
static void rotateBlockUp(const size_t fromIndex, const size_t toIndex,
                          struct onyx_memory_pool *chain)
{
    assert(toIndex < MAX_BLOCKS);
    assert(toIndex > fromIndex);
    for (int i = fromIndex; i < toIndex; i++) {
        OnyxMemBlock temp    = chain->blocks[i];
        chain->blocks[i]     = chain->blocks[i + 1];
        chain->blocks[i + 1] = temp;
    }
}

static void rotateBlockDown(const size_t fromIndex, const size_t toIndex,
                            struct onyx_memory_pool *chain)
{
    assert(fromIndex < MAX_BLOCKS);
    assert(fromIndex > toIndex);
    for (int i = fromIndex; i > toIndex; i--) {
        OnyxMemBlock temp    = chain->blocks[i];
        chain->blocks[i]     = chain->blocks[i - 1];
        chain->blocks[i - 1] = temp;
        assert(chain->blocks[i - 1].size < chain->totalSize);
    }
}

static void mergeBlocks(struct onyx_memory_pool *chain)
{
    assert(chain->count > 1); // must have at least 2 blocks to defragment
    for (int i = 0; i < chain->count - 1; i++) {
        OnyxMemBlock *curr = &chain->blocks[i];
        OnyxMemBlock *next = &chain->blocks[i + 1];
        if (!curr->inUse && !next->inUse) {
            // combine them together
            const VkDeviceSize cSize = curr->size + next->size;
            // we could make the other id available for re-use as well
            curr->size               = cSize;
            // set next block to 0
            memset(next, 0, sizeof(OnyxMemBlock));
            // rotate blocks down past i so that next goes to chain->count - 1
            // and the block at chain->size - 1 goes to chain->count - 2
            if (i + 1 != chain->count - 1) {
                rotateBlockUp(i + 1, chain->count - 1, chain);
            }
            // decrement the chain count
            chain->count--;
            i--;
        }
    }
}

static void defragment(struct onyx_memory_pool *chain)
{
    // TODO: implement a proper defragment function
    printBlockChainInfo(chain);
    fatal_error("Empty defragment function called\n");
}

static bool chainIsOrdered(const struct onyx_memory_pool *chain)
{
    for (int i = 0; i < chain->count - 1; i++) {
        const OnyxMemBlock *curr = &chain->blocks[i];
        const OnyxMemBlock *next = &chain->blocks[i + 1];
        if (curr->offset > next->offset)
            return false;
    }
    return true;
}

static OnyxMemBlock *requestBlock(const u64 size, const u64 alignment,
                                  struct onyx_memory_pool *chain)
{
#ifndef NDEBUG
    printBlockChainInfo(chain);
#endif
    AvailabilityInfo availInfo =
        findAvailableBlockIndex(chain, size, alignment);
    if (!availInfo.found_block) // try defragmenting. if that fails we're done.
    {
        defragment(chain);
        availInfo = findAvailableBlockIndex(chain, size, alignment);
        if (!availInfo.found_block) {
            DPRINT("Memory allocation failed\n");
            exit(0);
        }
    }
    OnyxMemBlock *curBlock = &chain->blocks[availInfo.index];
    if (curBlock->size == size &&
        (curBlock->offset % alignment == 0)) // just reuse this block;
    {
        curBlock->inUse = true;
        chain->usedSize += curBlock->size;
        DPRINT(">> Re-using block %d of size %09zu from chain %s. %zu bytes "
               "out of %zu now in use.\n",
               curBlock->id, curBlock->size, chain->name, chain->usedSize,
               chain->totalSize);
        return curBlock;
    }
    // split the block
    const size_t  newBlockIndex = chain->count++;
    OnyxMemBlock *newBlock      = &chain->blocks[newBlockIndex];
    assert(newBlockIndex < MAX_BLOCKS);
    assert(newBlock->inUse == false);
    // we will assume correct alignment for the first block... TODO Make sure
    // this is enforced somehow. if the newOffset is not equal to currentOffset,
    // we must change the currentOffset to the new offset, alter the size, and
    // also add the difference in offsets to the size of the previous block.
    // This is why we check if the index is 0 and hope for the best in that
    // case. we have already checked to make sure that the block has enough
    // space to fit the resource given its new offset.
    u64 diff = 0;
    if (availInfo.index > 0 && availInfo.new_offset != curBlock->offset) {
        diff             = availInfo.new_offset - curBlock->offset;
        curBlock->size   = curBlock->size - diff;
        curBlock->offset = availInfo.new_offset;
        chain->blocks[availInfo.index - 1].size =
            chain->blocks[availInfo.index - 1].size + diff;
    }
    newBlock->size   = curBlock->size - size;
    newBlock->offset = curBlock->offset + size;
    newBlock->id     = chain->nextBlockId++;
    curBlock->size   = size;
    curBlock->inUse  = true;
    if (newBlockIndex != availInfo.index + 1)
        rotateBlockDown(newBlockIndex, availInfo.index + 1, chain);
    assert(curBlock->size < chain->totalSize);
    assert(chainIsOrdered(chain));
    chain->usedSize +=
        curBlock->size + diff; // need to factor in the diff if we had to move
                               // the block's offset forward.
    DPRINT(">> Alocating block %d of size %09zu from chain %s. %zu bytes out "
           "of %zu now in use.\n",
           curBlock->id, curBlock->size, chain->name, chain->usedSize,
           chain->totalSize);
#ifndef NDEBUG
    printBlockChainInfo(chain);
#endif
    return curBlock;
}

static void freeBlock(struct onyx_memory_pool *chain, const uint32_t id)
{
    assert(id < chain->nextBlockId);
    const size_t blockCount = chain->count;
    int          blockIndex = 0;
    for (; blockIndex < blockCount; blockIndex++) {
        if (chain->blocks[blockIndex].id == id)
            break;
    }
    assert(blockIndex < blockCount); // block must not have come from this chain
    OnyxMemBlock      *block = &chain->blocks[blockIndex];
    const VkDeviceSize size  = block->size;
    block->inUse             = false;
    mergeBlocks(chain);
    chain->usedSize -= size;
    DPRINT(">> Freeing block %d of size %09zu from chain %s. %zu bytes out of "
           "%zu now in use.\n",
           id, size, chain->name, chain->usedSize, chain->totalSize);
}

void onyx_create_memory_basic(const OnyxInstance *instance,
                              OnyxMemorySizes sizes, OnyxMemory *memory)
{
    onyx_create_memory(instance, sizes.host_graphics_buffer_mb,
                       sizes.device_graphics_buffer_mb,
                       sizes.device_graphics_image_mb,
                       sizes.host_transfer_buffer_mb,
                       sizes.device_external_graphics_image_mb, memory);
}

void onyx_create_memory(const OnyxInstance *instance,
                        const uint32_t      hostGraphicsBufferMB,
                        const uint32_t      deviceGraphicsBufferMB,
                        const uint32_t      deviceGraphicsImageMB,
                        const uint32_t      hostTransferBufferMB,
                        const uint32_t      deviceExternalGraphicsImageMB,
                        OnyxMemory         *memory)
{
    assert(hostGraphicsBufferMB < 10000);          // maximum 10 GB
    assert(deviceGraphicsBufferMB < 10000);        // maximum 10 GB
    assert(deviceGraphicsImageMB < 10000);         // maximum 10 GB
    assert(hostTransferBufferMB < 10000);          // maximum 10 GB
    assert(deviceExternalGraphicsImageMB < 10000); // maximum 10 GB
    memset(memory, 0, sizeof(OnyxMemory));
    memory->instance = instance;

    memory->deviceProperties = onyx_get_physical_device_properties(instance);

    vkGetPhysicalDeviceMemoryProperties(instance->physical_device,
                                        &memory->properties);

    DPRINT("Memory Heap Info:\n");
#if 0
    for (int i = 0; i < memory->properties.memoryHeapCount; i++)
    {
        const char* typestr = memory->properties.memoryHeaps[i].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT ? "Device" : "Host";
        //TODO This DPRINT causes a crash on windows... just debug info so not important but worth investigating at some point
        //DPRINT("Heap %d: Size %zu: %s local\n", i, memory->properties.memoryHeaps[i].size, typestr);
        // note there are other possible flags, but seem to only deal with
        // multiple gpus
    }
#endif

    bool foundHvc = false;
    bool foundDl  = false;

    DPRINT("Memory Type Info:\n");
    for (int i = 0; i < memory->properties.memoryTypeCount; i++) {
        VkMemoryPropertyFlags flags =
            memory->properties.memoryTypes[i].propertyFlags;
        DPRINT("Type %d: Heap Index: %d Flags: | %s%s%s%s%s%s\n", i,
               memory->properties.memoryTypes[i].heapIndex,
               flags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT ? "Device Local | "
                                                           : "",
               flags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT ? "Host Visible | "
                                                           : "",
               flags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT ? "Host Coherent | "
                                                            : "",
               flags & VK_MEMORY_PROPERTY_HOST_CACHED_BIT ? "Host Cached | "
                                                          : "",
               flags & VK_MEMORY_PROPERTY_PROTECTED_BIT ? "Protected | " : "",
               flags & VK_MEMORY_PROPERTY_LAZILY_ALLOCATED_BIT
                   ? "Lazily allocated | "
                   : "");
        if ((flags & (VK_MEMORY_PROPERTY_HOST_COHERENT_BIT |
                      VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) &&
            !foundHvc) {
            memory->hostVisibleCoherentTypeIndex = i;
            foundHvc                             = true;
        }
        if ((flags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT) && !foundDl) {
            memory->deviceLocalTypeIndex = i;
            foundDl                      = true;
        }
    }

    assert(foundHvc);
    assert(foundDl);
    DPRINT("Host Visible and Coherent memory type index found: %d\n",
           memory->hostVisibleCoherentTypeIndex);
    DPRINT("Device local memory type index found: %d\n",
           memory->deviceLocalTypeIndex);

    VkBufferUsageFlags hostGraphicsFlags =
        VK_BUFFER_USAGE_VERTEX_BUFFER_BIT |
        VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR |
        VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_INDEX_BUFFER_BIT |
#ifndef ONYX_NO_BUFFER_DEVICE_ADDRESS
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT |
#endif
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT |
        VK_BUFFER_USAGE_SHADER_BINDING_TABLE_BIT_KHR |
        VK_BUFFER_USAGE_INDIRECT_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT |
        VK_BUFFER_USAGE_TRANSFER_SRC_BIT;

    VkBufferUsageFlags hostTransferFlags =
#ifndef ONYX_NO_BUFFER_DEVICE_ADDRESS
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT |
#endif
        VK_BUFFER_USAGE_TRANSFER_DST_BIT | VK_BUFFER_USAGE_TRANSFER_SRC_BIT;

    VkBufferUsageFlags devBufFlags =
        VK_BUFFER_USAGE_VERTEX_BUFFER_BIT |
        VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR |
        VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_INDEX_BUFFER_BIT |
#ifndef ONYX_NO_BUFFER_DEVICE_ADDRESS
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT |
#endif
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT |
        VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR |
        VK_BUFFER_USAGE_SHADER_BINDING_TABLE_BIT_KHR |
        VK_BUFFER_USAGE_TRANSFER_DST_BIT | VK_BUFFER_USAGE_TRANSFER_SRC_BIT;

    DPRINT("Onyx: Initializing memory block chains...\n");
    initBlockChain(
        memory, ONYX_MEMORY_HOST_GRAPHICS_TYPE, hostGraphicsBufferMB * MB,
        memory->hostVisibleCoherentTypeIndex, hostGraphicsFlags, true,
        "hstGraphBuffer", &memory->blockChainHostGraphicsBuffer);
    initBlockChain(
        memory, ONYX_MEMORY_HOST_TRANSFER_TYPE, hostTransferBufferMB * MB,
        memory->hostVisibleCoherentTypeIndex, hostTransferFlags, true,
        "hstTransBuffer", &memory->blockChainHostTransferBuffer);
    initBlockChain(memory, ONYX_MEMORY_DEVICE_TYPE, deviceGraphicsBufferMB * MB,
                   memory->deviceLocalTypeIndex, devBufFlags, false,
                   "devBuffer", &memory->blockChainDeviceGraphicsBuffer);
    initBlockChain(memory, ONYX_MEMORY_DEVICE_TYPE, deviceGraphicsImageMB * MB,
                   memory->deviceLocalTypeIndex, 0, false, "devImage",
                   &memory->blockChainDeviceGraphicsImage);
    initBlockChain(memory, ONYX_MEMORY_EXTERNAL_DEVICE_TYPE,
                   deviceExternalGraphicsImageMB * MB,
                   memory->deviceLocalTypeIndex, 0, false, "devExtImage",
                   &memory->blockChainExternalDeviceGraphicsImage);
}

OnyxBuffer onyx_request_buffer_region_aligned(OnyxMemory          *memory,
                                              const size_t         size,
                                              uint32_t             alignment,
                                              const OnyxMemoryType memType)
{
    assert(size > 0);
    if (size % 4 != 0) // only allow for word-sized blocks
    {
        hell_error(HELL_ERR_FATAL, "Size %zu is not 4 byte aligned.", size);
    }
    OnyxMemBlock            *block = NULL;
    struct onyx_memory_pool *chain = NULL;
    switch (memType) {
        case ONYX_MEMORY_HOST_GRAPHICS_TYPE:
            chain = &memory->blockChainHostGraphicsBuffer;
            break;
        case ONYX_MEMORY_HOST_TRANSFER_TYPE:
            chain = &memory->blockChainHostTransferBuffer;
            break;
        case ONYX_MEMORY_DEVICE_TYPE:
            chain = &memory->blockChainDeviceGraphicsBuffer;
            break;
        default:
            block = NULL;
            assert(0);
    }

    assert(hell_is_power_of_two(alignment));

    if (0 == alignment)
        alignment = chain->alignment;
    // i want to move to a model where we have a separate chain for each
    // alignment type. the main reason is for resizing: if i need to resize a
    // region I need to know what alignment it requires. I don't want the user
    // to have to provide that again. But I also don't want to store an
    // alignment along with every region. So for now, I just make sure the chain
    // alignment is as large as the largest alignment requirement it has
    // allocated for. since each is a power of 2, then it implicitly will
    // satisfy all of its regions alignment reqs.
    else if (alignment > chain->alignment)
        chain->alignment = alignment;
    block = requestBlock(size, alignment, chain);

    OnyxBuffer region = {0};
    region.offset     = block->offset;
    region.block_id   = block->id;
    region.size       = size;
    region.buffer     = chain->buffer;
    region.chain      = chain;

    // TODO this check is very brittle. we should probably change V_MemoryType
    // to a mask with flags for the different requirements. One bit for host or
    // device, one bit for transfer capabale, one bit for external, one bit for
    // image or buffer
    if (memType == ONYX_MEMORY_HOST_TRANSFER_TYPE ||
        memType == ONYX_MEMORY_HOST_GRAPHICS_TYPE)
        region.host_data = chain->hostData + block->offset;
    else
        region.host_data = NULL;

    return region;
}

OnyxBuffer onyx_request_buffer_region(OnyxMemory *memory, const size_t size,
                                      const VkBufferUsageFlags flags,
                                      const OnyxMemoryType     memType)
{
    uint32_t alignment = alignmentForBufferUsage(memory, flags);
    return onyx_request_buffer_region_aligned(
        memory, size, alignment,
        memType); // TODO: fix this. find the maximum alignment and choose that
}

OnyxBuffer onyx_request_buffer_region_array(OnyxMemory        *memory,
                                            uint32_t           elemSize,
                                            uint32_t           elemCount,
                                            VkBufferUsageFlags flags,
                                            OnyxMemoryType     memType)
{
    // calculate the size needed and call requestBufferRegionAligned.
    // make sure to set the stride.
    uint32_t   alignment = alignmentForBufferUsage(memory, flags);
    uint32_t   stride    = hell_align(elemSize, alignment);
    uint64_t   size      = stride * elemCount;
    OnyxBuffer region =
        onyx_request_buffer_region_aligned(memory, size, alignment, memType);
    region.stride = stride;
    return region;
}

uint32_t onyx_get_memory_type(const OnyxMemory *memory, uint32_t typeBits,
                              const VkMemoryPropertyFlags properties)
{
    for (uint32_t i = 0; i < memory->properties.memoryTypeCount; i++) {
        if (((typeBits & (1 << i)) > 0) &&
            (memory->properties.memoryTypes[i].propertyFlags & properties) ==
                properties) {
            return i;
        }
    }
    assert(0);
    return ~0u;
}

static bool image_requires_view(VkImageUsageFlags usage)
{
    return usage & (VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_STORAGE_BIT |
                    VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT |
                    VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT |
                    VK_IMAGE_USAGE_INPUT_ATTACHMENT_BIT |
                    // VK_IMAGE_USAGE_SHADING_RATE_IMAGE_BIT |
                    // VK_IMAGE_USAGE_FRAGMENT_DENSITY_MAP_BIT |
                    VK_IMAGE_USAGE_TRANSIENT_ATTACHMENT_BIT);
}

OnyxImage onyx_create_image(OnyxMemory *memory, const uint32_t width,
                            const uint32_t height, const VkFormat format,
                            const VkImageUsageFlags  usageFlags,
                            const VkImageAspectFlags aspectMask,
                            const VkSampleCountFlags sampleCount,
                            const uint32_t           mipLevels,
                            const OnyxMemoryType     memType)
{
    assert(mipLevels > 0);
    assert(memType == ONYX_MEMORY_DEVICE_TYPE ||
           memType == ONYX_MEMORY_EXTERNAL_DEVICE_TYPE);

    assert(memory->deviceProperties->limits.framebufferColorSampleCounts >=
           sampleCount);
    assert(memory->deviceProperties->limits.framebufferDepthSampleCounts >=
           sampleCount);

    void *pNext = NULL;

    VkExternalMemoryImageCreateInfo externalImageInfo;
    if (memType == ONYX_MEMORY_EXTERNAL_DEVICE_TYPE) {
        externalImageInfo.sType =
            VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO;
        externalImageInfo.handleTypes =
            VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT;
        externalImageInfo.pNext = NULL;
        pNext                   = &externalImageInfo;
    }

    uint32_t queueFamilyIndex =
        onyx_queue_family_index(memory->instance, ONYX_QUEUE_GRAPHICS_TYPE);
    VkImageCreateInfo imageInfo = {.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
                                   .pNext = pNext,
                                   .imageType   = VK_IMAGE_TYPE_2D,
                                   .format      = format,
                                   .extent      = {width, height, 1},
                                   .mipLevels   = mipLevels,
                                   .arrayLayers = 1,
                                   .samples     = sampleCount,
                                   .tiling      = VK_IMAGE_TILING_OPTIMAL,
                                   .usage       = usageFlags,
                                   .sharingMode = VK_SHARING_MODE_EXCLUSIVE,
                                   .queueFamilyIndexCount = 1,
                                   .pQueueFamilyIndices   = &queueFamilyIndex,
                                   .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED};

    OnyxImage image = {0};

    V_ASSERT(vkCreateImage(memory->instance->device, &imageInfo, NULL,
                           &image.handle));

    VkMemoryRequirements memReqs;
    vkGetImageMemoryRequirements(memory->instance->device, image.handle,
                                 &memReqs);

    DPRINT("Requesting image of size %zu (0x%zx) \n", memReqs.size,
           memReqs.size);
    DPRINT("Width * Height * Format size = %d\n", width * height * 4);
    DPRINT("Required memory bits for image: %0x\n", memReqs.memoryTypeBits);

    image.size          = memReqs.size;
    image.extent.depth  = 1;
    image.extent.width  = width;
    image.extent.height = height;
    image.mip_levels    = mipLevels;
    image.aspect_mask   = aspectMask;
    image.format        = format;
    image.sample_count  = sampleCount;
    image.usage_flags   = usageFlags;

    switch (memType) {
        case ONYX_MEMORY_DEVICE_TYPE:
            image.chain = &memory->blockChainDeviceGraphicsImage;
            break;
        case ONYX_MEMORY_EXTERNAL_DEVICE_TYPE:
            image.chain = &memory->blockChainExternalDeviceGraphicsImage;
            break;
        default:
            assert(0);
    }

    const OnyxMemBlock *block =
        requestBlock(memReqs.size, memReqs.alignment, image.chain);
    image.block_id = block->id;
    image.offset   = block->offset;

    vkBindImageMemory(memory->instance->device, image.handle,
                      image.chain->vkmemory, block->offset);

    if (image_requires_view(usageFlags)) {

        VkImageViewCreateInfo viewInfo = {
            .sType            = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
            .image            = image.handle,
            .viewType         = VK_IMAGE_VIEW_TYPE_2D,
            .components       = {0, 0, 0, 0}, // no swizzling
            .format           = format,
            .subresourceRange = {.aspectMask     = aspectMask,
                                 .baseMipLevel   = 0,
                                 .levelCount     = mipLevels,
                                 .baseArrayLayer = 0,
                                 .layerCount     = 1}};

        V_ASSERT(vkCreateImageView(memory->instance->device, &viewInfo, NULL,
                                   &image.view));

        // create specialized aspect views. these are needed for use in
        // descriptors, which can only access a single view of the image.
        if (aspectMask & VK_IMAGE_ASPECT_DEPTH_BIT) {
            viewInfo.subresourceRange.aspectMask = VK_IMAGE_ASPECT_DEPTH_BIT;
            V_ASSERT(vkCreateImageView(memory->instance->device, &viewInfo, NULL,
                                       &image.depth_only_view));
        }
        if (aspectMask & VK_IMAGE_ASPECT_STENCIL_BIT) {
            viewInfo.subresourceRange.aspectMask = VK_IMAGE_ASPECT_STENCIL_BIT;
            V_ASSERT(vkCreateImageView(memory->instance->device, &viewInfo, NULL,
                                       &image.stencil_only_view));
        }
    }

    image.sampler           = VK_NULL_HANDLE;
    image.last_known_layout = imageInfo.initialLayout;

    return image;
}

void onyx_free_image(OnyxImage *image)
{
    assert(image->size != 0);
    if (image->sampler != VK_NULL_HANDLE) {
        vkDestroySampler(image->chain->memory->instance->device, image->sampler,
                         NULL);
    }
    vkDestroyImageView(image->chain->memory->instance->device, image->view,
                       NULL);
    if (image->depth_only_view)
        vkDestroyImageView(image->chain->memory->instance->device, image->depth_only_view,
                           NULL);
    if (image->stencil_only_view)
        vkDestroyImageView(image->chain->memory->instance->device, image->stencil_only_view,
                           NULL);
    vkDestroyImage(image->chain->memory->instance->device, image->handle, NULL);
    freeBlock(image->chain, image->block_id);
    memset(image, 0, sizeof(OnyxImage));
}

void onyx_free_buffer(OnyxBuffer *pRegion)
{
    assert(pRegion->size != 0);
    freeBlock(pRegion->chain, pRegion->block_id);
    if (pRegion->host_data)
        memset(pRegion->host_data, 0, pRegion->size);
    memset(pRegion, 0, sizeof(OnyxBuffer));
}

void onyx_cmd_copy_buffer(VkCommandBuffer cmd, const OnyxBuffer *src,
                          OnyxBuffer *dst)
{
    VkBufferCopy copy;
    copy.srcOffset = src->offset;
    copy.dstOffset = dst->offset;
    copy.size      = src->size;

    vkCmdCopyBuffer(cmd, src->buffer, dst->buffer, 1, &copy);
}

void onyx_copy_buffer_region(const OnyxBuffer *src, OnyxBuffer *dst)
{
    OnyxCommand cmd =
        onyx_create_command(src->chain->memory->instance,
                            ONYX_QUEUE_GRAPHICS_TYPE); // arbitrary index;

    onyx_begin_command_buffer(cmd.buffer);

    onyx_cmd_copy_buffer(cmd.buffer, src, dst);

    onyx_end_command_buffer(cmd.buffer);

    onyx_submit_and_wait(&cmd, 0);

    onyx_destroy_command(cmd);
}

void onyx_v_CopyImageToBufferRegion(const OnyxImage *image,
                                    OnyxBuffer      *bufferRegion)
{
    // TODO
}

void onyx_transfer_to_device(OnyxMemory *memory, OnyxBuffer *pRegion)
{
    const OnyxBuffer srcRegion = *pRegion;
    assert(srcRegion.chain ==
           &memory->blockChainHostGraphicsBuffer); // only chain it makes sense
                                                   // to transfer from
    OnyxBuffer destRegion = onyx_request_buffer_region(
        memory, srcRegion.size, 0, ONYX_MEMORY_DEVICE_TYPE);

    onyx_copy_buffer_region(&srcRegion, &destRegion);

    onyx_free_buffer(pRegion);

    *pRegion = destRegion;
}

void onyx_destroy_memory(OnyxMemory *memory)
{
    freeBlockChain(memory, &memory->blockChainHostGraphicsBuffer);
    freeBlockChain(memory, &memory->blockChainHostTransferBuffer);
    freeBlockChain(memory, &memory->blockChainDeviceGraphicsImage);
    freeBlockChain(memory, &memory->blockChainDeviceGraphicsBuffer);
    freeBlockChain(memory, &memory->blockChainExternalDeviceGraphicsImage);
}

VkDeviceAddress onyx_get_buffer_region_address(const BufferRegion *region)
{
    assert(region->chain->bufferAddress != 0);
    return region->chain->bufferAddress + region->offset;
}

void onyx_create_unmanaged_buffer(OnyxMemory              *memory,
                                  const VkBufferUsageFlags bufferUsageFlags,
                                  const uint32_t           memorySize,
                                  const OnyxMemoryType     type,
                                  VkDeviceMemory *pMemory, VkBuffer *pBuffer)
{
    uint32_t typeIndex;
    switch (type) {
        case ONYX_MEMORY_HOST_GRAPHICS_TYPE:
            typeIndex = memory->hostVisibleCoherentTypeIndex;
            break;
        case ONYX_MEMORY_HOST_TRANSFER_TYPE:
            typeIndex = memory->hostVisibleCoherentTypeIndex;
            break;
        case ONYX_MEMORY_DEVICE_TYPE:
            typeIndex = memory->deviceLocalTypeIndex;
            break;
        case ONYX_MEMORY_EXTERNAL_DEVICE_TYPE:
            typeIndex = memory->deviceLocalTypeIndex;
            break;
    }

    const VkMemoryAllocateInfo allocInfo = {
        .sType           = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
        .allocationSize  = memorySize,
        .memoryTypeIndex = typeIndex};

    VkBufferCreateInfo ci = {
        .sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
        .usage = bufferUsageFlags,
        .sharingMode =
            VK_SHARING_MODE_EXCLUSIVE, // queue determined by first use
        .size = memorySize};

    V_ASSERT(
        vkAllocateMemory(memory->instance->device, &allocInfo, NULL, pMemory));

    V_ASSERT(vkCreateBuffer(memory->instance->device, &ci, NULL, pBuffer));

    V_ASSERT(
        vkBindBufferMemory(memory->instance->device, *pBuffer, *pMemory, 0));
}

VkDeviceMemory onyx_get_device_memory(const OnyxMemory    *memory,
                                      const OnyxMemoryType memType)
{
    switch (memType) {
        case ONYX_MEMORY_EXTERNAL_DEVICE_TYPE:
            return memory->blockChainExternalDeviceGraphicsImage.vkmemory;
        default:
            assert(0); // TODO
            return 0;
    }
}

VkDeviceSize onyx_get_memory_size(const OnyxMemory    *memory,
                                  const OnyxMemoryType memType)
{
    switch (memType) {
        case ONYX_MEMORY_EXTERNAL_DEVICE_TYPE:
            return memory->blockChainExternalDeviceGraphicsImage.totalSize;
        default:
            assert(0); // TODO
            return 0;
    }
}

#ifdef WIN32
bool onyx_get_external_memory_win32_handle(const OnyxMemory *memory,
                                           HANDLE *handle, uint64_t *size)
{
    VkMemoryGetWin32HandleInfoKHR handleInfo = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_GET_WIN32_HANDLE_INFO_KHR,
        .memory =
            onyx_get_device_memory(memory, ONYX_MEMORY_EXTERNAL_DEVICE_TYPE),
        .handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_WIN32_BIT,
    };

    V_ASSERT(vkGetMemoryWin32HandleKHR(onyx_get_device(memory->instance),
                                       &handleInfo, handle));

    *size = onyx_get_memory_size(memory, ONYX_MEMORY_EXTERNAL_DEVICE_TYPE);

    assert(*size);
    return true;
}
#else
bool onyx_get_external_memory_fd(const OnyxMemory *memory, int *fd,
                                 uint64_t *size)
{
    // fast path
    VkMemoryGetFdInfoKHR fdInfo = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_GET_FD_INFO_KHR,
        .memory =
            onyx_get_device_memory(memory, ONYX_MEMORY_EXTERNAL_DEVICE_TYPE),
        .handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT,
    };

    V_ASSERT(vkGetMemoryFdKHR(onyx_get_device(memory->instance), &fdInfo, fd));

    *size = onyx_get_memory_size(memory, ONYX_MEMORY_EXTERNAL_DEVICE_TYPE);

    assert(*size);
    return true;
}
#endif

uint64_t onyx_size_of_memory(void) { return sizeof(OnyxMemory); }

OnyxMemory *onyx_alloc_memory(void) { return hell_malloc(sizeof(OnyxMemory)); }

static void simpleBlockchainReport(const OnyxMemoryPool *chain)
{
    float percent = (float)chain->usedSize / chain->totalSize;
    hell_print("Blockchain: %s Used Size: %d Total Size: %d Percent Used: %f\n",
               chain->name, chain->usedSize, chain->totalSize, percent);
}

void onyx_memory_report_simple(const OnyxMemory *memory)
{
    hell_print("Memory Report\n");
    simpleBlockchainReport(&memory->blockChainHostGraphicsBuffer);
    simpleBlockchainReport(&memory->blockChainDeviceGraphicsBuffer);
    simpleBlockchainReport(&memory->blockChainDeviceGraphicsImage);
    simpleBlockchainReport(&memory->blockChainHostTransferBuffer);
    simpleBlockchainReport(&memory->blockChainExternalDeviceGraphicsImage);
}

void onyx_get_image_memory_usage(const OnyxMemory *memory,
                                 uint64_t *bytes_in_use, uint64_t *total_bytes)
{
    *bytes_in_use = memory->blockChainDeviceGraphicsImage.usedSize;
    *total_bytes  = memory->blockChainDeviceGraphicsImage.totalSize;
}

const OnyxInstance *onyx_get_memory_instance(const OnyxMemory *memory)
{
    return memory->instance;
}

#define error hell_error_fatal

static void growBufferRegion(BufferRegion *region, size_t new_size)
{
    OnyxMemoryPool *chain  = region->chain;
    uint32_t        cur_id = region->block_id;
    Block          *block  = NULL;

    for (int i = 0; i < chain->count; i++) {
        if (chain->blocks[i].id == cur_id) {
            block = &chain->blocks[i];
            break;
        }
    }
    assert(block);

    if (new_size <= block->size) {
        // can trivially set the region size to new_size and return
        region->size = new_size;
        return;
    }

    Block       *new_block  = requestBlock(new_size, chain->alignment, chain);
    BufferRegion new_region = *region;
    new_region.offset       = new_block->offset;
    new_region.block_id     = new_block->id;
    new_region.size         = new_size;

    // is host mapped
    if (new_region.host_data) {
        new_region.host_data = chain->hostData + new_block->offset;
        memcpy(new_region.host_data, region->host_data, region->size);
    } else {
        error("GPU resident grow region not implemented yet :(");
    }

    onyx_free_buffer(region);
    *region = new_region;
}

void onyx_resize_buffer_region(BufferRegion *region, size_t new_size)
{
    if (new_size > region->size)
        growBufferRegion(region, new_size);
    else
        hell_error_fatal("Shrinking buffer is not supported yet :(");
}
