#include "onyx.h"

int onyx_create_orb(const OnyxInstanceParms* ip,
    const uint32_t hostGraphicsBufferMB,
    const uint32_t deviceGraphicsBufferMB,
    const uint32_t deviceGraphicsImageMB, const uint32_t hostTransferBufferMB,
    const uint32_t deviceExternalGraphicsImageMB,
    Onyx* orb)
{
    orb->instance = onyx_alloc_instance();
    orb->memory   = onyx_alloc_memory();
    onyx_create_instance(ip, orb->instance);
    onyx_create_memory(orb->instance, hostGraphicsBufferMB,
        deviceGraphicsBufferMB, deviceGraphicsImageMB,
        hostTransferBufferMB, deviceExternalGraphicsImageMB, orb->memory);
    orb->device = onyx_get_device(orb->instance);
    return 0;
}

OnyxContext onyx_create_context(OnyxSettings settings)
{
    OnyxContext ctx = {0};
    ctx.instance = onyx_alloc_instance();
    ctx.memory = onyx_alloc_memory();
    onyx_create_instance(&settings.ip, ctx.instance);
    onyx_create_memory(ctx.instance,
            settings.memory_sizes.host_graphics_buffer_mb,
            settings.memory_sizes.device_graphics_buffer_mb,
            settings.memory_sizes.device_graphics_image_mb,
            settings.memory_sizes.host_transfer_buffer_mb,
            settings.memory_sizes.device_external_graphics_image_mb, ctx.memory);
    ctx.device = onyx_get_device(ctx.instance);
    return ctx;
}

void onyx_create_context_(OnyxMemorySizes msizes, OnyxContext* out)
{
    OnyxContext ctx = {0};
    ctx.instance = onyx_alloc_instance();
    ctx.memory = onyx_alloc_memory();
    onyx_create_instance_basic(ctx.instance);
    onyx_create_memory(ctx.instance,
            msizes.host_graphics_buffer_mb,
            msizes.device_graphics_buffer_mb,
            msizes.device_graphics_image_mb,
            msizes.host_transfer_buffer_mb,
            msizes.device_external_graphics_image_mb, ctx.memory);
    ctx.device = onyx_get_device(ctx.instance);
    *out = ctx;
}

void onyx_create_context__(OnyxMemorySizes msizes, OnyxContext* ctx)
{
    assert(ctx->memory);
    assert(ctx->instance);
    onyx_create_instance_basic(ctx->instance);
    onyx_create_memory(ctx->instance,
            msizes.host_graphics_buffer_mb,
            msizes.device_graphics_buffer_mb,
            msizes.device_graphics_image_mb,
            msizes.host_transfer_buffer_mb,
            msizes.device_external_graphics_image_mb, ctx->memory);
    ctx->device = onyx_get_device(ctx->instance);
}

OnyxMemory* onyx_get_memory(OnyxContext* ctx)
{
    return ctx->memory;
}

OnyxInstance* onyx_get_instance(OnyxContext* ctx)
{
    return ctx->instance;
}

OnyxReflection* onyx_alloc_reflection()
{
    OnyxReflection* refl = malloc(sizeof(OnyxReflection));
    memset(refl, 0, sizeof(*refl));
    return refl;
}

OnyxContext* onyx_alloc_context()
{
    return malloc(sizeof(OnyxContext));
}

OnyxContext* onyx_alloc_context_(HellAllocator *alloc)
{
    assert(alloc);
    return alloc->alloc(alloc->user_data, sizeof(OnyxContext));
}
