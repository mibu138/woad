#include "util.h"

void onyx_print_format_properties(const OnyxInstance* instance, VkFormat format)
{
    VkFormatProperties formatProps;
    vkGetPhysicalDeviceFormatProperties(onyx_get_physical_device(instance), format, &formatProps);
    hell_print("VkFormat %d features:\n", format);
    hell_print("linearTiling features: ");
    hell_bit_print(&formatProps.linearTilingFeatures, 32);
    hell_print("OptimalTiling features: ");
    hell_bit_print(&formatProps.optimalTilingFeatures, 32);
    hell_print("Buffer features: ");
    hell_bit_print(&formatProps.bufferFeatures, 32);
}
