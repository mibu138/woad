struct onyx_reflection;

// empty definition
void onyx_create_reflection(struct onyx_reflection *refl)
{
}
