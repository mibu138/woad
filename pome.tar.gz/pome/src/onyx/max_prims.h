#ifndef ONYX_MAX_PRIMS_H
#define ONYX_MAX_PRIMS_H

#define ONYX_S_MAX_PRIMS     2000

#endif /* end of include guard: ONYX_MAX_PRIMS_H */
