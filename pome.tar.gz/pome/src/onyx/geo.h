#ifndef ONYX_R_GEO_H
#define ONYX_R_GEO_H

#include "attribute.h"
#include "exportable.h"
#include "memory.h"
#include <coal/coal.h>
#include <stdint.h>

#define ONYX_R_MAX_VERT_ATTRIBUTES 8
#define ONYX_R_ATTR_NAME_LEN 4

#ifdef __cplusplus
extern "C" {
#endif

typedef enum onyx_geometry_type {
    ONYX_GEOMETRY_TYPE_TRIANGLES = 0,
    ONYX_GEOMETRY_TYPE_POINTS    = 1,
    ONYX_GEOMETRY_TYPE_LINES     = 2,
    ONYX_GEOMETRY_TYPE_MAX
} OnyxGeometryType;

typedef enum onyx_geometry_flag {
    ONYX_GEOMETRY_FLAG_ARRAY_OF_STRUCTS = 1 << 0,
    ONYX_GEOMETRY_FLAG_UNINDEXED        = 1 << 1,
    ONYX_GEOMETRY_FLAG_INDEX_SIZE_SHORT = 1 << 2,
    ONYX_GEOMETRY_FLAG_NO_TYPES         = 1 << 3,
    ONYX_GEOMETRY_FLAG_MAX
} OnyxGeometryFlags;

enum onyx_attribute_type {
    ONYX_ATTRIBUTE_TYPE_POS,
    ONYX_ATTRIBUTE_TYPE_UV,
    ONYX_ATTRIBUTE_TYPE_COLOR,
    ONYX_ATTRIBUTE_TYPE_NORMAL,
    ONYX_ATTRIBUTE_TYPE_TANGENT,
    ONYX_ATTRIBUTE_TYPE_BITANGENT,
    ONYX_ATTRIBUTE_TYPE_SIGN,
    ONYX_ATTRIBUTE_TYPE_INDEX,
    ONYX_ATTRIBUTE_TYPE_COUNT,
};

/// We cannot use the enum directly because we want to enforce uint8_t as the
/// member size
typedef uint8_t OnyxAttributeType;
typedef uint8_t OnyxAttributeSize;

typedef struct onyx_geometry_template {
    uint8_t           type;
    uint8_t           flags;
    uint8_t           attribute_count;
    OnyxAttributeSize attribute_sizes[8];
    OnyxAttributeType attribute_types[8];
} OnyxGeometryTemplate;

typedef struct onyx_geometry {
    OnyxGeometryTemplate templ;
    // if attribute_count is greater than 8 then p_attribute_sizes will point to
    // a separately allocated array where they are stored.
    // keeping these separate gives us two things. one is that we can
    // use different buffer usage flags for each, which may matter on some
    // devices.
    // more importantly it allows us to more easily put the index buffer and
    // vertex buffer in separate regions of memory. this simplifies
    // resizing the geometry (imagine resizing the geometry if the indices
    // started right after the vertices).
    OnyxBuffer           vertex_buffer_region;
    // maybe unused
    OnyxBuffer           index_buffer_region;
    // same pattern as sizes. maybe unused.
} OnyxGeometry;

typedef struct  {
    struct onyx_memory   *memory;
    enum onyx_memory_type memtype;
    OnyxGeometryTemplate  templ;
    uint32_t              vertex_count;
    uint32_t              index_count;
} OnyxCreateGeometryInfo;

typedef uint32_t     OnyxGeoIndex;
typedef OnyxGeoIndex OnyxAttrIndex;
typedef uint8_t      OnyxGeoAttributeSize;

// vertexRegion.offset is the byte offset info the buffer where the vertex data
// is kept. attrOffsets store the byte offset relative to the vertexRegion
// offset where the individual attribute data is kept attrSizes stores how many
// bytes each individual attribute element takes up attrCount is how many
// different attribute types the primitive holds vertexRegion.size is the total
// size of the vertex attribute data
// typedef struct OnyxGeometry {
//     uint32_t          vertexCount;
//     uint32_t          indexCount;
//     uint32_t          attrCount;
//     OnyxBufferRegion vertexRegion;
//     OnyxBufferRegion indexRegion;
//     char attrNames[ONYX_R_MAX_VERT_ATTRIBUTES][ONYX_R_ATTR_NAME_LEN];
//     OnyxGeoAttributeSize
//         attrSizes[ONYX_R_MAX_VERT_ATTRIBUTES]; // individual element sizes
//     VkDeviceSize attrOffsets[ONYX_R_MAX_VERT_ATTRIBUTES];
// } OnyxGeometry;
typedef struct {
    struct cgltf_data *data;
    char               err_msg[256];
} HellGltfData;

#define MAX_CHARACTER_WEIGHTS 32
#define JOINT_MAX_NAME_LEN          256
typedef struct {
    uint32_t nweights;
    float    weights[MAX_CHARACTER_WEIGHTS];
    uint32_t joints[MAX_CHARACTER_WEIGHTS];
} HellWeightsMap;

typedef struct {
    uint32_t    vert_count;
    HellWeightsMap *weights_data;
    uint32_t    joint_count;
    CoalMat4   *joints;
    char      (*joints_names)[JOINT_MAX_NAME_LEN];
} HellCharacterData;

/// if successful, must free gltf data
int  hell_gltf_init(const char *filepath, HellGltfData *data);
int  hell_gltf_read_mesh(HellGltfData *gltf, OnyxMemory *mem,
                    const OnyxGeometryTemplate *reqt, OnyxGeometry *geo);
void hell_gltf_term(HellGltfData *data);
int hell_gltf_read_character(HellGltfData *gltf, HellCharacterData *character);

typedef uint32_t OnyxFlags;

OnyxGeometryTemplate onyx_geo_template_create_base(int  attr_count,
                                                   bool no_types);
void onyx_geo_template_set_attr_size(OnyxGeometryTemplate *, int index,
                                     uint8_t size);
void onyx_geo_template_set_attr_type(OnyxGeometryTemplate *t, int index,
                                     OnyxAttributeType type);

int      onyx_geo_template_get_attribute_size(const OnyxGeometryTemplate *geo,
                                              int                         index);
int      onyx_geo_template_get_attribute_type(const OnyxGeometryTemplate *geo,
                                              int                         index);
int      onyx_geo_template_get_vertex_size(const OnyxGeometryTemplate *geo);
VkFormat onyx_geo_template_get_attribute_format(const OnyxGeometryTemplate *geo,
                                                int index);
int      onyx_geo_template_get_attribute_offset(const OnyxGeometryTemplate *geo,
                                                int                         index);

int onyx_geo_get_attribute_size(const OnyxGeometry *geo, int index);
int onyx_geo_get_attribute_type(const OnyxGeometry *geo, int index);
int onyx_geo_get_vertex_size(const OnyxGeometry *geo);

static inline OnyxGeometryTemplate
onyx_geo_get_template(const OnyxGeometry *geo)
{
    return geo->templ;
}

const char *onyx_geo_attribute_type_name(enum onyx_attribute_type type);

typedef struct {
    uint32_t binding_count;
    uint32_t attribute_count;
    VkVertexInputBindingDescription
        binding_descriptions[ONYX_R_MAX_VERT_ATTRIBUTES];
    VkVertexInputAttributeDescription
        attribute_descriptions[ONYX_R_MAX_VERT_ATTRIBUTES];
} OnyxVertexDescription;

OnyxGeometryTemplate onyx_create_geometry_template(enum onyx_geometry_type type,
                                                   uint32_t       flags,
                                                   uint32_t       attr_count,
                                                   const uint8_t *attr_sizes,
                                                   const uint8_t *attr_types);
// pos and color. clockwise for now.
OnyxGeometry         onyx_create_geometry(const OnyxCreateGeometryInfo *c);
void                 onyx_free_geometry(OnyxGeometry *geo);
OnyxGeometry         onyx_create_triangle(OnyxMemory *);
OnyxGeometry onyx_create_cube(OnyxMemory *memory, const bool isClockWise);
OnyxGeometry onyx_create_cube_with_tangents(OnyxMemory *memory,
                                            const bool  isClockWise);
OnyxGeometry onyx_create_points(OnyxMemory *memory, OnyxMemoryType memtype,
                                const uint32_t count, int attr_count,
                                const uint8_t *attr_sizes,
                                const uint8_t *attr_types);
int          onyx_load_gltf(const char *filepath, OnyxMemory *mem,
                            const OnyxGeometryTemplate *reqt, // if null will create a
                                                              // template from the gltf
                            OnyxGeometry *geo, char errmsg[256]);
// OnyxGeometry onyx_create_curve(OnyxMemory*, const uint32_t vertCount,
//                                const uint32_t patchSize,
//                                const uint32_t restartOffset);
// OnyxGeometry onyx_create_quad_n_d_c(OnyxMemory*, const float x, const float
// y,
//                                  const float width, const float height);
//// creates pos, normal, and uv attribute
// OnyxGeometry onyx_create_quad_n_d_c_2(OnyxMemory* memory, const float x,
//                                    const float y, const float width,
//                                    const float height);

// if the geometry is going to be used for compute or raytracing must pass
// storage buffer usage bit if the geometry is going to be used for acceleration
// structure creation must pass acceleration structure build usage flag
// OnyxGeometry onyx_create_geometry(OnyxMemory*       memory,
//                                  VkBufferUsageFlags extraBufferFlags,
//                                  const uint32_t     vertCount,
//                                  const uint32_t     indexCount,
//                                  const uint8_t      attrCount,
//                                  const uint8_t attrSizes[/*attrCount*/]);
//
//// allows passing of attrib names
// OnyxGeometry onyx_create_geometry2(OnyxMemory*       memory,
//                                    VkBufferUsageFlags extraBufferFlags,
//                                    const uint32_t     vertCount,
//                                    const uint32_t     indexCount,
//                                    const uint8_t      attrCount,
//                                    const uint8_t attrSizes[/*attrCount*/],
//                                    const char* attrNames[/*attrCount*/]);
OnyxVertexDescription onyx_get_vertex_description(
    const uint32_t             attrCount,
    const OnyxGeoAttributeSize attrSizes[/*attrCount*/]);
void       *onyx_get_geo_attribute(OnyxGeometry *geo, const uint32_t index);
const void *onyx_get_geo_attribute_ro(const OnyxGeometry *geo,
                                      const uint32_t      index);
void       *onyx_get_geo_attribute2(const OnyxGeometry *prim, const char *name);
uint32_t   *onyx_get_geo_indices(OnyxGeometry *prim);
const uint32_t *onyx_get_geo_indices_ro(const OnyxGeometry *prim);
void onyx_bind_geo(const VkCommandBuffer cmdBuf, const OnyxGeometry *prim);
void onyx_draw_geo(const VkCommandBuffer cmdBuf, const OnyxGeometry *prim,
                   uint32_t instance_count);
// for overriding the element count of the draw. useful if you have a points geo
// and don't want to actually draw all the points. if given a number larger than
// the actual geo elem count, it will just use the geo elem count.
void onyx_draw_geo_elem_count(const VkCommandBuffer cmdBuf,
                              const OnyxGeometry *prim, uint32_t elem_count,
                              uint32_t instance_count);
void onyx_transfer_geo_to_device(OnyxMemory *memory, OnyxGeometry *prim);
void onyx_print_geo(const OnyxGeometry *prim);

OnyxGeometry onyx_create_quad_ndc_pos8_uv8(OnyxMemory *memory, const float x,
                                           const float y, const float width,
                                           const float       height,
                                           OnyxGeometryFlags flags);

int      onyx_get_attr_index(const OnyxGeometry *geo, const char *attrname);
uint32_t onyx_get_geo_index_count(const OnyxGeometry *geo);
uint32_t onyx_get_geo_vertex_count(const OnyxGeometry *geo);
uint32_t onyx_get_geo_triangle_count(const OnyxGeometry *geo);

OnyxAttributeSize
onyx_vert_input_attr_size(const OnyxVertexInputAttributeReflection *vi);

OnyxAttributeType
onyx_vert_input_attr_type(const OnyxVertexInputAttributeReflection *vi);

bool onyx_geo_template_compatible_with_vertex_shader(
    OnyxGeometryTemplate templ, const OnyxRasterizationReflection *refl);

#ifdef __cplusplus
};
#endif

#endif /* end of include guard: R_GEO_H */
