#ifndef V_SWAPCHAIN_H
#define V_SWAPCHAIN_H

#include "coal/types.h"
#include "memory.h"
#include "command.h"
#include "image.h"
#include "types.h"
#include <hell/window.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*OnyxR_SwapchainRecreationFn)(void);

#define MAX_SWAPCHAIN_IMAGES 4


typedef struct onyx_swapchain_image {
    uint32_t    index;
    // index will be signalled when this image has been acquired.
    uint32_t    semaphore_index;
    const struct onyx_swapchain *swapchain;
} OnyxSwapchainImage;

typedef struct onyx_swapchain {
    VkDevice                     device;
    VkPhysicalDevice             physical_device;
    VkInstance                   instance;
    uint32_t                     image_count;
    // these ids will be unique for each swapchain image and can be used to
    // determine if the swapchain image has changed since the last use
    uint64_t                     image_uuid[MAX_SWAPCHAIN_IMAGES];
    VkImageView                  image_views[MAX_SWAPCHAIN_IMAGES];
    // index here does not correspond to the acquired image index, since we have
    // to pass a semaphore to vkAcquireImage before we actually know what the
    // image index will be.
    VkSemaphore                  image_acquired[MAX_SWAPCHAIN_IMAGES];
    VkFormat                     format;
    VkImageUsageFlags            image_usage_flags;
    VkSwapchainKHR               swapchain;
    // native windows are abstrated by surfaces. a swapchain can only be
    // associated with one window. 30.7 in spec.
    VkSurfaceKHR                 surface;
    bool                         window_resize_occurred;
    uint8_t                      next_semaphore_id;
    uint32_t                     width;
    uint32_t                     height;
    uint32_t                     acquired_image_index;
    VkPresentModeKHR             present_mode;
    uint64_t                     present_id;
} OnyxSwapchain;

static inline
CoalIvec2 onyx_swapchain_image_dimensions(const OnyxSwapchainImage *ref)
{
    CoalIvec2 v;
    v.x = ref->swapchain->width;
    v.y = ref->swapchain->height;
    return v;
}

static inline
VkImageView onyx_swapchain_image_view(const OnyxSwapchainImage *ref)
{
    return ref->swapchain->image_views[ref->index];
}

static inline
uint64_t onyx_swapchain_image_uuid(const OnyxSwapchainImage *ref)
{
    return ref->swapchain->image_uuid[ref->index];
}

OnyxSwapchain* onyx_alloc_swapchain(void);
size_t          onyx_size_of_swapchain(void);
void            onyx_free_swapchain(OnyxSwapchain* swapchain);
void
onyx_create_swapchain(
        VkInstance instance,
        VkDevice device,
        VkPhysicalDevice physical_device,
                   const HellWindow*      hellWindow,
                   VkImageUsageFlags      usageFlags,
                   OnyxSwapchain*         swapchain);
void onyx_destroy_swapchain(OnyxSwapchain* swapchain);
unsigned        onyx_get_swapchain_width(const OnyxSwapchain* swapchain);
unsigned        onyx_get_swapchain_height(const OnyxSwapchain* swapchain);
VkExtent2D      onyx_get_swapchain_extent(const OnyxSwapchain* swapchain);
VkExtent3D      onyx_get_swapchain_extent3_d(const OnyxSwapchain* swapchain);
VkFormat        onyx_get_swapchain_format(const OnyxSwapchain* swapchain);

void onyx_swapchain_notify_window_resized(OnyxSwapchain *swapchain, u32 w, u32 h);

VkImageView onyx_get_swapchain_image_view(const OnyxSwapchain* swapchain,
                                       int                   index);

unsigned onyx_get_swapchain_image_count(const OnyxSwapchain* swapchain);

// one thing to be careful of here is if this function fails the waitSemaphores
// will not be signalled.
bool onyx_present_frame(OnyxSwapchain* swapchain, const uint32_t semaphoreCount,
                       VkSemaphore* waitSemaphores);

int onyx_present_swapchains(VkQueue present_queue,
        uint32_t swapchain_count,
        OnyxSwapchain * const *swapchains,
        uint32_t wait_semaphore_count,
        VkSemaphore const *wait_semas);

// fence can be a VK_NULL_HANDLE
OnyxSwapchainImage onyx_acquire_swapchain_image(OnyxSwapchain* swapchain);

VkDeviceSize onyx_get_swapchain_image_size(const OnyxSwapchain* swapchain);

uint32_t onyx_get_swapchain_frame_count(const OnyxSwapchain*);

uint32_t onyx_get_swapchain_pixel_byte_count(const OnyxSwapchain* swapchain);

// returns 0 for success
int onyx_swapchain_wait_for_present(OnyxSwapchain* s, int64_t timeout_ns);

#ifdef __cplusplus
}
#endif

#endif /* end of include guard: V_SWAPCHAIN_H */
