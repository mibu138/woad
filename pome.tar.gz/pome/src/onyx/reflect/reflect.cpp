#include <bitset>
#include <cassert>
#include <ctype.h>
#include <filesystem>
#include <iostream>
#include <map>
#include <onyx/limits.h>
#include <onyx/types.h>
#include <onyx/vulkan.h>
#include <set>
#include <spirv_cross.hpp>
#include <stdio.h>
#include <utility>
#include <vector>
#include <hell/error.h>
#include <hell/io.h>
#include "reflect.h"

#undef ERROR
#undef MAIN_ERROR

#define MAIN_ERROR(error_string)                                               \
    do {                                                                       \
        printf("%s\n", error_string);                                          \
        return 1;                                                              \
    } while (0);

#define ERROR(error_string)                                                    \
    do {                                                                       \
        printf("%s\n", error_string);                                          \
        exit(1);                                                               \
    } while (0);

#define OUT_BUF_SIZE 500000
#define CODE_ARRAY_NAME_SUFFIX "_code"

constexpr const char *USAGE_STRING =
    "Usage: reflect SPV_FILE [SPV_FILE]... [PIPELINE FILE]";

char  out_buf[OUT_BUF_SIZE];
char *head = out_buf;

#define DRPINT 0
#define sbprint(fmt, ...)                                                      \
    do {                                                                       \
        head += sprintf(head, fmt, ##__VA_ARGS__);                             \
    } while (0)
#define dprint(fmt, ...)                                                       \
    do {                                                                       \
        if (DRPINT)                                                            \
            printf(fmt, ##__VA_ARGS__);                                        \
    } while (0)

char reflection_function_name[128] = "onyx_create_reflection";

// enum ShaderStage {
//     VERT,
//     FRAG,
//     COMPUTE,
//     RAYGEN,
//     RAYCHITv
//     RAYMISS
// };

#define MAX_NAME_SIZE 64
#define MAX_RESOURCE_COUNT 20
#define MAX_VERTEX_INPUTS 8

static const char *output_path;

struct ShaderName{ 
    char buf[MAX_NAME_SIZE];
};

std::vector<const char *> declared_vars;
std::vector<const char *> var_stack;
int                       scope_count  = 0;
int                       auto_var_cnt = 0;

#define AUTO_VAR_BASE "var"
#define MAX_AUTO_VARS 1000

#define INDENT_WIDTH 4
#define SCOPE_MAX 10

char indent_buf[INDENT_WIDTH * SCOPE_MAX];

static void begin_scope()
{
    sbprint("%s{\n", indent_buf);
    scope_count++;

    assert(scope_count < SCOPE_MAX);
    memset(indent_buf, 0, sizeof(indent_buf));
    memset(indent_buf, ' ', scope_count * INDENT_WIDTH);
}

static void end_scope()
{
    scope_count--;
    assert(scope_count >= 0);
    memset(indent_buf, 0, sizeof(indent_buf));
    memset(indent_buf, ' ', scope_count * INDENT_WIDTH);

    sbprint("%s}\n", indent_buf);
}

static void declare_var(const char *type, const char *name)
{
    for (size_t i = 0; i < declared_vars.size(); ++i) {
        if (strcmp(name, declared_vars[i]) == 0)
            assert(0 && "Variable names must not be reused");
    }
    sbprint("\n%s%s %s;\n%smemset(&%s, 0, sizeof(%s));\n", indent_buf, type,
            name, indent_buf, name, name);
    declared_vars.push_back(name);
}

static void copy_var(const char *src)
{
    sbprint("%s%s = %s;\n", indent_buf, var_stack.back(), src);
}

static void copy_var(const char *dst, const char *src)
{
    sbprint("%s%s = %s;\n", indent_buf, dst, src);
}

static void push_var(const char *name)
{
    for (const auto &var : var_stack) {
        if (strcmp(name, var) == 0) {
            assert(0 && "Cannot push a var already on the stack");
        }
    }
    var_stack.push_back(name);
}

static void declare_and_push_auto(const char *type,
                                  const char *basename = nullptr)
{
    // don't free, doesn't matter. this program is short lived.
    char *buf;
    int   bufsize;

    if (basename)
        bufsize = strlen(basename) + 5;
    else {
        bufsize  = sizeof(AUTO_VAR_BASE) + 5;
        basename = AUTO_VAR_BASE;
    }
    buf = (char *)calloc(bufsize, 1);

    sprintf(buf, "%s%d", basename, auto_var_cnt++);
    declare_var(type, buf);
    push_var(buf);
}

static const char *pop_var()
{
    assert(var_stack.size());
    const char *last = var_stack.back();
    var_stack.pop_back();
    return last;
}

// push the parameters onto the stack in reverse declaration order (last parm
// push first). if argc < var_stack.size(), will use the last value as a return.
static void call_function(const char *function_name, size_t argc)
{
    const char *return_var = nullptr;
    if (var_stack.size() > argc)
        return_var = var_stack[var_stack.size() - argc - 1];
    if (return_var)
        sbprint("%s%s = %s(", indent_buf, return_var, function_name);
    else
        sbprint("%s%s(", indent_buf, function_name);
    const char *var;
    while (argc-- > 0) {
        var = pop_var();
        sbprint("%s%s", var, argc == 0 ? "" : ", ");
    }
    sbprint(");\n");
}

static void return_var()
{
    const char *var = pop_var();
    sbprint("%sreturn %s;\n", indent_buf, var);
}

static void set_var_member(const char *member, const char *value)
{
    sbprint("%s%s.%s = %s;\n", indent_buf, var_stack.back(), member, value);
}

static void set_var_member(const char *member, int value)
{
    sbprint("%s%s.%s = %d;\n", indent_buf, var_stack.back(), member, value);
}

static void set_var_member_str(const char *member, const char *value)
{
    sbprint("%s%s.%s = \"%s\";\n", indent_buf, var_stack.back(), member, value);
}

static void set_var_member(const char *member, int elem, int value)
{
    sbprint("%s%s.%s[%d] = %d;\n", indent_buf, var_stack.back(), member, elem,
            value);
}

static void set_var_member(const char *member, int elem, const char *value)
{
    sbprint("%s%s.%s[%d] = %s;\n", indent_buf, var_stack.back(), member, elem,
            value);
}

static void set_var_member_str(const char *member, int elem, const char *value)
{
    sbprint("%s%s.%s[%d] = \"%s\";\n", indent_buf, var_stack.back(), member,
            elem, value);
}

static void set_var(const char *value)
{
    sbprint("%s%s = \"%s\";\n", indent_buf, var_stack.back(), value);
}

static void set_var(int value)
{
    sbprint("%s%s = %d;\n", indent_buf, var_stack.back(), value);
}

struct VertInput {
    int  location;
    int  n_components;
    char name[MAX_NAME_SIZE];
};

struct VertShaderInfo {
    int       input_count;
    VertInput inputs[MAX_VERTEX_INPUTS];
};

struct FragShaderInfo {
    int color_attachment_count;
};

struct CompShaderInfo {
    int local_sizes[3];
};

using DescriptorReference = OnyxDescriptorReference;

struct SpirvCode {
    unsigned char      *code;
    int                 byte_count;
    const char         *file_path;
    ShaderName          name;
    spv::ExecutionModel stage;
    union {
        VertShaderInfo vert_info;
        FragShaderInfo frag_info;
        CompShaderInfo comp_info;
    };
};

using ProgramType = OnyxProgramType;

constexpr int MAX = 100;

// can only increase in size. never reallocates as long as size < MAX.
template <typename T> class MonotonicArray
{
  public:
    MonotonicArray() { vec.reserve(MAX); }
    T       &operator[](int i) { return vec[i]; }
    const T &operator[](int i) const { return vec[i]; }
    int      push_back(T item)
    {
        vec.push_back(item);
        return vec.size() - 1;
    }
    int push_back_if_unique(T item)
    {
        for (size_t i = 0; i < vec.size(); i++) {
            if (item == vec[i])
                return i;
        }
        vec.push_back(item);
        return vec.size() - 1;
    }
    int  size() const { return vec.size(); }
    T   &back() { return vec.back(); }
    bool operator==(const MonotonicArray<T> &other) const
    {
        return (vec == other.vec);
    }
    typename std::vector<T>::iterator       begin() { return vec.begin(); }
    typename std::vector<T>::iterator       end() { return vec.end(); }
    typename std::vector<T>::const_iterator begin() const
    {
        return vec.begin();
    }
    typename std::vector<T>::const_iterator end() const { return vec.end(); }

  private:
    std::vector<T> vec;
};

struct Program {
    MonotonicArray<int>
        shader_indices; // should be long enough for any pipeline
    MonotonicArray<int>                 push_constant_indices;
    MonotonicArray<DescriptorReference> descriptor_references;
    int                                 pipeline_layout_index;
    ProgramType                         type;
    std::string                         name;
};

using namespace spirv_cross;

enum Error {
    INCOMPATIBLE_DESCRIPTORS = 1,
};

struct Descriptor {
    int                                 count;
    VkDescriptorType                    type;
    MonotonicArray<spv::ExecutionModel> stages;
    int                                 struct_index = -1;
    int                                 image_index  = -1;

    bool compatible(const Descriptor &other) const
    {
        return (other.count == count && other.type == type &&
                other.struct_index == struct_index);
    }
    bool compatible(int count_, VkDescriptorType type_) const
    {
        return (count_ == count && type_ == type);
    }

    void merge(Descriptor &other)
    {
        for (const auto &stage : other.stages) {
            stages.push_back_if_unique(stage);
        }
    }
};

struct ReflectContext;

struct DescriptorSet {
    MonotonicArray<int> bindings;
    MonotonicArray<int> descriptor_indices;

    // returns true if descriptor was added
    bool add_descriptor_if_possible(MonotonicArray<Descriptor> &descriptors,
                                    int binding, Descriptor &d)
    {
        // does not allow one set to contain different descriptors with the same
        // binding
        // in other words, bindings are unique to a set.
        assert(bindings.size() == descriptor_indices.size());
        for (int i = 0; i < bindings.size(); ++i) {
            if (bindings[i] == binding) {
                int di = descriptor_indices[i];
                if (descriptors[di].compatible(d)) {
                    descriptors[di].merge(d);
                    return true;
                }
                return false;
            }
        }

        bindings.push_back(binding);
        descriptor_indices.push_back(descriptors.push_back(d));
        return true;
    }
};

struct PushConstant {
    int                                 struct_index = 0;
    MonotonicArray<spv::ExecutionModel> stages;
};

struct PipelineLayout {
    MonotonicArray<int> descriptor_set_indices;
    MonotonicArray<int> push_constant_indices;

    bool operator==(const PipelineLayout &other) const
    {
        return (descriptor_set_indices == other.descriptor_set_indices &&
                push_constant_indices == other.push_constant_indices);
    }
};

#define MAX_STRUCT_DEF 1000
struct StructInfo {
    char definition[MAX_STRUCT_DEF];
    char name[MAX];
    int  size;
};

struct ImageInfo {
    char     name[MAX_NAME_SIZE];
    VkFormat format;
};

struct Parameter {
    enum class Type {
        TASK_NAME,
        WG_SIZE_FROM_IMAGE,
        WG_SIZE,
        RESOURCE_NAME,
        GRAPHICS_PIPELINE_SETTINGS,
        CLEAR_COLOR,
        GEOMETRY,
        GRAPH
    };

    Parameter(Type type_)
    {
        type = type_;
        memset(name, 0, sizeof(name));
        switch (type) {
            case Type::WG_SIZE_FROM_IMAGE:
                sprintf(type_name, "bool");
                break;
            case Type::GEOMETRY:
                sprintf(type_name, "const char*");
                sprintf(name, "geometry_name");
                break;
            case Type::TASK_NAME:
                sprintf(type_name, "const char*");
                sprintf(name, "task_name");
                break;
            case Type::RESOURCE_NAME:
                sprintf(type_name, "const char*");
                break;
            case Type::GRAPH:
                sprintf(type_name, "OnyxGraph*");
                sprintf(name, "graph");
                break;
            case Type::GRAPHICS_PIPELINE_SETTINGS:
                sprintf(type_name, "OnyxGraphicsPipelineSettings *");
                sprintf(name, "pipeline_settings");
                break;
            case Type::CLEAR_COLOR:
                sprintf(type_name, "CoalVec4");
                sprintf(name, "clear_color");
                break;
            case Type::WG_SIZE:
                sprintf(type_name, "CoalIvec3");
                sprintf(name, "wg_size");
                break;
        }
    }

    Type type;
    char type_name[64];
    char name[64];

    std::string declaration_string()
    {
        assert(strlen(name) > 0);
        std::string out;
        out.append(type_name);
        out.append(" ");
        out.append(name);
        return out;
    }
};

struct ProgramFunction {
    struct DescriptorRecord {
        const DescriptorReference &ref;
        const Descriptor          &desc;
        const int                  parm;

        DescriptorRecord(const DescriptorReference &ref_,
                         const Descriptor &desc_, const int parm_)
            : ref(ref_), desc(desc_), parm(parm_)
        {
        }
    };
    int                   prog_index;
    const Program        &prog;
    const ReflectContext &ctx;

    char                          fn_name[64];
    std::vector<Parameter>        parameters;
    std::vector<DescriptorRecord> descriptors;

    ProgramFunction(const ReflectContext &ctx, int prog_index);

    void sbprint_declaration() const
    {
        sbprint_header();
        sbprint(";\n");
    }

    void sbprint_definition() const
    {
        sbprint_header();
        begin_scope();

        switch (prog.type) {
            case OnyxProgramType::ONYX_PROGRAM_TYPE_COMPUTE:
                compute_impl();
                break;
            case OnyxProgramType::ONYX_PROGRAM_TYPE_RENDERPASS:
                rasterization_impl();
                break;
            case OnyxProgramType::ONYX_PROGRAM_TYPE_RAYTRACE:
                raytrace_impl();
                break;
        }

        end_scope();
    }

  private:
    void sbprint_header() const
    {
        sbprint("OnyxTaskId %s(", fn_name);
        for (int i = 0, n = parameters.size(); i < n; ++i) {
            const auto &parm = parameters[i];
            sbprint("\n%s%s %s%s", "    ", parm.type_name, parm.name,
                    i == n - 1 ? "" : ", ");
        }
        sbprint(")\n");
    }

    void compute_impl() const;

    void rasterization_impl() const;

    void raytrace_impl() const
    {
        declare_and_push_auto("OnyxTaskId", "tid");
        return_var();
    }

    void write_descriptors(const char *tid) const
    {
        for (const auto &rec : descriptors) {
            const auto       &ref            = rec.ref;
            const Descriptor &d              = rec.desc;
            const Parameter  &parm           = parameters[rec.parm];
            const char       *desc_type_name = nullptr;
            char              fn_name_buf[64];

            switch (d.type) {
                case VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER:
                    desc_type_name = "uniform_buffer";
                    break;
                case VK_DESCRIPTOR_TYPE_STORAGE_IMAGE:
                    desc_type_name = "storage_image";
                    break;
                default:
                    assert(0 && "Not supported yet.");
            }
            snprintf(fn_name_buf, LEN(fn_name_buf), "onyx_graph_add_%s_to_task",
                     desc_type_name);

            declare_and_push_auto("int", "binding");
            set_var(ref.binding);
            declare_and_push_auto("int", "set");
            set_var(ref.set);
            declare_and_push_auto("const char*", "res_name");
            copy_var(parm.name);
            push_var(tid);
            push_var("graph");
            call_function(fn_name_buf, 5);
        }
    }
};

struct ReflectContext {
    MonotonicArray<Descriptor>     descriptors;
    MonotonicArray<DescriptorSet>  descriptor_sets;
    MonotonicArray<StructInfo>     structs;
    MonotonicArray<ImageInfo>      images;
    MonotonicArray<Program>        programs;
    MonotonicArray<SpirvCode>      codes;
    MonotonicArray<PushConstant>   push_constants;
    MonotonicArray<PipelineLayout> pipeline_layouts;
    std::vector<ProgramFunction>   funcs;

    const SpirvCode get_shader_code_const(int i) const { return codes[i]; }

    // return nullptr if not found
    const Descriptor *get_descriptor(const DescriptorReference &ref) const
    {
        const auto &set = descriptor_sets[ref.set_index];
        for (int i = 0; i < set.bindings.size(); i++) {
            if (set.bindings[i] == ref.binding) {
                return &descriptors[set.descriptor_indices[i]];
            }
        }
        return nullptr;
    }

    std::vector<ProgramFunction> make_program_task_functions()
    {
        for (int i = 0; i < programs.size(); i++) {
            ProgramFunction func(*this, i);
            funcs.push_back(func);
        }
        return funcs;
    }
};

ProgramFunction::ProgramFunction(const ReflectContext &ctx_, int i)
    : prog_index(i), prog(ctx_.programs[i]), ctx(ctx_)
{
    memset(fn_name, 0, LEN(fn_name));
    snprintf(fn_name, LEN(fn_name), "onyx_graph_add_%s_task",
             prog.name.c_str());
    assert(LEN(fn_name) > strlen(fn_name));
    parameters.push_back(Parameter::Type::GRAPH);
    parameters.push_back(Parameter::Type::TASK_NAME);

    for (int i = 0, n = prog.descriptor_references.size(); i < n; ++i) {

        const auto       &ref = prog.descriptor_references[i];
        const Descriptor *d   = ctx.get_descriptor(ref);

        {
            Parameter parm(Parameter::Type::RESOURCE_NAME);
            sprintf(parm.name, "%s_resource_name", ref.name);

            assert(d);

            parameters.push_back(parm);
        }

        DescriptorRecord desc_rec(ref, *d, parameters.size() - 1);
        descriptors.push_back(desc_rec);

        if (prog.type == ProgramType::ONYX_PROGRAM_TYPE_COMPUTE) {
            if (d->type == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE) {
                Parameter wg_parm(Parameter::Type::WG_SIZE_FROM_IMAGE);
                sprintf(wg_parm.name, "wg_size_from_%s", ref.name);
                parameters.push_back(wg_parm);
            }
        }
    }

    switch (prog.type) {
        case OnyxProgramType::ONYX_PROGRAM_TYPE_RENDERPASS:
            parameters.push_back(Parameter::Type::GRAPHICS_PIPELINE_SETTINGS);
            parameters.push_back(Parameter::Type::CLEAR_COLOR);
            parameters.push_back(Parameter::Type::GEOMETRY);
            break;
        case OnyxProgramType::ONYX_PROGRAM_TYPE_COMPUTE:
            parameters.push_back(Parameter::Type::WG_SIZE);
            break;
        case OnyxProgramType::ONYX_PROGRAM_TYPE_RAYTRACE:
            break;
    }
}

void ProgramFunction::compute_impl() const
{
    char buf[64];
    sprintf(buf, "&graph->reflection->programs[%d]", prog_index);
    declare_and_push_auto("OnyxTaskId", "tid");
    declare_and_push_auto("OnyxGraphComputeParms", "parms");
    set_var_member("program", buf);
    push_var("task_name");
    push_var("graph");
    call_function("onyx_graph_add_compute_task", 3);
    auto tid = pop_var();

    write_descriptors(tid);

    push_var(tid);
    return_var();
}

void ProgramFunction::rasterization_impl() const
{
    // TODO need to fix
    // declare_and_push_auto("OnyxTaskId", "tid");
    // declare_and_push_auto("OnyxGraphRasterizationParms", "parms");
    // set_var_member("program", prog_index);
    ////set_var_member("clear_color", "clear_color");
    // set_var_member("pipeline_settings", "pipeline_settings");
    // push_var("task_name");
    // push_var("graph");
    // call_function("onyx_graph_add_rasterization_task", 3);
    // auto tid = pop_var();

    // write_descriptors(tid);

    // push_var("geometry_name");
    // push_var(tid);
    // push_var("graph");
    // call_function("onyx_graph_add_geometry_to_task", 3);

    // push_var(tid);
    // return_var();
}

using ShaderCodes = MonotonicArray<SpirvCode>;
using Programs    = MonotonicArray<Program>;

ReflectContext create_context(ShaderCodes codes, Programs progs)
{
    ReflectContext ctx;
    ctx.codes    = std::move(codes);
    ctx.programs = std::move(progs);
    return ctx;
}

// returns base_type if it cannot get the name
int get_type_name(const Compiler &comp, const SPIRType &type, char buf[100])
{
    using BT = SPIRType::BaseType;

    int rows = type.vecsize;
    int cols = type.columns;

#define write_name(name)                                                       \
    sprintf(buf, name);                                                        \
    return 0

    switch (type.basetype) {
        case (BT::Int):
            switch (rows) {
                case (1):
                    write_name("int32_t");
                case (2):
                    switch (cols) {
                        case (1):
                            write_name("CoalIVec2");
                        case (2):
                            write_name("CoalIMat2");
                        default:
                            return -1;
                    }
                case (3):
                    switch (cols) {
                        case (1):
                            write_name("CoalIvec3");
                        default:
                            return -1;
                    }
                default:
                    return -1;
            }
        case (BT::UInt):
            switch (rows) {
                case (1):
                    write_name("uint32_t");
                default:
                    return -1;
            }
        case (BT::Float):
            switch (rows) {
                case (1):
                    write_name("float");
                case (2):
                    switch (cols) {
                        case (1):
                            write_name("CoalVec2");
                            return 0;
                        case (2):
                            write_name("CoalMat2");
                        default:
                            return -1;
                    }
                case (3):
                    switch (cols) {
                        case (1):
                            write_name("CoalVec3");
                            return 0;
                        case (3):
                            write_name("CoalMat3x4");
                        default:
                            return -1;
                    }
                case (4):
                    switch (cols) {
                        case (1):
                            write_name("CoalVec4");
                            return 0;
                        case (4):
                            write_name("CoalMat4");
                        default:
                            return -1;
                    }
            }
        case (BT::Struct):
            sprintf(buf, "%s", comp.get_name(type.self).c_str());
            return 0;
        default:
            return -1;
    }

    return 0;
}

int struct_reflect(ReflectContext &ctx, const Compiler &comp,
                   const TypeID base_type_id, int *struct_index,
                   char *info_string)
{
    auto    &type         = comp.get_type(base_type_id);
    unsigned member_count = type.member_types.size();

    StructInfo struct_info;
    zero(&struct_info);

    snprintf(struct_info.name, MAX, "%s", comp.get_name(type.self).c_str());

    char *sd = struct_info.definition;
    sd += sprintf(sd, "typedef struct %s {\n", struct_info.name);
    struct_info.size = comp.get_declared_struct_size(type);

    for (unsigned i = 0; i < member_count; i++) {
        auto &member_type = comp.get_type(type.member_types[i]);
        [[maybe_unused]] size_t member_size =
            comp.get_declared_struct_member_size(type, i);

        // Get member offset within this struct.
        [[maybe_unused]] size_t offset =
            comp.type_struct_member_offset(type, i);
#if 0
        sd += sprintf(sd, "\t// member offset = %ld\n", offset);
        sd += sprintf(sd, "\t// member size = %ld\n", member_size);
        sd += sprintf(sd, "\t// width = %d\n", member_type.width);
        sd += sprintf(sd, "\t// array size = %d\n", member_type.array.size() ? member_type.array[0] : 0);
        sd += sprintf(sd, "\t// array literal? %s\n", member_type.array.size() ? 
                member_type.array_size_literal[0] ? "yes" : "no ": "no");
        sd += sprintf(sd, "\t// num columns = %d\n", member_type.columns);
#endif

        if (!member_type.array.empty()) {
            // Get array stride, e.g. float4 foo[]; Will have array stride of 16
            // bytes.
            [[maybe_unused]] size_t array_stride =
                comp.type_struct_member_array_stride(type, i);
            // sd += sprintf(sd, "\t// array_stride = %ld\n", array_stride);
        }

        if (member_type.columns > 1) {
            // Get bytes stride between columns (if column major), for float4x4
            // -> 16 bytes.
            [[maybe_unused]] size_t matrix_stride =
                comp.type_struct_member_matrix_stride(type, i);
            // sd += sprintf(sd, "\t// matrix_stride = %ld\n", matrix_stride);
        }
        const std::string &name = comp.get_member_name(type.self, i);

        char type_name[100];
        int  er = get_type_name(comp, member_type, type_name);
        if (er != 0) {
            // printf("Failed on member %s\n", name.c_str());
        }
        assert(er == 0);

        sd += sprintf(sd, "\t%s %s", type_name, name.c_str());
        for (const auto &dim : member_type.array) {
            sd += sprintf(sd, "[%d]", dim);
        }
        sd += sprintf(sd, ";\n");

        if (member_type.basetype == SPIRType::BaseType::Struct) {
            int dummy;
            struct_reflect(ctx, comp, type.member_types[i], &dummy,
                           info_string);
        }
    }

    sd += sprintf(sd, "} %s;\n", struct_info.name);

    *struct_index = -1;
    for (int i = 0; i < ctx.structs.size(); ++i) {
        const StructInfo &other = ctx.structs[i];
        if (strcmp(struct_info.name, other.name) == 0) {
            if (strcmp(struct_info.definition, other.definition) != 0) {
                sprintf(info_string, "Struct %s has conflicting definitions",
                        other.name);
                return 1;
            }
            *struct_index = i;
            break;
        };
    }

    if (*struct_index == -1) {
        *struct_index = ctx.structs.size();
        ctx.structs.push_back(struct_info);
    }

    return 0;
}

static bool readonly_descriptor_type(VkDescriptorType type)
{
    switch (type) {
        case VK_DESCRIPTOR_TYPE_STORAGE_IMAGE:
        case VK_DESCRIPTOR_TYPE_STORAGE_BUFFER:
        case VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC:
            return false;
        default:
            return true;
    }
}

int add_resource_descriptor(ReflectContext &ctx, const Compiler &comp,
                            spv::ExecutionModel stage, const Resource &res,
                            VkDescriptorType desc_type, int struct_index,
                            const std::vector<int> &program_indices,
                            char                   *info_string)
{
    int er = 0;

    int  set     = comp.get_decoration(res.id, spv::DecorationDescriptorSet);
    int  binding = comp.get_decoration(res.id, spv::DecorationBinding);
    bool non_readable = comp.get_decoration(res.id, spv::DecorationNonReadable);
    bool non_writeable =
        comp.get_decoration(res.id, spv::DecorationNonWritable);

    // most descriptors are read only so we can ignore the decorations for these
    if (readonly_descriptor_type(desc_type)) {
        non_readable  = false;
        non_writeable = true;
    }

    const auto &type             = comp.get_type(res.type_id);
    int         descriptor_count = 1;
    // descriptor can be a multidimensional array
    for (size_t i = 0; i < type.array.size(); ++i) {
        descriptor_count *= type.array[i];
        assert(type.array_size_literal[i] &&
               "Do not yet support specialization constant reflection");
    }

    Descriptor desc = {
        .count        = descriptor_count,
        .type         = desc_type,
        .struct_index = struct_index,
    };
    desc.stages.push_back(stage);

    int index = -1;
    for (int i = 0; i < ctx.descriptor_sets.size(); ++i) {
        auto &set = ctx.descriptor_sets[i];
        if (set.add_descriptor_if_possible(ctx.descriptors, binding, desc)) {
            index = i;
        }
    }
    if (index == -1) {
        DescriptorSet newset;
        bool          r =
            newset.add_descriptor_if_possible(ctx.descriptors, binding, desc);
        assert(r);
        ctx.descriptor_sets.push_back(newset);
        index = ctx.descriptor_sets.size() - 1;
    }

    for (int i : program_indices) {
        Program &pl    = ctx.programs[i];
        bool     found = false;

        for (const auto &ref : pl.descriptor_references) {
            if (set == ref.set && binding == ref.binding &&
                ref.set_index == index) {
                found = true;
                break;
            }
        }

        if (!found) {
            DescriptorReference ref =
                (DescriptorReference){.set_index         = index,
                                      .set           = set,
                                      .binding       = binding,
                                      .non_readable  = non_readable,
                                      .non_writeable = non_writeable};
            void *buf = malloc(res.name.size() + 1);
            memset(buf, 0, res.name.size() + 1);
            ::memcpy(buf, res.name.data(), res.name.size());
            ref.name = (const char *)buf;
            pl.descriptor_references.push_back(ref);
        }
    }

    return er;
}

void print_struct(const Compiler &comp, TypeID type_id)
{
    const SPIRType &type = comp.get_type(type_id);
    sbprint("struct member types:\n");
    sbprint("Name of struct %s\n", comp.get_name(type.self).c_str());
    int j = 0;
    for (const auto &i : type.member_types) {
        const SPIRType &member_type = comp.get_type(i);
        sbprint("member: name %s type %u, size %zu, offset %d, vecsize "
                "%d, columns %d\n",
                comp.get_member_name(type.self, j).c_str(),
                member_type.basetype,
                comp.get_declared_struct_member_size(type, j),
                comp.type_struct_member_offset(type, j), member_type.vecsize,
                member_type.columns);
        if (member_type.basetype == SPIRType::BaseType::Struct)
            print_struct(comp, i);
        j++;
    }
}

int print_spv(int code_size, unsigned char *code)
{
    assert(code_size % 4 == 0);
    int                   word_count = code_size / 4;
    uint32_t             *words      = (uint32_t *)code;
    spirv_cross::Compiler comp(words, word_count);
    std::string           out = comp.compile();
    printf("%s\n", out.c_str());
    spirv_cross::ShaderResources shader_resources = comp.get_shader_resources();
    for (const auto &res : shader_resources.stage_inputs) {
        uint32_t location =
            comp.get_decoration(res.id, spv::DecorationLocation);
        printf("Name: %s Location: %d\n", res.name.c_str(), location);
    }
    for (const auto &uniform : shader_resources.uniform_buffers) {
        head = out_buf;

        const SPIRType &base_type = comp.get_type(uniform.base_type_id);
        const SPIRType &type      = comp.get_type(uniform.type_id);

        head +=
            sprintf(head,
                    "Name: %s "
                    "basetype %d "
                    "type %d "
                    "\n",
                    uniform.name.c_str(), base_type.basetype, type.basetype);

        if (base_type.basetype == SPIRType::BaseType::Struct)
            print_struct(comp, uniform.base_type_id);

        printf("Info:\n%s\n", out_buf);
    }
    return 0;
}

ShaderName extract_name_from_path(const char* file)
{
    std::filesystem::path path(file);
    std::string           name = path.stem().string();
    for (char &c : name)
        if (c == '.' || c == '-')
            c = '_';
    assert(name.size() < MAX_NAME_SIZE);

    ShaderName shname;
    sprintf(shname.buf, "%s", name.c_str());
    return shname;
}

SpirvCode load_spv_file(const char *arg)
{
    ByteArray bytes;
    int er;

    er = hell_read_file(arg, &bytes);
    fatal_condition(er, "Error reading file");

    // tranfer bytes ownership to code
    SpirvCode code = {};
    code.byte_count = bytes.count;
    code.code       = bytes.elems;
    code.file_path  = arg;
    code.name = extract_name_from_path(code.file_path);
    printf("Code name: %s\n", code.name.buf);

    return code;
}

int parse_pipeline_string(const char *str, const ShaderCodes &codes,
                          Programs &programs)
{
    const char *cur         = str;
    Program    *cur_program = NULL;
    char        digit_buf[8];
    char       *db_head = digit_buf;

    memset(digit_buf, 0, sizeof(digit_buf));

    while (*cur) {
        while (isdigit(*cur)) {
            *db_head++ = *cur++;
        }
        // it is filled with a number
        if (db_head != digit_buf) {
            *db_head = '\0';
            int num  = atoi(digit_buf);
            if (cur_program == NULL) {
                // starting a new pipeline
                programs.push_back(Program());
                cur_program = &programs.back();
            }
            fatal_condition(num >= codes.size(),
                            "Num %d num, codes.size(): %d\n", num,
                            codes.size());

            cur_program->shader_indices.push_back(num);

            db_head = digit_buf;
        }

        if (*cur == ',')
            cur_program = NULL;

        cur++;
    }

    return 0;
}

std::string load_pipe_file(const char *arg)
{
    FILE *file = fopen(arg, "r");
    if (!file)
        ERROR("Could not read file.");

    int  er;
    char buf[250];
    zero(buf);
    er = fread(buf, 1, 250, file);

    er = fclose(file);
    if (er)
        ERROR("Error closing file");

    dprint("Buf: %s\n", buf);
    return std::string(buf);
}

SpirvCode load_glsl_file(const char* file, OnyxShaderType type)
{
    int err;
    ByteArray glsl_bytes;

    err = hell_read_file(file, &glsl_bytes);
    assert(!err);

    ShaderName name = extract_name_from_path(file);

    OnyxSpirvCompileInfo ci = {};
    ci.entry_point = "main";
    ci.name = name.buf;
    ci.shader_string = (char*)glsl_bytes.elems;
    ci.shader_type = type;

    unsigned char *spv_bytes;
    int spv_byte_count;
    bool r = glsl_to_spirv(&ci, &spv_bytes, &spv_byte_count);
    assert(r);

    byte_arr_free(&glsl_bytes);

    // we find out the stage later when we parse the spv... 
    SpirvCode code = {
        .code = spv_bytes,
        .byte_count = spv_byte_count,
        .file_path = file,
        .name = name,
    };
    return code;
}

// TODO take some time to write a good argument parses in Hell.
int parse_args(int argc, char **argv, ShaderCodes &codes, Programs &programs)
{
    int         pipe_file = -1;
    std::string pipeline_string;

    for (int i = 1; i < argc; ++i) {
        // printf("Opening file %s...\n", argv[i]);
        dprint("Args[%d] = %s\n", i, argv[i]);

        const char *arg = argv[i];
        int         len = strlen(arg);

        if (len > 3) {
            const char *ext3 = arg + len - 3;
            const char *ext4 = arg + len - 4;
            if (strcmp(ext3, "spv") == 0) {
                codes.push_back(load_spv_file(arg));
                continue;
            } else if (strcmp(ext4, "comp") == 0) {
                codes.push_back(load_glsl_file(arg, ONYX_SHADER_TYPE_COMPUTE));
                continue;
            } else if (strcmp(ext4, "vert") == 0) {
                codes.push_back(load_glsl_file(arg, ONYX_SHADER_TYPE_VERTEX));
                continue;
            } else if (strcmp(ext4, "frag") == 0) {
                codes.push_back(load_glsl_file(arg, ONYX_SHADER_TYPE_FRAGMENT));
                continue;
            } else if (strcmp(ext3, "pip") == 0 && pipe_file == -1) {
                pipe_file = i;
                continue;
            }
        }
        if (arg[0] == '<') {
            if (pipeline_string.size() > 0)
                ERROR("Only one pipeline string allowed");
            int len = strlen(arg);
            for (int j = 1; j < len; ++j) {
                if (arg[j] == '>') {
                    break;
                }
                pipeline_string += arg[j];
            }
        } else if (!output_path) {
            output_path = arg;
        } else if (arg[0] == '-') {
            if (arg[1] == 'f') {
                // the next argment is the function name to use for the
                // reflection.
                assert(i < argc - 1);
                arg = argv[++i];
                strcpy(reflection_function_name, arg);
            } else {
                ERROR("Unkown option passed.");
            }
        }
    }

    printf("Using reflection function name: %s\n", reflection_function_name);

    fatal_condition(!output_path, "Must supply the output file path");

    if (pipe_file != -1)
        pipeline_string = load_pipe_file(argv[pipe_file]);

    dprint("Pipeline string: %s\n", pipeline_string.c_str());
    parse_pipeline_string(pipeline_string.c_str(), codes, programs);

    return 0;
}

#define error_check(er)                                                        \
    do {                                                                       \
        if (er) {                                                              \
            printf("Error: %d while reflecting %s\n\t%s\n", er,                \
                   code.file_path, info_string);                               \
            return er;                                                         \
        }                                                                      \
    } while (0)

static void set_program_type(const ReflectContext &ctx, Program &pl)
{
    assert(pl.shader_indices.size());

    ProgramType         ptype;
    spv::ExecutionModel shtype =
        ctx.get_shader_code_const(pl.shader_indices[0]).stage;
    switch (shtype) {
        case spv::ExecutionModelVertex:
        case spv::ExecutionModelTessellationControl:
        case spv::ExecutionModelTessellationEvaluation:
        case spv::ExecutionModelGeometry:
        case spv::ExecutionModelFragment:
            ptype = ProgramType::ONYX_PROGRAM_TYPE_RENDERPASS;
            break;
        case spv::ExecutionModelGLCompute:
            ptype = ProgramType::ONYX_PROGRAM_TYPE_COMPUTE;
            break;
        case spv::ExecutionModelRayGenerationKHR:
        case spv::ExecutionModelIntersectionKHR:
        case spv::ExecutionModelAnyHitKHR:
        case spv::ExecutionModelClosestHitKHR:
        case spv::ExecutionModelMissKHR:
        case spv::ExecutionModelCallableKHR:
            ptype = ProgramType::ONYX_PROGRAM_TYPE_RAYTRACE;
            break;
        default:
            assert(0 && "Unrecognized execution model");
    }

    pl.type = ptype;
}

int code_reflect(ReflectContext &ctx, int code_index)
{
    SpirvCode &code = ctx.codes[code_index];
    assert(code.byte_count % 4 == 0);

    int       word_count = code.byte_count / 4;
    uint32_t *words      = (uint32_t *)code.code;

    int er = 0;

    Compiler        comp(words, word_count);
    ShaderResources resources = comp.get_shader_resources();

    const auto entry_points = comp.get_entry_points_and_stages();
    assert(entry_points.size() == 1 &&
           "Only support one entry point per spv code currently");
    code.stage       = entry_points[0].execution_model;

    char info_string[1000];
    zero(info_string);

    std::vector<int> programs_referencing_this_shader;
    for (int i = 0; i < ctx.programs.size(); ++i) {

        const Program &pl = ctx.programs[i];

        for (int j = 0; j < pl.shader_indices.size(); ++j) {
            int si = pl.shader_indices[j];
            if (si == code_index)
                programs_referencing_this_shader.push_back(i);
        }
    }

    for (const auto &res : resources.uniform_buffers) {
        int si;
        er = struct_reflect(ctx, comp, res.base_type_id, &si, info_string);
        error_check(er);
        er = add_resource_descriptor(
            ctx, comp, code.stage, res, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, si,
            programs_referencing_this_shader, info_string);
        error_check(er);
    }
    for (const auto &res : resources.storage_images) {
        er = add_resource_descriptor(
            ctx, comp, code.stage, res, VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, -1,
            programs_referencing_this_shader, info_string);
        error_check(er);
    }
    for (const auto &res : resources.storage_buffers) {
        int si;
        er = struct_reflect(ctx, comp, res.base_type_id, &si, info_string);
        error_check(er);
        er = add_resource_descriptor(
            ctx, comp, code.stage, res, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, si,
            programs_referencing_this_shader, info_string);
        error_check(er);
    }
    for (const auto &res : resources.push_constant_buffers) {
        int si;
        int pc_index = -1;

        er = struct_reflect(ctx, comp, res.base_type_id, &si, info_string);
        error_check(er);

        for (int i = 0; i < ctx.push_constants.size(); ++i) {
            if (ctx.push_constants[i].struct_index == si) {
                ctx.push_constants[i].stages.push_back_if_unique(code.stage);
                pc_index = i;
                break;
            }
        }

        if (pc_index == -1) {
            PushConstant pc;

            pc.stages.push_back(code.stage);
            pc.struct_index = si;

            pc_index = ctx.push_constants.push_back(pc);
        }

        for (const auto &i : programs_referencing_this_shader) {
            Program &pl = ctx.programs[i];

            bool found = false;

            for (int j = 0; j < pl.push_constant_indices.size(); ++j) {
                if (pl.push_constant_indices[j] == pc_index) {
                    found = true;
                    break;
                }
            }

            if (!found)
                pl.push_constant_indices.push_back(pc_index);
        }
    }

    switch (code.stage) {
        case spv::ExecutionModel::ExecutionModelVertex:
            for (const auto &res : resources.stage_inputs) {
                printf("Code name: %s res: %s\n", code.name.buf, res.name.c_str());
                const SPIRType &type = comp.get_type(res.type_id);
                assert(code.vert_info.input_count < MAX_VERTEX_INPUTS);

                VertInput &input =
                    code.vert_info.inputs[code.vert_info.input_count];
                input.location =
                    comp.get_decoration(res.id, spv::DecorationLocation);
                input.n_components = type.vecsize;
                strcpy(input.name, res.name.c_str());
                code.vert_info.input_count++;
            }
            break;
        case spv::ExecutionModel::ExecutionModelFragment:
            code.frag_info.color_attachment_count =
                resources.stage_outputs.size();
            break;
        case spv::ExecutionModel::ExecutionModelGLCompute:
            code.comp_info.local_sizes[0] = comp.get_execution_mode_argument(
                spv::ExecutionMode::ExecutionModeLocalSize, 0);
            code.comp_info.local_sizes[1] = comp.get_execution_mode_argument(
                spv::ExecutionMode::ExecutionModeLocalSize, 1);
            code.comp_info.local_sizes[2] = comp.get_execution_mode_argument(
                spv::ExecutionMode::ExecutionModeLocalSize, 2);
            break;
        default:
            break;
    }

    return er;
}

std::string descriptor_type_string(VkDescriptorType type)
{
    // clang-format off
    switch(type) {
        case VK_DESCRIPTOR_TYPE_SAMPLER: return "VK_DESCRIPTOR_TYPE_SAMPLER";
        case VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER: return "VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER";  
        case VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE: return "VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE";  
        case VK_DESCRIPTOR_TYPE_STORAGE_IMAGE: return "VK_DESCRIPTOR_TYPE_STORAGE_IMAGE";  
        case VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER: return "VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER";  
        case VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER: return "VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER";  
        case VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER: return "VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER";  
        case VK_DESCRIPTOR_TYPE_STORAGE_BUFFER: return "VK_DESCRIPTOR_TYPE_STORAGE_BUFFER";  
        case VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC: return "VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC";  
        case VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC: return "VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC";  
        case VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT: return "VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT";  
        case VK_DESCRIPTOR_TYPE_INLINE_UNIFORM_BLOCK: return "VK_DESCRIPTOR_TYPE_INLINE_UNIFORM_BLOCK";  
        case VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR: return "VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR";  
        case VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_NV: return "VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_NV";  
        case VK_DESCRIPTOR_TYPE_MUTABLE_VALVE: return "VK_DESCRIPTOR_TYPE_MUTABLE_VALVE";  
        default: assert(0 && "Invalid descriptor type");
    };
    // clang-format on
}

const char *shader_stage_string(spv::ExecutionModel model)
{
    // clang-format off
    switch(model) {
        case spv::ExecutionModelVertex: return "VK_SHADER_STAGE_VERTEX_BIT";
        case spv::ExecutionModelTessellationControl: return "VK_SHADER_STAGE_TESSELLATION_CONTROL_BIT";
        case spv::ExecutionModelTessellationEvaluation: return "VK_SHADER_STAGE_TESSELLATION_EVALUATION_BIT";
        case spv::ExecutionModelGeometry: return "VK_SHADER_STAGE_GEOMETRY_BIT";
        case spv::ExecutionModelFragment: return "VK_SHADER_STAGE_FRAGMENT_BIT";
        case spv::ExecutionModelGLCompute: return "VK_SHADER_STAGE_COMPUTE_BIT";
        case spv::ExecutionModelKernel: return "VK_SHADER_KERNEL_BIT";
        case spv::ExecutionModelRayGenerationKHR: return "VK_SHADER_STAGE_RAYGEN_BIT_KHR";
        case spv::ExecutionModelIntersectionKHR: return "VK_SHADER_STAGE_INTERSECTION_BIT_KHR";
        case spv::ExecutionModelAnyHitKHR: return "VK_SHADER_STAGE_ANY_HIT_BIT_KHR";
        case spv::ExecutionModelClosestHitKHR: return "VK_SHADER_STAGE_CLOSEST_HIT_BIT_KHR"; 
        case spv::ExecutionModelMissKHR: return "VK_SHADER_STAGE_MISS_BIT_KHR";
        case spv::ExecutionModelCallableKHR: return "VK_SHADER_STAGE_CALLABLE_BIT_KHR";
        default: assert(0 && "Unsupported shader stage");
    };
    // clang-format on
}

const char *shader_stage_short_string(spv::ExecutionModel model)
{
    // clang-format off
    switch(model) {
        case spv::ExecutionModelVertex: return "vert";
        case spv::ExecutionModelFragment: return "frag";
        case spv::ExecutionModelGLCompute: return "comp";
        default: assert(0 && "Unsupported shader stage");
    };
    // clang-format on
}

const char *program_type_string(ProgramType t)
{
    switch (t) {
        case OnyxProgramType::ONYX_PROGRAM_TYPE_RENDERPASS:
            return "ONYX_PROGRAM_TYPE_RENDERPASS";
        case OnyxProgramType::ONYX_PROGRAM_TYPE_COMPUTE:
            return "ONYX_PROGRAM_TYPE_COMPUTE";
        case OnyxProgramType::ONYX_PROGRAM_TYPE_RAYTRACE:
            return "ONYX_PROGRAM_TYPE_RAYTRACE";
    }
    assert(0 && "Program not found");
    return nullptr;
}

const char *
shader_stages_mask_string(const MonotonicArray<spv::ExecutionModel> &stages)
{
    std::string out;
    for (int i = 0; i < stages.size(); ++i) {
        out.append(shader_stage_string(stages[i]));
        if (i != stages.size() - 1)
            out.append(" | ");
    }
    char *buf = (char *)calloc(out.size() + 1, 1);
    assert(buf);
    memcpy(buf, out.data(), out.size());
    return buf;
}

const char *code_array_name(const SpirvCode &code)
{
    // 16 bytes should be enough for any name
    const char* stage_part = shader_stage_short_string(code.stage);
    char *buf =
        (char *)calloc(strnlen(code.name.buf, MAX_NAME_SIZE) + 16 + sizeof(CODE_ARRAY_NAME_SUFFIX) + 1, 1);
    assert(buf);
    sprintf(buf, "%s_%s_%s", code.name.buf, stage_part, CODE_ARRAY_NAME_SUFFIX);
    return buf;
}

int write_descriptors(const ReflectContext &ctx)
{
    assert(ctx.descriptors.size() <= ONYX_MAX_DESCRIPTORS);

    push_var("description");

    set_var_member("descriptor_count", ctx.descriptors.size());

    for (int i = 0; i < ctx.descriptors.size(); ++i) {
        const Descriptor &desc = ctx.descriptors[i];

        declare_and_push_auto("OnyxDescriptor", "descriptor");
        set_var_member("count", desc.count);
        set_var_member("type", desc.type);
        set_var_member("stages", shader_stages_mask_string(desc.stages));
        set_var_member("struct_info_index", desc.struct_index);
        set_var_member("image_info_index", desc.image_index);

        const char *var = pop_var();
        set_var_member("descriptors", i, var);
    }

    pop_var();
    return 0;
}

int write_descriptor_sets(const ReflectContext &ctx)
{
    assert(ctx.descriptor_sets.size() <= ONYX_MAX_DESCRIPTOR_SETS);

    push_var("description");

    set_var_member("descriptor_set_count", ctx.descriptor_sets.size());

    for (int i = 0; i < ctx.descriptor_sets.size(); ++i) {
        const DescriptorSet &set = ctx.descriptor_sets[i];

        assert(set.descriptor_indices.size() <= ONYX_MAX_DESCRIPTORS_PER_SET);

        declare_and_push_auto("OnyxDescriptorSet", "descriptor_set");
        set_var_member("descriptor_count", set.descriptor_indices.size());

        // clear bindings to -1
        for (int i = 0; i < ONYX_MAX_DESCRIPTORS_PER_SET; ++i) {
            set_var_member("descriptors", i, -1);
        }

        for (int i = 0; i < set.descriptor_indices.size(); ++i) {
            int binding = set.bindings[i];
            int desc    = set.descriptor_indices[i];

            set_var_member("descriptors", binding, desc);
        }

        const char *var = pop_var();
        set_var_member("descriptor_sets", i, var);
    }

    pop_var();

    return 0;
}

int write_pipeline_layouts(const ReflectContext &ctx)
{
    assert(ctx.pipeline_layouts.size() <= ONYX_MAX_PIPELINE_LAYOUTS);

    push_var("description");

    set_var_member("pipeline_layout_count", ctx.pipeline_layouts.size());

    const char *var;
    for (int i = 0; i < ctx.pipeline_layouts.size(); ++i) {
        const PipelineLayout &pl = ctx.pipeline_layouts[i];

        declare_and_push_auto("OnyxPipelineLayout", "pipeline_layout");

        set_var_member("descriptor_set_count",
                       pl.descriptor_set_indices.size());
        for (int i = 0; i < pl.descriptor_set_indices.size(); ++i)
            set_var_member("descriptor_set_indices", i,
                           pl.descriptor_set_indices[i]);

        set_var_member("push_constant_count", pl.push_constant_indices.size());
        for (int i = 0; i < pl.push_constant_indices.size(); ++i)
            set_var_member("push_constant_indices", i,
                           pl.push_constant_indices[i]);

        var = pop_var();
        set_var_member("pipeline_layouts", i, var);
    }

    pop_var();

    return 0;
}

int write_shader_stages(const ReflectContext &ctx)
{
    assert(ctx.codes.size() <= ONYX_MAX_SHADERS);

    push_var("description");

    set_var_member("shader_count", ctx.codes.size());

    const char *var;
    for (int i = 0; i < ctx.codes.size(); ++i) {
        const SpirvCode &code = ctx.codes[i];

        declare_and_push_auto("OnyxShaderInfo", "shader");

        set_var_member("stage", shader_stage_string(code.stage));
        set_var_member("byte_count", code.byte_count);
        set_var_member("code", code_array_name(code));
        set_var_member_str("entry_point", "main");
        set_var_member_str("name", code.name.buf);

        var = pop_var();
        set_var_member("shader_infos", i, var);
    }

    pop_var();

    return 0;
}

int write_push_constants(const ReflectContext &ctx)
{
    assert(ctx.push_constants.size() <= ONYX_MAX_PUSH_CONSTANTS);

    push_var("description");

    set_var_member("push_constant_count", ctx.push_constants.size());

    for (int i = 0; i < ctx.push_constants.size(); ++i) {
        const PushConstant &pc = ctx.push_constants[i];

        declare_and_push_auto("OnyxPushConstantInfo", "pc");

        set_var_member("stages", shader_stages_mask_string(pc.stages));
        set_var_member("struct_info_index", pc.struct_index);

        const char *var = pop_var();
        set_var_member("push_constant_infos", i, var);
    }

    pop_var();

    return 0;
}

int write_struct_infos(const ReflectContext &ctx)
{
    assert(ctx.structs.size() <= ONYX_MAX_PIPELINE_STRUCT_INFOS);

    push_var("description");

    set_var_member("struct_info_count", ctx.structs.size());

    const char *var;
    for (int i = 0; i < ctx.structs.size(); ++i) {
        const StructInfo &s = ctx.structs[i];
        declare_and_push_auto("OnyxPipelineStructInfo", "struct_info");

        set_var_member_str("name", s.name);
        set_var_member("size", s.size);

        var = pop_var();
        set_var_member("struct_infos", i, var);
    }

    pop_var();
    return 0;
}

int write_image_infos(const ReflectContext &ctx)
{
    // TODO
    return 0;
}

int write_programs(const ReflectContext &ctx)
{
    assert(ctx.programs.size() <= ONYX_MAX_PROGRAMS);

    push_var("reflection");

    set_var_member("program_count", ctx.programs.size());

    const char *var;
    for (int i = 0; i < ctx.programs.size(); ++i) {
        const Program &p = ctx.programs[i];

        declare_and_push_auto("OnyxProgramReflection", "prog");

        set_var_member("type", program_type_string(p.type));
        set_var_member("pipeline_layout_index", p.pipeline_layout_index);
        set_var_member("shader_count", p.shader_indices.size());
        for (int i = 0; i < p.shader_indices.size(); ++i) {
            set_var_member("shader_indices", i, p.shader_indices[i]);
        }
        set_var_member("push_constant_count", p.push_constant_indices.size());
        for (int i = 0; i < p.push_constant_indices.size(); ++i) {
            set_var_member("push_constant_indices", i,
                           p.push_constant_indices[i]);
        }
        set_var_member("descriptor_count", p.descriptor_references.size());
        for (int i = 0; i < p.descriptor_references.size(); ++i) {
            const DescriptorReference &ref = p.descriptor_references[i];

            declare_and_push_auto("OnyxDescriptorReference",
                                  "descriptor_reference");
            set_var_member("set_index", ref.set_index);
            set_var_member("set", ref.set);
            set_var_member("binding", ref.binding);
            set_var_member("non_readable", ref.non_readable);
            set_var_member("non_writeable", ref.non_writeable);
            set_var_member_str("name", ref.name);

            var = pop_var();
            set_var_member("descriptor_references", i, var);
        }

        if (p.type == ONYX_PROGRAM_TYPE_RENDERPASS) {
            assert(p.shader_indices.size() == 2);

            int vert_index = p.shader_indices[0];
            int frag_index = p.shader_indices[1];

            assert(ctx.codes[vert_index].stage == spv::ExecutionModelVertex);
            assert(ctx.codes[frag_index].stage == spv::ExecutionModelFragment);

            const VertShaderInfo &vi = ctx.codes[vert_index].vert_info;
            const FragShaderInfo &fi = ctx.codes[frag_index].frag_info;

            declare_and_push_auto("OnyxRasterizationReflection",
                                  "rasterization");
            set_var_member("color_attachment_count", fi.color_attachment_count);
            set_var_member("vertex_shader_index", vert_index);
            set_var_member("fragment_shader_index", frag_index);
            set_var_member("vertex_input_count", vi.input_count);

            assert(vi.input_count <= ONYX_MAX_VERTEX_ATTRIBUTES_PER_SHADER);
            for (int i = 0; i < vi.input_count; ++i) {
                const VertInput &inp = vi.inputs[i];
                declare_and_push_auto("OnyxVertexInputAttributeReflection",
                                      "attribute");
                set_var_member("location", inp.location);
                set_var_member_str("name", inp.name);
                set_var_member("n_components", inp.n_components);

                var = pop_var();
                set_var_member("vertex_inputs", i, var);
            }

            var = pop_var();
            set_var_member("rasterize", var);
        } else if (p.type == ONYX_PROGRAM_TYPE_COMPUTE) {
            declare_and_push_auto("OnyxComputeReflection", "compute");
            int                  shindex = p.shader_indices[0];
            const CompShaderInfo ci      = ctx.codes[shindex].comp_info;

            set_var_member("shader_index", shindex);
            set_var_member("local_x", ci.local_sizes[0]);
            set_var_member("local_y", ci.local_sizes[1]);
            set_var_member("local_z", ci.local_sizes[2]);

            var = pop_var();
            set_var_member("compute", var);
        } else
            assert(0 && "Ray trace not supported yet");

        var = pop_var();
        set_var_member("programs", i, var);
    }

    pop_var();
    return 0;
}

int write_output_to_file()
{
    int er = hell_write_file(output_path, out_buf, head - out_buf);
    if (er)
        ERROR("Failed to write to file");
    return er;
}

int write_the_file(const ReflectContext &ctx)
{
    int er = 0;

    head = out_buf;

    sbprint("#ifndef ONYX_SHADER_REFLECTION_H\n"
            "#define ONYX_SHADER_REFLECTION_H\n\n");
    sbprint("// HEADER\n\n");
    sbprint("#include <coal/types.h>\n\n");
    sbprint("#include <stdint.h>\n\n");
    sbprint("#include <stdbool.h>\n\n");
    sbprint("typedef struct onyx_graph OnyxGraph;\n");
    sbprint("typedef int32_t OnyxTaskId;\n");
    sbprint("typedef struct onyx_graphics_pipeline_settings "
            "OnyxGraphicsPipelineSettings;\n");
    sbprint("typedef struct onyx_reflection OnyxReflection;\n\n");

    // write structs
    for (int i = 0; i < ctx.structs.size(); ++i) {
        sbprint("%s\n", ctx.structs[i].definition);
    }

    // turn this off if you want to create a library from this
    const bool use_inline_function = true;
    if (!use_inline_function)
        sbprint("void %s(OnyxReflection *reflection);\n\n",
                reflection_function_name);

    // do not create these custon functions - they lead to symbol conflicts and
    // I don't use them anyway
    // for (const auto &pf : ctx.funcs) {
    //    pf.sbprint_declaration();
    //}
    sbprint("// IMPLEMENTATION\n\n");
    sbprint("#include <onyx/onyx.h>\n\n");

    // write spv arrays
    for (int i = 0; i < ctx.codes.size(); ++i) {
        const auto     &code       = ctx.codes[i];
        const int       word_count = code.byte_count / 4;
        const uint32_t *word       = (uint32_t *)code.code;
        const char* array_name = code_array_name(code);

        sbprint("static uint32_t %s[%d] = {\n", array_name,
                word_count);

        for (int i = 0; i < word_count; ++i) {
            sbprint("%d%s%s", *word++, i == word_count - 1 ? "" : ",",
                    (i + 1) % 16 == 0 ? "\n" : " ");
        }

        sbprint("};\n\n");
    }

    sbprint("%s void %s(OnyxReflection *out)\n", use_inline_function ? "static inline" : "", reflection_function_name);

    begin_scope();

    declare_var("OnyxReflection", "reflection");
    declare_var("OnyxPipedes", "description");

    write_descriptors(ctx);
    write_descriptor_sets(ctx);
    write_pipeline_layouts(ctx);
    write_shader_stages(ctx);
    write_push_constants(ctx);
    write_struct_infos(ctx);
    write_image_infos(ctx);
    write_programs(ctx);

    push_var("reflection");
    set_var_member("description", "description");
    pop_var();

    copy_var("*out", "reflection");

    end_scope();

    sbprint("#endif\n");

    write_output_to_file();

    return er;
}

int reflect(ReflectContext ctx)
{
    int er;

    for (int i = 0; i < ctx.codes.size(); ++i) {
        // dprint("Reflection for code %d\n", i);
        er = code_reflect(ctx, i);
        if (er)
            return er;
    }

    for (int i = 0; i < ctx.programs.size(); ++i) {
        Program &pl = ctx.programs[i];
        set_program_type(ctx, pl);
        // set the name
        for (int i = 0; i < pl.shader_indices.size(); i++) {
            if (i > 0)
                pl.name.append("_");
            pl.name.append(ctx.codes[pl.shader_indices[i]].name.buf);
        }
    }

    // create pipeline layouts
    for (auto &prog : ctx.programs) {
        PipelineLayout layout;
        layout.push_constant_indices = prog.push_constant_indices;
        for (const auto &desc : prog.descriptor_references) {
            layout.descriptor_set_indices.push_back_if_unique(desc.set_index);
        }
        prog.pipeline_layout_index =
            ctx.pipeline_layouts.push_back_if_unique(layout);
    }

    ctx.make_program_task_functions();

    write_the_file(ctx);

    return 0;
}

int prompt_for_pipeline_info(const ShaderCodes &codes, Programs *pipelines)
{
    for (int i = 0; i < codes.size(); ++i) {
        printf(" %d:\t%s\n", i, codes[i].name.buf);
    }
    printf("\nEnter how the shaders fit in the pipelines like this: 0-1, "
           "1-2-3, 4\n");
    char buf[128];
    fgets(buf, 128, stdin);

    parse_pipeline_string(buf, codes, *pipelines);

    return 0;
}

int main(int argc, char **argv)
{
    int er;

    if (argc < 2)
        MAIN_ERROR(USAGE_STRING);

    ShaderCodes codes;
    Programs    programs;

    er = parse_args(argc, argv, codes, programs);
    if (er)
        return 1;

    dprint("Program size %d\n", programs.size());
    if (programs.size() == 0)
        prompt_for_pipeline_info(codes, &programs);

    head = out_buf;
    // for (int i = 0; i < codes.count; ++i) {
    //     print_spv(codes.codes[i].byte_count, codes.codes[i].code);
    // }

    ReflectContext ctx = create_context(codes, programs);
    reflect(ctx);

    return 0;
}
