#ifndef ONYX_REFLECT_H
#define ONYX_REFLECT_H

#ifdef __cplusplus
extern "C" {
#endif

struct onyx_spirv_compile_info;
// msg_buf and spirv_code_buf should be large enough for spirv and message.
// consider heap allocating.
// spirv_code_size will be the size of the spirv code in bytes
// return true on success and false on failure
int
glsl_to_spirv(const struct onyx_spirv_compile_info* info, unsigned char** spirv_code_buf,
              int* spirv_code_size);

int reflect_spv(int code_size, unsigned char* code);

#ifdef __cplusplus
}
#endif

#endif
