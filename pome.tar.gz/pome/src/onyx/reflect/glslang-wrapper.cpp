#define HELL_SIMPLE_TYPE_NAMES
#define HELL_SIMPLE_FUNC_NAMES
#include <assert.h>
#include <glslang/Public/ShaderLang.h>
#include <SPIRV/GlslangToSpv.h>
#include <spirv_cross.hpp>
#include <iostream>
#include <onyx/types.h>
#include "reflect.h"
#include <hell/hell.h>

static bool initialized = false;

using namespace glslang;

#define error false
#define success true

// defined below
extern const TBuiltInResource default_t_built_in_resource;

struct Writer {
    const int len;
    int head = 0;
    char* buf = nullptr;

    Writer(char* msg_buf, int msg_buf_len) :
        len(msg_buf_len),
        buf(msg_buf)
    {
        assert(msg_buf);
        assert(msg_buf_len > 0);
    }

    void write(const char* str)
    {
        const int room = len - head;
        int n = strnlen(str, room);
        assert(n < room);
        snprintf(buf + head, room, "%s", str);
        head += n + 1;
    }
};

int
glsl_to_spirv(const struct onyx_spirv_compile_info* info, unsigned char** spirv_code_buf,
              int* spirv_code_size)
{
    bool ok = true;

    if (!initialized)
    {
        ok = InitializeProcess();
        if (!ok)
            return error;
        initialized = true;
    }

    EShLanguage shader_stage;
    switch (info->shader_type)
    {
        case ONYX_SHADER_TYPE_VERTEX: shader_stage = EShLanguage::EShLangVertex; break;
        case ONYX_SHADER_TYPE_FRAGMENT: shader_stage = EShLanguage::EShLangFragment; break;
        case ONYX_SHADER_TYPE_COMPUTE: shader_stage = EShLanguage::EShLangCompute; break;
        default: assert(0 && "Shader type not yet supported");
    }

    int glsl_len = strlen(info->shader_string);
    TShader shader(shader_stage);
    //shader.setStrings(&info->shader_string, 1);
    shader.setStringsWithLengthsAndNames(&info->shader_string, &glsl_len, &info->name, 1);
    shader.setEntryPoint(info->entry_point);
    shader.setEnvInput(EShSource::EShSourceGlsl, shader_stage, EShClient::EShClientVulkan, 460);
    shader.setEnvClient(EShClient::EShClientVulkan, EshTargetClientVersion::EShTargetVulkan_1_2);
    shader.setEnvTarget(EShTargetLanguage::EshTargetSpv, EShTargetLanguageVersion::EShTargetSpv_1_3);

    EShMessages messages = (EShMessages)(EShMsgSpvRules | EShMsgVulkanRules);

    ok = shader.parse(&default_t_built_in_resource, 460, false, messages);
    if (!ok)
    {
        printf("ERROR: %s\n", shader.getInfoLog());
        printf("ERROR: %s\n", shader.getInfoDebugLog());
        return error;
    }

    TProgram program;
    program.addShader(&shader);

    ok = program.link(messages);
    if (!ok)
    {
        printf("ERROR: %s\n", "Spirv link failed\n");
        return error;
    }

    std::vector<unsigned int> spirv;

    GlslangToSpv(*program.getIntermediate(shader_stage), spirv);
    
    int n = spirv.size() * sizeof(unsigned int);
    *spirv_code_size = n;

    *spirv_code_buf = (unsigned char*)malloc(n);
    memcpy(*spirv_code_buf, spirv.data(), *spirv_code_size);

    return success;
}

using namespace spirv_cross;

int reflect_spv(int code_size, unsigned char* code)
{
    assert(code_size % 4 == 0);
    int word_count = code_size / 4;
    uint32_t *words = (uint32_t*)code;
    spirv_cross::Compiler comp(words, word_count);
    std::string out = comp.compile();
    std::cout << out << std::endl;
    spirv_cross::ShaderResources shader_resources = comp.get_shader_resources();
    for (const auto& res : shader_resources.stage_inputs) 
    {
        uint32_t location = comp.get_decoration(res.id, spv::DecorationLocation);
        printf("Name: %s Location: %d\n", res.name.c_str(), location);
    }
    for (const auto& uniform : shader_resources.uniform_buffers) 
    {
        char buf[2000];
        memset(buf, 0, sizeof(buf));
        char *head = buf;

        const SPIRType& base_type = comp.get_type(uniform.base_type_id);
        const SPIRType& type = comp.get_type(uniform.type_id);

        head += sprintf(head, "%s \
                basetype %d \
                type %d \
                \n", 
                uniform.name.c_str(), 
                base_type.basetype,
                type.basetype);

        if (base_type.basetype == SPIRType::BaseType::Struct) {
            head += sprintf(head, "struct member types:\n");
            for (const auto& i : base_type.member_types) {
                const SPIRType& type = comp.get_type(i);
                head += sprintf(head, "  member type %d, vecsize %d, columns %d\n", type.basetype, type.vecsize, type.columns);
            }
        }
        
        printf("Info:\n%s\n", buf);
    }
    return 0;
}

const TBuiltInResource default_t_built_in_resource = {
    /* .MaxLights = */ 32,
    /* .MaxClipPlanes = */ 6,
    /* .MaxTextureUnits = */ 32,
    /* .MaxTextureCoords = */ 32,
    /* .MaxVertexAttribs = */ 64,
    /* .MaxVertexUniformComponents = */ 4096,
    /* .MaxVaryingFloats = */ 64,
    /* .MaxVertexTextureImageUnits = */ 32,
    /* .MaxCombinedTextureImageUnits = */ 80,
    /* .MaxTextureImageUnits = */ 32,
    /* .MaxFragmentUniformComponents = */ 4096,
    /* .MaxDrawBuffers = */ 32,
    /* .MaxVertexUniformVectors = */ 128,
    /* .MaxVaryingVectors = */ 8,
    /* .MaxFragmentUniformVectors = */ 16,
    /* .MaxVertexOutputVectors = */ 16,
    /* .MaxFragmentInputVectors = */ 15,
    /* .MinProgramTexelOffset = */ -8,
    /* .MaxProgramTexelOffset = */ 7,
    /* .MaxClipDistances = */ 8,
    /* .MaxComputeWorkGroupCountX = */ 65535,
    /* .MaxComputeWorkGroupCountY = */ 65535,
    /* .MaxComputeWorkGroupCountZ = */ 65535,
    /* .MaxComputeWorkGroupSizeX = */ 1024,
    /* .MaxComputeWorkGroupSizeY = */ 1024,
    /* .MaxComputeWorkGroupSizeZ = */ 64,
    /* .MaxComputeUniformComponents = */ 1024,
    /* .MaxComputeTextureImageUnits = */ 16,
    /* .MaxComputeImageUniforms = */ 8,
    /* .MaxComputeAtomicCounters = */ 8,
    /* .MaxComputeAtomicCounterBuffers = */ 1,
    /* .MaxVaryingComponents = */ 60,
    /* .MaxVertexOutputComponents = */ 64,
    /* .MaxGeometryInputComponents = */ 64,
    /* .MaxGeometryOutputComponents = */ 128,
    /* .MaxFragmentInputComponents = */ 128,
    /* .MaxImageUnits = */ 8,
    /* .MaxCombinedImageUnitsAndFragmentOutputs = */ 8,
    /* .MaxCombinedShaderOutputResources = */ 8,
    /* .MaxImageSamples = */ 0,
    /* .MaxVertexImageUniforms = */ 0,
    /* .MaxTessControlImageUniforms = */ 0,
    /* .MaxTessEvaluationImageUniforms = */ 0,
    /* .MaxGeometryImageUniforms = */ 0,
    /* .MaxFragmentImageUniforms = */ 8,
    /* .MaxCombinedImageUniforms = */ 8,
    /* .MaxGeometryTextureImageUnits = */ 16,
    /* .MaxGeometryOutputVertices = */ 256,
    /* .MaxGeometryTotalOutputComponents = */ 1024,
    /* .MaxGeometryUniformComponents = */ 1024,
    /* .MaxGeometryVaryingComponents = */ 64,
    /* .MaxTessControlInputComponents = */ 128,
    /* .MaxTessControlOutputComponents = */ 128,
    /* .MaxTessControlTextureImageUnits = */ 16,
    /* .MaxTessControlUniformComponents = */ 1024,
    /* .MaxTessControlTotalOutputComponents = */ 4096,
    /* .MaxTessEvaluationInputComponents = */ 128,
    /* .MaxTessEvaluationOutputComponents = */ 128,
    /* .MaxTessEvaluationTextureImageUnits = */ 16,
    /* .MaxTessEvaluationUniformComponents = */ 1024,
    /* .MaxTessPatchComponents = */ 120,
    /* .MaxPatchVertices = */ 32,
    /* .MaxTessGenLevel = */ 64,
    /* .MaxViewports = */ 16,
    /* .MaxVertexAtomicCounters = */ 0,
    /* .MaxTessControlAtomicCounters = */ 0,
    /* .MaxTessEvaluationAtomicCounters = */ 0,
    /* .MaxGeometryAtomicCounters = */ 0,
    /* .MaxFragmentAtomicCounters = */ 8,
    /* .MaxCombinedAtomicCounters = */ 8,
    /* .MaxAtomicCounterBindings = */ 1,
    /* .MaxVertexAtomicCounterBuffers = */ 0,
    /* .MaxTessControlAtomicCounterBuffers = */ 0,
    /* .MaxTessEvaluationAtomicCounterBuffers = */ 0,
    /* .MaxGeometryAtomicCounterBuffers = */ 0,
    /* .MaxFragmentAtomicCounterBuffers = */ 1,
    /* .MaxCombinedAtomicCounterBuffers = */ 1,
    /* .MaxAtomicCounterBufferSize = */ 16384,
    /* .MaxTransformFeedbackBuffers = */ 4,
    /* .MaxTransformFeedbackInterleavedComponents = */ 64,
    /* .MaxCullDistances = */ 8,
    /* .MaxCombinedClipAndCullDistances = */ 8,
    /* .MaxSamples = */ 4,
    /* .maxMeshOutputVerticesNV = */ 256,
    /* .maxMeshOutputPrimitivesNV = */ 512,
    /* .maxMeshWorkGroupSizeX_NV = */ 32,
    /* .maxMeshWorkGroupSizeY_NV = */ 1,
    /* .maxMeshWorkGroupSizeZ_NV = */ 1,
    /* .maxTaskWorkGroupSizeX_NV = */ 32,
    /* .maxTaskWorkGroupSizeY_NV = */ 1,
    /* .maxTaskWorkGroupSizeZ_NV = */ 1,
    /* .maxMeshViewCountNV = */ 4,
    /* .maxDualSourceDrawBuffersEXT = */ 1,

    /* .limits = { */
        /* .nonInductiveForLoops = */ 1,
        /* .whileLoops = */ 1,
        /* .doWhileLoops = */ 1,
        /* .generalUniformIndexing = */ 1,
        /* .generalAttributeMatrixVectorIndexing = */ 1,
        /* .generalVaryingIndexing = */ 1,
        /* .generalSamplerIndexing = */ 1,
        /* .generalVariableIndexing = */ 1,
        /* .generalConstantMatrixVectorIndexing = */ 1,
    /* } */ };
