#include "command.h"
#include "video.h"
#include <string.h>

void onyx_submit_and_wait(OnyxCommand* cmd, const uint32_t queueIndex)
{
    onyx_submit_to_queue_wait(cmd->instance, &cmd->buffer, cmd->queue_family, queueIndex);
}

OnyxCommand onyx_create_command(const OnyxInstance* instance, const OnyxQueueType queueFamilyType)
{
    OnyxCommand cmd = {
        .queue_family = onyx_queue_family_index(instance, queueFamilyType),
        .instance = instance
    };

    const VkCommandPoolCreateInfo cmdPoolCi = {
        .queueFamilyIndex = cmd.queue_family,
        .flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT,
        .sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
    };

    V_ASSERT( vkCreateCommandPool(instance->device, &cmdPoolCi, NULL, &cmd.pool) );

    const VkCommandBufferAllocateInfo allocInfo = {
        .commandBufferCount = 1,
        .commandPool = cmd.pool,
        .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO
    };

    V_ASSERT( vkAllocateCommandBuffers(instance->device, &allocInfo, &cmd.buffer) );

    const VkSemaphoreCreateInfo semaCi = {
        .sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO
    };

    V_ASSERT( vkCreateSemaphore(instance->device, &semaCi, NULL, &cmd.semaphore) );

    const VkFenceCreateInfo fenceCi = {
        .sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO,
        .flags = VK_FENCE_CREATE_SIGNALED_BIT
    };

    V_ASSERT( vkCreateFence(instance->device, &fenceCi, NULL, &cmd.fence) );

    return cmd;
}

VkResult
onyx_create_command_pool(    
        const Onyx *onyx,
        uint32_t family_index,
        VkCommandPoolCreateFlags flags,
        VkCommandPool *pool)
{
    VkCommandPoolCreateInfo cmdPoolCi = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
        .queueFamilyIndex = family_index,
        .flags = flags,
    };

    VkResult r;
    r = vkCreateCommandPool(onyx->device, &cmdPoolCi, NULL, pool);
    return r;
}

OnyxCommandPool onyx_create_command_pool_(VkDevice device,
    uint32_t queueFamilyIndex,
    VkCommandPoolCreateFlags poolflags,
    uint32_t bufcount)
{
    OnyxCommandPool pool = {};
    pool.queue_family = queueFamilyIndex;
    const VkCommandPoolCreateInfo cmdPoolCi = {
        .queueFamilyIndex = pool.queue_family,
        .flags = poolflags,
        .sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
    };

    V_ASSERT( vkCreateCommandPool(device, &cmdPoolCi, NULL, &pool.pool) );

    const VkCommandBufferAllocateInfo ai = {
        .commandBufferCount = bufcount,
        .commandPool = pool.pool,
        .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO
    };

    pool.cmdbufs = hell_malloc(sizeof(VkCommandBuffer) * bufcount);

    V_ASSERT( vkAllocateCommandBuffers(device, &ai, pool.cmdbufs) );

    pool.cmdbuf_count = bufcount;
    pool.device = device;

    return pool;
}

int onyx_command_pool_create(Onyx* onyx, OnyxQueueType t, uint32_t bufcount, OnyxCommandPool* cp)
{
   *cp = onyx_create_command_pool_(
        onyx->device, onyx_queue_family_index_(onyx->instance, t), VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT,
        bufcount);
   return 0;
}

void onyx_command_pool_reset(OnyxCommandPool* p)
{
    vkResetCommandPool(p->device, p->pool, 0);
}

void onyx_destroy_command_pool(VkDevice device, OnyxCommandPool* pool)
{
    vkDestroyCommandPool(device, pool->pool, NULL);
    hell_free(pool->cmdbufs);
    memset(pool, 0, sizeof(*pool));
}

void onyx_begin_command_buffer(VkCommandBuffer cmdBuf)
{
    VkCommandBufferBeginInfo beginInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
    };

    V_ASSERT( vkBeginCommandBuffer(cmdBuf, &beginInfo) );
}

void onyx_begin_command_buffer_one_time_submit(VkCommandBuffer cmdBuf)
{
    VkCommandBufferBeginInfo beginInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
        .flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT
    };

    V_ASSERT( vkBeginCommandBuffer(cmdBuf, &beginInfo) );
}

void onyx_end_command_buffer(VkCommandBuffer cmdBuf)
{
    vkEndCommandBuffer(cmdBuf);
}

VkResult onyx_wait_for_fence_and_reset(VkDevice device, VkFence fence)
{
    VkResult r;
    r = vkWaitForFences(device, 1, &fence, VK_TRUE, UINT64_MAX);
    if (r != VK_SUCCESS)
        return r;
    return vkResetFences(device, 1, &fence);
}

void onyx_wait_for_fence(VkDevice device, VkFence* fence)
{
    V_ASSERT(vkWaitForFences(device, 1, fence, VK_TRUE, UINT64_MAX));
    V_ASSERT(vkResetFences(device, 1, fence));
}

void onyx_wait_for_fence_time_out(VkDevice device, VkFence* fence, uint64_t timeout_ns)
{
    V_ASSERT(vkWaitForFences(device, 1, fence, VK_TRUE, timeout_ns));
    V_ASSERT(vkResetFences(device, 1, fence));
}


void onyx_destroy_fence(VkDevice device, VkFence fence)
{
    vkDestroyFence(device, fence, NULL);
}

void onyx_destroy_semaphore(VkDevice device, VkSemaphore semaphore)
{
    vkDestroySemaphore(device, semaphore, NULL);
}

void onyx_wait_for_fence_no_reset(VkDevice device, VkFence* fence)
{
    vkWaitForFences(device, 1, fence, VK_TRUE, UINT64_MAX);
}

void onyx_destroy_command(OnyxCommand cmd)
{
    vkDestroyCommandPool(cmd.instance->device, cmd.pool, NULL);
    vkDestroyFence(cmd.instance->device, cmd.fence, NULL);
    vkDestroySemaphore(cmd.instance->device, cmd.semaphore, NULL);
}

void onyx_reset_command(OnyxCommand* cmd)
{
    vkResetCommandPool(cmd->instance->device, cmd->pool, 0);
}

void onyx_v_MemoryBarrier(
    VkCommandBuffer      commandBuffer,
    VkPipelineStageFlags srcStageMask,
    VkPipelineStageFlags dstStageMask,
    VkDependencyFlags    dependencyFlags,
    VkAccessFlags        srcAccessMask,
    VkAccessFlags        dstAccessMask)
{
    const VkMemoryBarrier barrier = {
        .sType         = VK_STRUCTURE_TYPE_MEMORY_BARRIER,
        .pNext         = NULL,
        .srcAccessMask = srcAccessMask,
        .dstAccessMask = dstAccessMask 
    };

    vkCmdPipelineBarrier(commandBuffer, srcStageMask, 
            dstStageMask, dependencyFlags, 
            1, &barrier, 0, NULL, 0, NULL);
}

void onyx_create_fence(VkDevice device, bool signaled, VkFence* fence)
{
    VkFenceCreateInfo ci = {
        .sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO,
        .flags = signaled ? VK_FENCE_CREATE_SIGNALED_BIT : 0
    };

    V_ASSERT( vkCreateFence(device, &ci, NULL, fence) );
}

void onyx_create_semaphore(VkDevice device, VkSemaphore* semaphore)
{
    const VkSemaphoreCreateInfo semaCi = {
        .sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO
    };

    V_ASSERT( vkCreateSemaphore(device, &semaCi, NULL, semaphore) );
}

void onyx_create_semaphores(VkDevice device, u32 count, VkSemaphore* semas)
{
    const VkSemaphoreCreateInfo semaCi = {
        .sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO
    };
    for (u32 i = 0; i < count; ++i) 
    {
        V_ASSERT( vkCreateSemaphore(device, &semaCi, NULL, &semas[i]) );
    }
}

void onyx_create_fences(VkDevice device, bool signaled, int count, VkFence* fences)
{
    for (int i = 0; i < count; ++i) 
        onyx_create_fence(device, signaled, fences++);
}

void onyx_cmd_set_viewport_scissor(VkCommandBuffer cmdbuf, u32 x, u32 y, u32 w, u32 h)
{
    VkViewport vp = {
        .width = w,
        .height = h,
        .x = x, .y = y,
        .minDepth = 0.0,
        .maxDepth = 1.0,
    };
    VkRect2D sz = {
        .extent = {w, h},
        .offset = {x, y}
    };

    vkCmdSetViewport(cmdbuf, 0, 1, &vp);
    vkCmdSetScissor(cmdbuf, 0, 1, &sz);
}

void onyx_cmd_set_viewport_scissor_full(VkCommandBuffer cmdbuf, unsigned width, unsigned height)
{
    VkViewport vp = {
        .width = width,
        .height = height,
        .x = 0, .y = 0,
        .minDepth = 0.0,
        .maxDepth = 1.0,
    };
    VkRect2D sz = {
        .extent = {width, height},
        .offset = {0, 0}
    };

    vkCmdSetViewport(cmdbuf, 0, 1, &vp);
    vkCmdSetScissor(cmdbuf, 0, 1, &sz);
}

void onyx_cmd_begin_render_pass_color_depth(VkCommandBuffer cmdbuf, 
        const VkRenderPass renderPass, const VkFramebuffer framebuffer,
        unsigned width, unsigned height,
        float r, float g, float b, float a)
{
    VkClearValue clears[2] = {
        {r, g, b, a},
        {1.0, 0} //depth
    };

    VkRenderPassBeginInfo rpi = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
        .renderPass = renderPass,
        .framebuffer = framebuffer,
        .renderArea = {0, 0, width, height},
        .clearValueCount = 2,
        .pClearValues = clears
    };

    vkCmdBeginRenderPass(cmdbuf, &rpi, VK_SUBPASS_CONTENTS_INLINE);
}

void onyx_cmd_end_render_pass(VkCommandBuffer cmdbuf)
{
    vkCmdEndRenderPass(cmdbuf);
}

void onyx_cmd_clear_color_image(VkCommandBuffer cmdbuf, VkImage image, VkImageLayout layout,
        uint32_t base_mip_level, uint32_t mip_level_count,
        float r, float g, float b, float a)
{
    VkClearColorValue color = {
        .float32[0] = r,
        .float32[1] = g,
        .float32[2] = b,
        .float32[3] = a,
    };

    VkImageSubresourceRange range = {
        .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
        .baseArrayLayer = 0,
        .baseMipLevel = base_mip_level,
        .layerCount = 1,
        .levelCount = mip_level_count
    };

    vkCmdClearColorImage(cmdbuf, image, layout, &color, 1, &range);
}

VkResult
onyx_allocate_command_buffers(
        VkDevice device,
        VkCommandPool pool,
        uint32_t count,
        VkCommandBuffer *buffers)
{
    VkCommandBufferAllocateInfo ai = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
        .commandPool = pool,
        .commandBufferCount = count,
    };

    return vkAllocateCommandBuffers(device,
            &ai, buffers);
}

VkResult 
onyx_reset_command_pool(VkDevice device, VkCommandPool pool, VkCommandPoolResetFlags flags)
{
    return vkResetCommandPool(device, pool, flags);
}
