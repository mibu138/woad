#ifndef V_UTIL_H
#define V_UTIL_H

#include "video.h"

void onyx_print_format_properties(const OnyxInstance* instance, VkFormat);

#endif /* end of include guard: V_UTILS_H */
