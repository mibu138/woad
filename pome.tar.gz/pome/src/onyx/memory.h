#ifndef ONYX_V_MEMORY_H
#define ONYX_V_MEMORY_H

#include "video.h"
#include <stdbool.h>

uint64_t onyx_size_of_memory(void);
OnyxMemory* onyx_alloc_memory(void);
void onyx_create_memory(const OnyxInstance* instance, const uint32_t hostGraphicsBufferMB,
                  const uint32_t deviceGraphicsBufferMB,
                  const uint32_t deviceGraphicsImageMB, const uint32_t hostTransferBufferMB,
                  const uint32_t deviceExternalGraphicsImageMB, OnyxMemory* memory);

OnyxBuffer onyx_request_buffer_region(OnyxMemory*, size_t size,
                                             const VkBufferUsageFlags,
                                             const OnyxMemoryType);

// Returns a buffer region with enough space for elemCount elements of elemSize size. 
// The stride member set to the size of the space between
// elements, which might be different from elemSize if physicalDevice requirements demand it.
OnyxBuffer
onyx_request_buffer_region_array(OnyxMemory* memory, uint32_t elemSize, uint32_t elemCount,
                              VkBufferUsageFlags flags,
                              OnyxMemoryType  memType);

OnyxBuffer onyx_request_buffer_region_aligned(OnyxMemory*, const size_t size,
                                                    uint32_t     alignment,
                                                    const OnyxMemoryType);

uint32_t onyx_get_memory_type(const OnyxMemory*, uint32_t                    typeBits,
                            const VkMemoryPropertyFlags properties);

OnyxImage onyx_create_image(OnyxMemory*, const uint32_t width, const uint32_t height,
                              const VkFormat           format,
                              const VkImageUsageFlags  usageFlags,
                              const VkImageAspectFlags aspectMask,
                              const VkSampleCountFlags sampleCount,
                              const uint32_t           mipLevels,
                              const OnyxMemoryType);

void onyx_copy_buffer_region(const OnyxBuffer* src,
                        OnyxBuffer*       dst);
void
onyx_cmd_copy_buffer(VkCommandBuffer cmd, const OnyxBuffer* src,
        OnyxBuffer* dst);

void onyx_copy_image_to_buffer_region(const OnyxImage*  image,
                                  OnyxBuffer* bufferRegion);

void onyx_transfer_to_device(OnyxMemory* memory, OnyxBuffer* pRegion);

void onyx_free_image(OnyxImage* image);

void onyx_free_buffer(OnyxBuffer* pRegion);

void onyx_destroy_memory(OnyxMemory* memory);

void onyx_memory_report_simple(const OnyxMemory* memory);

VkDeviceAddress onyx_get_buffer_region_address(const OnyxBuffer* region);

// application's job to destroy this buffer and free the memory
void onyx_create_unmanaged_buffer(OnyxMemory* memory, const VkBufferUsageFlags bufferUsageFlags,
                                const uint32_t           memorySize,
                                const OnyxMemoryType  type,
                                VkDeviceMemory* pMemory, VkBuffer* pBuffer);

VkDeviceMemory onyx_get_device_memory(const OnyxMemory* memory, const OnyxMemoryType memType);
VkDeviceSize   onyx_get_memory_size(const OnyxMemory* memory, const OnyxMemoryType memType);

const OnyxInstance* onyx_get_memory_instance(const OnyxMemory* memory);

void onyx_get_image_memory_usage(const OnyxMemory* memory, uint64_t* bytes_in_use, uint64_t* total_bytes);

#ifdef WIN32
bool onyx_get_external_memory_win32_handle(const OnyxMemory* memory, HANDLE* handle, uint64_t* size);
#else
bool onyx_get_external_memory_fd(const OnyxMemory* memory, int* fd, uint64_t* size);
#endif

void
onyx_resize_buffer_region(OnyxBuffer* region, size_t new_size);

#endif /* end of include guard: V_MEMORY_H */
