#include "harfbuzz.h"

#include <hb.h>
#include <assert.h>
#include <stdio.h>

typedef OnyxGlyph draw_data_t;

static OnyxGlyph glyph_create()
{
    return (OnyxGlyph){.point_count = 0};
}

static uint32_t glyph_add_point(OnyxGlyph* g, float x, float y)
{
    uint32_t idx = g->point_count++;
    CoalVec2 p;

    assert(idx < ONYX_GLYPH_MAX_POINTS);

    p.x = x;
    p.y = y;

    g->points[idx] = p;
    return idx;
}

static uint32_t glyph_add_linear_segment(OnyxGlyph* g, float to_x, float to_y)
{
    uint32_t last_point = g->point_count;
    uint32_t next_point = glyph_add_point(g, to_x, to_y);

    uint32_t i = g->linear_segment_count++;
    assert(i < ONYX_GLYPH_MAX_SEGMENTS);

    g->linear_segments[i][0] = last_point;
    g->linear_segments[i][1] = next_point;
    return i;
}

static void glyph_add_segment(OnyxGlyph* g, uint32_t type, uint32_t index)
{
    uint32_t i = g->segment_count++;
    assert(i < ONYX_GLYPH_MAX_SEGMENTS);

    g->glyph[i][0] = type;
    g->glyph[i][1] = index;
}

static void
move_to (hb_draw_funcs_t *dfuncs, draw_data_t *draw_data,
	 hb_draw_state_t *st,
	 float to_x, float to_y,
	 void *user_data)
{
    printf("move to\n");
    printf("to_x %f to_y %f\n", to_x, to_y);
    glyph_add_point(draw_data, to_x, to_y);
}

static void
line_to (hb_draw_funcs_t *dfuncs, draw_data_t *draw_data,
	 hb_draw_state_t *st,
	 float to_x, float to_y,
	 void *user_data)
{
    printf("line to\n");
    printf("to_x %f to_y %f\n", to_x, to_y);
    uint32_t elem = glyph_add_linear_segment(draw_data, to_x, to_y);
    glyph_add_segment(draw_data, 1, elem);
}

static void
quadratic_to (hb_draw_funcs_t *dfuncs, draw_data_t *draw_data,
	      hb_draw_state_t *st,
	      float control_x, float control_y,
	      float to_x, float to_y,
	      void *user_data)
{
    printf("quadratic to\n");
    printf("to_x %f to_y %f\n", to_x, to_y);
    printf("control_x %f control_y %f\n", control_x, control_y);
}

static void
cubic_to (hb_draw_funcs_t *dfuncs, draw_data_t *draw_data,
	  hb_draw_state_t *st,
	  float control1_x, float control1_y,
	  float control2_x, float control2_y,
	  float to_x, float to_y,
	  void *user_data)
{
    printf("cubic to\n");
    printf("to_x %f to_y %f\n", to_x, to_y);
    printf("control1_x %f control1_y %f\n", control1_x, control1_y);
    printf("control2_x %f control2_y %f\n", control2_x, control2_y);
}

static void
close_path (hb_draw_funcs_t *dfuncs, draw_data_t *draw_data,
	    hb_draw_state_t *st,
	    void *user_data)
{
    printf("close_path\n");
}

OnyxGlyph onyx_harf_buzz_test()
{
    const char *text = "F";
    hb_buffer_t *buf;

    buf = hb_buffer_create();
    hb_buffer_add_utf8(buf, text, -1, 0, -1);

    hb_buffer_set_direction(buf, HB_DIRECTION_LTR);
    hb_buffer_set_script(buf, HB_SCRIPT_LATIN);
    hb_buffer_set_language(buf, hb_language_from_string("en", -1));

    hb_blob_t *blob = hb_blob_create_from_file("/usr/share/fonts/OTF/Hermit-Regular.otf");
    hb_face_t *face = hb_face_create(blob, 0);
    hb_font_t *font = hb_font_create(face);
    assert(font);

    hb_shape(font, buf, NULL, 0);

    unsigned int glyph_count;
    hb_glyph_info_t *glyph_info    = hb_buffer_get_glyph_infos(buf, &glyph_count);
    hb_glyph_position_t *glyph_pos = hb_buffer_get_glyph_positions(buf, &glyph_count);
    hb_draw_funcs_t *funcs = hb_draw_funcs_create();
    hb_draw_funcs_set_move_to_func (funcs, (hb_draw_move_to_func_t) move_to, NULL, NULL);
    hb_draw_funcs_set_line_to_func (funcs, (hb_draw_line_to_func_t) line_to, NULL, NULL);
    hb_draw_funcs_set_quadratic_to_func (funcs, (hb_draw_quadratic_to_func_t) quadratic_to, NULL, NULL);
    hb_draw_funcs_set_cubic_to_func (funcs, (hb_draw_cubic_to_func_t) cubic_to, NULL, NULL);
    hb_draw_funcs_set_close_path_func (funcs, (hb_draw_close_path_func_t) close_path, NULL, NULL);
    hb_draw_funcs_make_immutable (funcs);


    OnyxGlyph glyph = glyph_create();
    hb_position_t cursor_x = 0;
    hb_position_t cursor_y = 0;
    for (unsigned int i = 0; i < glyph_count; i++) {
        hb_codepoint_t glyphid  = glyph_info[i].codepoint;
        hb_position_t x_offset  = glyph_pos[i].x_offset;
        hb_position_t y_offset  = glyph_pos[i].y_offset;
        hb_position_t x_advance = glyph_pos[i].x_advance;
        hb_position_t y_advance = glyph_pos[i].y_advance;
        printf("glyph: %d\n", glyphid);
        hb_font_draw_glyph(font, glyphid, funcs, &glyph);
     /* draw_glyph(glyphid, cursor_x + x_offset, cursor_y + y_offset); */
        cursor_x += x_advance;
        cursor_y += y_advance;
    }

    hb_draw_funcs_destroy(funcs);
    hb_buffer_destroy(buf);
    hb_font_destroy(font);
    hb_face_destroy(face);
    hb_blob_destroy(blob);

    return glyph;
}    
