#include <stdint.h>
#include <coal/types.h>

#define ONYX_GLYPH_MAX_POINTS 64
#define ONYX_GLYPH_MAX_SEGMENTS 32

typedef struct OnyxGlyph {
    uint32_t point_count;
    CoalVec2 points[ONYX_GLYPH_MAX_POINTS];
    // indices into the points array
    uint32_t linear_segment_count;
    uint32_t linear_segments[ONYX_GLYPH_MAX_SEGMENTS][2];
    uint32_t quadratic_segment_count;
    uint32_t quadratic_segments[ONYX_GLYPH_MAX_SEGMENTS][3];
    uint32_t cubic_segment_count;
    uint32_t cubic_segments[ONYX_GLYPH_MAX_SEGMENTS][4];
    // first element indicate which segment array is being referenced
    // 0 = maybe signals a close to the path?
    // 1 = linear
    // 2 = quadratic
    // 3 = cubic
    // second element is the index into that array
    uint32_t segment_count;
    uint32_t glyph[ONYX_GLYPH_MAX_SEGMENTS][2];
} OnyxGlyph;

OnyxGlyph onyx_harf_buzz_test();
