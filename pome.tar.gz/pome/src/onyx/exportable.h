#ifndef ONYX_EXPORTABLE_H
#define ONYX_EXPORTABLE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <vulkan/vulkan_core.h>
#include <stdint.h>
#include <stdbool.h>
#include "format.h"
#include "limits.h"

typedef struct onyx_instance OnyxInstance;
typedef struct onyx_memory OnyxMemory;
typedef struct HellEventQueue HellEventQueue;
typedef struct hell_window HellWindow;
typedef struct onyx OnyxContext;
typedef struct onyx_reflection OnyxReflection;
typedef struct OnyxGraph OnyxGraph;
typedef uint32_t onyx_flags;
typedef onyx_flags OnyxFlags;

typedef struct onyx {
    OnyxInstance* instance;
    OnyxMemory*   memory;
    VkDevice device;
} Onyx;
//
// 1 less than VkCompareOp... because 0 as none is a bad default
typedef enum OnyxCompareOp {
    ONYX_COMPARE_OP_LESS  = 0,
    ONYX_COMPARE_OP_EQUAL = 1,
    ONYX_COMPARE_OP_LESS_OR_EQUAL = 2,
    ONYX_COMPARE_OP_GREATER = 3,
    ONYX_COMPARE_OP_NOT_EQUAL = 4,
    ONYX_COMPARE_OP_GREATER_OR_EQUAL = 5,
    ONYX_COMPARE_OP_ALWAYS = 6,
} OnyxCompareOp;

typedef Onyx OnyxContext;

// TODO this is brittle. we should probably change V_MemoryType to a mask with
// flags for the different
// requirements. One bit for host or device, one bit for transfer capabale, one
// bit for external, one bit for image or buffer
typedef enum onyx_memory_type {
    ONYX_MEMORY_HOST_GRAPHICS_TYPE,
    ONYX_MEMORY_HOST_TRANSFER_TYPE,
    ONYX_MEMORY_DEVICE_TYPE,
    ONYX_MEMORY_EXTERNAL_DEVICE_TYPE
} OnyxMemoryType;

typedef struct onyx_buffer {
    uint64_t           size;
    uint64_t           offset;
    VkBuffer           buffer;
    void*              host_data; // if hostData not null, its mapped
    uint32_t           block_id;
    uint32_t           stride; // if bufferregion stores an array this is the stride between elements. otherwise its 0. if the elements need to satify an alignment this stride will satisfy that
    struct onyx_memory_pool* chain;
} OnyxBuffer;

typedef enum onyx_cull_mode_bits {
    ONYX_CULL_MODE_NONE = 0,
    ONYX_CULL_MODE_FRONT_BIT = 0x00000001,
    ONYX_CULL_MODE_BACK_BIT = 0x00000002,
    ONYX_CULL_MODE_FRONT_AND_BACK = 0x00000003,
} OnyxCullModeBits;
typedef OnyxFlags OnyxCullModeFlags;

typedef enum onyx_front_face_type {
    ONYX_FRONT_FACE_COUNTER_CLOCKWISE = 0,
    ONYX_FRONT_FACE_CLOCKWISE = 1,
} OnyxFrontFace;

typedef enum onyx_polygon_mode {
    ONYX_POLYGON_MODE_FILL = 0,
    ONYX_POLYGON_MODE_LINE = 1,
    ONYX_POLYGON_MODE_POINT = 2,
} OnyxPolygonMode;

typedef struct onyx_offset_2d {
    int32_t    x;
    int32_t    y;
} OnyxOffset2D;

typedef struct onyx_extent_2d {
    uint32_t    width;
    uint32_t    height;
} OnyxExtent2D;

typedef struct onyx_rect_2d {
    OnyxOffset2D offset;
    OnyxExtent2D extent;
} OnyxRect2D;

typedef struct onyx_viewport {
    float    x;
    float    y;
    float    width;
    float    height;
    float    min_depth;
    float    max_depth;
} OnyxViewport;

typedef struct onyx_memory_sizes {
    uint32_t host_graphics_buffer_mb;
    uint32_t device_graphics_buffer_mb;
    uint32_t device_graphics_image_mb;
    uint32_t host_transfer_buffer_mb;
    uint32_t device_external_graphics_image_mb;
} OnyxMemorySizes;

typedef enum onyx_dynamic_state {
    ONYX_DYNAMIC_STATE_VIEWPORT = 0,
    ONYX_DYNAMIC_STATE_SCISSOR = 1,
    ONYX_DYNAMIC_STATE_LINE_WIDTH = 2,
    ONYX_DYNAMIC_STATE_DEPTH_BIAS = 3,
    ONYX_DYNAMIC_STATE_BLEND_CONSTANTS = 4,
    ONYX_DYNAMIC_STATE_DEPTH_BOUNDS = 5,
    ONYX_DYNAMIC_STATE_STENCIL_COMPARE_MASK = 6,
    ONYX_DYNAMIC_STATE_STENCIL_WRITE_MASK = 7,
    ONYX_DYNAMIC_STATE_STENCIL_REFERENCE = 8,
    ONYX_DYNAMIC_STATE_CULL_MODE = 1000267000,
    ONYX_DYNAMIC_STATE_FRONT_FACE = 1000267001,
    ONYX_DYNAMIC_STATE_PRIMITIVE_TOPOLOGY = 1000267002,
    ONYX_DYNAMIC_STATE_VIEWPORT_WITH_COUNT = 1000267003,
    ONYX_DYNAMIC_STATE_SCISSOR_WITH_COUNT = 1000267004,
    ONYX_DYNAMIC_STATE_VERTEX_INPUT_BINDING_STRIDE = 1000267005,
    ONYX_DYNAMIC_STATE_DEPTH_TEST_ENABLE = 1000267006,
    ONYX_DYNAMIC_STATE_DEPTH_WRITE_ENABLE = 1000267007,
    ONYX_DYNAMIC_STATE_DEPTH_COMPARE_OP = 1000267008,
    ONYX_DYNAMIC_STATE_DEPTH_BOUNDS_TEST_ENABLE = 1000267009,
    ONYX_DYNAMIC_STATE_STENCIL_TEST_ENABLE = 1000267010,
    ONYX_DYNAMIC_STATE_STENCIL_OP = 1000267011,
    ONYX_DYNAMIC_STATE_RASTERIZER_DISCARD_ENABLE = 1000377001,
    ONYX_DYNAMIC_STATE_DEPTH_BIAS_ENABLE = 1000377002,
    ONYX_DYNAMIC_STATE_PRIMITIVE_RESTART_ENABLE = 1000377004,
} OnyxDynamicState;

typedef struct onyx_graphics_pipeline_settings {
    float line_width;
    OnyxCullModeFlags cull_mode;
    // 0 == counter clock wise
    OnyxFrontFace     front_face;
    OnyxPolygonMode   polygon_mode;
    OnyxViewport      viewport;
    OnyxRect2D        scissor;
    uint32_t        dynamic_state_count;
    OnyxDynamicState  dynamic_states[ONYX_MAX_DYNAMIC_STATES_PER_PIPELINE];
    bool              stencil_test_enable;
    bool              depth_test_enable;
    bool              depth_write_enable;
    bool              depth_bounds_test_enable;
    float             min_depth_bounds;
    float             max_depth_bounds;
    OnyxCompareOp     depth_compare_op;
    VkStencilOpState  front_stencil_state;
    VkStencilOpState  back_stencil_state;
} OnyxGraphicsPipelineSettings; 


typedef struct onyx_push_constant_callback {
    const void *user_data;
    // write to the pc_structure.
    void (*func)(void *target_data, int64_t user_id, int64_t object_id,
               const void *user_data);
} OnyxPushConstantCallback;

typedef struct onyx_push_constant_parms {
    int64_t user_id;
} OnyxPushConstantParms;

typedef struct onyx_image {
    VkImage            handle;
    VkImageView        view;
    // only will be used for depth / stencil images
    VkImageView        depth_only_view;
    VkImageView        stencil_only_view;
    VkSampler          sampler;
    VkImageAspectFlags aspect_mask;
    uint64_t       size; // size in bytes. taken from GetMemReqs
    uint64_t       offset;//TODO: delete this and see if its even necessary... should probably be a VkOffset3D object
    VkExtent3D         extent;
    VkImageLayout      last_known_layout;
    VkSampleCountFlags sample_count;
    VkImageUsageFlags  usage_flags;
    VkFormat         format;
    uint32_t           mip_levels;
    uint32_t           queue_family;
    uint32_t           block_id;
    struct onyx_memory_pool* chain;
} OnyxImage;

// zeroes it out
OnyxReflection* onyx_alloc_reflection(void);

// this function must is meant to be undefined until binary linking stage.
// its definition gets created by the reflection of the shaders, or a default
// empty function
// 
// commenting this out since we are using the inline defintition from the header
// void onyx_create_reflection(OnyxReflection* refl);

OnyxMemory* onyx_get_memory(OnyxContext* ctx);
OnyxInstance* onyx_get_instance(OnyxContext* ctx);

uint64_t onyx_size_of_instance(void);
OnyxInstance* onyx_alloc_instance(void);

uint64_t onyx_size_of_memory(void);
OnyxMemory* onyx_alloc_memory(void);

// allocates and initializes with sensible defaults
void onyx_create_instance_basic(OnyxInstance* instance);

void onyx_create_memory_basic(const OnyxInstance* instance, 
        OnyxMemorySizes sizes, OnyxMemory* memory);

OnyxGraph* onyx_alloc_graph(void);

void onyx_init_graph(OnyxContext *ctx, const OnyxReflection *reflection,
                     OnyxGraph *graph);

int32_t
onyx_graph_add_image_copy_task_(OnyxGraph *g, const char *name,
        const char *src, const char *dst);

int32_t
onyx_graph_add_compute_task_for_image(OnyxGraph *graph, const char *name,
        uint32_t program_number, const char *image_name);

void onyx_graph_add_push_constant_to_task_(OnyxGraph *g, int32_t tid,
                                          const char *name,
                                          uint64_t user_data_id,
                                          OnyxPushConstantCallback callback);

void onyx_graph_bake(OnyxGraph *g);

void onyx_graph_set_output_task(OnyxGraph *g, int32_t id);

bool onyx_graph_is_baked(OnyxGraph* g);

void onyx_graph_add_image(OnyxGraph *g, const char *name,
        uint32_t width, uint32_t height, OnyxFormat format);

int32_t onyx_graph_add_host_copy_task_(
        OnyxGraph* g, const char* name, const char* image_name, uint64_t size, const void* src);

OnyxImage onyx_create_image(OnyxMemory*, const uint32_t width, const uint32_t height,
                              const VkFormat           format,
                              const VkImageUsageFlags  usageFlags,
                              const VkImageAspectFlags aspectMask,
                              const VkSampleCountFlags sampleCount,
                              const uint32_t           mipLevels,
                              const OnyxMemoryType);

void onyx_free_image(OnyxImage* image);

#ifdef __cplusplus
}
#endif

#endif
