#include "howl.h"

int howl_create_context(HowlContext* ctx)
{
    return -1;
}
