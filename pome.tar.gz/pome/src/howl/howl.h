#ifndef HOWL_H
#define HOWL_H

typedef struct HowlContext {
} HowlContext;

int howl_create_context(HowlContext* ctx);

#endif /* ifndef HOWL_H */
