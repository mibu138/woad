#include "result.h"
#include <cstdio>

using namespace pome;

constexpr const char *Error::code_to_string(Error::Code code)
{
    switch (code) {
        case Code::generic_error:
            return "Generic error.";
        case Code::no_command_buffer_available:
            return "No command buffer available.";
    }
    return nullptr;
}

void Error::print() const { printf("Error: %s\n", code_to_string(this->code)); }
