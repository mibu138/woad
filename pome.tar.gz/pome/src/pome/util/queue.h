#ifndef POME_QUEUE_H
#define POME_QUEUE_H

#include "common.h"
#include "option.h"

namespace pome
{

template <typename T> struct Queue {
    void add(T item)
    {
        auto index         = (this->end++) % this->size;
        this->items[index] = item;
    }

    Option<T> next()
    {
        assert(this->start <= this->end);

        if (this->start == this->end)
            return nullopt;

        auto index = (this->start++) % this->size;
        return items[index];
    }

    static constexpr u64 size  = 32;
    u64                  start = 0;
    u64                  end   = 0;
    T                    items[size];
};

}; // namespace pome

#endif
