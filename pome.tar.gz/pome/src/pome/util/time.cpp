#include "time.h"
#include "assert.h"

#include <chrono>
#include <thread>

using namespace pome::time;

using os_clock = std::chrono::high_resolution_clock;
static_assert(
    std::is_same<os_clock::duration, std::chrono::nanoseconds>::value);

void Clock::start()
{
    auto tp          = os_clock::now().time_since_epoch();
    this->start_time = Nanoseconds(tp.count());
}

Nanoseconds Clock::time() const
{
    assert(this->start_time.valid());
    auto ns = Nanoseconds(os_clock::now().time_since_epoch().count());
    return ns - this->start_time;
}

void pome::time::sleep(Nanoseconds ns)
{
    std::this_thread::sleep_for(std::chrono::nanoseconds(ns.as_i64()));
}

void pome::time::sleep(double seconds) { ::sleep(Nanoseconds(seconds)); }
