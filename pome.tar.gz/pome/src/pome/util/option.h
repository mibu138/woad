#ifndef POME_OPTION_H
#define POME_OPTION_H

#include <optional>

namespace pome
{

template <typename T> using Option = std::optional<T>;

template <typename T, typename... Args>
inline Option<T> make_option(Args &&...args)
{
    return std::make_optional<T>(std::forward<Args>(args)...);
}

static constexpr inline std::nullopt_t nullopt = std::nullopt;

}; // namespace pome

#endif
