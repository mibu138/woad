#ifndef POME_UNIQUEPTR_H
#define POME_UNIQUEPTR_H

#include <memory>

namespace pome
{

template <typename T, typename Deleter = std::default_delete<T>>
using UniquePtr = std::unique_ptr<T, Deleter>;

template <typename T, typename... Args>
inline UniquePtr<T> make_unique(Args &&...args)
{
    return std::make_unique<T>(std::forward<Args>(args)...);
}

}; // namespace pome

#endif
