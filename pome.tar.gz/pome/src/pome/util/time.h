#ifndef POME_TIME_H
#define POME_TIME_H

#include "common.h"

namespace pome::time
{

struct Nanoseconds;

struct Seconds {
    explicit Seconds(Nanoseconds ns);

  private:
    i64 t = 0;
};

struct Nanoseconds {
    Nanoseconds() = default;
    explicit Nanoseconds(i64 tick) : t(tick) {}
    explicit Nanoseconds(double seconds) : t(seconds * 1'000'000'000.0) {}

    friend Nanoseconds operator-(Nanoseconds a, Nanoseconds b)
    {
        return Nanoseconds(a.t - b.t);
    }

    bool valid() const { return this->t != 0; }

    i64 as_i64() const { return this->t; }
    f64 as_f64() const { return static_cast<f64>(this->t); }
    f64 as_f64_seconds() const { return this->as_f64() / 1'000'000'000.0; }

  private:
    i64 t = 0;
};

struct Clock {
    void        start();
    Nanoseconds time() const;

  private:
    Nanoseconds start_time;
};

inline Seconds::Seconds(Nanoseconds ns) : t(ns.as_i64() / 1'000'000'000) {}

void sleep(Nanoseconds);
void sleep(double seconds);

}; // namespace pome::time

#endif
