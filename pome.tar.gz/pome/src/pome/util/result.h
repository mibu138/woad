#ifndef POME_RESULT_H
#define POME_RESULT_H

#include <assert.h>
#include <variant>

namespace pome
{

struct Error {
    enum class Code {
        generic_error,
        no_command_buffer_available,
    };

    explicit Error(Code c) : code(c) {}

    static constexpr const char *code_to_string(Code code);

    void print() const;

    Code        code;
    const char *msg = nullptr;
};

template <typename T> struct Result {
    Result(T t) : item(std::move(t)){};
    Result(Error t) : item(t){};

    static Result error(Error::Code code) { return Result<T>(Error(code)); }
    static Result success(T &&t) { return Result<T>(t); }

    std::variant<T, Error> item;

    bool ok() const { return std::holds_alternative<T>(this->item); }

    T &&unpack() &&
    {
        auto t = std::get_if<T>(&this->item);
        assert(t);
        return std::move(*t);
    }

    Error &&error() &&
    {
        auto t = std::get_if<Error>(&this->item);
        assert(t);
        return std::move(*t);
    }
};

using VoidResult = Result<std::monostate>;

}; // namespace pome

#endif
