#ifndef POME_SHARED_PTR_H
#define POME_SHARED_PTR_H

#include <memory>

template <typename T> using SharedPtr = std::shared_ptr<T>;

template <typename T, typename... Args>
inline SharedPtr<T> make_shared(Args &&...args)
{
    return std::make_shared<T>(std::forward<Args>(args)...);
}

#endif
