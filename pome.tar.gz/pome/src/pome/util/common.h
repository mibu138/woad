#ifndef POME_COMMON_H
#define POME_COMMON_H

#include <hell/debug.h>
#include <hell/numerictypes.h>

#endif
