#ifndef POME_NON_COPYABLE_H
#define POME_NON_COPYABLE_H

#define POME_NON_COPYABLE(S)                                                   \
    S(const S &)            = delete;                                          \
    S &operator=(const S &) = delete;

#endif
