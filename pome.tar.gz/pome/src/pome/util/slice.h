#ifndef POME_SLICE_H
#define POME_SLICE_H

#include "common.h"

namespace pome
{

template <typename T> struct Slice {
    u64 count;
    T  *elems;
};

}; // namespace pome

#endif
