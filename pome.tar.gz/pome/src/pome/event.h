#ifndef POME_EVENT_H
#define POME_EVENT_H

#include <hell/input.h>
#include <iterator>

#include "pome/util/noncopyable.h"
#include "util/option.h"

namespace pome
{

struct Window;

using ResizeEvent = HellResizeEventData;

struct MouseEvent {
    int16_t x;
    int16_t y;
    uint8_t button_code;
    bool    down;
};

struct KeyEvent {
    uint32_t key_code;
    bool     down;
};

struct Event {
    Event() = default;
    explicit Event(HellEvent ev) : event(ev){};

    HellEventType type() const { return event.type; }

    Option<ResizeEvent> resize_event() const;
    Option<MouseEvent>  mouse_event() const;
    Option<KeyEvent>    key_event() const;

    void print() const { hell_event_print(&this->event); }

  private:
    HellEvent event;
};

struct EventQueue {
    struct Iterator {
        using iterator_category = std::forward_iterator_tag;
        using difference_type   = i64;
        using value_type        = Event;
        using pointer           = const Event *;
        using reference         = const Event &;

        Iterator(const HellEventQueue &queue, int index)
            : queue(queue), index(index)
        {
            this->cur = Event(this->queue.queue[this->index]);
        };

        reference operator*() const { return this->cur; }

        pointer operator->() const { return &this->cur; }

        Iterator &operator++()
        {
            this->advance();
            return *this;
        }

        Iterator operator++(int)
        {
            Iterator tmp = *this;
            ++(*this);
            return tmp;
        }

        friend bool operator==(const Iterator &a, const Iterator &b)
        {
            return a.index == b.index;
        }

        friend bool operator!=(const Iterator &a, const Iterator &b)
        {
            return a.index != b.index;
        }

      private:
        void advance()
        {
            this->index = (this->index + 1) % MAX_QUEUE_EVENTS;
            this->cur   = Event(this->queue.queue[this->index]);
        }

        bool can_advance() { return this->index != queue.head; }

        const HellEventQueue &queue;
        int                   index;
        Event                 cur;
    };

    EventQueue();
    POME_NON_COPYABLE(EventQueue);

    EventQueue(EventQueue &&other) noexcept { *this = std::move(other); }

    EventQueue &operator=(EventQueue &&other) noexcept
    {
        this->queue = other.queue;
        return *this;
    }

    Iterator begin() const { return Iterator(this->queue, this->queue.tail); }
    Iterator end() const { return Iterator(this->queue, this->queue.head); }

    void clear() { queue.tail = queue.head; }

  private:
    friend Window;
    HellEventQueue queue;
};

}; // namespace pome

#endif
