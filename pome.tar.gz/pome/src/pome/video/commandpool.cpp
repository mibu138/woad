#include "commandpool.h"

#include <utility>

using namespace pome;
using namespace pome::video;

CommandBufferHandle::CommandBufferHandle(CommandPool *pool, u32 index)
    : index(index), pool(pool)
{
    pool->begin_recording(index);
}

CommandBufferHandle::~CommandBufferHandle()
{
    if (pool)
        pool->end_recording(index);
}

CommandPool::CommandPool(VulkanDeviceInterface vk, Queue queue,
                         u32 command_buffer_count)
    : cmd_buffer_count(command_buffer_count), device(vk.device), queue(queue)
{
    assert(command_buffer_count < MAX_CMD_BUFFERS);

    VkCommandPoolCreateInfo ci = {};
    ci.sType                   = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    ci.queueFamilyIndex        = this->queue.family_index();

    auto r = vkCreateCommandPool(this->device, &ci, nullptr, &this->pool);
    assert(r == VK_SUCCESS);

    VkCommandBufferAllocateInfo ai = {};
    ai.commandPool                 = this->pool;
    ai.commandBufferCount          = command_buffer_count;
    ai.level                       = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    ai.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;

    r = vkAllocateCommandBuffers(this->device, &ai, this->cmd_buffers);
    assert(r == VK_SUCCESS);

    for (int i = 0; i < command_buffer_count; ++i) {
        this->semaphores[i].emplace(device);
        this->buffer_states[i] = CommandBufferState::Initial;
    }
}

CommandPool::~CommandPool()
{
    vkDestroyCommandPool(this->device, this->pool, nullptr);
}

Result<CommandBufferHandle> CommandPool::acquire_cmd_buffer()
{
    for (int i = 0; i < this->cmd_buffer_count; ++i) {
        if (this->buffer_states[i] != CommandBufferState::Initial)
            continue;
        return Result<CommandBufferHandle>(CommandBufferHandle(this, i));
    }
    return Result<CommandBufferHandle>::error(
        Error::Code::no_command_buffer_available);
}

void CommandPool::begin_recording(u32 index)
{
    assert(this->buffer_states[index] == CommandBufferState::Initial);
    onyx_begin_command_buffer(this->cmd_buffers[index]);
    this->buffer_states[index] = CommandBufferState::Recording;
}

void CommandPool::end_recording(u32 index)
{
    assert(this->buffer_states[index] == CommandBufferState::Recording);
    onyx_end_command_buffer(this->cmd_buffers[index]);
    this->buffer_states[index] = CommandBufferState::Executable;
}

VoidResult CommandPool::submit_commands(Slice<Semaphore *> semaphores)
{
    return VoidResult::error(Error::Code::generic_error);
}

BinarySemaphore::BinarySemaphore(VkDevice dev)
    : Semaphore(dev), status(Status::initial)
{
    onyx_create_semaphore(dev, &this->semaphore);
}

Semaphore::~Semaphore()
{
    assert(this->device);
    onyx_destroy_semaphore(this->device, this->semaphore);
}

MonotonicSemaphore::MonotonicSemaphore(VkDevice dev) : Semaphore(dev)
{
    VkSemaphoreTypeCreateInfo ci = {};
    ci.sType                     = VK_STRUCTURE_TYPE_SEMAPHORE_TYPE_CREATE_INFO;
    ci.semaphoreType             = VK_SEMAPHORE_TYPE_TIMELINE;
    ci.initialValue              = this->value;

    VkSemaphoreCreateInfo c = {};
    c.sType                 = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
    c.pNext                 = &ci;

    auto r = vkCreateSemaphore(dev, &c, nullptr, &this->semaphore);
    assert(r == VK_SUCCESS);
}
