#ifndef POME_VIDEO_DEVICE_H
#define POME_VIDEO_DEVICE_H

#include <onyx/onyx.h>

#include "pome/util/noncopyable.h"
#include "pome/util/sharedptr.h"

namespace pome::video
{

struct VulkanDeviceInterface {
    VkDevice         device;
    VkInstance       instance;
    VkPhysicalDevice physical_device;
};

struct Device;

struct Queue {
    u32 family_index() const { return this->family; }

  private:
    friend Device;

    u32     family;
    VkQueue queue;
};

struct Device {
    using Handle = SharedPtr<Device>;
    POME_NON_COPYABLE(Device);

    // will attempt to choose good default setting
    static Handle create();
    static Handle create(OnyxSettings settings);

    VkDevice vkdevice() { return this->ctx.device; }

    VulkanDeviceInterface vulkan_interface() const;

    Queue graphics_queue() const;

  private:
    // a private key so users cannot construct this. must go through create
    // see
    // https://github.com/isocpp/CppCoreGuidelines/commit/1a88c5a5379dbdc4b9873fef3cdeb2405614fb12
    // for explanation
    struct Token {
    };

    Onyx ctx;

  public:
    // would like to make this private but cannot due to also wanting to use
    // make_shared, which needs these available. so we used a private class as a
    // key.
    ~Device();
    // this private struct Token means no one can construct this directly
    Device(Token){};
};

using DeviceHandle = Device::Handle;

}; // namespace pome::video

#endif
