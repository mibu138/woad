#ifndef POME_COMMAND_POOL_H
#define POME_COMMAND_POOL_H

#include "pome/util/option.h"
#include "pome/util/result.h"
#include "pome/util/sharedptr.h"
#include "pome/util/slice.h"
#include "videodevice.h"
#include <utility>

namespace pome::video
{

struct CommandPool;

struct Semaphore {
    virtual u64 wait_value() const   = 0;
    virtual u64 signal_value() const = 0;

    ~Semaphore();
    POME_NON_COPYABLE(Semaphore);

  protected:
    explicit Semaphore(VkDevice device) : device(device) {}

    VkDevice    device    = VK_NULL_HANDLE;
    VkSemaphore semaphore = VK_NULL_HANDLE;
};

struct BinarySemaphore final : public Semaphore {
    enum class Status {
        initial,
        submitted_for_signalling,
        submitted_for_waiting_on,
    };

    explicit BinarySemaphore(VkDevice);

    u64 wait_value() const override { return 0; }
    u64 signal_value() const override { return 0; }

    Status status;
};

struct MonotonicSemaphore final : public Semaphore {
    explicit MonotonicSemaphore(VkDevice);

    u64 wait_value() const override { return value; }
    u64 signal_value() const override { return value + 1; }

  private:
    u64 value = 0;
};

enum class CommandBufferState {
    Initial,
    Recording,
    RecordingRenderPass,
    Executable,
    Pending,
};

struct CommandBufferHandle {
    ~CommandBufferHandle();
    CommandBufferHandle(CommandBufferHandle &&rhs) noexcept
        : index(rhs.index), pool(rhs.pool)
    {
        rhs.pool = nullptr;
    }

    CommandBufferHandle &operator=(CommandBufferHandle &&rhs) noexcept
    {
        std::swap(*this, rhs);
        return *this;
    }

    POME_NON_COPYABLE(CommandBufferHandle);

  private:
    friend CommandPool;

    CommandBufferHandle(CommandPool *pool, u32 index);

    u32          index;
    CommandPool *pool = nullptr;
};

struct CommandPool {
    CommandPool(VulkanDeviceInterface, Queue, u32 command_buffer_count);
    ~CommandPool();
    POME_NON_COPYABLE(CommandPool);

    // command buffer will be in the recording state immediately
    // it will enter the executable state once it goes out of scope
    Result<CommandBufferHandle> acquire_cmd_buffer();

  private:
    friend CommandBufferHandle;
    static constexpr int MAX_CMD_BUFFERS = 6;

    void begin_recording(u32 index);
    void end_recording(u32 index);

    VoidResult submit_commands(Slice<Semaphore *> wait_semaphores);

    u32                        cmd_buffer_count = 0;
    VkDevice                   device;
    VkCommandPool              pool;
    VkCommandBuffer            cmd_buffers[MAX_CMD_BUFFERS]   = {};
    Option<MonotonicSemaphore> semaphores[MAX_CMD_BUFFERS]    = {};
    CommandBufferState         buffer_states[MAX_CMD_BUFFERS] = {};
    Queue                      queue;
};

}; // namespace pome::video

#endif
