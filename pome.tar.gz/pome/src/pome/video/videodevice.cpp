#include "videodevice.h"

#include <assert.h>

using namespace pome::video;

Device::Handle Device::create()
{
    OnyxMemorySizes m           = {};
    m.device_graphics_buffer_mb = 100;
    m.host_graphics_buffer_mb   = 100;
    m.device_graphics_image_mb  = 400;
    m.host_transfer_buffer_mb   = 50;

    OnyxSettings s            = {};
    s.ip.disable_present_wait = false;
    s.ip.disable_validation   = false;
    s.ip.enable_ray_tracing   = false;
    s.ip.surface_type         = OnyxSurfaceType::ONYX_SURFACE_TYPE_XCB;
    s.memory_sizes            = m;

    return Device::create(s);
}

Device::Handle Device::create(OnyxSettings settings)
{
    Token key;

    auto  device = make_shared<Device>(key);
    auto &ctx    = device->ctx;

    ctx.instance = new OnyxInstance;
    ctx.memory   = new OnyxMemory;

    onyx_create_instance(&settings.ip, ctx.instance);

    const auto &msizes = settings.memory_sizes;
    onyx_create_memory(ctx.instance, msizes.host_graphics_buffer_mb,
                       msizes.device_graphics_buffer_mb,
                       msizes.device_graphics_image_mb,
                       msizes.host_transfer_buffer_mb,
                       msizes.device_external_graphics_image_mb, ctx.memory);

    return device;
}

Device::~Device()
{
    auto &ctx = this->ctx;

    assert(ctx.instance);
    assert(ctx.memory);

    onyx_destroy_memory(ctx.memory);
    onyx_destroy_instance(ctx.instance);
    delete ctx.instance;
    delete ctx.memory;
}

VulkanDeviceInterface Device::vulkan_interface() const
{
    VulkanDeviceInterface v = {};
    v.device                = this->ctx.instance->device;
    v.instance              = this->ctx.instance->vkinstance;
    v.physical_device       = this->ctx.instance->physical_device;
    return v;
}

Queue Device::graphics_queue() const
{
    Queue q = {};
    q.family =
        onyx_queue_family_index(this->ctx.instance, ONYX_QUEUE_GRAPHICS_TYPE);
    q.queue = onyx_queue(this->ctx.instance, ONYX_QUEUE_GRAPHICS_TYPE, 0);
    return q;
}
