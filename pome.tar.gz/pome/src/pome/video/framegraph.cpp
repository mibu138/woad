#include <string.h>

#include "framegraph.h"
#include "pome/util/uniqueptr.h"

using namespace pome::video;

Graph::Graph(OnyxCreateReflectionFnPtr reflection_fn)
{
    this->reflection = make_unique<OnyxReflection>();
    reflection_fn(this->reflection.get());
    this->graph = make_unique<OnyxGraph>();
}
