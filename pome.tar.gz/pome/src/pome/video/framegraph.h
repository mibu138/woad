#ifndef POME_FRAMEGRAPH_H
#define POME_FRAMEGRAPH_H

#include "pome/util/uniqueptr.h"
#include <onyx/onyx.h>

namespace pome::video
{

struct Graph {
    explicit Graph(OnyxCreateReflectionFnPtr);

  private:
    UniquePtr<OnyxGraph>      graph;
    UniquePtr<OnyxReflection> reflection;
};

}; // namespace pome::video

#endif
