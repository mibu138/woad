#ifndef POME_WINDOW_H
#define POME_WINDOW_H

#include <hell/window.h>
#include <onyx/swapchain.h>

#include "event.h"
#include "util/common.h"
#include "util/noncopyable.h"
#include "video/videodevice.h"

namespace pome
{

struct Window {
    Window(video::VulkanDeviceInterface device, u16 width, u16 height);
    ~Window();
    POME_NON_COPYABLE(Window);

    Window(Window &&other) noexcept { *this = std::move(other); }

    Window &operator=(Window &&other) noexcept
    {
        this->window      = other.window;
        this->swapchain   = other.swapchain;
        this->event_queue = std::move(other.event_queue);
        return *this;
    }

    // must call this on each new frame so we can handle resizes and such
    void begin_frame();

    struct Image {
      private:
        friend Window;
        Image(OnyxSwapchainImage img) : acquired_image(img) {}

        OnyxSwapchainImage acquired_image;
    };

    Image acquire_image();

  private:
    HellWindow    window;
    EventQueue    event_queue;
    OnyxSwapchain swapchain;
};

}; // namespace pome

#endif
