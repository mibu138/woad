#include "event.h"
#include "util/common.h"

using namespace pome;

EventQueue::EventQueue() { hell_create_event_queue(&this->queue); }

Option<ResizeEvent> Event::resize_event() const
{
    if (this->event.type != HELL_EVENT_TYPE_RESIZE)
        return nullopt;
    return make_option<ResizeEvent>(this->event.data.win_data.data.resize_data);
}
