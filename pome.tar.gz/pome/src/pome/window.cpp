#include "window.h"

using namespace pome;

Window::Window(video::VulkanDeviceInterface vk, u16 w, u16 h)
{
    hell_create_window(w, h, nullptr, &this->window);
    onyx_create_swapchain(vk.instance, vk.device, vk.physical_device,
                          &this->window, VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT,
                          &this->swapchain);
}

Window::~Window() { onyx_destroy_swapchain(&this->swapchain); }

void Window::begin_frame()
{
    // reset the queue
    this->event_queue.clear();
    // fill the queue
    hell_drain_window_events(&this->event_queue.queue, &this->window);
    for (const auto &event : this->event_queue) {
        if (auto e = event.resize_event()) {
            onyx_swapchain_notify_window_resized(&this->swapchain, e->width,
                                                 e->height);
        }
    }
}

Window::Image Window::acquire_image()
{
    return Image(onyx_acquire_swapchain_image(&this->swapchain));
}
