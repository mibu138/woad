#ifndef POME_APPLICATION_H
#define POME_APPLICATION_H

#include "util/noncopyable.h"
#include "util/queue.h"
#include "util/time.h"
#include "video/commandpool.h"
#include "video/framegraph.h"
#include "video/videodevice.h"
#include "window.h"
#include <vector>

namespace pome
{

struct FrameData {
    u64 number;
};

enum FrameCode : int {
    CONTINUE = 0,
    EXIT     = 1,
};

using WindowId = i64;

struct Application;

struct System {
    typedef void (*VoidFunction)(void);

    struct Command {
        enum Type : int {
            open_window = 0,
        };

        struct Parameters {
            int i0, i1, i2, i3;
        };

        Type         type;
        VoidFunction completion_fn;
        Parameters   parameters;

        using ResultType_open_window = Result<WindowId>;
    };

    // we template the struct instead of the functions because we want
    // type checking on the completion function parameter, where the first
    // parameter type should always be the AppData type that the
    // application::run is invoked with
    template <typename AppData> struct CommandList {
        typedef void (*OpenWindowFn)(AppData *app_data,
                                     Command::ResultType_open_window);

        void open_window(u16 width, u16 height, OpenWindowFn on_complete)
        {
            Command cmd;
            cmd.type          = Command::Type::open_window;
            cmd.completion_fn = reinterpret_cast<VoidFunction>(on_complete);
            cmd.parameters.i0 = width;
            cmd.parameters.i1 = height;
            this->add_cmd(cmd);
        }

        CommandList() = default;
        ~CommandList() = default;
        POME_NON_COPYABLE(CommandList);

        void reset() { cmds.clear(); }

        std::vector<Command> cmds;

      private:
        void add_cmd(Command cmd) { cmds.push_back(cmd); }
    };

    template <typename AppData> struct CommandPool {
        CommandList<AppData> &new_list()
        {
            auto &list = lists[this->index];
            list.reset();

            this->index = (index + 1) % this->list_count;

            return list;
        }

        void enqueue(Queue<Command> &queue)
        {
            for (const auto &cmd : lists[0].cmds) {
                queue.add(cmd);
            }
        }

      private:
        static constexpr int list_count = 1;

        u8                   index = 0;
        CommandList<AppData> lists[list_count];
    };

    ~System() = default;

  private:
    friend Application;

    System();

    void new_frame();

    template <typename AppData>
    void execute_commands(AppData *app_data, pome::Queue<Command> &cmd_queue)
    {
        for (Option<Command> cmd; (cmd = cmd_queue.next());) {
            switch (cmd->type) {
                case Command::Type::open_window: {
                    auto res = execute_open_window(cmd->parameters);
                    auto fn  = reinterpret_cast<void (*)(
                        AppData *, Command::ResultType_open_window)>(
                        cmd->completion_fn);
                    fn(app_data, res);
                    break;
                }
            }
        }
    }

    Command::ResultType_open_window execute_open_window(Command::Parameters);

    // Result<CommandBufferHandle> acquire_cmd_buffer();

    std::vector<Window>      windows;
    time::Clock              clock;
    video::DeviceHandle vdev;
    // UniquePtr<CommandPool> cmd_pool;
};

struct Application {
    template <typename AppData>
    static void run(int (*frame_fn)(const FrameData &,
                                    System::CommandPool<AppData> &, AppData &))
    {
        System    system;
        AppData  *app_data;
        FrameData frame;

        // this could be large so allocate on the heap
        app_data = new AppData;

        frame.number = 0;

        Queue<System::Command>       cmd_queue;
        System::CommandPool<AppData> cmd_pool;

        for (;;) {
            int c = frame_fn(frame, cmd_pool, *app_data);
            if (c == EXIT)
                return;
            cmd_pool.enqueue(cmd_queue);
            system.execute_commands<AppData>(app_data, cmd_queue);
            frame.number++;
        }
    }
};

}; // namespace pome

#endif
