#include "application.h"

using namespace pome;

System::System()
{
    this->vdev = video::Device::create();
    // this->cmd_pool = make_unique<CommandPool>(this->vdev->vulkan_interface(),
    // this->vdev->graphics_queue(), 4);
}

Result<WindowId> System::execute_open_window(System::Command::Parameters parms)
{
    this->windows.emplace_back(this->vdev->vulkan_interface(), parms.i0,
                               parms.i1);
    return Result<WindowId>::success(this->windows.size() - 1);
}

// Result<CommandBufferHandle>
// System::acquire_cmd_buffer()
//{
//     return this->cmd_pool->acquire_cmd_buffer();
// }
