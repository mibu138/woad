#ifndef COAL_TYPES_H
#define COAL_TYPES_H

#ifdef COAL_64_BIT_REAL
typedef double real;
#else
typedef float real;
#endif

#define COAL_PI 3.1415926535897932384626433
#define COAL_TAU 2 * COAL_PI

#ifdef __cplusplus
#define COAL_VECTOR_OPERATORS(N) \
    CoalVec##N operator+(const CoalVec##N &v) const \
    { \
        CoalVec##N out; \
        for (int i = 0; i < N; ++i) \
            out.e[i] = this->e[i] + v.e[i]; \
        return out; \
    } \
 \
    CoalVec##N &operator+=(const CoalVec##N &v) \
    { \
        for (int i = 0; i < N; ++i) \
            this->e[i] += v.e[i]; \
        return *this; \
    } \
 \
    CoalVec##N &operator-=(const CoalVec##N &v) \
    { \
        for (int i = 0; i < N; ++i) \
            this->e[i] -= v.e[i]; \
        return *this; \
    } \
 \
    CoalVec##N operator-(const CoalVec##N &v) const \
    { \
        CoalVec##N out; \
        for (int i = 0; i < N; ++i) \
            out.e[i] = this->e[i] - v.e[i]; \
        return out; \
    } \
 \
    CoalVec##N operator*(const real s) const \
    { \
        CoalVec##N out; \
        for (int i = 0; i < N; ++i) \
            out.e[i] = this->e[i] * s; \
        return out; \
    }
#else
#define COAL_VECTOR_OPERATORS(N)
#endif

typedef union CoalVec2 {
    real e[2];
    struct {
        real x;
        real y;
    };
    struct {
        real width;
        real height;
    };
    COAL_VECTOR_OPERATORS(2)
#ifdef __cplusplus
    CoalVec2() = default;
    explicit constexpr CoalVec2(real x, real y)
        : x(x), y(y) {}
#endif
} CoalVec2;

typedef union CoalIvec2 {
    int e[2];
    struct {
        int x;
        int y;
    };
    struct {
        int width;
        int height;
    };
} CoalIvec2;

typedef union CoalIvec3 {
    int e[3];
    struct {
        int x;
        int y;
        int z;
    };
} CoalIvec3;

typedef union CoalVec3 {
    real e[3];
    struct {
        real x;
        real y;
        real z;
    };
    struct {
        real r;
        real g;
        real b;
    };
    COAL_VECTOR_OPERATORS(3)
#ifdef __cplusplus
    CoalVec3() = default;
    explicit constexpr CoalVec3(real x, real y, real z)
        : x(x), y(y), z(z) {}
#endif
} CoalVec3;

typedef union CoalVec4 {
    real e[4];
    struct {
        real x;
        real y;
        real z;
        real w;
    };
    struct {
        real r;
        real g;
        real b;
        real a;
    };
    struct {
        real offsetx;
        real offsety;
        real width;
        real height;
    };
    COAL_VECTOR_OPERATORS(4);
#ifdef __cplusplus
    CoalVec4() = default;
    explicit constexpr CoalVec4(real x, real y, real z, real w)
        : x(x), y(y), z(z), w(w) {}
#endif
} CoalVec4;

typedef union CoalMat2 {
    real e[2][2];
    struct {
        real x00;
        real x01;
        real x10;
        real x11;
    };
} CoalMat2;

typedef struct CoalMat3 {
    real e[3][3];
} CoalMat3;

typedef struct CoalMat3x4 {
    real e[3][4];
} CoalMat3x4;

typedef struct CoalMat4 {
    real e[4][4];
} CoalMat4;

typedef struct CoalRay {
    CoalVec2 orig;
    CoalVec2 dir;
} CoalRay;

typedef struct Segment {
    CoalVec2 A;
    CoalVec2 B;
} CoalSegment;

#ifdef COAL_SIMPLE_TYPE_NAMES
typedef CoalVec2    Vec2;
typedef CoalVec3    Vec3;
typedef CoalVec4    Vec4;
typedef CoalMat2    Mat2;
typedef CoalMat3    Mat3;
typedef CoalMat4    Mat4;
typedef CoalIvec2   Ivec2;
typedef CoalRay     Ray;
typedef CoalSegment Segment;
#ifdef PI
#error
#endif
#ifdef TAU
#error
#endif
#define PI COAL_PI
#define TAU COAL_TAU
#endif

#endif
