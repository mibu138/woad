#ifndef COAL_GENERICS_H
#define COAL_GENERICS_H

#include "linalg.h"
#include "types.h"

#define coal_notImplemented(...)                                               \
    do                                                                         \
    {                                                                          \
    } while (0)

#ifndef __cplusplus
#define coal_ident(a) _Generic((a), CoalMat2 : coal_ident_mat2)()

#define coal_add(a, b)                                                         \
    _Generic((a), CoalIvec2                                                   \
             : _Generic((b), CoalIvec2                                        \
                        : coal_add_ivec2, CoalVec2                            \
                        : coal_add_ivec2_vec2),                                 \
               CoalVec2                                                       \
             : _Generic((b), CoalVec2                                         \
                        : coal_add_vec2)),                                     \
        (a, b)

#define coal_mul(a, b)                                                         \
    _Generic((a), double                                                       \
             : _Generic((b), CoalVec2                                         \
                        : coal_scale_vec2, CoalIvec2                          \
                        : coal_scale_ivec2, CoalMat2                          \
                        : coal_scale_mat2),                                    \
               float                                                           \
             : _Generic((b), CoalVec2                                         \
                        : coal_scale_vec2, CoalIvec2                          \
                        : coal_scale_ivec2, CoalMat2                          \
                        : coal_scale_mat2),                                    \
               CoalMat2                                                       \
             : _Generic((b), CoalVec2                                         \
                        : coal_mult_mat2_vec2, CoalIvec2                       \
                        : coal_mult_mat2_vec2, CoalMat2                        \
                        : coal_mult_mat2))(a, b)

#define coal_rot(a, b)                                                         \
    _Generic((a), float                                                        \
             : _Generic((b), CoalMat2                                         \
                        : coal_rotate_mat2),                                   \
               double                                                          \
             : _Generic((b), CoalMat2                                         \
                        : coal_rotate_mat2))(a, b)

#define coal_floor(a) _Generic((a), CoalVec2 : coal_floor_vec2)(a)

#define coal_print(a) _Generic((a), CoalMat2 : coal_print_mat2)(a)
#else
#define coal_ident(a) coal_notImplemented()
#define coal_mul(a, b) coal_notImplemented()
#define coal_rot(a, b) coal_notImplemented()
#define coal_print(a) coal_notImplemented()
#endif

#ifdef COAL_SIMPLE_FUNC_NAMES
#define add coal_add
#define mul coal_mul
#define ident coal_ident
#define rot coal_rot
#define floor coal_floor
#endif

#endif
