#ifndef COAL_UTIL_H
#define COAL_UTIL_H

#include "types.h"

void coal_print_vec2(CoalVec2);
void coal_print_vec3(CoalVec3);
void coal_print_vec4(CoalVec4);
void coal_print_mat4(CoalMat4);
void coal_print_mat3(CoalMat3 m);
void coal_print_mat2(CoalMat2);
void coal_sprint_vec2(char* s, const CoalVec2 v);

#endif /* end of include guard: COAL_UTIL_H */

