#include "types.h"
#include <stdbool.h>

bool coal_ray_segment_intersect(CoalRay ray, CoalSegment segment);
bool coal_segment_intersect(CoalSegment seg1, CoalSegment seg2);
bool coal_point_in_circle(CoalVec2 point, CoalVec2 center, const real radius);
int  coal_triangle_intersect(CoalVec3 orig, CoalVec3 dir, CoalVec3 vert0,
                            CoalVec3 vert1, CoalVec3 vert2, real* t, real* u,
                            real* v);
bool coal_a_a_b_b_intersect(real x1, real y1, real w1, real h1, real x2, real y2, real w2, real h2);
bool coal_point_in_box(real x, real y, real bx, real by, real bw, real bh);

bool coal_square_segment_intersect(CoalSegment line,
                                   CoalVec2    lower_left_corner,
                                   real         side_length);
