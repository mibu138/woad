#ifndef COAL_LINALG_H
#define COAL_LINALG_H

#include "types.h"
#include <math.h>
#include <stdbool.h>

#define COAL_MAT4_IDENT                                                        \
    (CoalMat4) { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 }

static inline CoalMat2 coal_ident_mat2() { return (CoalMat2){1, 0, 0, 1}; }

// START FUNCDECLS
CoalMat4                coal_ident_mat4(void);
CoalMat4                coal_build_perspective(real nearDist, real farDist);
CoalVec3                coal_get_local_x_mat4(CoalMat4 m);
CoalVec3                coal_get_local_y_mat4(CoalMat4 m);
CoalVec3                coal_get_local_z_mat4(CoalMat4 m);
CoalVec3                coal_get_translation_mat4(CoalMat4 m);
CoalVec3                coal_add_vec3(CoalVec3 a, CoalVec3 b);
CoalVec3                coal_sub_vec3(CoalVec3 a, CoalVec3 b);
CoalVec3                coal_normalize_vec3(CoalVec3 v);
CoalVec4                coal_normalize_vec4(CoalVec4 v);
CoalVec3                coal_scale_vec3(real s, CoalVec3 v);
static inline CoalIvec2 coal_add_ivec2(CoalIvec2 a, CoalIvec2 b)
{
    CoalIvec2 o;
    o.x = a.x + b.x;
    o.y = a.y + b.y;
    return o;
}
static inline CoalVec2 coal_add_ivec2_vec2(CoalIvec2 a, CoalVec2 b)
{
    CoalVec2 o;
    o.x = a.x + b.x;
    o.y = a.y + b.y;
    return o;
}
static inline bool coal_equal_vec2(CoalVec2 a, CoalVec2 b)
{
    return (a.x == b.x && a.y == b.y);
}
static inline bool coal_equal_ivec2(CoalIvec2 a, CoalIvec2 b)
{
    return (a.x == b.x && a.y == b.y);
}
CoalVec3 coal_cross(CoalVec3 a, CoalVec3 b);
CoalMat4 coal_look_at(CoalVec3 pos, CoalVec3 target, CoalVec3 up);
void coal_look_at_inverse(const CoalMat4 m, real pivotDistance, CoalVec3 *pos,
                        CoalVec3 *target, CoalVec3 *up);
CoalMat2 coal_rotate_mat2(real a, CoalMat2 m);
CoalVec2 coal_rotate_vec2(real angle /* radians */, CoalVec2);
CoalMat4 coal_rotate_y_mat4(real angle, CoalMat4 m);
CoalMat4 coal_build_from_basis_mat4(const real x[3], const real y[3],
                                   const real z[3]);
CoalMat4 coal_build_rotate(real angle, CoalVec3 axis);
CoalVec3 coal_rotate_y_vec3(real angle, CoalVec3 v);
CoalMat4 coal_rotate_z_mat4(real angle, CoalMat4 m);
CoalVec2 coal_mult_mat2_vec2(CoalMat2 m, CoalVec2 v);

static inline CoalMat2 coal_mult_mat2(CoalMat2 a, CoalMat2 b)
{
    CoalMat2 out;
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++) {
            out.e[i][j] = 0;
            for (int k = 0; k < 2; k++)
                out.e[i][j] += a.e[i][k] * b.e[k][j];
        }
    return out;
}

static inline CoalIvec2 coal_floor_vec2(CoalVec2 a)
{
    CoalIvec2 i;
    i.x = floor(a.x);
    i.y = floor(a.y);
    return i;
}

CoalMat4 coal_mult_mat4(CoalMat4 a, CoalMat4 b);
CoalVec3 coal_mult_mat4_vec3(CoalMat4 m, CoalVec3 v);
CoalVec4 coal_mult_mat4_vec4(CoalMat4 m, CoalVec4 v);
CoalVec3 coal_mult_mat3_vec3(CoalMat3 m, CoalVec3 v);
CoalMat4 coal_translate_mat4(CoalVec3 t, CoalMat4 m);
CoalMat4 coal_transpose_mat4(CoalMat4 m);
CoalMat4 coal_scale_uniform_mat4(real s, CoalMat4 m);

static inline CoalVec2 coal_scale_ivec2(real s, CoalIvec2 v)
{
    CoalVec2 o;
    o.x = s * v.x;
    o.y = s * v.y;
    return o;
}

static inline CoalMat2 coal_scale_mat2(real s, CoalMat2 m)
{
    m.x00 *= s;
    m.x01 *= s;
    m.x10 *= s;
    m.x11 *= s;
    return m;
}

CoalMat4 coal_scale_non_uniform_mat4(CoalVec3 s, CoalMat4 m);
CoalVec2 coal_translate_vec2(CoalVec2 t, CoalVec2);
CoalVec2 coal_scale_vec2(real scale, CoalVec2);
CoalVec2 coal_add_vec2(CoalVec2, CoalVec2); // calls coal_add
real      coal_distance(CoalVec2 a, CoalVec2 b);
real      coal_dot(CoalVec3 a, CoalVec3 b);
// first - second
CoalVec2 coal_subtract(CoalVec2, CoalVec2);
CoalVec2 coal_sub_vec2(CoalVec2, CoalVec2); // calls coal_subtract
// returns a random real between 0 and 1
real      coal_rand(void);
// returns a random real between -1 and 1
real      coal_rand_neg(void);
real      coal_length_vec2(CoalVec2);
real      coal_length2_vec2(CoalVec2);
real      coal_determinant_mat2(CoalMat2);
CoalVec2 coal_polar_to_cart(real angle, real radius);
CoalMat3 coal_invert3x3(const CoalMat3 mat);
CoalMat4 coal_invert4x4(CoalMat4);
CoalVec3 coal_lerp_vec3(CoalVec3 a, CoalVec3 b, real t);
real      coal_rand(void);
real      coal_rand_range(real min, real max);
CoalVec3 coal_rand_vec3(real min, real max);
real      coal_segment_length(CoalSegment seg);
void      coal_get_samples_along_line_segment(CoalSegment seg, real rad,
                                              CoalVec2 *buf, int max_samples,
                                              int *sample_count);
// END FUNCDECLS

#ifdef COAL_SIMPLE_FUNC_NAMES
#define ident_Mat4() coal_ident_mat4()
#define buildPerspective(p0, p1) coal_build_perspective(p0, p1)
#define getLocalX_Mat4(p0) coal_get_local_x_mat4(p0)
#define getLocalY_Mat4(p0) coal_get_local_y_mat4(p0)
#define getLocalZ_Mat4(p0) coal_get_local_z_mat4(p0)
#define getTranslation_Mat4(p0) coal_get_translation_mat4(p0)
#define add_Vec3(p0, p1) coal_add_vec3(p0, p1)
#define sub_Vec3(p0, p1) coal_sub_vec3(p0, p1)
#define normalize_Vec3(p0) coal_normalize_vec3(p0)
#define normalize_Vec4(p0) coal_normalize_vec4(p0)
#define scale_Vec3(p0, p1) coal_scale_vec3(p0, p1)
#define cross(p0, p1) coal_cross(p0, p1)
#define lookAt(p0, p1, p2) coal_look_at(p0, p1, p2)
#define lookAtInverse(p0, p1, p2, p3, p4) coal_look_at_inverse(p0, p1, p2, p3, p4)
#define rotate_Vec2(p0, p1) coal_rotate_vec2(p0, p1)
#define rotateY_Mat4(p0, p1) coal_rotate_y_mat4(p0, p1)
#define buildFromBasis_Mat4(p0, p1, p2) coal_build_from_basis_mat4(p0, p1, p2)
#define buildRotate(p0, p1) coal_build_rotate(p0, p1)
#define rotateY_Vec3(p0, p1) coal_rotate_y_vec3(p0, p1)
#define rotateZ_Mat4(p0, p1) coal_rotate_z_mat4(p0, p1)
#define mult_Mat4(p0, p1) coal_mult_mat4(p0, p1)
#define mult_Mat4Vec3(p0, p1) coal_mult_mat4_vec3(p0, p1)
#define mult_Mat4Vec4(p0, p1) coal_mult_mat4_vec4(p0, p1)
#define translate_Mat4(p0, p1) coal_translate_mat4(p0, p1)
#define transpose_Mat4(p0) coal_transpose_mat4(p0)
#define scaleUniform_Mat4(p0, p1) coal_scale_uniform_mat4(p0, p1)
#define scaleNonUniform_Mat4(p0, p1) coal_scale_non_uniform_mat4(p0, p1)
#define translate_Vec2(p0, p1) coal_translate_vec2(p0, p1)
#define scale_Vec2(p0, p1) coal_scale_vec2(p0, p1)
#define add_Vec2(p0, p1) coal_add_vec2(p0, p1)
#define distance(p0, p1) coal_distance(p0, p1)
#define dot(p0, p1) coal_dot(p0, p1)
#define subtract(p0, p1) coal_subtract(p0, p1)
#define sub_Vec2(p0, p1) coal_sub_vec2(p0, p1)
#define rand() coal_rand()
#define randNeg() coal_rand_neg()
#define length_Vec2(p0) coal_length_vec2(p0)
#define length2_Vec2(p0) coal_length2_vec2(p0)
#define determinant(p0) coal_determinant_mat2(p0)
#define polarToCart(p0, p1) coal_polar_to_cart(p0, p1)
#define invert4x4(p0) coal_invert4x4(p0)
#define lerp_Vec3(p0, p1, p2) coal_lerp_vec3(p0, p1, p2)
#define rand() coal_rand()
#define randRange(p0, p1) coal_rand_range(p0, p1)
#define rand_Vec3(p0, p1) coal_rand_vec3(p0, p1)
#define ident_mat2() coal_ident_mat2()
#endif

#endif /* end of include guard: M_MATH_H */
