A general framework for creating graphical applications.

It is hobby project and serves primarily as a test bed for software architecture ideas I have.
