#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#define zero(t) memset(t, 0, sizeof(*t))
#define array_type(T, t) \
    typedef struct { \
        int nelem; \
        int cap; \
        T *elems; \
    } T##Array; \
    \
    static inline int t##_array_push(T##Array* ar, T elem) { \
        if (ar->nelem == ar->cap) { \
            if (ar->cap == 0) \
                ar->cap = 4; \
            else \
                ar->cap *= 2; \
            T* tmp = realloc(ar->elems, ar->cap * sizeof(T)); \
            if (!tmp) return -1; \
            ar->elems = tmp; \
        } \
        ar->elems[ar->nelem++] = elem; \
        return 0; \
    }

typedef struct {
    float diameter;
    float height;
    int type;
} Bucket;

typedef int Int;

array_type(Int, int);
array_type(Bucket, bucket);

int main(int argc, char *argv[])
{
    BucketArray buckets = {0};

    int er;
    Bucket b = {0.5, 1.0, 1};
    bucket_array_push(&buckets, b);
    for (int i = 0; i < 5; ++i) {
        b.diameter *= 1.1;
        b.height *= 1.01;
        er = bucket_array_push(&buckets, b);
        assert(!er);
    }

    const Bucket* bs = buckets.elems;
    for (int i = 0; i < buckets.nelem; ++i) {
        printf("Bucket %d: height %f width %f\n", i, bs[i].height, bs[i].diameter);
    }
    return 0;
}
