#include <pome/pome.h>
#include <reflection.h>

Pome p;
OnyxReflection reflection;
OnyxGraph graph;
CruxContext *crux;

typedef struct frame_data {
    OnyxCommandPool cmdpool;
    VkFence         cmds_cmplt_fence;
    VkSemaphore     img_acquired_sem;
    VkSemaphore     cmds_cmplt_sem;
    int             cur_cmd_buf;
} FrameData;

int fd_count = 0;
FrameData frame_data[4];

PC pc = {.c1 = {1, 0, 0, 1}, .c2 = {1, 0, 1, 1}, .freq = 1.0};

static void frame_data_init(Onyx *onyx, FrameData *fd)
{
    zero(fd);
    int er = onyx_command_pool_create(onyx, ONYX_QUEUE_GRAPHICS_TYPE, 3, &fd->cmdpool);
    assert(!er);
    onyx_create_fence(onyx->device, true, &fd->cmds_cmplt_fence);
    onyx_create_semaphore(onyx->device, &fd->img_acquired_sem);
    onyx_create_semaphore(onyx->device, &fd->cmds_cmplt_sem);
}

static VkCommandBuffer 
frame_data_pull_cmd_buf(struct frame_data *d)
{
    assert(d->cur_cmd_buf < d->cmdpool.cmdbuf_count);
    VkCommandBuffer cb = d->cmdpool.cmdbufs[d->cur_cmd_buf];
    d->cur_cmd_buf = (d->cur_cmd_buf + 1) % fd_count;
    return cb;
}

static void frame_data_reset(FrameData* data, VkDevice dev)
{
    onyx_wait_for_fence(dev, &data->cmds_cmplt_fence);
    vkResetCommandPool(dev, data->cmdpool.pool, 0);
}       

void menu(Crux* c)
{
    if (crux_begin_menu(c, "Ctrl")) {
        crux_slider(c, "freq", &pc.freq, 0.1, 100.0);
        crux_slider(c, "phase", &pc.phase, 0.1, 100.0);
        crux_color_picker_3(c, "c1", pc.c1.e);
        crux_color_picker_3(c, "c2", pc.c2.e);
        crux_end_menu(c);
    }
}

void app_frame(int64_t fi, int64_t dt)
{
    pome_handle_events(&p, NULL);
    pome_main_menu(&p, menu);
    pc.time += dt * 0.0000001;
}

void pc_fn(void* target_data, i64 id, i64 obj_id, const void* user_data)
{
    *(PC*)target_data = pc;
}

static void init_graph(OnyxGraph *g)
{
    onyx_init_graph(&p.onyx, &reflection, g);

    VkExtent2D ext = onyx_get_swapchain_extent(&p.swapchain);

    OnyxTaskId ct = onyx_graph_add_compute_task(g, "comp",
            (OnyxGraphComputeParms){
            .program = &reflection.programs[0],
            .wg_size_type = ONYX_COMPUTE_WORKGROUP_SIZE_TYPE_FROM_IMAGE,
            .wg_size.image_name = "img"
            });

    onyx_graph_add_descriptor_to_task(g,
            ct, "img", 0, 0, ONYX_RESOURCE_TYPE_IMAGE);

    OnyxTaskId copy = onyx_graph_add_copy_task(g,
            "copy", "img", ONYX_RESOURCE_TYPE_IMAGE,
            "out", ONYX_RESOURCE_TYPE_IMAGE);

    onyx_graph_add_image_to_task(g, ct, "img",
            (OnyxGraphResourceImageParms){
            .ref_type = ONYX_RESOURCE_REFERENCE_TYPE_STORAGE_IMAGE,
            .res_usage = ONYX_RESOURCE_USAGE_WRITE_BIT,
            .stages = VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT
            });

    onyx_graph_set_image_properties(
            g, "img", ONYX_IMAGE_COLOR_TYPE, ext.width, ext.height,
            VK_FORMAT_R8G8B8A8_UNORM, VK_SAMPLE_COUNT_1_BIT, true);

    onyx_graph_set_image_properties(
            g, "out", ONYX_IMAGE_COLOR_TYPE, ext.width, ext.height,
            (OnyxFormat)onyx_get_swapchain_format(&p.swapchain), VK_SAMPLE_COUNT_1_BIT, false);

    onyx_graph_add_push_constant_to_task(g, ct, "pc", 
            (OnyxPushConstantParms){.user_id = 0});

    onyx_graph_add_image_output(g, "out", VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL);
    onyx_graph_bake(g);
}

int main(int argc, char *argv[])
{
    PomeSettings ps = pome_standard_settings(800, 800);

    printf("Size of onyx graph: %ld\n", sizeof(graph));
    pome_init(ps, &p);
    onyx_create_reflection(&reflection);
    init_graph(&graph);

    crux = crux_allocate_context();
    crux_create_context(crux, &p.onyx, &p.swapchain);

    fd_count = p.swapchain.image_count;
    for (int i = 0; i < fd_count; ++i) {
        frame_data_init(&p.onyx, &frame_data[i]);
    }

    for (;;) {
        hell_begin_frame(&p.hell);

        const uint8_t cur = p.hell.frame_count % fd_count;
        FrameData* fd = &frame_data[cur];

        frame_data_reset(fd, p.onyx.device);

        const OnyxFrame *frame = onyx_acquire_swapchain_frame(&p.swapchain, 
                VK_NULL_HANDLE,
                fd->img_acquired_sem);

        if (frame->dirty) {
            onyx_term_graph(&graph);
            init_graph(&graph);
        }

        crux_new_frame(crux, frame, p.hell.frame_delta);
        
        // app code

        app_frame(p.hell.frame_count, p.hell.frame_delta);
        
        // rendering code

        VkCommandBuffer cb = frame_data_pull_cmd_buf(fd);

        onyx_begin_command_buffer(cb);

        OnyxPushConstantCallback pccb = {
            .func = pc_fn,
            .user_data = NULL,
        };
        OnyxGraphBinding bindings[2];
        bindings[0].name = "pc";
        bindings[0].src.pc = pccb;
        bindings[1].name = "out";
        bindings[1].src.img = &frame->aovs[0];

        onyx_graph_execute(&graph, cb, &(OnyxGraphExecuteArgs) {
                .binding_count = 2,
                .bindings = bindings,
                });

        crux_render(crux, cb);

        onyx_end_command_buffer(cb);

        VkPipelineStageFlags mask = VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT;
        VkSubmitInfo si = {
            .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
            .commandBufferCount = 1,
            .pCommandBuffers = &cb,
            .waitSemaphoreCount = 1,
            .pWaitSemaphores = &fd->img_acquired_sem,
            .signalSemaphoreCount = 1,
            .pSignalSemaphores = &fd->cmds_cmplt_sem,
            .pWaitDstStageMask = &mask,
        };

        onyx_queue_submit(onyx_get_graphics_queue(p.onyx.instance, 0), 1, &si, fd->cmds_cmplt_fence);

        onyx_present_frame(&p.swapchain, 1, &fd->cmds_cmplt_sem);
    }

    return 0;
}
