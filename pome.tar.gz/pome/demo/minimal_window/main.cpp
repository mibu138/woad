#include <pome/pome.h>
#include <unistd.h>

struct AppData {
    const char    *name = "Doomquake";
    pome::WindowId window_id;
};

int main(int argc, char **argv)
{
    auto frame_fn = [](const pome::FrameData              &fd,
                       pome::System::CommandPool<AppData> &sys_cmd_pool,
                       AppData                            &ad) -> int {
        auto &sys_cmd = sys_cmd_pool.new_list();

        if (fd.number == 0) {
            sys_cmd.open_window(
                500, 500, [](AppData *app, pome::Result<pome::WindowId> res) {
                    app->window_id = std::move(res).unpack();
                });
            return 0;
        }
        printf("Hello my name is %s number %lu. Window id: %lu \n", ad.name,
               fd.number, ad.window_id);
        sleep(1);
        if (fd.number > 4)
            return pome::EXIT;
        return 0;
    };

    pome::Application::run<AppData>(frame_fn);

    return 0;
}
