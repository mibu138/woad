#define CRUX_SIMPLE_NAMES
#include <pome/pome.h>
#include <hell/debug.h>
#include <onyx/dtags.h>

#define auto __auto_type

Pome  pome;
OnyxTaskId host_copy_tid;

struct pixel {
    union {
        struct {
            uint8_t r;
            uint8_t g;
            uint8_t b;
            uint8_t a;
        };
        uint8_t e[4];
    };
};

#define IMG_DIM 32
#define NUM_PIXELS IMG_DIM * IMG_DIM

struct pixel pixels[NUM_PIXELS];

uint8_t phase;

    // intentially overflow
void update_pixels(uint8_t phase)
{
    for (int i = 0; i < NUM_PIXELS; ++i) {
        for (int j = 0; j < 4; ++j) {
            pixels[i].e[j] = (phase + i) * j;
        }
    }
}

void frame(i64 fn, i64 dt)
{
    update_pixels(phase++);

    OnyxGraphHostCopy copy = {
        .size = sizeof(pixels),
        .src = (const void*)pixels,
        .task_id = host_copy_tid
    };

    pome_render(&pome, &(OnyxGraphExecuteArgs){
            .host_copy_count = 1,
            .host_copies = &copy
            });
}

void app_init()
{
    update_pixels(phase);
}

int main()
{
    PomeSettings ps = pome_standard_settings(800, 800);

    pome_init(ps, &pome);

    OnyxGraph *g = &pome.graph;

    host_copy_tid =
        onyx_graph_add_host_copy_task(g, "hostcopy",
                                      (OnyxGraphHostCopyParms){
                                          .res_name = "img",
                                          .res_type = ONYX_RESOURCE_TYPE_IMAGE,
                                          .size = sizeof(pixels),
                                      });

    onyx_graph_add_image(g, "img", IMG_DIM, IMG_DIM, ONYX_FORMAT_R8G8B8A8_UNORM);

    onyx_graph_add_image_copy_task(g, "image_copy", "img", "out");
    pome_graph_bake(&pome, "out");

    hell_add_filter_tag(ONYX_DEBUG_TAG_IMG);
    hell_add_filter_tag(ONYX_DEBUG_TAG_SWAP);

    app_init();
    pome_run(&pome, frame);

    return 0;
}
