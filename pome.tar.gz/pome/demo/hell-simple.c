#include "hell/common.h"

HellContext* hellmouth;

void frame(i64 fi, i64 dt)
{
    int evcount;
    const HellEvent* events = hell_get_events(hellmouth, &evcount);
    hell_print("Event count %d\n", evcount);
    if (fi > 400)
        hell_close_and_exit(hellmouth);
}

int hellmain(void)
{
    HellGrimoire*   grimoire   = hell_malloc(hell_size_of_grimoire());
    HellConsole*    console    = hell_malloc(hell_size_of_console());
    HellEventQueue* eventQueue = hell_malloc(hell_size_of_event_queue());
    HellWindow*     window     = hell_malloc(hell_size_of_window());
    hellmouth  = hell_malloc(hell_size_of_hellmouth());
    hell_create_event_queue(eventQueue);
    hell_create_grimoire(eventQueue, grimoire);
    hell_create_console(console);
    hell_create_window(eventQueue, 500, 500, NULL, window);
    hell_create_hellmouth(grimoire, eventQueue, console, 1, &window, frame, NULL, hellmouth);

    for (;;) {
        hell_begin_frame(hellmouth);
        frame(hellmouth->frame_count, hellmouth->frame_delta);
        hell_end_frame(hellmouth);
    }

    return 0;
}

#ifdef WIN32
int APIENTRY WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance,
    _In_ PSTR lpCmdLine, _In_ int nCmdShow)
{
    hell_set_hinstance(hInstance);
    hellmain();
    return 0;
}
#elif UNIX
int main(int argc, char* argv[])
{
    hellmain();
}
#endif
