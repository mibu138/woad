#define CRUX_SIMPLE_NAMES
#include <pome/pome.h>
#include <reflection.h>

Pome  pome;

OnyxGeometry         points;

PC pc = {.width = 1.0, .domain = 3.14, .freq = 0.01};

void menu(Crux* c)
{
    if (crux_begin_menu(c, "Ctrls")) {
        crux_drag(c, "width", 0.001, &pc.width);
        crux_drag(c, "domain", 0.01, &pc.domain);
        crux_drag(c, "shift", 0.01, &pc.shift);
        crux_drag(c, "freq", 0.01, &pc.freq);
        crux_end_menu(c);
    }
}

void frame(int64_t fi, int64_t dt)
{
    pome_handle_events(&pome, NULL);
    pome_main_menu(&pome, menu);
    pc.time += dt * 0.000001;
}

void cb(void *target, i64 u, i64 o, void* d)
{
    *(PC*)target = pc;
}

int main()
{
    PomeSettings ps = pome_standard_settings(800, 800);
    pome_init(ps, &pome);

    OnyxGraph* graph = &pome.graph;

    const int point_count = 1000000;
    pc.count = point_count;

    points = onyx_create_points(pome.onyx.memory, ONYX_MEMORY_HOST_GRAPHICS_TYPE, point_count,
            1, &(uint8_t){8}, &(uint8_t){ONYX_ATTRIBUTE_TYPE_POS});

    {
        OnyxGraph *g = graph;
        OnyxGraphicsPipelineSettings ps = {
            .polygon_mode = VK_POLYGON_MODE_POINT,
            .dynamic_state_count = 2,
            .dynamic_states = {VK_DYNAMIC_STATE_VIEWPORT,
                VK_DYNAMIC_STATE_SCISSOR}
        };
        OnyxTaskId rp =onyx_graph_add_rasterization_task(g, "rp1", (OnyxGraphRasterizationParms){
                .program = &pome.reflection.programs[0],
                .pipeline_settings = &ps});
        onyx_graph_add_geometry_to_task(g, rp, "points");
        onyx_graph_add_push_constant_to_task(g, rp, "pc", (OnyxPushConstantParms){
                .user_id= 0});
        onyx_graph_bind_geometry(g, "points", &points);
        onyx_graph_bind_push_constant(g, "pc", (OnyxPushConstantCallback){.fn = cb});
        onyx_graph_add_color_attachment_output_task(g, rp, "out",
                (OnyxResourceAttachmentParms)
                {.ref = {
                .load_op = ONYX_ATTACHMENT_LOAD_OP_CLEAR,
                .store = true,
                .type = ONYX_ATTACHMENT_COLOR_TYPE,
                .clear_val.color.float32 = {0.11, 0.1, 0.1, 1.0},
                .color = (OnyxColorAttachmentReference){
                    .shader_location = 0,
                    .blend_enabled = false,
                }
                }});
        pome_graph_bake(&pome, "out");
    }

    pome_run(&pome, frame);
    return 0;
}
