#include "onyx/onyx.h"

static const char* vertex_shader_code =
    "layout(location = 0) in vec2 pos;"
    "layout(location = 1) in vec2 uv;"
    "layout(set = 0, binding = 0) uniform Buf {"
    "   mat3 view;\n"
    "} buf;"
    "void main()"
    "{"
    "   gl_Position = vec4(pos.x, pos.y, 0.0, 1.0);"
    "}"
    "";

static const char* fragment_shader_code =
    "struct Sample {\n"
    "   vec2 mpos;\n"
    "   vec2 padding;\n"
    "};\n"
    "layout (set = 0, binding = 0, r8) uniform image2D storage_image;\n"
    "layout (set = 0, binding = 1) uniform Buf {\n"
    "   Sample samples[8];\n"
    "} ub;"   
    "layout (push_constant) uniform Constants {\n"
    "   float radius;\n"
    "   int   sample_count;\n"
    "   vec2  uv_offset;\n"
    "   vec2  xy_offset;\n"
    "   uint  clear;\n"
    "   uint  padding;\n"
    "} pc;\n"
    "layout(location = 0) out vec4 out_color;"
    "void main()"
    "{"
    "   out_color = vec4(0.8, 0.4, 0, 1);\n"
    "}"
    "";

int main(int argc, char *argv[])
{
    OnyxSpirvCompileInfo ci = {
        .entry_point = "main",
        .name = "vert_shader",
        .shader_string = vertex_shader_code,
        .shader_type = ONYX_SHADER_TYPE_VERTEX
    };
    onyx_reflect_glsl(&ci);
    return 0;
}
