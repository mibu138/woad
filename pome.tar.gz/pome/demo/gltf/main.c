#include <hell/hell.h>
#include <hell/io.h>
#include <stdlib.h>

char strbuf[1000];

const char *box_glb_path = "/assets/Box/glTF-Binary/Box.glb";
const char *test= "/assets/test.glb";

int main()
{
    const char *root = getenv("S");
    if (!root)
        hell_error_fatal("S env var not set!");

    const size_t l = strlen(root);
    memcpy(strbuf, root, l);
    memcpy(strbuf + l, box_glb_path, strlen(box_glb_path));
    printf("%s\n", strbuf);

    int err;
    HellTriangleMesh mesh;
    err = hell_gltf_load(strbuf, &mesh);

    if (err) {
        hell_error_fatal("%d", err);
    }

    memcpy(strbuf + l, test, strlen(test) + 1);
    printf("%s\n", strbuf);
    err = hell_gltf_load(strbuf, &mesh);
    if (err) {
        hell_error_fatal("%d", err);
    }
}
