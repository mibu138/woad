#include "hell/hell.h"

bool mouseEventHandler1(const HellEvent* event, void* data)
{
    hell_print("fn1 :: x: %d y: %d\n", hell_get_mouse_x(event), hell_get_mouse_y(event));
    return true;
}

bool mouseEventHandler2(const HellEvent* event, void* data)
{
    hell_print("fn2 :: x: %d y: %d\n", hell_get_mouse_x(event), hell_get_mouse_y(event));
    return true;
}

HellWindow* window1;
HellWindow* window2;

static void userFrame(i64 fn, i64 dt)
{
    hell_print("window1 :: w: %d h: %d\n", hell_get_window_width(window1), hell_get_window_height(window1));
    hell_print("window2 :: w: %d h: %d\n", hell_get_window_width(window2), hell_get_window_height(window2));
}

int hellmain(void)
{
    window1   = hell_alloc_window();
    window2   = hell_alloc_window();
    HellConsole*    console   = hell_alloc_console();
    HellEventQueue* queue     = hell_alloc_event_queue();
    HellGrimoire*   grimoire  = hell_alloc_grimoire();
    HellContext*  hellmouth = hell_alloc_hellmouth();
    hell_create_console(console);
    hell_create_event_queue(queue);
    hell_create_grimoire(queue, grimoire);
    hell_create_window(queue, 666, 666, 0, window1);
    hell_create_window(queue, 400, 700, 0, window2);
    HellWindow* windows[2] = {window1, window2};
    hell_create_hellmouth(grimoire, queue, console, 2, windows, userFrame, NULL, hellmouth);

    hell_subscribe(queue, HELL_EVENT_MASK_POINTER_BIT | HELL_EVENT_MASK_WINDOW_BIT, 1, mouseEventHandler1, NULL);
    hell_subscribe(queue, HELL_EVENT_MASK_POINTER_BIT | HELL_EVENT_MASK_WINDOW_BIT, 2, mouseEventHandler2, NULL);

    for (;;) {
        hell_begin_frame(hellmouth);
        userFrame(hellmouth->frame_count, hellmouth->frame_delta);
        hell_end_frame(hellmouth);
    }
    return 0;
}

#ifdef WIN32
int APIENTRY WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance,
    _In_ PSTR lpCmdLine, _In_ int nCmdShow)
{
    hell_set_hinstance(hInstance);
    hellmain();
    return 0;
}
#elif UNIX
int main(int argc, char* argv[])
{
    hellmain();
}
#endif
