#include "onyx/onyx.h"
#include <coal/coal.h>
#include <hell/cmd.h>
#include <hell/common.h>
#include <hell/debug.h>
#include <hell/len.h>
#include <hell/window.h>

#define WIREFRAME 0

static HellEventQueue* eventQueue;
static HellGrimoire*   grimoire;
static HellMouth*  hellmouth;
static HellConsole*    console;
static HellWindow*     window;

static OnyxGeometry triangle;

static VkFramebuffer    framebuffer;
static VkRenderPass     renderPass;
static VkPipelineLayout pipelineLayout;
static VkPipeline       pipeline;
static VkFramebuffer    framebuffers[2];
static OnyxImage       depthImage;

static VkFence      drawFence;
static VkSemaphore  acquireSemaphore;
static VkSemaphore  drawSemaphore;
static OnyxCommand drawCommands[2];

static OnyxInstance*  oInstance;
static OnyxMemory*    oMemory;
static OnyxSwapchain* swapchain;
static VkDevice        device;

static const VkFormat depthFormat = VK_FORMAT_D24_UNORM_S8_UINT;

static const char* vertex_shader_code =
    "layout(location = 0) in vec2 pos;"
    "void main()"
    "{"
    "   gl_Position = vec4(pos.x, pos.y, 0.0, 1.0);"
    "}"
    "";

static const char* fragment_shader_code =
    "layout(location = 0) out vec4 out_color;"
    "void main()"
    "{"
    "   out_color = vec4(0.8, 0.4, 0, 1);\n"
    "}"
    "";

static void
createSurfaceDependent(void)
{
    VkExtent2D dim = onyx_get_swapchain_extent(swapchain);
    depthImage     = onyx_create_image(
            oMemory, dim.width, dim.height, depthFormat,
            VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT, VK_IMAGE_ASPECT_DEPTH_BIT,
            VK_SAMPLE_COUNT_1_BIT, 1, ONYX_MEMORY_DEVICE_TYPE);
    VkImageView attachments_0[2] = {onyx_get_swapchain_image_view(swapchain, 0),
                                    depthImage.view};
    VkImageView attachments_1[2] = {onyx_get_swapchain_image_view(swapchain, 1),
                                    depthImage.view};
    onyx_create_framebuffer(device, 2, attachments_0, dim.width, dim.height,
                           renderPass, &framebuffers[0]);
    onyx_create_framebuffer(device, 2, attachments_1, dim.width, dim.height,
                           renderPass, &framebuffers[1]);
}

static void
destroySurfaceDependent(void)
{
    onyx_free_image(&depthImage);
    onyx_destroy_framebuffer(device, framebuffers[0]);
    onyx_destroy_framebuffer(device, framebuffers[1]);
}

static void
onSwapchainRecreate(void)
{
    destroySurfaceDependent();
    createSurfaceDependent();
}

void
initApp(void)
{
    OnyxCreateGeometryInfo gi = {
        .attr_count = 1,
        .attr_sizes = (uint8_t[]){12},
        .attr_types = (uint8_t[]){ONYX_ATTRIBUTE_TYPE_POS},
        .vertex_count = 3,
        .index_count = 4,
        .memory = oMemory,
        .type = ONYX_GEOMETRY_TYPE_TRIANGLES,
        .memtype = ONYX_MEMORY_HOST_GRAPHICS_TYPE
    };
    triangle         = onyx_create_geometry(&gi);
    CoalVec3* verts = (CoalVec3*)triangle.vertex_buffer_region.host_data;
    verts[0].x       = 0.0;
    verts[0].y       = -1.0;
    verts[0].z       = 0.0;
    verts[1].x       = -1.0;
    verts[1].y       = 1.0;
    verts[1].z       = 0.0;
    verts[2].x       = 1.0;
    verts[2].y       = 1.0;
    verts[2].z       = 0.0;
    OnyxAttrIndex* indices = (OnyxAttrIndex*)triangle.index_buffer_region.host_data;
    indices[0]              = 0;
    indices[1]              = 1;
    indices[2]              = 2;
    indices[3] =
        0; // this last index is so we render the full triangle in line mode

    onyx_print_geo(&triangle);

    // call this render pass joe
    onyx_create_render_pass_color_depth(
        device, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
        VK_IMAGE_LAYOUT_UNDEFINED,
        VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
        VK_ATTACHMENT_LOAD_OP_CLEAR, VK_ATTACHMENT_STORE_OP_STORE,
        VK_ATTACHMENT_LOAD_OP_CLEAR, VK_ATTACHMENT_STORE_OP_DONT_CARE,
        onyx_get_swapchain_format(swapchain), depthFormat, &renderPass);
    OnyxPipelineLayoutInfo pli = {0}; // nothin
    onyx_create_pipeline_layouts(device, 1, &pli, &pipelineLayout);
    
    VkShaderModule vertsm, fragsm;

    onyx_create_shader_module(device, vertex_shader_code, "vert", ONYX_SHADER_TYPE_VERTEX, &vertsm);
    onyx_create_shader_module(device, fragment_shader_code, "frag", ONYX_SHADER_TYPE_FRAGMENT, &fragsm);

    OnyxGraphicsPipelineInfo pi = {
        .attachment_count = 1,
        .attachment_blends = &(OnyxPipelineColorBlendAttachment)
        {
            .blend_enable = true,
            .blend_mode = ONYX_BLEND_MODE_OVER
        },
        .cull_mode = VK_CULL_MODE_NONE,
        .depth_test_enable = false,
        .depth_write_enable = false,
        .dynamic_state_count = 2,
        .dynamic_states = (VkDynamicState[2]){VK_DYNAMIC_STATE_VIEWPORT,
            VK_DYNAMIC_STATE_SCISSOR},
        .front_face = VK_FRONT_FACE_COUNTER_CLOCKWISE,
        .layout = pipelineLayout,
        .polygon_mode = VK_POLYGON_MODE_FILL,
        .rasterization_samples = VK_SAMPLE_COUNT_1_BIT,
        .render_pass = renderPass,
        .shader_stage_count = 2,
        .shader_stages = (OnyxPipelineShaderStageInfo[2]){
            (OnyxPipelineShaderStageInfo){
                .module = vertsm,
                .entry_point = "main",
                .stage = VK_SHADER_STAGE_VERTEX_BIT
            },(OnyxPipelineShaderStageInfo){
                .module = fragsm,
                .entry_point = "main",
                .stage = VK_SHADER_STAGE_FRAGMENT_BIT
            }
        },
        .subpass = 0,
        .topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
        .vertex_attribute_description_count = 1,
        .vertex_attribute_descriptions = &(VkVertexInputAttributeDescription){
            .binding = 0,
            .format = VK_FORMAT_R32G32B32_SFLOAT,
            .location = 0,
            .offset = 0,
        },
        .vertex_binding_description_count = 1,
        .vertex_binding_descriptions = &(VkVertexInputBindingDescription){
            .binding = 0,
            .inputRate = VK_VERTEX_INPUT_RATE_VERTEX,
            .stride = 12
        },
    };

    onyx_create_graphics_pipeline(device, &pi, NULL, &pipeline);

    createSurfaceDependent();
    onyx_create_fence(device, false, &drawFence);
    onyx_create_semaphore(device, &drawSemaphore);
    onyx_create_semaphore(device, &acquireSemaphore);
    drawCommands[0] = onyx_create_command(oInstance, ONYX_V_QUEUE_GRAPHICS_TYPE);
    drawCommands[1] = onyx_create_command(oInstance, ONYX_V_QUEUE_GRAPHICS_TYPE);
}

#define TARGET_RENDER_INTERVAL 10000 // render every 30 ms

void
draw(i64 fi, i64 dt)
{
    static HellTick timeOfLastRender    = 0;
    static HellTick timeSinceLastRender = TARGET_RENDER_INTERVAL;
    static uint64_t  frameCounter        = 0;
    timeSinceLastRender                  = hell_time() - timeOfLastRender;
    if (timeSinceLastRender < TARGET_RENDER_INTERVAL)
        return;
    timeOfLastRender    = hell_time();
    timeSinceLastRender = 0;

    const OnyxFrame* fb = onyx_acquire_swapchain_frame(swapchain, VK_NULL_HANDLE,
                                                      acquireSemaphore);

    if (fb->dirty)
        onSwapchainRecreate();

    OnyxCommand cmd = drawCommands[frameCounter % 2];

    onyx_reset_command(&cmd);

    onyx_begin_command_buffer(cmd.buffer);

    const VkExtent2D dim = onyx_get_swapchain_extent(swapchain);
    onyx_cmd_set_viewport_scissor_full(cmd.buffer, dim.width, dim.height);

    onyx_cmd_begin_render_pass_color_depth(cmd.buffer, renderPass,
                                       framebuffers[fb->index], dim.width,
                                       dim.height, 0.0, 0.0, 0.01, 1.0);

    vkCmdBindPipeline(cmd.buffer, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline);
    onyx_draw_geo(cmd.buffer, &triangle);

    onyx_cmd_end_render_pass(cmd.buffer);

    onyx_end_command_buffer(cmd.buffer);

    onyx_submit_graphics_command(
        oInstance, 0, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, 1,
        &acquireSemaphore, 1, &drawSemaphore, drawFence, cmd.buffer);

    bool result = onyx_present_frame(swapchain, 1, &drawSemaphore);

    onyx_wait_for_fence(device, &drawFence);

    frameCounter++;
}

int
hellmain()
{
    eventQueue = hell_alloc_event_queue();
    grimoire   = hell_alloc_grimoire();
    console    = hell_alloc_console();
    window     = hell_alloc_window();
    hellmouth  = hell_alloc_hellmouth();
    hell_create_console(console);
    hell_create_event_queue(eventQueue);
    hell_create_grimoire(eventQueue, grimoire);
    hell_create_window(eventQueue, 666, 666, 0, window);
    hell_create_hellmouth(grimoire, eventQueue, console, 1, &window, draw, NULL,
                         hellmouth);
    hell_set_var(grimoire, "maxFps", 1000.0, 0);
    hell_print("Starting hello triangle.\n");

    oInstance             = onyx_alloc_instance();
    oMemory               = onyx_alloc_memory();
    swapchain             = onyx_alloc_swapchain();
    OnyxAovInfo depthAov = {
        .aspectFlags = VK_IMAGE_ASPECT_DEPTH_BIT,
        .usageFlags  = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT,
        .format      = depthFormat,
    };
#if UNIX
    const char* instanceExtensions[] = {VK_KHR_SURFACE_EXTENSION_NAME,
                                        VK_KHR_XCB_SURFACE_EXTENSION_NAME};
#elif WIN32
    const char* instanceExtensions[] = {VK_KHR_SURFACE_EXTENSION_NAME,
                                        VK_KHR_WIN32_SURFACE_EXTENSION_NAME};
#endif
    OnyxInstanceParms ip = {
        .enabled_instance_extension_count = LEN(instanceExtensions),
        .pp_enabled_instance_extension_names = instanceExtensions,
    };
#if WIN32
    onyx_set_runtime_spv_prefix("C:/dev/onyx/build/shaders/");
#endif
    onyx_create_instance(&ip, oInstance);
    onyx_create_memory(oInstance, 100, 100, 100, 0, 0, oMemory);
    onyx_create_swapchain(oInstance, oMemory, eventQueue, window,
                         VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT, 1, &depthAov,
                         swapchain);
    device = onyx_get_device(oInstance);
    initApp();

    for (;;) {
        hell_begin_frame(hellmouth);
        draw(hellmouth->frame_count, hellmouth->frame_delta);
        hell_end_frame(hellmouth);
    }
    return 0;
}

#ifdef WIN32
int APIENTRY
WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance,
        _In_ PSTR lpCmdLine, _In_ int nCmdShow)
{
    hell_set_hinstance(hInstance);
    hellmain();
    return 0;
}
#elif UNIX
int
main(int argc, char* argv[])
{
    hellmain();
}
#endif
