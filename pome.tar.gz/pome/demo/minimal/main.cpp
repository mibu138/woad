#include <pome/pome.h>
#include <unistd.h>

struct AppData {
    const char *name = "goblin";
};

int main()
{
    auto frame_fn = [](const pome::FrameData &fd, pome::System::CommandPool<AppData> &system, AppData &ad) -> int {
        printf("Hello my name is %s number %lu \n", ad.name, fd.number);
        sleep(1);
        if (fd.number > 4)
            return pome::EXIT;
        return 0;
    };

    pome::Application::run<AppData>(frame_fn);

    return 0;
}
