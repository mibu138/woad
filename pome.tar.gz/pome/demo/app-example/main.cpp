#define CRUX_SIMPLE_NAMES
#include <pome/pome.h>
#include <reflection.h>

Pome  pome;

OnyxGeometry         points;
OnyxReflection       reflection;

bool image_loaded = false;

Ubo ubo = {
    CoalVec4(0.7, 0.5, 0.3, 1.0),
    CoalVec4(0.2, 0.5, 0.8, 1.0),
    CoalVec4(0.4, 0.2, 0.5, 1.0),
    CoalVec4(0.9, 0.5, 0.1, 1.0),
};

PC pc[2];

float speed1 = 1.0;
float speed2 = 1.0;

void update_menu(Crux* crux)
{
    if (begin_menu(crux, "Controls")) {
        crux_text("Cube 1");
        crux_color_picker_4(crux, "Color11", ubo.col[0].e);
        crux_color_picker_4(crux, "Color12", ubo.col[1].e);
        crux_slider(crux, "Speed1", &speed1, -5.0, 5.0);
        crux_slider(crux, "X1", &pc[0].rot_x, -3.14, 3.14);
        crux_slider(crux, "Y1", &pc[0].rot_y, -3.14, 3.14);
        crux_slider(crux, "T1", &pc[0].t_x, -1, 1);
        crux_text("Cube 2");
        crux_color_picker_4(crux, "Color21", ubo.col[2].e);
        crux_color_picker_4(crux, "Color22", ubo.col[3].e);
        crux_slider(crux, "Speed2", &speed2,  -5.0, 5.0);
        crux_slider(crux, "X2", &pc[1].rot_x, -3.14, 3.14);
        crux_slider(crux, "Y2", &pc[1].rot_y, -3.14, 3.14);
        crux_slider(crux, "T2", &pc[1].t_x, -1, 1);
        end_menu(crux);
    }
}

void frame(int64_t fi, int64_t dt)
{
    pome_handle_events(&pome, NULL);
    pome_main_menu(&pome, update_menu);

    pc[0].rot_z += speed1 * 0.01;
    pc[1].rot_z -= speed2 *  0.01;
}

static void
pc_cb(void* target, i64 user_id, i64 obj, void* data)
{
    *(PC*)target = pc[user_id];
}

int main()
{
    PomeSettings ps = pome_standard_settings(800, 800);
    pome_init(ps, &pome);
    onyx_create_reflection(&reflection);

    OnyxGraph* graph = pome_init_frame_graph(&pome, &reflection);

    points = onyx_create_cube(pome.onyx.memory, false);

    {
        OnyxGraph *g = graph;

        OnyxGraphicsPipelineSettings ps = {};
        ps.polygon_mode = ONYX_POLYGON_MODE_FILL;
        ps.cull_mode = ONYX_CULL_MODE_BACK_BIT;
        ps.line_width = 4.0;
        ps.dynamic_state_count = 2;
        ps.front_face = ONYX_FRONT_FACE_COUNTER_CLOCKWISE;
        ps.dynamic_states[0] = ONYX_DYNAMIC_STATE_VIEWPORT;
        ps.dynamic_states[1] = ONYX_DYNAMIC_STATE_SCISSOR;

        OnyxTaskId rp = onyx_graph_add_simple_vert_simple_frag_task(g,
                "rp1", "ubo", &ps, (CoalVec4){0.1, 0.2, 0.3, 1.0},
                "box");
        OnyxTaskId rp2 = onyx_graph_add_simple_vert_simple_frag_task(g,
                "rp2", "ubo", &ps, (CoalVec4){0.1, 0.2, 0.3, 1.0},
                "box");
        onyx_graph_bind_geometry(g, "box", &points);
        onyx_graph_bind_uniform_buffer(g, "ubo", sizeof(ubo), &ubo, true);
        onyx_graph_add_push_constant_to_task(g, rp, "pc", (OnyxPushConstantParms)
                {.user_id = 0});
        onyx_graph_add_push_constant_to_task(g, rp2, "pc", (OnyxPushConstantParms)
                {.user_id = 1});
        onyx_graph_bind_push_constant(g, "pc", (OnyxPushConstantCallback)
                {.fn = pc_cb});
        onyx_graph_add_color_attachment_output_task(g, rp, "out",
                (OnyxResourceAttachmentParms)
                {.ref = {
                .load_op = ONYX_ATTACHMENT_LOAD_OP_CLEAR,
                .store = true,
                .type = ONYX_ATTACHMENT_COLOR_TYPE,
                .clear_val.color.float32 = {0.11, 0.1, 0.1, 1.0},
                .color = (OnyxColorAttachmentReference){
                    .shader_location = 0,
                    .blend_enabled = false,
                }
                }});
        onyx_graph_add_depth_attachment_to_task(g, rp, "depth",
                (OnyxResourceAttachmentParms)
                {.ref = {
                .load_op = ONYX_ATTACHMENT_LOAD_OP_CLEAR,
                .type = ONYX_ATTACHMENT_DEPTH_TYPE,
                .clear_val.depthStencil.depth = 1.0,
                .store = true}});
        onyx_graph_add_color_attachment_output_task(g, rp2, "out",
                (OnyxResourceAttachmentParms)
                {.ref = {
                .load_op = ONYX_ATTACHMENT_LOAD_OP_LOAD,
                .type = ONYX_ATTACHMENT_COLOR_TYPE,
                .color = (OnyxColorAttachmentReference){
                    .shader_location = 0,
                    .blend_enabled = true,
                    .blend_mode = ONYX_BLEND_MODE_OVER,
                },
                .store = true}});
        onyx_graph_add_depth_attachment_to_task(g, rp2, "depth",
                (OnyxResourceAttachmentParms)
                {.ref = {
                .load_op = ONYX_ATTACHMENT_LOAD_OP_LOAD,
                .type = ONYX_ATTACHMENT_DEPTH_TYPE,
                .clear_val.depthStencil.depth = 1.0,
                .store = false}});
        onyx_graph_add_task_dependency(g, rp2, rp);
        pome_graph_bake(&pome, "out");
    }

    pome_run(&pome, frame);
    return 0;
}
