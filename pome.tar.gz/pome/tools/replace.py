import fileinput
import re
import os

modules = ('onyx', 'coal', 'hell', 'crux', 'pome')

def camel_to_snake(name):
    return re.sub(r'(?<!^)(?=[A-Z])', '_', name).lower()
    name = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', name).lower()

files = []
for m in modules:
    dirs = (
        f"include/{m}/",
        f"src/{m}/",
        f"example/",
        f"test/")
    for d in dirs:
        files += [d + f for f in os.listdir(d) if f.endswith('.c') or f.endswith('.h') or f.endswith('.cpp')]

print(files)

for file in files:
    for line in fileinput.input(file, True):
        for name in modules:
            cap_name = name.capitalize()
            if cap_name + '_' in line:
                line = line.replace(cap_name + '_', cap_name)
            func_names = re.findall(r"{}_\w+".format(name), line)
            for orig_name in func_names:
                ending = orig_name.lstrip(name + "_")
                if ending[0].islower():
                    continue
                new_ending = camel_to_snake(ending)
                new_func_name = name + "_" + new_ending
                new_func_name = new_func_name.replace('__', '_')
                line = line.replace(orig_name, new_func_name)
        print(line, end='')
