#include <hell/hell.h>
#include <hell/len.h>
#include <onyx/onyx.h>

static OnyxInstance*  oInstance;
static OnyxMemory*    oMemory;

int main(int argc, char *argv[])
{
    oInstance = onyx_alloc_instance();
    oMemory   = onyx_alloc_memory();
    #if UNIX
    const char* instanceExtensions[] = {
        VK_KHR_SURFACE_EXTENSION_NAME,
        VK_KHR_XCB_SURFACE_EXTENSION_NAME
    };
    #elif WIN32
    const char* instanceExtensions[] = {
        VK_KHR_SURFACE_EXTENSION_NAME,
        VK_KHR_WIN32_SURFACE_EXTENSION_NAME
    };
    #endif
    OnyxInstanceParms ip = {
        .enabled_instance_extension_count = LEN(instanceExtensions),
        .pp_enabled_instance_extension_names = instanceExtensions,
    };
    onyx_create_instance(&ip, oInstance);
    hell_print("Memory time\n");
    hell_d_print("Debug says hello\n");
    onyx_create_memory(oInstance, 100, 100, 100, 0, 0, oMemory);
    return 0;
}
