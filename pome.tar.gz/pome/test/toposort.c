#include <hell/graph.h>
#include <stdio.h>

HellGraph graph;

const int correct[] = {3, 2, 0, 1};

int main(int argc, char *argv[])
{
    HellGraph* g = &graph;
    hell_create_graph(4, g);
    hell_graph_add_input_to_vertex(g, 0, 3);
    hell_graph_add_input_to_vertex(g, 1, 2);
    hell_graph_add_input_to_vertex(g, 2, 3);
    hell_graph_add_input_to_vertex(g, 1, 0);
    IntArray sorted = hell_graph_topological_sort(g, 1, (HellGraphSortingParms){0});
    for (int i = 0; i < sorted.count; ++i) {
        if (sorted.elems[i] != correct[i]) 
            return 1;
        //printf("%d%s", sorted.elems[i], i == sorted.count - 1 ? "\n" : ", ");
    }
    return 0;
}
